package genpact.pmr.start.dto;

public class RevenueChartDto {

	private Double v1;
	private Double v2;
	private Double v3;
	private Double v4;
	private Double v5;
	private Double v6;
	private Double v7;
	String type =null;
	
	public RevenueChartDto() {
		super();
	}

	public RevenueChartDto(Double v1, Double v2, Double v3, Double v4, Double v5, Double v6, Double v7) {
		super();
		this.v1 = v1;
		this.v2 = v2;
		this.v3 = v3;
		this.v4 = v4;
		this.v5 = v5;
		this.v6 = v6;
		this.v7 = v7;
	}

	public Double getV1() {
		return v1;
	}

	public void setV1(Double v1) {
		this.v1 = v1;
	}

	public Double getV2() {
		return v2;
	}

	public void setV2(Double v2) {
		this.v2 = v2;
	}

	public Double getV3() {
		return v3;
	}

	public void setV3(Double v3) {
		this.v3 = v3;
	}

	public Double getV4() {
		return v4;
	}

	public void setV4(Double v4) {
		this.v4 = v4;
	}

	public Double getV5() {
		return v5;
	}

	public void setV5(Double v5) {
		this.v5 = v5;
	}

	public Double getV6() {
		return v6;
	}

	public void setV6(Double v6) {
		this.v6 = v6;
	}

	public Double getV7() {
		return v7;
	}

	public void setV7(Double v7) {
		this.v7 = v7;
	}


}
