package genpact.pmr.start.dto;

public class ManufacturingTableDTO {
	private TableManufacturing tableManufacturing;
	
	

	public TableManufacturing getTableManufacturing() {
		return tableManufacturing;
	}


	public void setTableManufacturing(TableManufacturing tableManufacturing) {
		this.tableManufacturing = tableManufacturing;
	}


	public ManufacturingTableDTO(TableManufacturing tableManufacturing) {
		super();
		this.tableManufacturing = tableManufacturing;
	}



}