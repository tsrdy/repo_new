package genpact.pmr.start.dto;

import java.util.List;
import java.util.Map;

public class TradingJSONDataDto {
	private List<FormatDataDto> formatDataDtos;
	private List<TradingTableDataDto> tradingTableDataDtos;
	private List<TradingChartDto> tradingChartDtos; //for actual plan date
	private Map<String, Double> milestoneChart;
	private List<String> categories;
	private List<Double> data;
	
	
	
	
	
	public List<String> getCategories() {
		return categories;
	}

	public void setCategories(List<String> categories) {
		this.categories = categories;
	}

	public List<Double> getData() {
		return data;
	}

	public void setData(List<Double> data) {
		this.data = data;
	}

	private int indexOfTodayDate;
	
	
	
	public List<TradingChartDto> getTradingChartDtos() {
		return tradingChartDtos;
	}

	public void setTradingChartDtos(List<TradingChartDto> tradingChartDtos) {
		this.tradingChartDtos = tradingChartDtos;
	}

	public int getIndexOfTodayDate() {
		return indexOfTodayDate;
	}

	public void setIndexOfTodayDate(int indexOfTodayDate) {
		this.indexOfTodayDate = indexOfTodayDate;
	}

	public Map<String, Double> getMilestoneChart() {
		return milestoneChart;
	}

	public void setMilestoneChart(Map<String, Double> milestoneChart) {
		this.milestoneChart = milestoneChart;
	}

	public TradingJSONDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TradingJSONDataDto(List<FormatDataDto> formatDataDtos, List<TradingTableDataDto> tradingTableDataDtos,
			String documentCurrency) {
		super();
		this.formatDataDtos = formatDataDtos;
		this.tradingTableDataDtos = tradingTableDataDtos;
		DocumentCurrency = documentCurrency;
	}

	public List<TradingTableDataDto> getTradingTableDataDtos() {
		return tradingTableDataDtos;
	}

	public void setTradingTableDataDtos(List<TradingTableDataDto> tradingTableDataDtos) {
		this.tradingTableDataDtos = tradingTableDataDtos;
	}

	public String getDocumentCurrency() {
		return DocumentCurrency;
	}

	public void setDocumentCurrency(String documentCurrency) {
		DocumentCurrency = documentCurrency;
	}

	String DocumentCurrency = "USD";

	public List<FormatDataDto> getFormatDataDtos() {
		return formatDataDtos;
	}

	public void setFormatDataDtos(List<FormatDataDto> formatDataDtos) {
		this.formatDataDtos = formatDataDtos;
	}

}
