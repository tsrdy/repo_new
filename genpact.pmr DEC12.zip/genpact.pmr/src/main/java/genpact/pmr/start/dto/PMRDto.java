package genpact.pmr.start.dto;

public class PMRDto{


		private String cbl;
		private String actuals;
		private String etc;
				
		public String getAllowance() {
			return allowance;
		}

		public void setAllowance(String allowance) {
			this.allowance = allowance;
		}

		public String getCal() {
			return Cal;
		}

		public void setCal(String cal) {
			Cal = cal;
		}

		public String getMat_Service() {
			return Mat_Service;
		}

		public void setMat_Service(String mat_Service) {
			Mat_Service = mat_Service;
		}

		public String getMisc() {
			return Misc;
		}

		public void setMisc(String misc) {
			Misc = misc;
		}

		public String getPrice() {
			return Price;
		}

		public void setPrice(String price) {
			Price = price;
		}

		public String getStaff_cost() {
			return Staff_cost;
		}

		public void setStaff_cost(String staff_cost) {
			Staff_cost = staff_cost;
		}

		public String getTaxes() {
			return Taxes;
		}

		public void setTaxes(String taxes) {
			Taxes = taxes;
		}

		public String getGroup_() {
			return group_;
		}

		public void setGroup_(String group_) {
			this.group_ = group_;
		}

		public PMRDto(String cbl, String actuals, String etc, String eac, String previous_eac, String cost_code,
				String allowance, String cal, String mat_Service, String misc, String price, String staff_cost,
				String taxes, String group_) {
			super();
			this.cbl = cbl;
			this.actuals = actuals;
			this.etc = etc;
			this.eac = eac;
			this.previous_eac = previous_eac;
			this.cost_code = cost_code;
			this.allowance = allowance;
			this.Cal = cal;
			this.Mat_Service = mat_Service;
			this.Misc = misc;
			this.Price = price;
			this.Staff_cost = staff_cost;
			this.Taxes = taxes;
			this.group_ = group_;
		}

		private String eac;
		private String previous_eac;
		private String cost_code;
		private String allowance;
		private String Cal;
		private String Mat_Service;
		private String Misc;
		private String Price;
		private String Staff_cost;
		private String Taxes;
		private String group_;
		private String type;
	//	private String eac;
		
		public PMRDto(){
		}

		public PMRDto(String cbl, String actuals, String etc, String eac, String previous_eac, String cost_code) {
			super();
			this.cbl = cbl;
			this.actuals = actuals;
			this.etc = etc;
			this.eac = eac;
			this.previous_eac = previous_eac;
			this.cost_code = cost_code;
			
		}
		public PMRDto(String cbl, String actuals, String etc, String eac, String previous_eac, String cost_code, String type) {
			super();
			this.cbl = cbl;
			this.actuals = actuals;
			this.etc = etc;
			this.eac = eac;
			this.previous_eac = previous_eac;
			this.cost_code = cost_code;
			this.type = type;
			
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getCbl() {
			return cbl;
		}

		public void setCbl(String cbl) {
			this.cbl = cbl;
		}

		public String getActuals() {
			return actuals;
		}

		public void setActuals(String actuals) {
			this.actuals = actuals;
		}

		public String getEtc() {
			return etc;
		}

		public void setEtc(String etc) {
			this.etc = etc;
		}

		public String getEac() {
			return eac;
		}

		public void setEac(String eac) {
			this.eac = eac;
		}

		public String getPrevious_eac() {
			return previous_eac;
		}

		public void setPrevious_eac(String previous_eac) {
			this.previous_eac = previous_eac;
		}

		public String getCost_code() {
			return cost_code;
		}

		public void setCost_code(String cost_code) {
			this.cost_code = cost_code;
		}
		
		
		

}
