package genpact.pmr.start.dto;

public class TableDataDto {

	TotalRevenueCalcDto totalRevenueCalcDto;
	TotalCostCalcDto totalCostCalcDto;
	TotalMarginCalcDto totalMarginCalcDto;
	
	
	public TableDataDto(TotalRevenueCalcDto totalRevenueCalcDto, TotalCostCalcDto totalCostCalcDto,
			TotalMarginCalcDto totalMarginCalcDto) {
		super();
		this.totalRevenueCalcDto = totalRevenueCalcDto;
		this.totalCostCalcDto = totalCostCalcDto;
		this.totalMarginCalcDto = totalMarginCalcDto;
	}
	public TableDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TotalRevenueCalcDto getTotalRevenueCalcDto() {
		return totalRevenueCalcDto;
	}
	public void setTotalRevenueCalcDto(TotalRevenueCalcDto totalRevenueCalcDto) {
		this.totalRevenueCalcDto = totalRevenueCalcDto;
	}
	public TotalCostCalcDto getTotalCostCalcDto() {
		return totalCostCalcDto;
	}
	public void setTotalCostCalcDto(TotalCostCalcDto totalCostCalcDto) {
		this.totalCostCalcDto = totalCostCalcDto;
	}
	public TotalMarginCalcDto getTotalMarginCalcDto() {
		return totalMarginCalcDto;
	}
	public void setTotalMarginCalcDto(TotalMarginCalcDto totalMarginCalcDto) {
		this.totalMarginCalcDto = totalMarginCalcDto;
	}
	
	
	
}
