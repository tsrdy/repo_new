package genpact.pmr.start.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.TradingDao;
import genpact.pmr.start.dto.CountData;
import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.ProjectIdFilter;
import genpact.pmr.start.dto.ProjectManagerFilter;
import genpact.pmr.start.dto.RegionFilter;
import genpact.pmr.start.dto.RequestTradingFilter;
import genpact.pmr.start.dto.TradingChartDto;
import genpact.pmr.start.dto.TradingJSONDataDto;
import genpact.pmr.start.dto.TradingTableDataDto;

@CrossOrigin
@RestController
public class TradingService {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private TradingDao tradingDao;// just to check

    @RequestMapping(value = "/trading", method = RequestMethod.GET)
    public String msg() {
        return "Running Succesfully";
    }

    // To retrieve info
    @RequestMapping(value = "/gettrading", method = RequestMethod.GET)
    public TradingJSONDataDto getInfo() {
        String str = "";
        TradingJSONDataDto tradingJSONDataDto = new TradingJSONDataDto();
        List<FormatDataDto> formatDataDtos = null;
        String sql = "select distinct(region) from trading";
        List<TradingTableDataDto> tradingTableDataDtos = tradingDao.getTotalTradingTableData(str);
        tradingJSONDataDto.setTradingTableDataDtos(tradingTableDataDtos);
        formatDataDtos = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
            int counter;

            public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {
                return new FormatDataDto(++counter, rs.getString("region"));
            }

        });
        tradingJSONDataDto.setFormatDataDtos(formatDataDtos);

        List<TradingChartDto> tradingChartDtos = tradingDao.getMilestoneChart(str);

        Map<String, Double> mileStoneIndividualChartCalculateValue = getMilestoneDetail(tradingChartDtos);
        tradingJSONDataDto.setMilestoneChart(mileStoneIndividualChartCalculateValue);

        List<CountData> countDatass = getTimelineChartCount(tradingChartDtos);

        List<String> categories = new ArrayList<String>();
        List<Double> data = new ArrayList<Double>();
        //double cumulative_result =0.0;
        for (CountData cd : countDatass) {
            categories.add(cd.getRefernceDate());
        //  cumulative_result += cd.getCount();
            data.add(cd.getCount());//=====
        }

        tradingJSONDataDto.setCategories(categories);
        tradingJSONDataDto.setData(data);

        int indexNo = getIndexNoOfToday(categories);

        tradingJSONDataDto.setIndexOfTodayDate(indexNo);

        return tradingJSONDataDto;

    }

    // // retrieve info with Region

    @RequestMapping(value = "/gettrading/region", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    public TradingJSONDataDto getProjectManager(@RequestBody RequestTradingFilter[] requestTradingFilterArr) {

        RequestTradingFilter requestTradingFilter = requestTradingFilterArr[0];
        TradingJSONDataDto tradingJSONDataDto = new TradingJSONDataDto();

        List<RegionFilter> regionFilters = requestTradingFilter.getRegionFilters();

        String region = "";
        int i = 0;
        for (RegionFilter regionFilter : regionFilters) {

            if ((i + 1) == regionFilters.size()) {
                region += regionFilter.getLabel() + ",";

                break;
            } else if (i < regionFilters.size()) {
                region += regionFilter.getLabel() + ",";

            }
            i++;
        }

        String segment = "select distinct(project_manager) from trading where region in (";

        segment += createSql(region);

        segment += ")";
        System.out.println(segment);

        List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

            int counter;

            public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

                return new FormatDataDto(++counter, rs.getString("project_manager"));

            }

        });
        String str = "where region in (" + createSql(region) + ")";
        List<TradingTableDataDto> tradingTableDataDtos = tradingDao.getTotalTradingTableData(str);
        tradingJSONDataDto.setTradingTableDataDtos(tradingTableDataDtos);
        tradingJSONDataDto.setFormatDataDtos(formatDataDtos);

        List<TradingChartDto> tradingChartDtos = tradingDao.getMilestoneChart(str);

        Map<String, Double> mileStoneIndividualChartCalculateValue = getMilestoneDetail(tradingChartDtos);
        tradingJSONDataDto.setMilestoneChart(mileStoneIndividualChartCalculateValue);
        /// -----------------

        List<CountData> countDatass = getTimelineChartCount(tradingChartDtos);

        List<String> categories = new ArrayList<String>();
        List<Double> data = new ArrayList<Double>();

        for (CountData cd : countDatass) {
            categories.add(cd.getRefernceDate());
            data.add(cd.getCount());
        }

        tradingJSONDataDto.setCategories(categories);
        tradingJSONDataDto.setData(data);

        int indexNo = getIndexNoOfToday(categories);

        tradingJSONDataDto.setIndexOfTodayDate(indexNo);

        System.out.println("working fine");

        return tradingJSONDataDto;
    }

    @RequestMapping(value = "/gettrading/region/projectmanager", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")

    public TradingJSONDataDto getProjectId(@RequestBody RequestTradingFilter[] requestTradingFilterArr) {

        TradingJSONDataDto tradingJSONDataDto = new TradingJSONDataDto();
        RequestTradingFilter requestTradingFilter = requestTradingFilterArr[0];
        List<RegionFilter> regionFilters = requestTradingFilter.getRegionFilters();
        List<ProjectManagerFilter> projectManagerFilters = requestTradingFilter.getProjectManagerFilters();

        String region = "";
        String project_manager = "";

        int i = 0;
        for (RegionFilter regionFilter : regionFilters) {

            if ((i + 1) == regionFilters.size()) {
                region += regionFilter.getLabel() + ",";
                System.out.println("region_business_unit");
                break;
            } else if (i < regionFilters.size()) {
                region += regionFilter.getLabel() + ",";
                System.out.println("region");
            }
            i++;
        }

        i = 0;

        for (ProjectManagerFilter projectManagerFilter : projectManagerFilters) {

            if ((i + 1) == projectManagerFilters.size()) {
                project_manager += projectManagerFilter.getLabel() + ",";
                break;
            } else if (i < projectManagerFilters.size()) {
                project_manager += projectManagerFilter.getLabel() + ",";

            }
            i++;
        }

        String segment = "select distinct(project_id) from trading where region in (";

        segment += createSql(region);

        segment += ") and project_manager in (";

        segment += createSql(project_manager);

        segment += ")";
        System.out.println(segment);
        List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

            int counter;

            public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

                return new FormatDataDto(++counter, rs.getString("project_id"));

            }
        });
        String str = "where region in (" + createSql(region) + ") and project_manager in (" + createSql(project_manager)
                + ")";
        List<TradingTableDataDto> tradingTableDataDtos = tradingDao.getTotalTradingTableData(str);
        tradingJSONDataDto.setTradingTableDataDtos(tradingTableDataDtos);
        tradingJSONDataDto.setFormatDataDtos(formatDataDtos);

        List<TradingChartDto> tradingChartDtos = tradingDao.getMilestoneChart(str);
        Map<String, Double> mileStoneIndividualChartCalculateValue = getMilestoneDetail(tradingChartDtos);
        tradingJSONDataDto.setMilestoneChart(mileStoneIndividualChartCalculateValue);
        List<CountData> countDatass = getTimelineChartCount(tradingChartDtos);

        List<String> categories = new ArrayList<String>();
        List<Double> data = new ArrayList<Double>();

        for (CountData cd : countDatass) {
            categories.add(cd.getRefernceDate());
            data.add(cd.getCount());
        }

        tradingJSONDataDto.setCategories(categories);
        tradingJSONDataDto.setData(data);

        int indexNo = getIndexNoOfToday(categories);

        tradingJSONDataDto.setIndexOfTodayDate(indexNo);

        System.out.println("working fine");
        return tradingJSONDataDto;
    }

    @RequestMapping(value = "/gettrading/region/projectmanager/projectid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")

    public TradingJSONDataDto getBasedOnProjectId(@RequestBody RequestTradingFilter[] requestTradingFilterArr) {

        TradingJSONDataDto tradingJSONDataDto = new TradingJSONDataDto();
        RequestTradingFilter requestTradingFilter = requestTradingFilterArr[0];
        List<RegionFilter> regionFilters = requestTradingFilter.getRegionFilters();
        List<ProjectManagerFilter> projectManagerFilters = requestTradingFilter.getProjectManagerFilters();
        List<ProjectIdFilter> projectIdFilters = requestTradingFilter.getProjectIdFilters();

        String region = "";
        String project_manager = "";
        String project_id = "";

        int i = 0;
        for (RegionFilter regionFilter : regionFilters) {

            if ((i + 1) == regionFilters.size()) {
                region += regionFilter.getLabel() + ",";
                System.out.println("region_business_unit");
                break;
            } else if (i < regionFilters.size()) {
                region += regionFilter.getLabel() + ",";
                System.out.println("region");
            }
            i++;
        }

        i = 0;

        for (ProjectManagerFilter projectManagerFilter : projectManagerFilters) {

            if ((i + 1) == projectManagerFilters.size()) {
                project_manager += projectManagerFilter.getLabel() + ",";
                // System.out.println("vertical");
                break;
            } else if (i < projectManagerFilters.size()) {
                project_manager += projectManagerFilter.getLabel() + ",";
                // System.out.println("vertical");
            }
            i++;
        }
        for (ProjectIdFilter projectIdFilter : projectIdFilters) {

            if ((i + 1) == projectIdFilters.size()) {
                project_id += projectIdFilter.getLabel() + ",";
                // System.out.println("vertical");
                break;
            } else if (i < projectIdFilters.size()) {
                project_id += projectIdFilter.getLabel() + ",";
                // System.out.println("vertical");
            }
            i++;
        }

        String segment = "select distinct(project_id) from trading where region in (";

        segment += createSql(region);

        segment += ") and project_manager in (";

        segment += createSql(project_manager);

        segment += ") and project_id in (";

        segment += createSql(project_id);
        segment += ")";
        System.out.println(segment);

        List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

            int counter;

            public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

                return new FormatDataDto(++counter, rs.getString("project_id"));

            }
        });
        String str = "where region in (" + createSql(region) + ") and project_manager in (" + createSql(project_manager)
                + ") and project_id in (" + createSql(project_id) + ")";

        System.out.println(str);
        List<TradingTableDataDto> tradingTableDataDtos = tradingDao.getTotalTradingTableData(str);
        tradingJSONDataDto.setTradingTableDataDtos(tradingTableDataDtos);
        tradingJSONDataDto.setFormatDataDtos(formatDataDtos);

        List<TradingChartDto> tradingChartDtos = tradingDao.getMilestoneChart(str);

        Map<String, Double> mileStoneIndividualChartCalculateValue = getMilestoneDetail(tradingChartDtos);
        tradingJSONDataDto.setMilestoneChart(mileStoneIndividualChartCalculateValue);
        List<CountData> countDatass = getTimelineChartCount(tradingChartDtos);

        List<String> categories = new ArrayList<String>();
        List<Double> data = new ArrayList<Double>();

        for (CountData cd : countDatass) {
            categories.add(cd.getRefernceDate());
            data.add(cd.getCount());
        }

        tradingJSONDataDto.setCategories(categories);
        tradingJSONDataDto.setData(data);

        int indexNo = getIndexNoOfToday(categories);

        tradingJSONDataDto.setIndexOfTodayDate(indexNo);
        System.out.println("working fine");
        return tradingJSONDataDto;
    }

    private List<CountData> getTimelineChartCount(List<TradingChartDto> lst) {
        DateFormat dateFormat = new SimpleDateFormat("MMM-yy");
        List<CountData> finalData = new ArrayList<CountData>();
        List<String> sortedMonth=new ArrayList<>();
        Map<String,Double> monthWiseMap=new HashMap<>();
        for(int i=0;i<lst.size();i++){
            
            TradingChartDto obj_class=lst.get(i);
            String monthYear=dateFormat.format(obj_class.getActual_plan_date());
            if(monthWiseMap.containsKey(monthYear)){
                monthWiseMap.put(monthYear, monthWiseMap.get(monthYear)+obj_class.getTrading_value());
            }else
            {
                monthWiseMap.put(monthYear, obj_class.getTrading_value());
                sortedMonth.add(monthYear);
            }
        }
        
//      System.err.println("Sorted order months and years : "+sortedMonth);
        double cumilative=0.0;
        for(int i=0;i<sortedMonth.size();i++){
            CountData cd=new CountData();
            
            cumilative+=monthWiseMap.get(sortedMonth.get(i));

            cd.setRefernceDate(sortedMonth.get(i));
            cd.setCount(cumilative);
//          System.err.print(" "+cumilative);
            
            finalData.add(cd);
        }
        
        
        
        //===================================
        /*for (int i = 0; i < lst.size(); i++) {
            TradingChartDto obj_class = lst.get(i);
            boolean flag = true;
            double valueHolder = 0.0d;
            String month_year = dateFormat.format(obj_class.getActual_plan_date());
            for (int j = 0; j < map.size(); j++) {
                CountData obj = map.get(j);
                if (obj.getRefernceDate().equals(month_year)) {
                    obj.setCount(obj.getCount() + obj_class.getTrading_value()+valueHolder);
                    valueHolder = obj.getCount() + obj_class.getTrading_value();
                    System.out.println("ujgffcbsuscfcksksk   "+valueHolder);
                    
                    flag = false;

                }
            }

            if (flag) {
                CountData obj = new CountData();
                obj.setCount(obj_class.getTrading_value()+ valueHolder);
                valueHolder += obj_class.getTrading_value();
                System.out.println("ujgffcbsuscfcksksk2   "+valueHolder);

                obj.setRefernceDate(month_year);
                map.add(obj);
            }

        }
        System.out.println("MAPPPPPPPPPPPPPPPPP" + map);
*/
        return finalData;
    }

    private Map<String, Double> getMilestoneDetail(List<TradingChartDto> tradingChartDtos) {

        Map<String, Double> milestone_chartMap = new HashMap<String, Double>();
        Set<String> mileStoneDescriptionSet = new HashSet<String>();

        for (TradingChartDto tcd : tradingChartDtos) {
            String mileStoneDescription = tcd.getMilestone_description();

            if (mileStoneDescriptionSet.add(mileStoneDescription)) {
                // first time
                milestone_chartMap.put(mileStoneDescription, tcd.getTrading_value());
            } else {
                // duplicate avl

                Double oldTradingValue = milestone_chartMap.get(mileStoneDescription);

                milestone_chartMap.put(mileStoneDescription, oldTradingValue + tcd.getTrading_value());

            }
        }
        return milestone_chartMap;
    }

    private String createSql(String str) {
        String[] strArray = str.split(",");

        String seg = "";

        for (int i = 0; i <= strArray.length; i++) {

            seg += "'" + strArray[i] + "'";

            if ((i + 1) == strArray.length) {
                break;
            } else if (i < strArray.length) {
                seg += ",";
            }
        }
        System.out.println(seg + "in vertical");
        return seg;
    }

    public int getIndexNoOfToday(List<String> dateListInString) {
        int indexNo;

        DateFormat dateFormat = new SimpleDateFormat("MMM-yy");
        String today = dateFormat.format(new Date());

        indexNo = dateListInString.indexOf(today);

        // if today current month is not available

        boolean pastYearflag = false;
        boolean currentYearflag = false;
        boolean futureYearflag = false;

        if (indexNo == -1) {
            String[] currentDateArr = today.split("-");
            int currentYear = Integer.parseInt(currentDateArr[1]);
            String[] recordDateArr = null;
            int recordYear = 0;
            for (String dateData : dateListInString) {
                recordDateArr = dateData.split("-");
                recordYear = Integer.parseInt(recordDateArr[1]);

                if (currentYear > recordYear) {
                    // write for past year
                    pastYearflag = true;
                }
                if (currentYear == recordYear) {
                    // same year bt month is not matching
                    currentYearflag = true;
                    //we will wrt latr for current mont is not bt another month for same month
                }
                if (currentYear < recordYear) {
                    //
                    futureYearflag = true;
                }
            }
            
            if(futureYearflag==true && currentYearflag==false && pastYearflag==false){
                indexNo=-1;
            }
            if(futureYearflag==false && currentYearflag==false && pastYearflag==true){
                indexNo=-2; //special value for
            }

        }
        //
        return indexNo;
    }
}
