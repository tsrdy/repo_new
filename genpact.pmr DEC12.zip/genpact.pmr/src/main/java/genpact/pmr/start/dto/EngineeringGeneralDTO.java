package genpact.pmr.start.dto;

import java.util.Arrays;

public class EngineeringGeneralDTO {

	

	private String projectManager;
	private String projectID;
	private String[] costType;
	
	
	public String[] getCostType() {
		return costType;
	}
	public void setCostType(String[] costType) {
		this.costType = costType;
	}
	
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getProjectID() {
		return projectID;
	}
	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}
	public EngineeringGeneralDTO(String projectManager, String projectID, String[] costType) {
		super();
		this.projectManager = projectManager;
		this.projectID = projectID;
		this.costType = costType;
	}
	public EngineeringGeneralDTO() {
		super();
	}
	
}
