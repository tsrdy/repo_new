package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.EstimateDto;
import genpact.pmr.start.dto.GoForwardCalcList;
@Repository
public class EstimateDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<GoForwardCalcList> getAverageList(String sql){
		
		System.out.println("sql  : "+sql);
		
		List<GoForwardCalcList> goForwardCalcLists = jdbcTemplate.query(sql, new RowMapper<GoForwardCalcList>(){

			@Override
			public GoForwardCalcList mapRow(ResultSet rs, int rowNum) throws SQLException {
			
				return new GoForwardCalcList(rs.getDouble("average"), rs.getInt("time_"));//rs.getDouble("average");
			}
			
		});
		
				
		return goForwardCalcLists;
	}
	
/*public List<GoForwardCalcList> getCostCurveAverageList(String projectId,int timePercent){
		//average list means respective column of projectId
	
	String sql = "select time_, ("+ projectId +") as average from cost_curve where time_ between  1 and 100";
//	String sql = "select time_ from cost_curve where time_ between "+ timePercent+" and 100";
	System.out.println("gvliiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiwoirpoeuuowrupqurpqw    "+sql);
		List<GoForwardCalcList> goForwardCalcLists = jdbcTemplate.query(sql, new RowMapper<GoForwardCalcList>(){

			@Override
			public GoForwardCalcList mapRow(ResultSet rs, int rowNum) throws SQLException {
			
				return new GoForwardCalcList(rs.getDouble("average"), rs.getInt("time_"));//rs.getDouble("average");
			}
			
		});
		
	//	System.out.println("STRRRRRRRRRRRRRRRRR");
				
		return goForwardCalcLists;
	}
	*/

}
