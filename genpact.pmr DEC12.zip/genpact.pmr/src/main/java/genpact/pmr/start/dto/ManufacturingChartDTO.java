package genpact.pmr.start.dto;

public class ManufacturingChartDTO {
	
	MCShopDTO mcDto;
	LampressDTO lampressDTO;
	PinventDTO pinventDTO;
	RotorDTO rotorDTO;
	StatcoreDTO statcoreDTO;
	CoilsDTO coilsDTO;
	CopperDTO copperDTO;
	StatwindDTO statwindDTO;
	VpiDTO vpiDTO;
	AssemblyDTO assemblyDTO;
	TestDTO testDTO;
	
	public MCShopDTO getMcDto() {
		return mcDto;
	}

	public void setMcDto(MCShopDTO mcDto) {
		this.mcDto = mcDto;
	}

	public LampressDTO getLampressDTO() {
		return lampressDTO;
	}

	public void setLampressDTO(LampressDTO lampressDTO) {
		this.lampressDTO = lampressDTO;
	}

	public PinventDTO getPinventDTO() {
		return pinventDTO;
	}

	public void setPinventDTO(PinventDTO pinventDTO) {
		this.pinventDTO = pinventDTO;
	}

	public RotorDTO getRotorDTO() {
		return rotorDTO;
	}

	public void setRotorDTO(RotorDTO rotorDTO) {
		this.rotorDTO = rotorDTO;
	}

	public StatcoreDTO getStatcoreDTO() {
		return statcoreDTO;
	}

	public void setStatcoreDTO(StatcoreDTO statcoreDTO) {
		this.statcoreDTO = statcoreDTO;
	}

	public CoilsDTO getCoilsDTO() {
		return coilsDTO;
	}

	public void setCoilsDTO(CoilsDTO coilsDTO) {
		this.coilsDTO = coilsDTO;
	}

	public CopperDTO getCopperDTO() {
		return copperDTO;
	}

	public void setCopperDTO(CopperDTO copperDTO) {
		this.copperDTO = copperDTO;
	}

	public StatwindDTO getStatwindDTO() {
		return statwindDTO;
	}

	public void setStatwindDTO(StatwindDTO statwindDTO) {
		this.statwindDTO = statwindDTO;
	}

	public VpiDTO getVpiDTO() {
		return vpiDTO;
	}

	public void setVpiDTO(VpiDTO vpiDTO) {
		this.vpiDTO = vpiDTO;
	}

	public AssemblyDTO getAssemblyDTO() {
		return assemblyDTO;
	}

	public void setAssemblyDTO(AssemblyDTO assemblyDTO) {
		this.assemblyDTO = assemblyDTO;
	}

	public TestDTO getTestDTO() {
		return testDTO;
	}

	public void setTestDTO(TestDTO testDTO) {
		this.testDTO = testDTO;
	}

	public ManufacturingChartDTO(MCShopDTO mcDto, LampressDTO lampressDTO, PinventDTO pinventDTO, RotorDTO rotorDTO,
			StatcoreDTO statcoreDTO, CoilsDTO coilsDTO, CopperDTO copperDTO, StatwindDTO statwindDTO, VpiDTO vpiDTO,
			AssemblyDTO assemblyDTO, TestDTO testDTO) {
		super();
		this.mcDto = mcDto;
		this.lampressDTO = lampressDTO;
		this.pinventDTO = pinventDTO;
		this.rotorDTO = rotorDTO;
		this.statcoreDTO = statcoreDTO;
		this.coilsDTO = coilsDTO;
		this.copperDTO = copperDTO;
		this.statwindDTO = statwindDTO;
		this.vpiDTO = vpiDTO;
		this.assemblyDTO = assemblyDTO;
		this.testDTO = testDTO;
	}

	@Override
	public String toString() {
		return "ManufacturingChartDTO [mcDto=" + mcDto + ", lampressDTO=" + lampressDTO + ", pinventDTO=" + pinventDTO
				+ ", rotorDTO=" + rotorDTO + ", statcoreDTO=" + statcoreDTO + ", coilsDTO=" + coilsDTO + ", copperDTO="
				+ copperDTO + ", statwindDTO=" + statwindDTO + ", vpiDTO=" + vpiDTO + ", assemblyDTO=" + assemblyDTO
				+ ", testDTO=" + testDTO + "]";
	}

	
}
