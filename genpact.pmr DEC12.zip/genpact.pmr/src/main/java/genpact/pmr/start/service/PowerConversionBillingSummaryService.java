package genpact.pmr.start.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.PowerConversionBillingSummaryDao;
import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.JSONDataDto;
import genpact.pmr.start.dto.PowerCBSRegionWiseDataDto;
import genpact.pmr.start.dto.PowerConversionBillingSummaryRequestJSONDataDto;
import genpact.pmr.start.dto.PowerConversionBillingSummaryResponseJSONDataDto;
import genpact.pmr.start.dto.RegionFilter;
import genpact.pmr.start.dto.RequestFilter;

@CrossOrigin
@RestController
public class PowerConversionBillingSummaryService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private PowerConversionBillingSummaryDao billingSummaryDao;

	// just to check
	@RequestMapping(value = "/billingsummary", method = RequestMethod.GET)
	public String msg() {
		return "Running Succesfully";
	}

	// To retrive info
	@RequestMapping(value = "/getbillingsummary", method = RequestMethod.GET)
	public PowerConversionBillingSummaryResponseJSONDataDto getInfo() {
		PowerConversionBillingSummaryResponseJSONDataDto conversionBillingSummaryResponseJSONDataDto = null;

		conversionBillingSummaryResponseJSONDataDto = billingSummaryDao.getRegions();

		return conversionBillingSummaryResponseJSONDataDto;

	}

	@RequestMapping(value = "/getbillingsummary/region", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PowerConversionBillingSummaryResponseJSONDataDto getRegionalManager(
			@RequestBody PowerConversionBillingSummaryRequestJSONDataDto[] requestJSONDataDtos) {

		PowerConversionBillingSummaryResponseJSONDataDto conversionBillingSummaryResponseJSONDataDto = null;

		PowerConversionBillingSummaryRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		conversionBillingSummaryResponseJSONDataDto = billingSummaryDao.getRegionalManager(requestJSONDataDto);

		return conversionBillingSummaryResponseJSONDataDto;
	}

	@RequestMapping(value = "/getbillingsummary/region/regionalmanager", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PowerConversionBillingSummaryResponseJSONDataDto getProjectManager(
			@RequestBody PowerConversionBillingSummaryRequestJSONDataDto[] requestJSONDataDtos) {

		PowerConversionBillingSummaryResponseJSONDataDto conversionBillingSummaryResponseJSONDataDto = null;

		PowerConversionBillingSummaryRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		conversionBillingSummaryResponseJSONDataDto = billingSummaryDao.getProjectManager(requestJSONDataDto);

		return conversionBillingSummaryResponseJSONDataDto;

		
	}

	@RequestMapping(value = "/getbillingsummary/region/regionalmanager/projectmanager", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PowerConversionBillingSummaryResponseJSONDataDto getTableDataByAllFilter(
			@RequestBody PowerConversionBillingSummaryRequestJSONDataDto[] requestJSONDataDtos) {
		
		
		PowerConversionBillingSummaryResponseJSONDataDto conversionBillingSummaryResponseJSONDataDto = null;

		PowerConversionBillingSummaryRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		conversionBillingSummaryResponseJSONDataDto = billingSummaryDao.getTableDataByAllFilter(requestJSONDataDto);

		return conversionBillingSummaryResponseJSONDataDto;
	}

	
	@RequestMapping(value = "/getbillingsummary/region/regionalmanager/projectmanager/billingquarter", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PowerConversionBillingSummaryResponseJSONDataDto getTableDataByBillingQuarter(
			@RequestBody PowerConversionBillingSummaryRequestJSONDataDto[] requestJSONDataDtos) {

		PowerConversionBillingSummaryResponseJSONDataDto conversionBillingSummaryResponseJSONDataDto = null;

		PowerConversionBillingSummaryRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		conversionBillingSummaryResponseJSONDataDto = billingSummaryDao.getTableDataByBillingQuarterFilter(requestJSONDataDto);

		return conversionBillingSummaryResponseJSONDataDto;
	}

}
