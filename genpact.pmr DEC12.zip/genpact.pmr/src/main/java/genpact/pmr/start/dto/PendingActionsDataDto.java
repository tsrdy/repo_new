package genpact.pmr.start.dto;

public class PendingActionsDataDto {

	private int in_lessthan_equal_3d;
	private int in_greaterthan_1w;
	private int done;
	private int greatherthan_1w;
	private int greatherthan_2w;
	private int in_lessthan_equal_1w;
	private int greaterthan_0w;
	public int getIn_lessthan_equal_3d() {
		return in_lessthan_equal_3d;
	}
	public void setIn_lessthan_equal_3d(int in_lessthan_equal_3d) {
		this.in_lessthan_equal_3d = in_lessthan_equal_3d;
	}
	public int getIn_greaterthan_1w() {
		return in_greaterthan_1w;
	}
	public void setIn_greaterthan_1w(int in_greaterthan_1w) {
		this.in_greaterthan_1w = in_greaterthan_1w;
	}
	public int getDone() {
		return done;
	}
	public void setDone(int done) {
		this.done = done;
	}
	public int getGreatherthan_1w() {
		return greatherthan_1w;
	}
	public void setGreatherthan_1w(int greatherthan_1w) {
		this.greatherthan_1w = greatherthan_1w;
	}
	public int getGreatherthan_2w() {
		return greatherthan_2w;
	}
	public void setGreatherthan_2w(int greatherthan_2w) {
		this.greatherthan_2w = greatherthan_2w;
	}
	public int getIn_lessthan_equal_1w() {
		return in_lessthan_equal_1w;
	}
	public void setIn_lessthan_equal_1w(int in_lessthan_equal_1w) {
		this.in_lessthan_equal_1w = in_lessthan_equal_1w;
	}
	public int getGreaterthan_0w() {
		return greaterthan_0w;
	}
	public void setGreaterthan_0w(int greaterthan_0w) {
		this.greaterthan_0w = greaterthan_0w;
	}
	public PendingActionsDataDto(int in_lessthan_equal_3d, int in_greaterthan_1w, int done, int greatherthan_1w,
			int greatherthan_2w, int in_lessthan_equal_1w, int greaterthan_0w) {
		super();
		this.in_lessthan_equal_3d = in_lessthan_equal_3d;
		this.in_greaterthan_1w = in_greaterthan_1w;
		this.done = done;
		this.greatherthan_1w = greatherthan_1w;
		this.greatherthan_2w = greatherthan_2w;
		this.in_lessthan_equal_1w = in_lessthan_equal_1w;
		this.greaterthan_0w = greaterthan_0w;
	}
	public PendingActionsDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
		
}
