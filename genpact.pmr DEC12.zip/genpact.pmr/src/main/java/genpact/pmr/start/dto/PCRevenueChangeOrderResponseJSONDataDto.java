package genpact.pmr.start.dto;

import java.util.List;

public class PCRevenueChangeOrderResponseJSONDataDto {
	
	private List<FormatDataDto> nextfilterList;
	private List<PCRCORegionDataDto> regionList;//====
	private List<PCRCOProjectManagerDataDto> projectManagerList;//=====
	private List<PCRCProjectIdDataDto> projectIdList;//======
	public PCRevenueChangeOrderResponseJSONDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PCRevenueChangeOrderResponseJSONDataDto(List<FormatDataDto> nextfilterList,
			List<PCRCORegionDataDto> regionList, List<PCRCOProjectManagerDataDto> projectManagerList,
			List<PCRCProjectIdDataDto> projectIdList) {
		super();
		this.nextfilterList = nextfilterList;
		this.regionList = regionList;
		this.projectManagerList = projectManagerList;
		this.projectIdList = projectIdList;
	}
	public List<FormatDataDto> getNextfilterList() {
		return nextfilterList;
	}
	public void setNextfilterList(List<FormatDataDto> nextfilterList) {
		this.nextfilterList = nextfilterList;
	}
	public List<PCRCORegionDataDto> getRegionList() {
		return regionList;
	}
	public void setRegionList(List<PCRCORegionDataDto> regionList) {
		this.regionList = regionList;
	}
	public List<PCRCOProjectManagerDataDto> getProjectManagerList() {
		return projectManagerList;
	}
	public void setProjectManagerList(List<PCRCOProjectManagerDataDto> projectManagerList) {
		this.projectManagerList = projectManagerList;
	}
	public List<PCRCProjectIdDataDto> getProjectIdList() {
		return projectIdList;
	}
	public void setProjectIdList(List<PCRCProjectIdDataDto> projectIdList) {
		this.projectIdList = projectIdList;
	}
	
	}
