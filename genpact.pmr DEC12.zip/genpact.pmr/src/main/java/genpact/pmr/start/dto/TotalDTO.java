package genpact.pmr.start.dto;

public class TotalDTO {
	private String name ; 
	  private long Cbl;
	  private long PreviousEac;
	  private long Eac;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getCbl() {
		return Cbl;
	}
	public void setCbl(long cbl) {
		Cbl = cbl;
	}
	public long getPreviousEac() {
		return PreviousEac;
	}
	public void setPreviousEac(long previousEac) {
		PreviousEac = previousEac;
	}
	public long getEac() {
		return Eac;
	}
	public void setEac(long eac) {
		Eac = eac;
	}
	public TotalDTO() {
		super();
	}
	public TotalDTO(String name, long cbl, long previousEac, long eac) {
		super();
		this.name = name;
		Cbl = cbl;
		PreviousEac = previousEac;
		Eac = eac;
	}
	

}
