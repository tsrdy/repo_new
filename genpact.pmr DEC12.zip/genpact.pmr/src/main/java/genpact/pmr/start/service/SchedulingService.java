package genpact.pmr.start.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.SchedulingServiceDAO;
import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.OTDStatusFilter;
import genpact.pmr.start.dto.ProjectIdFilter;
import genpact.pmr.start.dto.ProjectManagerFilter;
import genpact.pmr.start.dto.RegionFilter;
import genpact.pmr.start.dto.RequestFilter;
import genpact.pmr.start.dto.SchedulingDto;

@CrossOrigin
@RestController
public class SchedulingService {

	@Autowired
	public JdbcTemplate jdbcTemplate;

	@Autowired
	private SchedulingServiceDAO schedulingServiceDAO;

	@RequestMapping(value = "/getschedulingdata", method=RequestMethod.GET)
	public SchedulingDto getSchedulingData(){
		SchedulingDto schedulingDto = new SchedulingDto();

		List<FormatDataDto> formatDataDto = new ArrayList<FormatDataDto>();
		String sql = "select distinct(region) from scheduling";
		formatDataDto = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>(){
			int counter = 0;
			@Override
			public FormatDataDto mapRow(ResultSet rs, int arg1) throws SQLException {
				return new FormatDataDto(++counter, rs.getString("region"));
			}
		});
		String str = "";
		schedulingDto = schedulingServiceDAO.getSchedulingData(str);
		schedulingDto.setFormatDataDtos(formatDataDto);
		return schedulingDto;

	}


	@RequestMapping(value = "/getschedulingdata/region", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public SchedulingDto getprojectManagerlist(@RequestBody RequestFilter[] requestFilterArr) {
		SchedulingDto schedulingDto = new SchedulingDto();
		RequestFilter requestFilter = requestFilterArr[0];
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();

		String region = "";

		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region += regionFilter.getLabel() + ",";

				break;
			} else if (i < regionFilters.size()) {
				region += regionFilter.getLabel() + ",";

			}
			i++;
		}

		String segment = "select distinct(project_manager) from scheduling where region in ( ";
		segment+=createSql(region);
		segment += ")";

		List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {
			int counter;
			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new FormatDataDto(++counter, rs.getString("project_manager"));
			}
		});
		schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+ createSql(region)+ ")");
		schedulingDto.setFormatDataDtos(formatDataDtos);

		return schedulingDto;
	}




	@RequestMapping(value = "/getschedulingdata/region/projectmanager", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")

	public SchedulingDto getProjectManager(@RequestBody RequestFilter[] requestFilterArr) {

		RequestFilter requestFilter = requestFilterArr[0];
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();
		List<ProjectManagerFilter> managerFilters = requestFilter.getProjectManagerFilters();

		String region ="";
		String manager ="" ;

		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region += regionFilter.getLabel() + ",";
				break;
			} else if (i < regionFilters.size()) {
				region += regionFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;

		for (ProjectManagerFilter managerFilter : managerFilters) {
			if ((i + 1) == managerFilters.size()) {
				manager+=managerFilter.getLabel()+",";
				break;
			} else if (i < managerFilters.size()) {
				manager += managerFilter.getLabel()+",";
			}
			i++;
		}

		System.out.println(manager);

		String segment = "select distinct(project_id) from scheduling where region in (";
		segment+=createSql(region);
		segment+=") and project_manager in (";
		segment += createSql(manager);
		segment += ")";
		List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {
			int counter;
			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("project_id"));

			}
		});

		SchedulingDto schedulingDto = new SchedulingDto();
		schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+ ") and project_manager in ("+createSql(manager)+")");
		schedulingDto.setFormatDataDtos(formatDataDtos);

		return schedulingDto;
	}

	@RequestMapping(value = "/getschedulingdata/region/projectmanager/projectid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")

	public SchedulingDto getSchDataOnId(@RequestBody RequestFilter[] requestFilterArr) {

		RequestFilter requestFilter = requestFilterArr[0];
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();
		List<ProjectManagerFilter> managerFilters = requestFilter.getProjectManagerFilters();
		List<ProjectIdFilter> projectIdFilters = requestFilter.getProjectIdFilters();

		String region ="";
		String manager ="" ;
		String project_id="" ;

		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region += regionFilter.getLabel() + ",";
				break;
			} else if (i < regionFilters.size()) {
				region += regionFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;

		for (ProjectManagerFilter managerFilter : managerFilters) {
			if ((i + 1) == managerFilters.size()) {
				manager+=managerFilter.getLabel()+",";
				break;
			} else if (i < managerFilters.size()) {
				manager += managerFilter.getLabel()+",";
			}
			i++;
		}

		i =0;

		for (ProjectIdFilter	projectIdFilter : projectIdFilters) {

			if ((i + 1) == projectIdFilters.size()) {
				project_id+= projectIdFilter.getLabel() + ",";
				break;
			} else if (i < projectIdFilters.size()) {
				project_id += projectIdFilter.getLabel() + ",";
			}
			i++;
		}

		SchedulingDto schedulingDto = new SchedulingDto();
		schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+ ") and project_manager in ("+createSql(manager)+") and project_id in ("+createSql(project_id)+")");
		return schedulingDto;
	}



	@RequestMapping(value = "/getschedulingdata/otdstatus", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")

	public SchedulingDto getSchDataOnOTDStatus(@RequestBody RequestFilter[] requestFilterArr) {

		RequestFilter requestFilter = requestFilterArr[0];
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();
		List<ProjectManagerFilter> managerFilters = requestFilter.getProjectManagerFilters();
		List<ProjectIdFilter> projectIdFilters = requestFilter.getProjectIdFilters(); 
		List<OTDStatusFilter> otdStatusFilters = requestFilter.getOtdStatusFilters();

		String region ="";
		String manager ="" ;
		String project_id ="" ;
		String otdStatus = "" ;

		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region += regionFilter.getLabel() + ",";
				break;
			} else if (i < regionFilters.size()) {
				region += regionFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;

		for (ProjectManagerFilter managerFilter : managerFilters) {
			if ((i + 1) == managerFilters.size()) {
				manager+=managerFilter.getLabel()+",";
				break;
			} else if (i < managerFilters.size()) {
				manager += managerFilter.getLabel()+",";
			}
			i++;
		}

		i =0;

		for (ProjectIdFilter projectIdFilter : projectIdFilters) {

			if ((i + 1) == projectIdFilters.size()) {
				project_id+= projectIdFilter.getLabel() + ",";
				break;
			} else if (i < projectIdFilters.size()) {
				project_id += projectIdFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;

		for (OTDStatusFilter otdStatusFilter : otdStatusFilters) {
			if ((i + 1) == otdStatusFilters.size()) {
				otdStatus = otdStatusFilter.getLabel();
			}
		}

		SchedulingDto schedulingDto = new SchedulingDto();
		if(region.equals("") && manager.equals("") && project_id.equals("")){
			schedulingDto = schedulingServiceDAO.getSchedulingData(" where act_otd_status like '"+otdStatus+"'");
		}else if(region != ""){
			if(otdStatus.equals(""))
				schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+")");
			else
				schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+") and act_otd_status like '"+otdStatus+"'");
			
		}else if(region != "" &&  manager != ""){
			if(otdStatus.equals(""))
				schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+ ") and project_manager in ("+createSql(manager)+")");
			else
				schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+ ") and project_manager in ("+createSql(manager)+") and act_otd_status like '"+otdStatus+"'");
		}else if(region != "" &&  manager != "" &&  project_id != ""){
			if(otdStatus.equals(""))
				schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+ ") and project_manager in ("+createSql(manager)+")and project_id in ("+createSql(project_id)+")");
			else
				schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+ ") and project_manager in ("+createSql(manager)+")and project_id in ("+createSql(project_id)+") and act_otd_status like '"+otdStatus+"'");
		}
		else{
			schedulingDto = schedulingServiceDAO.getSchedulingData(" where region in("+createSql(region)+ ") "
					+ "and project_manager in ("+createSql(manager)+") and project_id in ("+createSql(project_id)+") and act_otd_status = '"+otdStatus+"'");
		}
		return schedulingDto;
	}


	private String createSql(String str) {
		String[] strArray = str.split(",");
		String seg = "";
		for (int i = 0; i <= strArray.length; i++) {
			seg += "'" + strArray[i] + "'";
			if ((i + 1) == strArray.length) {
				break;
			} else if (i < strArray.length) {
				seg += ",";
			}
		}
		return seg;
	}



}
