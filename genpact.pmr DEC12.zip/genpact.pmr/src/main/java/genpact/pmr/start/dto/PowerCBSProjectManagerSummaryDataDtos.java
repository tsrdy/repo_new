package genpact.pmr.start.dto;

public class PowerCBSProjectManagerSummaryDataDtos {
	
	
	private String projectmanager;
	private double billed;
	private double tobebilled;
	private double total;
	public PowerCBSProjectManagerSummaryDataDtos() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PowerCBSProjectManagerSummaryDataDtos(String projectmanager, double billed, double tobebilled,
			double total) {
		super();
		this.projectmanager = projectmanager;
		this.billed = billed;
		this.tobebilled = tobebilled;
		this.total = total;
	}
	public String getProjectmanager() {
		return projectmanager;
	}
	public void setProjectmanager(String projectmanager) {
		this.projectmanager = projectmanager;
	}
	public double getBilled() {
		return billed;
	}
	public void setBilled(double billed) {
		this.billed = billed;
	}
	public double getTobebilled() {
		return tobebilled;
	}
	public void setTobebilled(double tobebilled) {
		this.tobebilled = tobebilled;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	


}
