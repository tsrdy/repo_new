package genpact.pmr.start.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.ManufacturingDAO;
import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.ManufacturingDTO;
import genpact.pmr.start.dto.ManufacturingDrilDownDTO;
import genpact.pmr.start.dto.ManufacturingGeneralDTO;
import genpact.pmr.start.dto.ManufacturingTableDTO;
import genpact.pmr.start.dto.MaufacturingGeneral1DTO;
import genpact.pmr.start.dto.ProjectIdFilter;
import genpact.pmr.start.dto.TableManufacturing;

@RestController
public class ManufacturingService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	ManufacturingDAO manufacturingDAO;

	@RequestMapping(value = "/getprojectmanagers", method = RequestMethod.GET)
	public ManufacturingDTO getProjectManagers() {
		ManufacturingDTO manufacturingDTO = new ManufacturingDTO();
		List<FormatDataDto> formatDataDto = new ArrayList<FormatDataDto>();
		String sql = "select distinct(project_manager) from manufacturing";
		formatDataDto = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter = 0;

			@Override
			public FormatDataDto mapRow(ResultSet rs, int arg1) throws SQLException {
				return new FormatDataDto(++counter, rs.getString("project_manager"));
			}
		});
		String str = "";
		/*
		 * manufacturingDTO.setManufacturingTableDTOs(manufacturingDAO.
		 * getManufacturing(str));
		 */
		manufacturingDTO.setFormatDataDto(formatDataDto);
		return manufacturingDTO;
	}

	@RequestMapping(value = "/getmanufacturingprojecid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ManufacturingDTO getManufacturingProjecid(@RequestBody ProjectIdFilter projectIdFilter) {
		ManufacturingDTO manufacturingDTO = new ManufacturingDTO();
		List<FormatDataDto> formatDataDto = new ArrayList<FormatDataDto>();
		String projectManager = projectIdFilter.getLabel();
		String sql = "select distinct(project) from manufacturing where project_manager= " + "'" + projectManager + "'";
		System.out.println(sql);
		formatDataDto = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter = 0;

			@Override
			public FormatDataDto mapRow(ResultSet rs, int arg1) throws SQLException {
				return new FormatDataDto(++counter, rs.getString("project"));
			}
		});
		manufacturingDTO.setFormatDataDto(formatDataDto);
		return manufacturingDTO;
	}

	@RequestMapping(value = "/gettabledataonprojectid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ManufacturingTableDTO getManufacturingOnProject(@RequestBody ProjectIdFilter projectIdFilter) {
		String project = projectIdFilter.getLabel();

		return manufacturingDAO.getManufacturing(project);
	}

	@RequestMapping(value = "/gettabledataonprojectallid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public MaufacturingGeneral1DTO getManufacturingOnProjectIds(
			@RequestBody ManufacturingGeneralDTO manufacturingGeneralDTO) {

		return manufacturingDAO.getManufacturingAll(manufacturingGeneralDTO);
	}
}
