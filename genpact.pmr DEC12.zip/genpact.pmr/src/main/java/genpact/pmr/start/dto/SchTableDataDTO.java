package genpact.pmr.start.dto;

public class SchTableDataDTO {
	
	private String projectId;
	private String projectManager;
	private String soldToPartyName;
	private String actMilestone;
	private String activityName;
	private String actOtdStatus;
	private String actBlFinish;
	private String actFinish;
	private String prjScheduleDate;
	private String variation;
	
	
	public SchTableDataDTO(String projectId, String projectManager, String soldToPartyName, String actMilestone,
			String activityName, String actOtdStatus, String actBlFinish, String actFinish, String prjScheduleDate,
			String variation) {
		super();
		this.projectId = projectId;
		this.projectManager = projectManager;
		this.soldToPartyName = soldToPartyName;
		this.actMilestone = actMilestone;
		this.activityName = activityName;
		this.actOtdStatus = actOtdStatus;
		this.actBlFinish = actBlFinish;
		this.actFinish = actFinish;
		this.prjScheduleDate = prjScheduleDate;
		this.variation = variation;
	}
	public String getVariation() {
		return variation;
	}
	public void setVariation(String variation) {
		this.variation = variation;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getSoldToPartyName() {
		return soldToPartyName;
	}
	public void setSoldToPartyName(String soldToPartyName) {
		this.soldToPartyName = soldToPartyName;
	}
	public String getActMilestone() {
		return actMilestone;
	}
	public void setActMilestone(String actMilestone) {
		this.actMilestone = actMilestone;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getActOtdStatus() {
		return actOtdStatus;
	}
	public void setActOtdStatus(String actOtdStatus) {
		this.actOtdStatus = actOtdStatus;
	}
	public String getActBlFinish() {
		return actBlFinish;
	}
	public void setActBlFinish(String actBlFinish) {
		this.actBlFinish = actBlFinish;
	}
	public String getActFinish() {
		return actFinish;
	}
	public void setActFinish(String actFinish) {
		this.actFinish = actFinish;
	}
	public String getPrjScheduleDate() {
		return prjScheduleDate;
	}
	public void setPrjScheduleDate(String prjScheduleDate) {
		this.prjScheduleDate = prjScheduleDate;
	}
	
	
	public SchTableDataDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SchTableDataDTO [projectId=" + projectId + ", projectManager=" + projectManager + ", soldToPartyName="
				+ soldToPartyName + ", actMilestone=" + actMilestone + ", activityName=" + activityName
				+ ", actOtdStatus=" + actOtdStatus + ", actBlFinish=" + actBlFinish + ", actFinish=" + actFinish
				+ ", prjScheduleDate=" + prjScheduleDate + "]";
	}
	
	
	
	
}
