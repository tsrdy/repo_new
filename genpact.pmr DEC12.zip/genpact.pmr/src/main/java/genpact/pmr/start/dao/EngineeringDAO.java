package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.EngineeringDTO;
import genpact.pmr.start.dto.EngineeringGeneral1DTO;
import genpact.pmr.start.dto.EngineeringGeneralDTO;
import genpact.pmr.start.dto.EngineeringGeneralFreeDTO;
import genpact.pmr.start.dto.GeneralEngineeringDto;
import genpact.pmr.start.dto.MCShopDTO;
import genpact.pmr.start.dto.TableEngineering;

@Repository
public class EngineeringDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	String sql = "";

	public EngineeringDTO getEngineering(String str) {
		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from engineeringscorecard where project ="
				+ "'" + str + "'" + " and  group_=('R&D Technical Eng') group by machine";

		List<MCShopDTO> rdtechnicaleng = jdbcTemplate.query(sql, new RowMapper<MCShopDTO>() {
			public MCShopDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				MCShopDTO mc = new MCShopDTO();
				mc.setName(rs.getString("machine"));
				mc.setCbl(rs.getInt("CBL"));
				mc.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				mc.setEac(rs.getInt("EAC"));
				return mc;
			}
		});
		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from engineeringscorecard where project ="
				+ "'" + str + "'" + " and  group_=('Agency Draughtperson') group by machine";

		List<MCShopDTO> agencyDraughtperson = jdbcTemplate.query(sql, new RowMapper<MCShopDTO>() {
			public MCShopDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				MCShopDTO mc = new MCShopDTO();
				mc.setName(rs.getString("machine"));
				mc.setCbl(rs.getInt("CBL"));
				mc.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				mc.setEac(rs.getInt("EAC"));
				return mc;
			}
		});
		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from engineeringscorecard where project ="
				+ "'" + str + "'" + " and  group_=('R&D Draughtsperson') group by machine";
		List<MCShopDTO> rdDraughtsperson = jdbcTemplate.query(sql, new RowMapper<MCShopDTO>() {
			public MCShopDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				MCShopDTO mc = new MCShopDTO();
				mc.setName(rs.getString("machine"));
				mc.setCbl(rs.getInt("CBL"));
				mc.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				mc.setEac(rs.getInt("EAC"));
				return mc;
			}
		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from engineeringscorecard where project ="
				+ "'" + str + "'" + " and  group_=('Draughtsperson') group by machine";
		List<MCShopDTO> draughtsperson = jdbcTemplate.query(sql, new RowMapper<MCShopDTO>() {
			public MCShopDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				MCShopDTO mc = new MCShopDTO();
				mc.setName(rs.getString("machine"));
				mc.setCbl(rs.getInt("CBL"));
				mc.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				mc.setEac(rs.getInt("EAC"));
				return mc;
			}
		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from engineeringscorecard where project ="
				+ "'" + str + "'" + " and  group_=('TOTAL') group by machine";
		List<MCShopDTO> total = jdbcTemplate.query(sql, new RowMapper<MCShopDTO>() {
			public MCShopDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				MCShopDTO mc = new MCShopDTO();
				mc.setName(rs.getString("machine"));
				mc.setCbl(rs.getInt("CBL"));
				mc.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				mc.setEac(rs.getInt("EAC"));
				return mc;
			}
		});
		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from engineeringscorecard where project ="
				+ "'" + str + "'" + " and  group_=('Technical Engineer') group by machine";
		List<MCShopDTO> technicalEngineer = jdbcTemplate.query(sql, new RowMapper<MCShopDTO>() {
			public MCShopDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				MCShopDTO mc = new MCShopDTO();
				mc.setName(rs.getString("machine"));
				mc.setCbl(rs.getInt("CBL"));
				mc.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				mc.setEac(rs.getInt("EAC"));
				return mc;
			}
		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from engineeringscorecard where project ="
				+ "'" + str + "'" + " and  group_=('PC India Bt in Serv') group by machine";
		List<MCShopDTO> pcIndiaBtinServ = jdbcTemplate.query(sql, new RowMapper<MCShopDTO>() {
			public MCShopDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				MCShopDTO mc = new MCShopDTO();
				mc.setName(rs.getString("machine"));
				mc.setCbl(rs.getInt("CBL"));
				mc.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				mc.setEac(rs.getInt("EAC"));
				return mc;
			}
		});

		return new EngineeringDTO(new TableEngineering(rdtechnicaleng, agencyDraughtperson, rdDraughtsperson,
				draughtsperson, total, technicalEngineer, pcIndiaBtinServ));

	}

	private String createSql(String str) {
		String[] strArray = str.split(",");
		String seg = "";
		for (int i = 0; i <= strArray.length; i++) {
			seg += "'" + strArray[i] + "'";
			if ((i + 1) == strArray.length) {
				break;
			} else if (i < strArray.length) {
				seg += ",";
			}
		}
		return seg;
	}

	public EngineeringGeneral1DTO getEngineeringAll(EngineeringGeneralDTO str) {

		String projectid = str.getProjectID();
		String projectmanager = str.getProjectManager();
		String[] machine = str.getCostType();
		List<String> regionFilters = Arrays.asList(machine);

		String region = "";

		int i = 0;
		for (String regionFilter : regionFilters) {

			region += regionFilter + ",";
		}

		String sql1 = createSql(region);

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from engineeringscorecard where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='R&D Technical Eng'";

		EngineeringGeneralFreeDTO rdtechnicalengList = jdbcTemplate.query(sql,
				new ResultSetExtractor<EngineeringGeneralFreeDTO>() {
					@Override
					public EngineeringGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						EngineeringGeneralFreeDTO engineeringGeneralFreeDTO = new EngineeringGeneralFreeDTO();
						// TODO Auto-generated method stub
						while (rs.next()) {
							engineeringGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							engineeringGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							engineeringGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return engineeringGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from engineeringscorecard where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='Agency Draughtperson'";

		EngineeringGeneralFreeDTO gencyDraughtpersonList = jdbcTemplate.query(sql,
				new ResultSetExtractor<EngineeringGeneralFreeDTO>() {
					@Override
					public EngineeringGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						EngineeringGeneralFreeDTO engineeringGeneralFreeDTO = new EngineeringGeneralFreeDTO();
						// TODO Auto-generated method stub
						while (rs.next()) {
							engineeringGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							engineeringGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							engineeringGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return engineeringGeneralFreeDTO;

					}
				});
		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from engineeringscorecard where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='R&D Draughtsperson'";

		EngineeringGeneralFreeDTO rdDraughtspersonList = jdbcTemplate.query(sql,
				new ResultSetExtractor<EngineeringGeneralFreeDTO>() {
					@Override
					public EngineeringGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						EngineeringGeneralFreeDTO engineeringGeneralFreeDTO = new EngineeringGeneralFreeDTO();
						// TODO Auto-generated method stub
						while (rs.next()) {
							engineeringGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							engineeringGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							engineeringGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return engineeringGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from engineeringscorecard where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='Draughtsperson'";
		EngineeringGeneralFreeDTO draughtspersonList = jdbcTemplate.query(sql,
				new ResultSetExtractor<EngineeringGeneralFreeDTO>() {
					@Override
					public EngineeringGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						EngineeringGeneralFreeDTO engineeringGeneralFreeDTO = new EngineeringGeneralFreeDTO();
						// TODO Auto-generated method stub
						while (rs.next()) {
							engineeringGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							engineeringGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							engineeringGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return engineeringGeneralFreeDTO;

					}
				});
		
		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from engineeringscorecard where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='Technical Engineer'";

		EngineeringGeneralFreeDTO technicalEngineer = jdbcTemplate.query(sql,
				new ResultSetExtractor<EngineeringGeneralFreeDTO>() {
					@Override
					public EngineeringGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						EngineeringGeneralFreeDTO engineeringGeneralFreeDTO = new EngineeringGeneralFreeDTO();
						// TODO Auto-generated method stub
						while (rs.next()) {
							engineeringGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							engineeringGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							engineeringGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return engineeringGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from engineeringscorecard where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='PC India Bt in Serv'";

		EngineeringGeneralFreeDTO pcIndiaBtinServ = jdbcTemplate.query(sql,
				new ResultSetExtractor<EngineeringGeneralFreeDTO>() {
					@Override
					public EngineeringGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						EngineeringGeneralFreeDTO engineeringGeneralFreeDTO = new EngineeringGeneralFreeDTO();
						// TODO Auto-generated method stub
						while (rs.next()) {
							engineeringGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							engineeringGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							engineeringGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return engineeringGeneralFreeDTO;

					}
				});
		
		return new EngineeringGeneral1DTO(
                new GeneralEngineeringDto(rdtechnicalengList.getSumsbl(), gencyDraughtpersonList.getSumsbl(),
                        rdDraughtspersonList.getSumsbl(), draughtspersonList.getSumsbl(), 
                        technicalEngineer.getSumsbl(), pcIndiaBtinServ.getSumsbl()),
                new GeneralEngineeringDto(rdtechnicalengList.getSumeac(), gencyDraughtpersonList.getSumeac(),
                        rdDraughtspersonList.getSumeac(), draughtspersonList.getSumeac(),
                        technicalEngineer.getSumeac(), pcIndiaBtinServ.getSumeac()),
                new GeneralEngineeringDto(rdtechnicalengList.getSumpeac(), gencyDraughtpersonList.getSumpeac(),
                        rdDraughtspersonList.getSumpeac(), draughtspersonList.getSumpeac(),
                        technicalEngineer.getSumpeac(), pcIndiaBtinServ.getSumpeac()));

    }

}


		