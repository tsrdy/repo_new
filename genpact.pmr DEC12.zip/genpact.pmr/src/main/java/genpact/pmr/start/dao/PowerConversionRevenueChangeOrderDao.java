package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.PCRCOProjectManagerDataDto;
import genpact.pmr.start.dto.PCRCORegion;
import genpact.pmr.start.dto.PCRCORegionDataDto;
import genpact.pmr.start.dto.PCRCProjectIdDataDto;
import genpact.pmr.start.dto.PCRevenueChangeOrderRequestJSONDataDto;
import genpact.pmr.start.dto.PCRevenueChangeOrderResponseJSONDataDto;

@Repository
public class PowerConversionRevenueChangeOrderDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public PCRevenueChangeOrderResponseJSONDataDto getAllDataByQuarter(PCRevenueChangeOrderRequestJSONDataDto requestJson) {
		
		PCRevenueChangeOrderResponseJSONDataDto responseJSON = new PCRevenueChangeOrderResponseJSONDataDto();

		// next filter

		String quarter = requestJson.getQuarter();
		
		String SQL_REGION = "select distinct(region) from revenue_change_order";
		List<FormatDataDto> regionList = getFormatDataList(SQL_REGION, "region");
		responseJSON.setNextfilterList(regionList);

		// for region
		String sqlInternal = "select sum("+quarter+") as quarter,region,regional_manager from  revenue_change_order where externalninternal='Internal' group by region,regional_manager";
		String sqlExternal = "select sum("+quarter+") as quarter,region,regional_manager from  revenue_change_order where externalninternal='External' group by region,regional_manager";

		List<PCRCORegionDataDto> regionInternalList = getInternalnExternalforRegion(sqlInternal);
		List<PCRCORegionDataDto> regionExternalList = getInternalnExternalforRegion(sqlExternal);

		List<PCRCORegionDataDto> calculatedRegionData = getCalculatedRegionData(regionInternalList, regionExternalList);
		responseJSON.setRegionList(calculatedRegionData);

		// for project manager
		String sqlPMInternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='Internal' group by region,regional_manager,project_manager";
		String sqlPMExternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='External' group by region,regional_manager,project_manager";

		List<PCRCOProjectManagerDataDto> pmInternal=getInternalnExternalforPM(sqlPMInternal);
		List<PCRCOProjectManagerDataDto> pmExternal=getInternalnExternalforPM(sqlPMExternal);
		
		List<PCRCOProjectManagerDataDto> calculatedPMData=getCalculatedPMData(pmInternal,pmExternal);
		responseJSON.setProjectManagerList(calculatedPMData);
		
		//for project Id
		String sqlPIDInternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='Internal' group by region,regional_manager,project_manager,project_id";
		String sqlPIDExternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='External' group by region,regional_manager,project_manager,project_id";

		List<PCRCProjectIdDataDto> pIdInternal=getInternalnExternalforPID(sqlPIDInternal);
		List<PCRCProjectIdDataDto> pIdExternal=getInternalnExternalforPID(sqlPIDExternal);
		
		List<PCRCProjectIdDataDto> calculatedPIdData=getCalculatedPIDData(pIdInternal,pIdExternal);
		responseJSON.setProjectIdList(calculatedPIdData);
		
		return responseJSON;

	}
	public PCRevenueChangeOrderResponseJSONDataDto getAllData() {

		PCRevenueChangeOrderResponseJSONDataDto responseJSON = new PCRevenueChangeOrderResponseJSONDataDto();

		// next filter

		String SQL_REGION = "select distinct(region) from revenue_change_order";
		List<FormatDataDto> regionList = getFormatDataList(SQL_REGION, "region");
		responseJSON.setNextfilterList(regionList);

		// for region
		String sqlInternal = "select sum(quar3) as quarter,region,regional_manager from  revenue_change_order where externalninternal='Internal' group by region,regional_manager";
		String sqlExternal = "select sum(quar3) as quarter,region,regional_manager from  revenue_change_order where externalninternal='External' group by region,regional_manager";

		List<PCRCORegionDataDto> regionInternalList = getInternalnExternalforRegion(sqlInternal);
		List<PCRCORegionDataDto> regionExternalList = getInternalnExternalforRegion(sqlExternal);

		List<PCRCORegionDataDto> calculatedRegionData = getCalculatedRegionData(regionInternalList, regionExternalList);
		responseJSON.setRegionList(calculatedRegionData);

		// for project manager
		String sqlPMInternal = "select sum(quar3) as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='Internal' group by region,regional_manager,project_manager";
		String sqlPMExternal = "select sum(quar3) as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='External' group by region,regional_manager,project_manager";

		List<PCRCOProjectManagerDataDto> pmInternal=getInternalnExternalforPM(sqlPMInternal);
		List<PCRCOProjectManagerDataDto> pmExternal=getInternalnExternalforPM(sqlPMExternal);
		
		List<PCRCOProjectManagerDataDto> calculatedPMData=getCalculatedPMData(pmInternal,pmExternal);
		responseJSON.setProjectManagerList(calculatedPMData);
		
		//for project Id
		String sqlPIDInternal = "select sum(quar3) as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='Internal' group by region,regional_manager,project_manager,project_id";
		String sqlPIDExternal = "select sum(quar3) as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='External' group by region,regional_manager,project_manager,project_id";

		List<PCRCProjectIdDataDto> pIdInternal=getInternalnExternalforPID(sqlPIDInternal);
		List<PCRCProjectIdDataDto> pIdExternal=getInternalnExternalforPID(sqlPIDExternal);
		
		List<PCRCProjectIdDataDto> calculatedPIdData=getCalculatedPIDData(pIdInternal,pIdExternal);
		responseJSON.setProjectIdList(calculatedPIdData);
		
		return responseJSON;

	}
	
	public PCRevenueChangeOrderResponseJSONDataDto getRegionData(PCRevenueChangeOrderRequestJSONDataDto requestJson) {

		PCRevenueChangeOrderResponseJSONDataDto responseJSON = new PCRevenueChangeOrderResponseJSONDataDto();
		

		String quarter = requestJson.getQuarter();
		List<FormatDataDto> regions = requestJson.getRegions();
		
		String regionFilterFormat = createSql(getFormatForSql(regions));
		// next filter

		String SQL_REGION = "select distinct(regional_manager) from revenue_change_order where region in("+regionFilterFormat+")";
		List<FormatDataDto> regionList = getFormatDataList(SQL_REGION, "regional_manager");
		responseJSON.setNextfilterList(regionList);

		// for region
		String sqlInternal = "select sum("+quarter+") as quarter,region,regional_manager from  revenue_change_order where externalninternal='Internal' and region in("+regionFilterFormat+") group by region,regional_manager";
		String sqlExternal = "select sum("+quarter+") as quarter,region,regional_manager from  revenue_change_order where externalninternal='External' and region in("+regionFilterFormat+")  group by region,regional_manager";

		List<PCRCORegionDataDto> regionInternalList = getInternalnExternalforRegion(sqlInternal);
		List<PCRCORegionDataDto> regionExternalList = getInternalnExternalforRegion(sqlExternal);

		List<PCRCORegionDataDto> calculatedRegionData = getCalculatedRegionData(regionInternalList, regionExternalList);
		responseJSON.setRegionList(calculatedRegionData);

		// for project manager
		String sqlPMInternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='Internal'  and region in("+regionFilterFormat+")  group by region,regional_manager,project_manager";
		String sqlPMExternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='External'  and region in("+regionFilterFormat+")  group by region,regional_manager,project_manager";

		List<PCRCOProjectManagerDataDto> pmInternal=getInternalnExternalforPM(sqlPMInternal);
		List<PCRCOProjectManagerDataDto> pmExternal=getInternalnExternalforPM(sqlPMExternal);
		
		List<PCRCOProjectManagerDataDto> calculatedPMData=getCalculatedPMData(pmInternal,pmExternal);
		responseJSON.setProjectManagerList(calculatedPMData);
		
		//for project Id
		String sqlPIDInternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='Internal' and region in("+regionFilterFormat+")  group by region,regional_manager,project_manager,project_id";
		String sqlPIDExternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='External' and region in("+regionFilterFormat+")  group by region,regional_manager,project_manager,project_id";

		List<PCRCProjectIdDataDto> pIdInternal=getInternalnExternalforPID(sqlPIDInternal);
		List<PCRCProjectIdDataDto> pIdExternal=getInternalnExternalforPID(sqlPIDExternal);
		
		List<PCRCProjectIdDataDto> calculatedPIdData=getCalculatedPIDData(pIdInternal,pIdExternal);
		responseJSON.setProjectIdList(calculatedPIdData);
		
		return responseJSON;

	}
	
	
	public PCRevenueChangeOrderResponseJSONDataDto getRegionalManagerData(PCRevenueChangeOrderRequestJSONDataDto requestJson) {

		PCRevenueChangeOrderResponseJSONDataDto responseJSON = new PCRevenueChangeOrderResponseJSONDataDto();
		

		String quarter = requestJson.getQuarter();
		List<FormatDataDto> regions = requestJson.getRegions();
		List<FormatDataDto> regionalManager = requestJson.getRegionalManagers();
		
		String regionFilterFormat = createSql(getFormatForSql(regions));
		String regionalManagerFilterFormat = createSql(getFormatForSql(regionalManager));
		// next filter

		String SQL_REGION = "select distinct(project_manager) from revenue_change_order where region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+")";
		List<FormatDataDto> regionList = getFormatDataList(SQL_REGION, "project_manager");
		responseJSON.setNextfilterList(regionList);

		// for region
		String sqlInternal = "select sum("+quarter+") as quarter,region,regional_manager from  revenue_change_order where externalninternal='Internal' and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") group by region,regional_manager";
		String sqlExternal = "select sum("+quarter+") as quarter,region,regional_manager from  revenue_change_order where externalninternal='External' and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") group by region,regional_manager";

		List<PCRCORegionDataDto> regionInternalList = getInternalnExternalforRegion(sqlInternal);
		List<PCRCORegionDataDto> regionExternalList = getInternalnExternalforRegion(sqlExternal);

		List<PCRCORegionDataDto> calculatedRegionData = getCalculatedRegionData(regionInternalList, regionExternalList);
		responseJSON.setRegionList(calculatedRegionData);

		// for project manager
		String sqlPMInternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='Internal'  and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+")  group by region,regional_manager,project_manager";
		String sqlPMExternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='External'  and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+")  group by region,regional_manager,project_manager";

		List<PCRCOProjectManagerDataDto> pmInternal=getInternalnExternalforPM(sqlPMInternal);
		List<PCRCOProjectManagerDataDto> pmExternal=getInternalnExternalforPM(sqlPMExternal);
		
		List<PCRCOProjectManagerDataDto> calculatedPMData=getCalculatedPMData(pmInternal,pmExternal);
		responseJSON.setProjectManagerList(calculatedPMData);
		
		//for project Id
		String sqlPIDInternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='Internal' and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") group by region,regional_manager,project_manager,project_id";
		String sqlPIDExternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='External' and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") group by region,regional_manager,project_manager,project_id";

		List<PCRCProjectIdDataDto> pIdInternal=getInternalnExternalforPID(sqlPIDInternal);
		List<PCRCProjectIdDataDto> pIdExternal=getInternalnExternalforPID(sqlPIDExternal);
		
		List<PCRCProjectIdDataDto> calculatedPIdData=getCalculatedPIDData(pIdInternal,pIdExternal);
		responseJSON.setProjectIdList(calculatedPIdData);
		
		return responseJSON;

	}
	//================
	
	public PCRevenueChangeOrderResponseJSONDataDto getProjectManagerData(PCRevenueChangeOrderRequestJSONDataDto requestJson) {

		PCRevenueChangeOrderResponseJSONDataDto responseJSON = new PCRevenueChangeOrderResponseJSONDataDto();
		

		String quarter = requestJson.getQuarter();
		List<FormatDataDto> regions = requestJson.getRegions();
		List<FormatDataDto> regionalManager = requestJson.getRegionalManagers();
		List<FormatDataDto> projectManager = requestJson.getProjectManagers();
		
		String regionFilterFormat = createSql(getFormatForSql(regions));
		String regionalManagerFilterFormat = createSql(getFormatForSql(regionalManager));
		String projectManagerFilterFormat = createSql(getFormatForSql(projectManager));
		// next filter

		/*String SQL_REGION = "select distinct(project_manager) from revenue_change_order";
		List<FormatDataDto> regionList = getFormatDataList(SQL_REGION, "project_manager");
		responseJSON.setNextfilterList(regionList);
*/
		// for region
		String sqlInternal = "select sum("+quarter+") as quarter,region,regional_manager from  revenue_change_order where externalninternal='Internal' and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") and project_manager in("+projectManagerFilterFormat+") group by region,regional_manager";
		String sqlExternal = "select sum("+quarter+") as quarter,region,regional_manager from  revenue_change_order where externalninternal='External' and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") and project_manager in("+projectManagerFilterFormat+") group by region,regional_manager";

		List<PCRCORegionDataDto> regionInternalList = getInternalnExternalforRegion(sqlInternal);
		List<PCRCORegionDataDto> regionExternalList = getInternalnExternalforRegion(sqlExternal);

		List<PCRCORegionDataDto> calculatedRegionData = getCalculatedRegionData(regionInternalList, regionExternalList);
		responseJSON.setRegionList(calculatedRegionData);

		// for project manager
		String sqlPMInternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='Internal'  and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") and project_manager in("+projectManagerFilterFormat+")  group by region,regional_manager,project_manager";
		String sqlPMExternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager from  revenue_change_order where externalninternal='External'  and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") and project_manager in("+projectManagerFilterFormat+")  group by region,regional_manager,project_manager";

		List<PCRCOProjectManagerDataDto> pmInternal=getInternalnExternalforPM(sqlPMInternal);
		List<PCRCOProjectManagerDataDto> pmExternal=getInternalnExternalforPM(sqlPMExternal);
		
		List<PCRCOProjectManagerDataDto> calculatedPMData=getCalculatedPMData(pmInternal,pmExternal);
		responseJSON.setProjectManagerList(calculatedPMData);
		
		//for project Id
		String sqlPIDInternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='Internal' and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") and project_manager in("+projectManagerFilterFormat+") group by region,regional_manager,project_manager,project_id";
		String sqlPIDExternal = "select sum("+quarter+") as quarter,region,regional_manager,project_manager,project_id from  revenue_change_order where externalninternal='External' and region in("+regionFilterFormat+") and regional_manager in("+regionalManagerFilterFormat+") and project_manager in("+projectManagerFilterFormat+") group by region,regional_manager,project_manager,project_id";

		List<PCRCProjectIdDataDto> pIdInternal=getInternalnExternalforPID(sqlPIDInternal);
		List<PCRCProjectIdDataDto> pIdExternal=getInternalnExternalforPID(sqlPIDExternal);
		
		List<PCRCProjectIdDataDto> calculatedPIdData=getCalculatedPIDData(pIdInternal,pIdExternal);
		responseJSON.setProjectIdList(calculatedPIdData);
		
		return responseJSON;

	}
	
	private List<PCRCProjectIdDataDto> getCalculatedPIDData(List<PCRCProjectIdDataDto> internal,
			List<PCRCProjectIdDataDto> external) {

		Map<String, PCRCProjectIdDataDto> map = new HashMap<>();
		List<PCRCProjectIdDataDto> reg = new ArrayList<>();

		String key = "";
		for (PCRCProjectIdDataDto pp : internal) {
			key = pp.getRegion() + "," + pp.getRegionalManager()+","+pp.getProjectManager()+","+pp.getProjectId();

			map.put(key, pp);
		}

		key = "";

		for (PCRCProjectIdDataDto pp : external) {
			key = pp.getRegion() + "," + pp.getRegionalManager()+","+pp.getProjectManager()+","+pp.getProjectId();

			if (map.containsKey(key)) {

				PCRCProjectIdDataDto oo = map.get(key);
				oo.setExternalSales(pp.getInternalSales());// here internal is
															// external in
															// jdbcTemplate
			} else {
				pp.setExternalSales(pp.getInternalSales());
				pp.setInternalSales(0.0);
				map.put(key, pp);
			}
		}

		for (String key1 : map.keySet()) {

			reg.add(map.get(key1));
		}

		return reg;
	}

	
	private List<PCRCProjectIdDataDto> getInternalnExternalforPID(String sql) {

		return jdbcTemplate.query(sql, new RowMapper<PCRCProjectIdDataDto>() {

			@Override
			public PCRCProjectIdDataDto mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return new PCRCProjectIdDataDto(rs.getString("region"),rs.getString("project_id"), rs.getString("regional_manager"), rs.getString("project_manager"), rs.getDouble("quarter"), 0.0d); 
			}

		});
	}

	private List<PCRCOProjectManagerDataDto> getCalculatedPMData(List<PCRCOProjectManagerDataDto> internal,
			List<PCRCOProjectManagerDataDto> external) {

		Map<String, PCRCOProjectManagerDataDto> map = new HashMap<>();
		List<PCRCOProjectManagerDataDto> reg = new ArrayList<>();

		String key = "";
		for (PCRCOProjectManagerDataDto pp : internal) {
			key = pp.getRegion() + "," + pp.getRegionalManager()+","+pp.getProjectManager();

			map.put(key, pp);
		}

		key = "";

		for (PCRCOProjectManagerDataDto pp : external) {
			key = pp.getRegion() + "," + pp.getRegionalManager()+","+pp.getProjectManager();

			if (map.containsKey(key)) {

				PCRCOProjectManagerDataDto oo = map.get(key);
				oo.setExternalSales(pp.getInternalSales());// here internal is
															// external in
															// jdbcTemplate
			} else {
				pp.setExternalSales(pp.getInternalSales());
				pp.setInternalSales(0.0);
				map.put(key, pp);
			}
		}

		for (String key1 : map.keySet()) {

			reg.add(map.get(key1));
		}

		return reg;
	}

	private List<PCRCORegionDataDto> getCalculatedRegionData(List<PCRCORegionDataDto> internal,
			List<PCRCORegionDataDto> external) {

		Map<String, PCRCORegionDataDto> map = new HashMap<>();
		List<PCRCORegionDataDto> reg = new ArrayList<>();

		String key = "";
		for (PCRCORegionDataDto pp : internal) {
			key = pp.getRegion() + "," + pp.getRegionalManager();

			map.put(key, pp);
		}

		key = "";

		for (PCRCORegionDataDto pp : external) {
			key = pp.getRegion() + "," + pp.getRegionalManager();

			if (map.containsKey(key)) {

				PCRCORegionDataDto oo = map.get(key);
				oo.setExternalSales(pp.getInternalSales());// here internal is
															// external in
															// jdbcTemplate
			} else {
				pp.setExternalSales(pp.getInternalSales());
				pp.setInternalSales(0.0);
				map.put(key, pp);
			}
		}

		for (String key1 : map.keySet()) {

			reg.add(map.get(key1));
		}

		return reg;
	}
	
	private List<PCRCOProjectManagerDataDto> getInternalnExternalforPM(String sql) {

		return jdbcTemplate.query(sql, new RowMapper<PCRCOProjectManagerDataDto>() {

			@Override
			public PCRCOProjectManagerDataDto mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return new PCRCOProjectManagerDataDto(rs.getString("region"), rs.getString("regional_manager"), rs.getString("project_manager"), rs.getDouble("quarter"), 0.0d); 
			}

		});
	}


	private List<PCRCORegionDataDto> getInternalnExternalforRegion(String sql) {

		return jdbcTemplate.query(sql, new RowMapper<PCRCORegionDataDto>() {

			@Override
			public PCRCORegionDataDto mapRow(ResultSet rs, int arg1) throws SQLException {
				// TODO Auto-generated method stub
				return new PCRCORegionDataDto(rs.getString("region"), rs.getString("regional_manager"),
						rs.getDouble("quarter"), 0.0d);
			}

		});
	}



	private List<FormatDataDto> getFormatDataList(String sql, String columnName) {
		List<FormatDataDto> formatDataDtos = null;

		formatDataDtos = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {

			int count;

			@Override
			public FormatDataDto mapRow(ResultSet rs, int rowCount) throws SQLException {
				// TODO Auto-generated method stub
				return new FormatDataDto(++count, rs.getString(columnName));
			}

		});
		return formatDataDtos;
	}

	private List<PCRCORegion> getRegionDataList(String sql, String quarter) {

		return jdbcTemplate.query(sql, new RowMapper<PCRCORegion>() {

			@Override
			public PCRCORegion mapRow(ResultSet rs, int rowCount) throws SQLException {
				return new PCRCORegion(rs.getString("region"), rs.getString("regional_manager"),
						rs.getString("externalninternal"), rs.getString("project_id"), rs.getString("project_manager"),
						Double.parseDouble(rs.getString(quarter)));
			}

		});
	}

	private String getFormatForSql(List<FormatDataDto> regionFilters) {

		String regions = "";

		int i = 0;
		for (FormatDataDto regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				regions += regionFilter.getLabel() + ",";

				break;
			} else if (i < regionFilters.size()) {
				regions += regionFilter.getLabel() + ",";

			}
			i++;
		}
		return regions;
	}

	private String createSql(String str) {
		String[] strArray = str.split(",");

		String seg = "";

		for (int i = 0; i <= strArray.length; i++) {

			seg += "'" + strArray[i] + "'";

			if ((i + 1) == strArray.length) {
				break;
			} else if (i < strArray.length) {
				seg += ",";
			}
		}

		System.out.println(seg);
		return seg;
	}
}
