package genpact.pmr.start.dto;

import java.util.List;

public class BillingChartJDto {
	private List<Double> billing_value;
	private List<String> billing_date;
	public List<Double> getBilling_value() {
		return billing_value;
	}
	public void setBilling_value(List<Double> billing_value) {
		this.billing_value = billing_value;
	}
	public List<String> getBilling_date() {
		return billing_date;
	}
	public void setBilling_date(List<String> billing_date) {
		this.billing_date = billing_date;
	}
	public BillingChartJDto(List<Double> billing_value, List<String> billing_date) {
		super();
		this.billing_value = billing_value;
		this.billing_date = billing_date;
	}
	public BillingChartJDto() {
		super();
	}
}
