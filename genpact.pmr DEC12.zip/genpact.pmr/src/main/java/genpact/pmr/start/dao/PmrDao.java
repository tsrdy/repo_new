package genpact.pmr.start.dao;

import java.awt.List;

public class PmrDao {
	public class PmrList {
		private List pmrList;

		public List getPmrList() {
			return pmrList;
		}

		public void setPmrList(List pmrList) {
			this.pmrList = pmrList;
		}

		public PmrList(List pmrList) {
			super();
			this.pmrList = pmrList;
		}

		public PmrList() {
			super();
			// TODO Auto-generated constructor stub
		}
	}
}
