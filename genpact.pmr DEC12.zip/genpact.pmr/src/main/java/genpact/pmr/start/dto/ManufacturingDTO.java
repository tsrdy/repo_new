package genpact.pmr.start.dto;

import java.util.List;

public class ManufacturingDTO {

	List<FormatDataDto> formatDataDto;
	
	
	public ManufacturingDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public List<FormatDataDto> getFormatDataDto() {
		return formatDataDto;
	}
	public void setFormatDataDto(List<FormatDataDto> formatDataDto) {
		this.formatDataDto = formatDataDto;
	}
	

	

}
