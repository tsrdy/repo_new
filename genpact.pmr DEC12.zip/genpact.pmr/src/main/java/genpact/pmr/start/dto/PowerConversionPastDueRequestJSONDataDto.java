package genpact.pmr.start.dto;

import java.util.List;

public class PowerConversionPastDueRequestJSONDataDto {

	
	private List<FormatDataDto> billingQuarterFilters;
	private List<FormatDataDto> regionFilters;
	private List<FormatDataDto> regionalManagerFilter;
	private List<FormatDataDto> projectManagerFilters;
	public PowerConversionPastDueRequestJSONDataDto() {
		
		super();
		// TODO Auto-generated constructor stub
	}
	public List<FormatDataDto> getBillingQuarterFilters() {
		return billingQuarterFilters;
	}
	public void setBillingQuarterFilters(List<FormatDataDto> billingQuarterFilters) {
		this.billingQuarterFilters = billingQuarterFilters;
	}
	public List<FormatDataDto> getRegionFilters() {
		return regionFilters;
	}
	public void setRegionFilters(List<FormatDataDto> regionFilters) {
		this.regionFilters = regionFilters;
	}
	public List<FormatDataDto> getRegionalManagerFilter() {
		return regionalManagerFilter;
	}
	public void setRegionalManagerFilter(List<FormatDataDto> regionalManagerFilter) {
		this.regionalManagerFilter = regionalManagerFilter;
	}
	public List<FormatDataDto> getProjectManagerFilters() {
		return projectManagerFilters;
	}
	public void setProjectManagerFilters(List<FormatDataDto> projectManagerFilters) {
		this.projectManagerFilters = projectManagerFilters;
	}
	@Override
	public String toString() {
		return "PowerConversionPastDueDaoRequestJSONDataDto [billingQuarterFilters=" + billingQuarterFilters
				+ ", regionFilters=" + regionFilters + ", regionalManagerFilter=" + regionalManagerFilter
				+ ", projectManagerFilters=" + projectManagerFilters + "]";
	}
}
