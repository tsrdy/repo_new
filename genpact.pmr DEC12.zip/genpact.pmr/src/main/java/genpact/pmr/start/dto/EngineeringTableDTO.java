package genpact.pmr.start.dto;

import java.util.List;

public class EngineeringTableDTO {
	
	
	List<FormatDataDto> formatDataDto;

	public List<FormatDataDto> getFormatDataDto() {
		return formatDataDto;
	}

	public void setFormatDataDto(List<FormatDataDto> formatDataDto) {
		this.formatDataDto = formatDataDto;
	}

	
	
	

}
