package genpact.pmr.start.dto;

import java.util.List;

public class MaufacturingGeneral1DTO {
	
	
	private GeneralManufacturingDto cBL;
	
	private GeneralManufacturingDto eAC;
	
	private GeneralManufacturingDto pEAC;
	
	public GeneralManufacturingDto getcBL() {
		return cBL;
	}

	public void setcBL(GeneralManufacturingDto cBL) {
		this.cBL = cBL;
	}

	public MaufacturingGeneral1DTO(GeneralManufacturingDto cBL, GeneralManufacturingDto eAC,
			GeneralManufacturingDto pEAC) {
		super();
		this.cBL = cBL;
		this.eAC = eAC;
		this.pEAC = pEAC;
	}

	public GeneralManufacturingDto geteAC() {
		return eAC;
	}

	public void seteAC(GeneralManufacturingDto eAC) {
		this.eAC = eAC;
	}

	public GeneralManufacturingDto getpEAC() {
		return pEAC;
	}

	public void setpEAC(GeneralManufacturingDto pEAC) {
		this.pEAC = pEAC;
	}

	

}
