package genpact.pmr.start.dto;

import java.util.List;

public class BillingJSONDataDto {
	private List<FormatDataDto> formatDataDtos;
	private List<BillingTableDataDto>  billingTableDataDtos;
	//private BillingChartJDto billingChartDto;//================
	private List<Long> billingValues;
	List<BillingTimelineDTO> billingTimelineDTOs;
	private long billingtotal;
	ColourIndex colourIndex;
	
	public List<FormatDataDto> getFormatDataDtos() {
		return formatDataDtos;
	}
	public void setFormatDataDtos(List<FormatDataDto> formatDataDtos) {
		this.formatDataDtos = formatDataDtos;
	}
	public List<BillingTableDataDto> getBillingTableDataDtos() {
		return billingTableDataDtos;
	}
	public void setBillingTableDataDtos(List<BillingTableDataDto> billingTableDataDtos) {
		this.billingTableDataDtos = billingTableDataDtos;
	}
	
	public List<BillingTimelineDTO> getBillingTimelineDTOs() {
		return billingTimelineDTOs;
	}
	public void setBillingTimelineDTOs(List<BillingTimelineDTO> billingTimelineDTOs) {
		this.billingTimelineDTOs = billingTimelineDTOs;
	}
	public List<Long> getBillingValues() {
		return billingValues;
	}
	public void setBillingValues(List<Long> billingValues) {
		this.billingValues = billingValues;
	}
	
	public ColourIndex getColourIndex() {
		return colourIndex;
	}
	public void setColourIndex(ColourIndex colourIndex) {
		this.colourIndex = colourIndex;
	}
	
	public long getBillingtotal() {
		return billingtotal;
	}
	public void setBillingtotal(long billingtotal) {
		this.billingtotal = billingtotal;
	}
	public BillingJSONDataDto(List<FormatDataDto> formatDataDtos, List<BillingTableDataDto> billingTableDataDtos,
			List<Long> billingValues, List<BillingTimelineDTO> billingTimelineDTOs) {
		super();
		this.formatDataDtos = formatDataDtos;
		this.billingTableDataDtos = billingTableDataDtos;
		this.billingValues = billingValues;
		this.billingTimelineDTOs = billingTimelineDTOs;
	}
	public BillingJSONDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "BillingJSONDataDto [formatDataDtos=" + formatDataDtos + ", billingTableDataDtos=" + billingTableDataDtos
				+ ", billingValues=" + billingValues + ", billingTimelineDTOs=" + billingTimelineDTOs + ", colourIndex="
				+ colourIndex + "]";
	}
	

	
}
