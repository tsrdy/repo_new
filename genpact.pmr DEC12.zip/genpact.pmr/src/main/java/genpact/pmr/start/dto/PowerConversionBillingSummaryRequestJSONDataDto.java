package genpact.pmr.start.dto;

import java.util.List;

public class PowerConversionBillingSummaryRequestJSONDataDto {
	
	private List<FormatDataDto> billingQuarterFilters;
	private List<FormatDataDto> regionFilters;
	private List<FormatDataDto> regionalManagerFilter;
	private List<FormatDataDto> projectManagerFilters;
	public List<FormatDataDto> getBillingQuarterFilters() {
		return billingQuarterFilters;
	}
	public void setBillingQuarterFilters(List<FormatDataDto> billingQuarterFilters) {
		this.billingQuarterFilters = billingQuarterFilters;
	}
	public List<FormatDataDto> getRegionFilters() {
		return regionFilters;
	}
	public void setRegionFilters(List<FormatDataDto> regionFilters) {
		this.regionFilters = regionFilters;
	}
	public List<FormatDataDto> getRegionalManagerFilter() {
		return regionalManagerFilter;
	}
	public void setRegionalManagerFilter(List<FormatDataDto> regionalManagerFilter) {
		this.regionalManagerFilter = regionalManagerFilter;
	}
	public List<FormatDataDto> getProjectManagerFilters() {
		return projectManagerFilters;
	}
	public void setProjectManagerFilters(List<FormatDataDto> projectManagerFilters) {
		this.projectManagerFilters = projectManagerFilters;
	}
	public PowerConversionBillingSummaryRequestJSONDataDto(List<FormatDataDto> billingQuarterFilters,
			List<FormatDataDto> regionFilters, List<FormatDataDto> regionalManagerFilter,
			List<FormatDataDto> projectManagerFilters) {
		super();
		this.billingQuarterFilters = billingQuarterFilters;
		this.regionFilters = regionFilters;
		this.regionalManagerFilter = regionalManagerFilter;
		this.projectManagerFilters = projectManagerFilters;
	}
	public PowerConversionBillingSummaryRequestJSONDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
