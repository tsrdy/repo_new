package genpact.pmr.start.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.RiskAndOpportunityDao;
import genpact.pmr.start.dto.RiskAndOpportunityRequestJson;
import genpact.pmr.start.dto.RiskAndOpportunityResponseJSON;

@CrossOrigin
@RestController
public class RiskAndOpportunityService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private RiskAndOpportunityDao riskAndOpportunityDao;

	// just to check
	@RequestMapping(value = "/riskandopportunity", method = RequestMethod.GET)
	public String msg() {
		return "Running Succesfully";
	}

	// To retrive info
	@RequestMapping(value = "/getriskandopportunity", method = RequestMethod.GET)
	public RiskAndOpportunityResponseJSON getInfo() {

		RiskAndOpportunityResponseJSON riskAndOpportunityResponseJSON = null;

		riskAndOpportunityResponseJSON = riskAndOpportunityDao.getAllData();

		return riskAndOpportunityResponseJSON;

	}

	@RequestMapping(value = "/getriskandopportunity/region", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public RiskAndOpportunityResponseJSON getRegionData(@RequestBody RiskAndOpportunityRequestJson[] requestFilterArr) {

		return riskAndOpportunityDao.getRegionData(requestFilterArr[0]);
	}

	@RequestMapping(value = "/getriskandopportunity/region/pm", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public RiskAndOpportunityResponseJSON getPmData(@RequestBody RiskAndOpportunityRequestJson[] requestFilterArr) {

		return riskAndOpportunityDao.getProjectManagerData(requestFilterArr[0]);
	}
	
	@RequestMapping(value = "/getriskandopportunity/region/pm/market", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public RiskAndOpportunityResponseJSON getMarketData(@RequestBody RiskAndOpportunityRequestJson[] requestFilterArr) {

		return riskAndOpportunityDao.getMarketData(requestFilterArr[0]);
	}
	
	@RequestMapping(value = "/getriskandopportunity/region/pm/market/jobnumber", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public RiskAndOpportunityResponseJSON getJobNomberData(@RequestBody RiskAndOpportunityRequestJson[] requestFilterArr) {

		return riskAndOpportunityDao.getJobNumberData(requestFilterArr[0]);
	}
	
	@RequestMapping(value = "/getriskandopportunity/region/pm/market/jobnumber/jobname", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public RiskAndOpportunityResponseJSON getJobNameData(@RequestBody RiskAndOpportunityRequestJson[] requestFilterArr) {

		return riskAndOpportunityDao.getJobNameData(requestFilterArr[0]);
	}
}
