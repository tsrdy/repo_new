package genpact.pmr.start.dto;

import java.util.List;


public class SchedulingDto {
	
	List<FormatDataDto> formatDataDtos;
	List<ActivityStatusDto> activityStatusList; 
	List<SchTableDataDTO> schTableDataDTOList;
	List<ActivityOTDStatusDto> activityOTDStatusDtoList;
	
	
	public List<FormatDataDto> getFormatDataDtos() {
		return formatDataDtos;
	}
	public void setFormatDataDtos(List<FormatDataDto> formatDataDtos) {
		this.formatDataDtos = formatDataDtos;
	}
	public List<ActivityStatusDto> getActivityStatusList() {
		return activityStatusList;
	}
	public void setActivityStatusList(List<ActivityStatusDto> activityStatusList) {
		this.activityStatusList = activityStatusList;
	}
	public List<SchTableDataDTO> getSchTableDataDTOList() {
		return schTableDataDTOList;
	}
	public void setSchTableDataDTOList(List<SchTableDataDTO> schTableDataDTOList) {
		this.schTableDataDTOList = schTableDataDTOList;
	}
	public List<ActivityOTDStatusDto> getActivityOTDStatusDtoList() {
		return activityOTDStatusDtoList;
	}
	public void setActivityOTDStatusDtoList(List<ActivityOTDStatusDto> activityOTDStatusDtoList) {
		this.activityOTDStatusDtoList = activityOTDStatusDtoList;
	}
	public SchedulingDto(List<ActivityStatusDto> activityStatusList, List<SchTableDataDTO> schTableDataDTOList,List<ActivityOTDStatusDto> activityOTDStatusDtoList) {
		super();
		this.activityStatusList = activityStatusList;
		this.schTableDataDTOList = schTableDataDTOList;
		this.activityOTDStatusDtoList = activityOTDStatusDtoList;
	}
	
	public SchedulingDto(List<ActivityOTDStatusDto> activityOTDStatusDtoList) {
		super();
		this.activityOTDStatusDtoList = activityOTDStatusDtoList;
	}
	public SchedulingDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "SchedulingDto [formatDataDtos=" + formatDataDtos + ", activityStatusList=" + activityStatusList
				+ ", schTableDataDTOList=" + schTableDataDTOList + ", activityOTDStatusDtoList="
				+ activityOTDStatusDtoList + "]";
	}
	
	

}
