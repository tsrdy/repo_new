package genpact.pmr.start.dto;

import java.util.List;

public class TableManufacturing {

	List<MCShopDTO> mcDto;
	List<LampressDTO> lampressDTO;
	List<PinventDTO> pinventDTO;
	List<RotorDTO> rotorDTO;
	List<StatcoreDTO> statcoreDTO;
	List<CoilsDTO> coilsDTO;
	List<CopperDTO> copperDTO;
	List<StatwindDTO> statwindDTO;
	List<VpiDTO> vpiDTO;
	List<AssemblyDTO> assemblyDTO;
	List<TestDTO> testDTO;
	List<TotalDTO> totalDTO;

	public TableManufacturing() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<MCShopDTO> getMcDto() {
		return mcDto;
	}

	public void setMcDto(List<MCShopDTO> mcDto) {
		this.mcDto = mcDto;
	}

	public List<LampressDTO> getLampressDTO() {
		return lampressDTO;
	}

	public void setLampressDTO(List<LampressDTO> lampressDTO) {
		this.lampressDTO = lampressDTO;
	}

	public List<PinventDTO> getPinventDTO() {
		return pinventDTO;
	}

	public void setPinventDTO(List<PinventDTO> pinventDTO) {
		this.pinventDTO = pinventDTO;
	}

	public List<RotorDTO> getRotorDTO() {
		return rotorDTO;
	}

	public void setRotorDTO(List<RotorDTO> rotorDTO) {
		this.rotorDTO = rotorDTO;
	}

	public List<StatcoreDTO> getStatcoreDTO() {
		return statcoreDTO;
	}

	public void setStatcoreDTO(List<StatcoreDTO> statcoreDTO) {
		this.statcoreDTO = statcoreDTO;
	}

	public List<CoilsDTO> getCoilsDTO() {
		return coilsDTO;
	}

	public void setCoilsDTO(List<CoilsDTO> coilsDTO) {
		this.coilsDTO = coilsDTO;
	}

	public List<CopperDTO> getCopperDTO() {
		return copperDTO;
	}

	public void setCopperDTO(List<CopperDTO> copperDTO) {
		this.copperDTO = copperDTO;
	}

	public List<StatwindDTO> getStatwindDTO() {
		return statwindDTO;
	}

	public void setStatwindDTO(List<StatwindDTO> statwindDTO) {
		this.statwindDTO = statwindDTO;
	}

	public List<VpiDTO> getVpiDTO() {
		return vpiDTO;
	}

	public void setVpiDTO(List<VpiDTO> vpiDTO) {
		this.vpiDTO = vpiDTO;
	}

	public List<AssemblyDTO> getAssemblyDTO() {
		return assemblyDTO;
	}

	public void setAssemblyDTO(List<AssemblyDTO> assemblyDTO) {
		this.assemblyDTO = assemblyDTO;
	}

	public List<TestDTO> getTestDTO() {
		return testDTO;
	}

	public void setTestDTO(List<TestDTO> testDTO) {
		this.testDTO = testDTO;
	}

	public TableManufacturing(List<MCShopDTO> mcDto, List<LampressDTO> lampressDTO, List<PinventDTO> pinventDTO,
			List<RotorDTO> rotorDTO, List<StatcoreDTO> statcoreDTO, List<CoilsDTO> coilsDTO, List<CopperDTO> copperDTO,
			List<StatwindDTO> statwindDTO, List<VpiDTO> vpiDTO, List<AssemblyDTO> assemblyDTO, List<TestDTO> testDTO,
			List<TotalDTO> totalDTO) {
		super();
		this.mcDto = mcDto;
		this.lampressDTO = lampressDTO;
		this.pinventDTO = pinventDTO;
		this.rotorDTO = rotorDTO;
		this.statcoreDTO = statcoreDTO;
		this.coilsDTO = coilsDTO;
		this.copperDTO = copperDTO;
		this.statwindDTO = statwindDTO;
		this.vpiDTO = vpiDTO;
		this.assemblyDTO = assemblyDTO;
		this.testDTO = testDTO;
		this.totalDTO = totalDTO;
	}

	public List<TotalDTO> getTotalDTO() {
		return totalDTO;
	}

	public void setTotalDTO(List<TotalDTO> totalDTO) {
		this.totalDTO = totalDTO;
	}


}
