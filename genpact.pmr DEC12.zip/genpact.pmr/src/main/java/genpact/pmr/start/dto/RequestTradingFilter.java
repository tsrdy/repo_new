package genpact.pmr.start.dto;

import java.util.List;

public class RequestTradingFilter {
	List<RegionFilter> regionFilters;
	List<ProjectIdFilter> projectIdFilters;
	List<ProjectManagerFilter> projectManagerFilters;
	List<FormatDataDto> granularity; 
	
	public RequestTradingFilter() {
		super();
		// TODO Auto-generated constructor stub
	}
	public List<RegionFilter> getRegionFilters() {
		return regionFilters;
	}
	public void setRegionFilters(List<RegionFilter> regionFilters) {
		this.regionFilters = regionFilters;
	}
	public List<ProjectIdFilter> getProjectIdFilters() {
		return projectIdFilters;
	}
	public void setProjectIdFilters(List<ProjectIdFilter> projectIdFilters) {
		this.projectIdFilters = projectIdFilters;
	}
	
	public List<FormatDataDto> getGranularity() {
		return granularity;
	}
	public void setGranularity(List<FormatDataDto> granularity) {
		this.granularity = granularity;
	}
	public RequestTradingFilter(List<RegionFilter> regionFilters, List<ProjectIdFilter> projectIdFilters,
			List<ProjectManagerFilter> projectManagerFilters) {
		super();
		this.regionFilters = regionFilters;
		this.projectIdFilters = projectIdFilters;
		this.projectManagerFilters = projectManagerFilters;
	}
	public List<ProjectManagerFilter> getProjectManagerFilters() {
		return projectManagerFilters;
	}
	public void setProjectManagerFilters(List<ProjectManagerFilter> projectManagerFilters) {
		this.projectManagerFilters = projectManagerFilters;
	}

}
