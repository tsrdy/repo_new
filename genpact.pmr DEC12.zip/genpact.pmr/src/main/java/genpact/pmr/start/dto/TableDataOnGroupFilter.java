package genpact.pmr.start.dto;

import java.util.List;

public class TableDataOnGroupFilter {
	List<RegionFilter> regionFilters;
	List<ProjectIdFilter> projectIdFilters;
	List<ProjectManagerFilter> projectManagerFilters;
	List<FormatDataDto> group; 
	
	public TableDataOnGroupFilter() {
		super();
		// TODO Auto-generated constructor stub
	}
	public List<FormatDataDto> getGroup() {
		return group;
	}
	public void setGroup(List<FormatDataDto> group) {
		this.group = group;
	}
	public List<RegionFilter> getRegionFilters() {
		return regionFilters;
	}
	public void setRegionFilters(List<RegionFilter> regionFilters) {
		this.regionFilters = regionFilters;
	}
	public List<ProjectIdFilter> getProjectIdFilters() {
		return projectIdFilters;
	}
	public void setProjectIdFilters(List<ProjectIdFilter> projectIdFilters) {
		this.projectIdFilters = projectIdFilters;
	}
	
	
	public TableDataOnGroupFilter(List<RegionFilter> regionFilters, List<ProjectIdFilter> projectIdFilters,
			List<ProjectManagerFilter> projectManagerFilters) {
		super();
		this.regionFilters = regionFilters;
		this.projectIdFilters = projectIdFilters;
		this.projectManagerFilters = projectManagerFilters;
	}
	public List<ProjectManagerFilter> getProjectManagerFilters() {
		return projectManagerFilters;
	}
	public void setProjectManagerFilters(List<ProjectManagerFilter> projectManagerFilters) {
		this.projectManagerFilters = projectManagerFilters;
	}

}
