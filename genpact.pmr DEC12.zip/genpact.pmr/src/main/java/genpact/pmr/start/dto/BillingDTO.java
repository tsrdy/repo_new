package genpact.pmr.start.dto;

import java.util.List;

public class BillingDTO {
	
	List<BillingTimelineDTO> billingTimelineDTOs;

	public List<BillingTimelineDTO> getBillingTimelineDTOs() {
		return billingTimelineDTOs;
	}

	public void setBillingTimelineDTOs(List<BillingTimelineDTO> billingTimelineDTOs) {
		this.billingTimelineDTOs = billingTimelineDTOs;
	}

	@Override
	public String toString() {
		return "BillingDTO [billingTimelineDTOs=" + billingTimelineDTOs + "]";
	}
	
	
}
