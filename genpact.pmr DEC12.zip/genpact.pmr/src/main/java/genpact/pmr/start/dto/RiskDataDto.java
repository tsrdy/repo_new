package genpact.pmr.start.dto;

public class RiskDataDto {

	
	private int medium;
	private int out;
	private int in;
	private int small;
	private int significant;
	
	
	
	public RiskDataDto(int medium, int out, int in, int small, int significant) {
		super();
		this.medium = medium;
		this.out = out;
		this.in = in;
		this.small = small;
		this.significant = significant;
	}
	public RiskDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMedium() {
		return medium;
	}
	public void setMedium(int medium) {
		this.medium = medium;
	}
	public int getOut() {
		return out;
	}
	public void setOut(int out) {
		this.out = out;
	}
	public int getIn() {
		return in;
	}
	public void setIn(int in) {
		this.in = in;
	}
	public int getSmall() {
		return small;
	}
	public void setSmall(int small) {
		this.small = small;
	}
	public int getSignificant() {
		return significant;
	}
	public void setSignificant(int significant) {
		this.significant = significant;
	}
	



}
