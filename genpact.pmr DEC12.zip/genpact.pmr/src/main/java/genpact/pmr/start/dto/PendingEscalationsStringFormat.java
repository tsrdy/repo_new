package genpact.pmr.start.dto;

public class PendingEscalationsStringFormat {

	private String delay_text;
	private String SYS_ENG;
	private String EQU_GSC;
	private String PE_ENG;
	private String PE_GSC;
	private String PE_MFG;
	private String IandC;
	private String QUA;
	private String CON_MGT;
	private String LEG;
	private String OTR_FIN;
	private String ITO;
	
	public String getDelay_text() {
		return delay_text;
	}
	public void setDelay_text(String delay_text) {
		this.delay_text = delay_text;
	}
	public String getSYS_ENG() {
		return SYS_ENG;
	}
	public void setSYS_ENG(String sYS_ENG) {
		SYS_ENG = sYS_ENG;
	}
	public String getEQU_GSC() {
		return EQU_GSC;
	}
	public void setEQU_GSC(String eQU_GSC) {
		EQU_GSC = eQU_GSC;
	}
	public String getPE_ENG() {
		return PE_ENG;
	}
	public void setPE_ENG(String pE_ENG) {
		PE_ENG = pE_ENG;
	}
	public String getPE_GSC() {
		return PE_GSC;
	}
	public void setPE_GSC(String pE_GSC) {
		PE_GSC = pE_GSC;
	}
	public String getPE_MFG() {
		return PE_MFG;
	}
	public void setPE_MFG(String pE_MFG) {
		PE_MFG = pE_MFG;
	}
	public String getIandC() {
		return IandC;
	}
	public void setIandC(String iandC) {
		IandC = iandC;
	}
	public String getQUA() {
		return QUA;
	}
	public void setQUA(String qUA) {
		QUA = qUA;
	}
	public String getCON_MGT() {
		return CON_MGT;
	}
	public void setCON_MGT(String cON_MGT) {
		CON_MGT = cON_MGT;
	}
	public String getLEG() {
		return LEG;
	}
	public void setLEG(String lEG) {
		LEG = lEG;
	}
	public String getOTR_FIN() {
		return OTR_FIN;
	}
	public void setOTR_FIN(String oTR_FIN) {
		OTR_FIN = oTR_FIN;
	}
	public String getITO() {
		return ITO;
	}
	public void setITO(String iTO) {
		ITO = iTO;
	}
	public PendingEscalationsStringFormat(String delay_text,String sYS_ENG, String eQU_GSC, String pE_ENG, String pE_GSC, String pE_MFG,
			String iandC, String qUA, String cON_MGT, String lEG, String oTR_FIN, String iTO) {
		super();
		this.delay_text=delay_text;
		SYS_ENG = sYS_ENG;
		EQU_GSC = eQU_GSC;
		PE_ENG = pE_ENG;
		PE_GSC = pE_GSC;
		PE_MFG = pE_MFG;
		IandC = iandC;
		QUA = qUA;
		CON_MGT = cON_MGT;
		LEG = lEG;
		OTR_FIN = oTR_FIN;
		ITO = iTO;
	}
	public PendingEscalationsStringFormat() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PendingEscalationsStringFormat [SYS_ENG=" + SYS_ENG + ", EQU_GSC=" + EQU_GSC + ", PE_ENG=" + PE_ENG
				+ ", PE_GSC=" + PE_GSC + ", PE_MFG=" + PE_MFG + ", IandC=" + IandC + ", QUA=" + QUA + ", CON_MGT="
				+ CON_MGT + ", LEG=" + LEG + ", OTR_FIN=" + OTR_FIN + ", ITO=" + ITO + "]";
	}
	
}
