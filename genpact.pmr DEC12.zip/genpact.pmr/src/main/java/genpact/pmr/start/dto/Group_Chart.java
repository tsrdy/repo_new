package genpact.pmr.start.dto;

public class Group_Chart {
	private String name;
	private double eac;
	private double cbl;
	private double previous_eac;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getEac() {
		return eac;
	}
	public void setEac(double eac) {
		this.eac = eac;
	}
	public double getCbl() {
		return cbl;
	}
	public void setCbl(double cbl) {
		this.cbl = cbl;
	}
	public double getPrevious_eac() {
		return previous_eac;
	}
	public void setPrevious_eac(double previous_eac) {
		this.previous_eac = previous_eac;
	}

	
	public Group_Chart(String name, double eac, double cbl, double previous_eac) {
		super();
		this.name = name;
		this.eac = eac;
		this.cbl = cbl;
		this.previous_eac = previous_eac;
	}
	public Group_Chart() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
