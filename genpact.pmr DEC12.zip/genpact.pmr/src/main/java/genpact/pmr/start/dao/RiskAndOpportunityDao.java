package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.PendingActionsDataDto;
import genpact.pmr.start.dto.PendingEscalations;
import genpact.pmr.start.dto.PendingEscalationsStringFormat;
import genpact.pmr.start.dto.RiskAndOpportunityRequestJson;
import genpact.pmr.start.dto.RiskAndOpportunityResponseJSON;
import genpact.pmr.start.dto.RiskDataDto;

@Repository
public class RiskAndOpportunityDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public RiskAndOpportunityResponseJSON getAllData() {

		RiskAndOpportunityResponseJSON responseJSON = new RiskAndOpportunityResponseJSON();

		String SQL_REGION = "select distinct(region) from risk_opportunity";

		List<FormatDataDto> regions = getFormatDatas(SQL_REGION, "region");
		responseJSON.setNextFiletrDatas(regions);

		String SQL_RISK = "select score_rating from risk_opportunity where header = 'Risk'";

		// FOR RISK
		RiskDataDto risk = getRiskData(SQL_RISK);
		responseJSON.setRiskDataDto(risk);

		String SQL_OPPORTUNITY = "select score_rating from risk_opportunity where header = 'Opp.'";

		// FOR OPP.
		RiskDataDto opportunity = getRiskData(SQL_OPPORTUNITY);
		responseJSON.setOpportunityDataDto(opportunity);

		// PENDING Action
		String SQL_PENDING_ACTION = "select delay_text from risk_opportunity";

		PendingActionsDataDto pendingData = getPendingActionData(SQL_PENDING_ACTION);
		responseJSON.setPendingActionsDataDto(pendingData);

		// Pending Escalation based on significant
		String SQL_PENDINGESCALATION_SIGNIFICANT = "select delay_text, SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 0 w','> 2 w') and score_rating='Significant'";
		Map<String,PendingEscalations> pendingEscalationSignificant = getPendingEscalationData(SQL_PENDINGESCALATION_SIGNIFICANT);

		responseJSON.setSignificantMap(pendingEscalationSignificant);
		
		// Pending Escalation based on medium
		String SQL_PENDINGESCALATION_MEDIUM = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', 'in <= 1 w') and score_rating='Medium'";
		Map<String,PendingEscalations> pendingEscalationMedium = getPendingEscalationData(SQL_PENDINGESCALATION_MEDIUM);
		responseJSON.setMediumMap(pendingEscalationMedium);
		
		// Pending Escalation based on small
		String SQL_PENDINGESCALATION_SMALL = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 1 w') and score_rating='Small'";
		Map<String,PendingEscalations> pendingEscalationSmall = getPendingEscalationData(SQL_PENDINGESCALATION_SMALL);
		responseJSON.setSmallMap(pendingEscalationSmall);
		
		return responseJSON;
	}
	
	public RiskAndOpportunityResponseJSON getRegionData(RiskAndOpportunityRequestJson requestJson){
		RiskAndOpportunityResponseJSON responseJSON = new RiskAndOpportunityResponseJSON();

		List<FormatDataDto> regionFilters=requestJson.getRegions();
		
		String region_data=createSql(getFormatForSql(regionFilters));
		System.out.println("Region filters");
		
		String SQL_REGION = "select distinct(pm) from risk_opportunity where region in ("+region_data+")";

		List<FormatDataDto> regions = getFormatDatas(SQL_REGION, "pm");
		responseJSON.setNextFiletrDatas(regions);

		String SQL_RISK = "select score_rating from risk_opportunity where header = 'Risk' and  region in ("+region_data+")";

		// FOR RISK
		RiskDataDto risk = getRiskData(SQL_RISK);
		responseJSON.setRiskDataDto(risk);

		String SQL_OPPORTUNITY = "select score_rating from risk_opportunity where header = 'Opp.' and  region in ("+region_data+")";

		// FOR OPP.
		RiskDataDto opportunity = getRiskData(SQL_OPPORTUNITY);
		responseJSON.setOpportunityDataDto(opportunity);

		// PENDING Action
		String SQL_PENDING_ACTION = "select delay_text from risk_opportunity  where  region in ("+region_data+")";

		PendingActionsDataDto pendingData = getPendingActionData(SQL_PENDING_ACTION);
		responseJSON.setPendingActionsDataDto(pendingData);

		// Pending Escalation based on significant
		String SQL_PENDINGESCALATION_SIGNIFICANT = "select delay_text, SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 0 w','> 2 w') and score_rating='Significant'  and  region in ("+region_data+")";
		Map<String,PendingEscalations> pendingEscalationSignificant = getPendingEscalationData(SQL_PENDINGESCALATION_SIGNIFICANT);

		responseJSON.setSignificantMap(pendingEscalationSignificant);

		// Pending Escalation based on medium
		String SQL_PENDINGESCALATION_MEDIUM = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', 'in <= 1 w') and score_rating='Medium'  and  region in ("+region_data+")";
		Map<String,PendingEscalations> pendingEscalationMedium = getPendingEscalationData(SQL_PENDINGESCALATION_MEDIUM);
		responseJSON.setMediumMap(pendingEscalationMedium);
		
		// Pending Escalation based on small
		String SQL_PENDINGESCALATION_SMALL = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 1 w') and score_rating='Small'  and  region in ("+region_data+")";
		Map<String,PendingEscalations> pendingEscalationSmall = getPendingEscalationData(SQL_PENDINGESCALATION_SMALL);
		responseJSON.setSmallMap(pendingEscalationSmall);
		
		return responseJSON;
	}

	public RiskAndOpportunityResponseJSON getProjectManagerData(RiskAndOpportunityRequestJson requestJson){
		RiskAndOpportunityResponseJSON responseJSON = new RiskAndOpportunityResponseJSON();

		List<FormatDataDto> regionFilters=requestJson.getRegions();
		List<FormatDataDto> pmFilters=requestJson.getProjectManagers();
		
		String region_data=createSql(getFormatForSql(regionFilters));
		String pm_data=createSql(getFormatForSql(pmFilters));
		
		System.out.println("Region filters");
		
		String SQL_REGION = "select distinct(market) from risk_opportunity where region in ("+region_data+") and pm in("+pm_data+")";

		List<FormatDataDto> regions = getFormatDatas(SQL_REGION, "market");
		responseJSON.setNextFiletrDatas(regions);

		String SQL_RISK = "select score_rating from risk_opportunity where header = 'Risk' and  region in ("+region_data+")  and pm in("+pm_data+")";

		// FOR RISK
		RiskDataDto risk = getRiskData(SQL_RISK);
		responseJSON.setRiskDataDto(risk);

		String SQL_OPPORTUNITY = "select score_rating from risk_opportunity where header = 'Opp.' and  region in ("+region_data+")  and pm in("+pm_data+")";

		// FOR OPP.
		RiskDataDto opportunity = getRiskData(SQL_OPPORTUNITY);
		responseJSON.setOpportunityDataDto(opportunity);

		// PENDING Action
		String SQL_PENDING_ACTION = "select delay_text from risk_opportunity  where  region in ("+region_data+")  and pm in("+pm_data+")";

		PendingActionsDataDto pendingData = getPendingActionData(SQL_PENDING_ACTION);
		responseJSON.setPendingActionsDataDto(pendingData);

		// Pending Escalation based on significant
		String SQL_PENDINGESCALATION_SIGNIFICANT = "select delay_text, SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 0 w','> 2 w') and score_rating='Significant'  and  region in ("+region_data+")  and pm in("+pm_data+")";
		Map<String,PendingEscalations> pendingEscalationSignificant = getPendingEscalationData(SQL_PENDINGESCALATION_SIGNIFICANT);

		responseJSON.setSignificantMap(pendingEscalationSignificant);

		// Pending Escalation based on medium
		String SQL_PENDINGESCALATION_MEDIUM = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', 'in <= 1 w') and score_rating='Medium'  and  region in ("+region_data+")  and pm in("+pm_data+")";
		Map<String,PendingEscalations> pendingEscalationMedium = getPendingEscalationData(SQL_PENDINGESCALATION_MEDIUM);
		responseJSON.setMediumMap(pendingEscalationMedium);
		
		// Pending Escalation based on small
		String SQL_PENDINGESCALATION_SMALL = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 1 w') and score_rating='Small'  and  region in ("+region_data+")  and pm in("+pm_data+")";
		Map<String,PendingEscalations> pendingEscalationSmall = getPendingEscalationData(SQL_PENDINGESCALATION_SMALL);
		responseJSON.setSmallMap(pendingEscalationSmall);
		
		return responseJSON;
	}

	public RiskAndOpportunityResponseJSON getMarketData(RiskAndOpportunityRequestJson requestJson){
		RiskAndOpportunityResponseJSON responseJSON = new RiskAndOpportunityResponseJSON();

		List<FormatDataDto> regionFilters=requestJson.getRegions();
		List<FormatDataDto> pmFilters=requestJson.getProjectManagers();
		List<FormatDataDto> marketFilters=requestJson.getMarkets();
				
		String region_data=createSql(getFormatForSql(regionFilters));
		String pm_data=createSql(getFormatForSql(pmFilters));
		String market_data=createSql(getFormatForSql(marketFilters));
		
		System.out.println("Region filters");
		
		String SQL_REGION = "select distinct(job_reference) from risk_opportunity where region in ("+region_data+") and pm in("+pm_data+") and market in("+market_data+")";

		List<FormatDataDto> regions = getFormatDatas(SQL_REGION, "job_reference");
		responseJSON.setNextFiletrDatas(regions);

		String SQL_RISK = "select score_rating from risk_opportunity where header = 'Risk' and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+")";

		// FOR RISK
		RiskDataDto risk = getRiskData(SQL_RISK);
		responseJSON.setRiskDataDto(risk);

		String SQL_OPPORTUNITY = "select score_rating from risk_opportunity where header = 'Opp.' and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+")";

		// FOR OPP.
		RiskDataDto opportunity = getRiskData(SQL_OPPORTUNITY);
		responseJSON.setOpportunityDataDto(opportunity);

		// PENDING Action
		String SQL_PENDING_ACTION = "select delay_text from risk_opportunity  where  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+")";

		PendingActionsDataDto pendingData = getPendingActionData(SQL_PENDING_ACTION);
		responseJSON.setPendingActionsDataDto(pendingData);

		// Pending Escalation based on significant
		String SQL_PENDINGESCALATION_SIGNIFICANT = "select delay_text, SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 0 w','> 2 w') and score_rating='Significant'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+")";
		Map<String,PendingEscalations> pendingEscalationSignificant = getPendingEscalationData(SQL_PENDINGESCALATION_SIGNIFICANT);

		responseJSON.setSignificantMap(pendingEscalationSignificant);

		// Pending Escalation based on medium
		String SQL_PENDINGESCALATION_MEDIUM = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', 'in <= 1 w') and score_rating='Medium'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+")";
		Map<String,PendingEscalations> pendingEscalationMedium = getPendingEscalationData(SQL_PENDINGESCALATION_MEDIUM);
		responseJSON.setMediumMap(pendingEscalationMedium);
		
		// Pending Escalation based on small
		String SQL_PENDINGESCALATION_SMALL = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 1 w') and score_rating='Small'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+")";
		Map<String,PendingEscalations> pendingEscalationSmall = getPendingEscalationData(SQL_PENDINGESCALATION_SMALL);
		responseJSON.setSmallMap(pendingEscalationSmall);
		
		return responseJSON;
	}
	public RiskAndOpportunityResponseJSON getJobNumberData(RiskAndOpportunityRequestJson requestJson){
		RiskAndOpportunityResponseJSON responseJSON = new RiskAndOpportunityResponseJSON();

		List<FormatDataDto> regionFilters=requestJson.getRegions();
		List<FormatDataDto> pmFilters=requestJson.getProjectManagers();
		List<FormatDataDto> marketFilters=requestJson.getMarkets();
		List<FormatDataDto> jobNumberFilters=requestJson.getJobNumbers();
				
		String region_data=createSql(getFormatForSql(regionFilters));
		String pm_data=createSql(getFormatForSql(pmFilters));
		String market_data=createSql(getFormatForSql(marketFilters));
		String jobNumber_data=createSql(getFormatForSql(jobNumberFilters));
		
		System.out.println("Region filters");
		
		String SQL_REGION = "select distinct(job_name) from risk_opportunity where region in ("+region_data+") and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+")";

		List<FormatDataDto> regions = getFormatDatas(SQL_REGION, "job_name");
		responseJSON.setNextFiletrDatas(regions);

		String SQL_RISK = "select score_rating from risk_opportunity where header = 'Risk' and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+")";

		// FOR RISK
		RiskDataDto risk = getRiskData(SQL_RISK);
		responseJSON.setRiskDataDto(risk);

		String SQL_OPPORTUNITY = "select score_rating from risk_opportunity where header = 'Opp.' and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+")";

		// FOR OPP.
		RiskDataDto opportunity = getRiskData(SQL_OPPORTUNITY);
		responseJSON.setOpportunityDataDto(opportunity);

		// PENDING Action
		String SQL_PENDING_ACTION = "select delay_text from risk_opportunity  where  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+")";

		PendingActionsDataDto pendingData = getPendingActionData(SQL_PENDING_ACTION);
		responseJSON.setPendingActionsDataDto(pendingData);

		// Pending Escalation based on significant
		String SQL_PENDINGESCALATION_SIGNIFICANT = "select delay_text, SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 0 w','> 2 w') and score_rating='Significant'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+")";
		Map<String,PendingEscalations> pendingEscalationSignificant = getPendingEscalationData(SQL_PENDINGESCALATION_SIGNIFICANT);

		responseJSON.setSignificantMap(pendingEscalationSignificant);

		// Pending Escalation based on medium
		String SQL_PENDINGESCALATION_MEDIUM = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', 'in <= 1 w') and score_rating='Medium'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+")";
		Map<String,PendingEscalations> pendingEscalationMedium = getPendingEscalationData(SQL_PENDINGESCALATION_MEDIUM);
		responseJSON.setMediumMap(pendingEscalationMedium);
		
		// Pending Escalation based on small
		String SQL_PENDINGESCALATION_SMALL = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 1 w') and score_rating='Small'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+")";
		Map<String,PendingEscalations> pendingEscalationSmall = getPendingEscalationData(SQL_PENDINGESCALATION_SMALL);
		responseJSON.setSmallMap(pendingEscalationSmall);
		
		return responseJSON;
	}
	public RiskAndOpportunityResponseJSON getJobNameData(RiskAndOpportunityRequestJson requestJson){
		RiskAndOpportunityResponseJSON responseJSON = new RiskAndOpportunityResponseJSON();

		List<FormatDataDto> regionFilters=requestJson.getRegions();
		List<FormatDataDto> pmFilters=requestJson.getProjectManagers();
		List<FormatDataDto> marketFilters=requestJson.getMarkets();
		List<FormatDataDto> jobNumberFilters=requestJson.getJobNumbers();
		List<FormatDataDto> jobNameFilters=requestJson.getJobNames();
		
		
		String region_data=createSql(getFormatForSql(regionFilters));
		String pm_data=createSql(getFormatForSql(pmFilters));
		String market_data=createSql(getFormatForSql(marketFilters));
		String jobNumber_data=createSql(getFormatForSql(jobNumberFilters));
		String jobName_data=createSql(getFormatForSql(jobNameFilters));
		
		System.out.println("Region filters");
		//not required
		
		String SQL_REGION = "select distinct(job_name) from risk_opportunity where region in ("+region_data+") and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+")";

		List<FormatDataDto> regions = getFormatDatas(SQL_REGION, "job_name");
		responseJSON.setNextFiletrDatas(regions);

		String SQL_RISK = "select score_rating from risk_opportunity where header = 'Risk' and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+") and job_name in("+jobName_data+")";

		// FOR RISK
		RiskDataDto risk = getRiskData(SQL_RISK);
		responseJSON.setRiskDataDto(risk);

		String SQL_OPPORTUNITY = "select score_rating from risk_opportunity where header = 'Opp.' and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+") and job_name in("+jobName_data+")";

		// FOR OPP.
		RiskDataDto opportunity = getRiskData(SQL_OPPORTUNITY);
		responseJSON.setOpportunityDataDto(opportunity);

		// PENDING Action
		String SQL_PENDING_ACTION = "select delay_text from risk_opportunity  where  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+") and job_name in("+jobName_data+")";

		PendingActionsDataDto pendingData = getPendingActionData(SQL_PENDING_ACTION);
		responseJSON.setPendingActionsDataDto(pendingData);

		// Pending Escalation based on significant
		String SQL_PENDINGESCALATION_SIGNIFICANT = "select delay_text, SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 0 w','> 2 w') and score_rating='Significant'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+") and job_name in("+jobName_data+")";
		Map<String,PendingEscalations> pendingEscalationSignificant = getPendingEscalationData(SQL_PENDINGESCALATION_SIGNIFICANT);

		responseJSON.setSignificantMap(pendingEscalationSignificant);

		// Pending Escalation based on medium
		String SQL_PENDINGESCALATION_MEDIUM = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', 'in <= 1 w') and score_rating='Medium'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+") and job_name in("+jobName_data+")";
		Map<String,PendingEscalations> pendingEscalationMedium = getPendingEscalationData(SQL_PENDINGESCALATION_MEDIUM);
		responseJSON.setMediumMap(pendingEscalationMedium);
		
		// Pending Escalation based on small
		String SQL_PENDINGESCALATION_SMALL = "select delay_text,SYS_ENG,EQU_GSC,PE_ENG,PE_GSC,PE_MFG,IandC,QUA,CON_MGT,LEG,OTR_FIN,ITO from risk_opportunity where delay_text in('in > 1 w', '> 1 w') and score_rating='Small'  and  region in ("+region_data+")  and pm in("+pm_data+") and market in("+market_data+") and job_reference in("+jobNumber_data+") and job_name in("+jobName_data+")";
		Map<String,PendingEscalations> pendingEscalationSmall = getPendingEscalationData(SQL_PENDINGESCALATION_SMALL);
		responseJSON.setSmallMap(pendingEscalationSmall);
		
		return responseJSON;
	}
	

	private Map<String,PendingEscalations>  getPendingEscalationData(String sql) {

		Map<String,PendingEscalations> map=new HashMap<>();
		PendingEscalations pe = null;

		List<PendingEscalationsStringFormat> pendingEscalationList = jdbcTemplate.query(sql,
				new RowMapper<PendingEscalationsStringFormat>() {

					@Override
					public PendingEscalationsStringFormat mapRow(ResultSet rs, int rowCount) throws SQLException {
						return new PendingEscalationsStringFormat(rs.getString("delay_text"),rs.getString("SYS_ENG"), rs.getString("EQU_GSC"),
								rs.getString("PE_ENG"), rs.getString("PE_GSC"), rs.getString("PE_MFG"),
								rs.getString("IandC"), rs.getString("QUA"), rs.getString("CON_MGT"),
								rs.getString("LEG"), rs.getString("OTR_FIN"), rs.getString("ITO"));
					}

				});
		

		for (PendingEscalationsStringFormat pesf : pendingEscalationList) {

			pe=new PendingEscalations();
			
			if (pesf.getCON_MGT()!=null) {

				pe.setCON_MGT(pe.getCON_MGT() + 1);
			}
			if (pesf.getEQU_GSC()!=null) {

				pe.setEQU_GSC(pe.getEQU_GSC() + 1);
			}
			if (pesf.getIandC()!=null) {

				pe.setIandC(pe.getIandC() + 1);
			}
			if (pesf.getITO()!=null) {

				pe.setITO(pe.getITO() + 1);
			}
			if (pesf.getLEG()!=null) {
				
				pe.setLEG(pe.getLEG() + 1);
			}
			if (pesf.getOTR_FIN()!=null) {

				pe.setOTR_FIN(pe.getOTR_FIN() + 1);
			}
			if (pesf.getPE_ENG()!=null) {

				pe.setPE_ENG(pe.getPE_ENG() + 1);
			}
			if (pesf.getPE_GSC()!=null) {

				pe.setPE_GSC(pe.getPE_GSC() + 1);
			}
			if (pesf.getPE_MFG()!=null) {

				pe.setPE_MFG(pe.getPE_MFG() + 1);
			}
			if (pesf.getQUA()!=null) {

				pe.setQUA(pe.getQUA() + 1);
			}
			if (pesf.getSYS_ENG()!=null) {
				
				pe.setSYS_ENG(pe.getSYS_ENG() + 1);
			}
			
			map.put(pesf.getDelay_text(), pe);
		}
		return map;
	}

	private PendingActionsDataDto getPendingActionData(String sql) {

		/*
		 * "in <= 3 d" "in > 1 w" "DONE" "> 1 w" "> 2 w" "in <= 1 w" "> 0 w"
		 */
		String[] arr = { "in <= 3 d", "in > 1 w", "DONE", "> 1 w", "> 2 w", "in <= 1 w", "> 0 w" };

		PendingActionsDataDto pending = new PendingActionsDataDto();

		List<String> pendingDataList = jdbcTemplate.query(sql, new RowMapper<String>() {

			@Override
			public String mapRow(ResultSet rs, int rowCount) throws SQLException {
				return rs.getString("delay_text");
			}

		});

		for (int i = 0; i < arr.length; i++) {

			for (String str : pendingDataList) {

				if (arr[i].equals(str)) {

					switch (arr[i]) {

					case "in <= 3 d":
						pending.setIn_lessthan_equal_3d(pending.getIn_lessthan_equal_3d() + 1);
						break;
					case "in > 1 w":
						pending.setIn_greaterthan_1w(pending.getIn_greaterthan_1w() + 1);
						break;
					case "DONE":
						pending.setDone(pending.getDone() + 1);
						break;
					case "> 1 w":
						pending.setGreatherthan_1w(pending.getGreatherthan_1w() + 1);
						break;
					case "> 2 w":
						pending.setGreatherthan_2w(pending.getGreatherthan_2w() + 1);
						break;
					case "in <= 1 w":
						pending.setIn_lessthan_equal_1w(pending.getIn_lessthan_equal_1w() + 1);
						break;
					case "> 0 w":
						pending.setGreaterthan_0w(pending.getGreaterthan_0w() + 1);
						break;
					}
				}
			}
		}

		return pending;
	}

	private RiskDataDto getRiskData(String sql) {

		RiskDataDto risk = new RiskDataDto();

		String[] arr = { "In", "Significant", "Medium", "Small", "Out" };

		List<String> riskList = jdbcTemplate.query(sql, new RowMapper<String>() {

			@Override
			public String mapRow(ResultSet rs, int rowCount) throws SQLException {

				return rs.getString("score_rating");
			}
		});

		for (int i = 0; i < arr.length; i++) {

			for (String dt : riskList) {

				if (arr[i].equals(dt)) {

					switch (dt) {

					case "In":
						risk.setIn(risk.getIn() + 1);
						break;
					case "Significant":
						risk.setSignificant(risk.getSignificant() + 1);
						break;
					case "Medium":
						risk.setMedium(risk.getMedium() + 1);
						break;
					case "Small":
						risk.setSmall(risk.getSmall() + 1);
						break;
					case "Out":
						risk.setOut(risk.getOut() + 1);
						break;
					}
				}
			}
		}

		return risk;

	}

	private List<FormatDataDto> getFormatDatas(String sql, String columnName) {

		return jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int count;

			@Override
			public FormatDataDto mapRow(ResultSet rs, int rowCount) throws SQLException {
				// TODO Auto-generated method stub
				return new FormatDataDto(++count, rs.getString(columnName));
			}

		});
	}

	
	private String getFormatForSql(List<FormatDataDto> regionFilters) {

			String regions = "";

			int i = 0;
			for (FormatDataDto regionFilter : regionFilters) {

				if ((i + 1) == regionFilters.size()) {
					regions += regionFilter.getLabel() + ",";

					break;
				} else if (i < regionFilters.size()) {
					regions += regionFilter.getLabel() + ",";

				}
				i++;
			}
			return regions;
		}

		private String createSql(String str) {
			String[] strArray = str.split(",");

			String seg = "";

			for (int i = 0; i <= strArray.length; i++) {

				seg += "'" + strArray[i] + "'";

				if ((i + 1) == strArray.length) {
					break;
				} else if (i < strArray.length) {
					seg += ",";
				}
			}

			System.out.println(seg);
			return seg;
		}

}
