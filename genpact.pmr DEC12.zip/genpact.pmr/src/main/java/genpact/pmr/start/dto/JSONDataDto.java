package genpact.pmr.start.dto;

import java.util.List;
import java.util.Map;

public class JSONDataDto {

	List<FormatDataDto> formatDataDtos;
	TableDataDto tableDataDto;
	RevenueChartDto revenueChartDto;
	CostDetailGroupTypeChartTypeDto costDetailGroupTypeChartTypeDto;
	Map<String, List<Group_Chart>> group_cost;
	Map<String, List<ChartDto>> groupedtype_cost;
	RevenueChartName revenueChartName;



	public RevenueChartName getRevenueChartName() {
		return revenueChartName;
	}

	public void setRevenueChartName(RevenueChartName revenueChartName) {
		this.revenueChartName = revenueChartName;
	}

	public JSONDataDto(List<FormatDataDto> formatDataDtos, TableDataDto tableDataDto, RevenueChartDto revenueChartDto,
			CostDetailGroupTypeChartTypeDto costDetailGroupTypeChartTypeDto, Map<String, List<Group_Chart>> group_cost,
			Map<String, List<ChartDto>> groupedtype_cost, RevenueChartName revenueChartName) {
		super();
		this.formatDataDtos = formatDataDtos;
		this.tableDataDto = tableDataDto;
		this.revenueChartDto = revenueChartDto;
		this.costDetailGroupTypeChartTypeDto = costDetailGroupTypeChartTypeDto;
		this.group_cost = group_cost;
		this.groupedtype_cost = groupedtype_cost;
		this.revenueChartName = revenueChartName;
	}

	public Map<String, List<Group_Chart>> getGroup_cost() {
		return group_cost;
	}

	public void setGroup_cost(Map<String, List<Group_Chart>> group_cost) {
		this.group_cost = group_cost;
	}

	public Map<String, List<ChartDto>> getGroupedtype_cost() {
		return groupedtype_cost;
	}

	public void setGroupedtype_cost(Map<String, List<ChartDto>> groupedtype_cost) {
		this.groupedtype_cost = groupedtype_cost;
	}

	public JSONDataDto(List<FormatDataDto> formatDataDtos, TableDataDto tableDataDto, RevenueChartDto revenueChartDto,
			CostDetailGroupTypeChartTypeDto costDetailGroupTypeChartTypeDto) {
		super();
		this.formatDataDtos = formatDataDtos;
		this.tableDataDto = tableDataDto;
		this.revenueChartDto = revenueChartDto;
		this.costDetailGroupTypeChartTypeDto = costDetailGroupTypeChartTypeDto;
	}

	public CostDetailGroupTypeChartTypeDto getCostDetailGroupTypeChartTypeDto() {
		return costDetailGroupTypeChartTypeDto;
	}

	public void setCostDetailGroupTypeChartTypeDto(CostDetailGroupTypeChartTypeDto costDetailGroupTypeChartTypeDto) {
		this.costDetailGroupTypeChartTypeDto = costDetailGroupTypeChartTypeDto;
	}

	public JSONDataDto(TableDataDto tableDataDto, RevenueChartDto revenueChartDto, RevenueChartName revenueChartName) {
		super();
		this.tableDataDto = tableDataDto;
		this.revenueChartDto = revenueChartDto;
		this.revenueChartName = revenueChartName;
	}
	public JSONDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RevenueChartDto getRevenueChartDto() {
		return revenueChartDto;
	}

	public void setRevenueChartDto(RevenueChartDto revenueChartDto) {
		this.revenueChartDto = revenueChartDto;
	}

	public JSONDataDto(List<FormatDataDto> formatDataDtos, TableDataDto tableDataDto) {
		super();
		this.formatDataDtos = formatDataDtos;
		this.tableDataDto = tableDataDto;
	}

	public List<FormatDataDto> getFormatDataDtos() {
		return formatDataDtos;
	}
	public void setFormatDataDtos(List<FormatDataDto> formatDataDtos) {
		this.formatDataDtos = formatDataDtos;
	}
	public TableDataDto getTableDataDto() {
		return tableDataDto;
	}
	public void setTableDataDto(TableDataDto tableDataDto) {
		this.tableDataDto = tableDataDto;
	}


}
