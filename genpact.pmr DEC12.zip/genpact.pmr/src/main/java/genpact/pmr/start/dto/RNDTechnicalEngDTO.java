package genpact.pmr.start.dto;

public class RNDTechnicalEngDTO {
	
	  private String name ; 
	  private long rndtechTotalCbl;
	  private long rndtechTotalPreviousEac;
	  private long rndtechTotalEac;
	  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getRndtechTotalCbl() {
		return rndtechTotalCbl;
	}
	public void setRndtechTotalCbl(long rndtechTotalCbl) {
		this.rndtechTotalCbl = rndtechTotalCbl;
	}
	public long getRndtechTotalPreviousEac() {
		return rndtechTotalPreviousEac;
	}
	public void setRndtechTotalPreviousEac(long rndtechTotalPreviousEac) {
		this.rndtechTotalPreviousEac = rndtechTotalPreviousEac;
	}
	public long getRndtechTotalEac() {
		return rndtechTotalEac;
	}
	public void setRndtechTotalEac(long rndtechTotalEac) {
		this.rndtechTotalEac = rndtechTotalEac;
	}

}
