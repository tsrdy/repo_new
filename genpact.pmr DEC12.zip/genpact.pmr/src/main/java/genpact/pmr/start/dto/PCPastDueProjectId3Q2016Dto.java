package genpact.pmr.start.dto;

public class PCPastDueProjectId3Q2016Dto {
	
	private String region;
	private String regionalManager;
	private String projectManager;
	private String ProjectId;
	private double sum;
	
	public PCPastDueProjectId3Q2016Dto(String region, String regionalManager, String projectManager, String projectId,
			double sum) {
		super();
		this.region = region;
		this.regionalManager = regionalManager;
		this.projectManager = projectManager;
		ProjectId = projectId;
		this.sum = sum;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegionalManager() {
		return regionalManager;
	}
	public void setRegionalManager(String regionalManager) {
		this.regionalManager = regionalManager;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getProjectId() {
		return ProjectId;
	}
	public void setProjectId(String projectId) {
		ProjectId = projectId;
	}
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public PCPastDueProjectId3Q2016Dto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ProjectId == null) ? 0 : ProjectId.hashCode());
		result = prime * result + ((projectManager == null) ? 0 : projectManager.hashCode());
		result = prime * result + ((region == null) ? 0 : region.hashCode());
		result = prime * result + ((regionalManager == null) ? 0 : regionalManager.hashCode());
		long temp;
		temp = Double.doubleToLongBits(sum);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PCPastDueProjectId3Q2016Dto other = (PCPastDueProjectId3Q2016Dto) obj;
		if (ProjectId == null) {
			if (other.ProjectId != null)
				return false;
		} else if (!ProjectId.equals(other.ProjectId))
			return false;
		if (projectManager == null) {
			if (other.projectManager != null)
				return false;
		} else if (!projectManager.equals(other.projectManager))
			return false;
		if (region == null) {
			if (other.region != null)
				return false;
		} else if (!region.equals(other.region))
			return false;
		if (regionalManager == null) {
			if (other.regionalManager != null)
				return false;
		} else if (!regionalManager.equals(other.regionalManager))
			return false;
		if (Double.doubleToLongBits(sum) != Double.doubleToLongBits(other.sum))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PCPastDueProjectId3Q2016Dto [region=" + region + ", regionalManager=" + regionalManager
				+ ", projectManager=" + projectManager + ", ProjectId=" + ProjectId + ", sum=" + sum + "]";
	}
	
	

}
