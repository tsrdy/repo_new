package genpact.pmr.start.dto;

public class DraughtsPersonDTO {
	  private String name ; 
	  private long drauTotalCbl;
	  private long drauTotalPreviousEac;
	  private long drauTotalEac;
	  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getDrauTotalCbl() {
		return drauTotalCbl;
	}
	public void setDrauTotalCbl(long drauTotalCbl) {
		this.drauTotalCbl = drauTotalCbl;
	}
	public long getDrauTotalPreviousEac() {
		return drauTotalPreviousEac;
	}
	public void setDrauTotalPreviousEac(long drauTotalPreviousEac) {
		this.drauTotalPreviousEac = drauTotalPreviousEac;
	}
	public long getDrauTotalEac() {
		return drauTotalEac;
	}
	public void setDrauTotalEac(long drauTotalEac) {
		this.drauTotalEac = drauTotalEac;
	}
	  
	  
}
