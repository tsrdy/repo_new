package genpact.pmr.start.dto;

public class RegionSumDto {

	private double sum;
	private String name;
	private String regionalManager;
	
	
	public RegionSumDto(double sum, String name, String regionalManager) {
		super();
		this.sum = sum;
		this.name = name;
		this.regionalManager = regionalManager;
	}
	public String getRegionalManager() {
		return regionalManager;
	}
	public void setRegionalManager(String regionalManager) {
		this.regionalManager = regionalManager;
	}
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public RegionSumDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RegionSumDto(double sum, String name) {
		super();
		this.sum = sum;
		this.name = name;
	}
	@Override
	public String toString() {
		return "RegionSumDto [sum=" + sum + ", name=" + name + "]";
	}
	
}
