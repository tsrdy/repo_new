package genpact.pmr.start.dto;

import java.util.List;

public class RequestFilter {
	
	List<RegionFilter> regionFilters;
	List<VerticalFilter> verticalFilters;
	List<SubVerticalFilter> subVerticalFilters;
	List<RiskFilter> riskFilters;
	List<ProjectIdFilter> projectIdFilters;
	List<ProjectNameFilter> projectNameFilters;
	List<ProjectManagerFilter> projectManagerFilters; 
	List<OTDStatusFilter> otdStatusFilters;
	
	
	
	public List<RegionFilter> getRegionFilters() {
		return regionFilters;
	}
	public void setRegionFilters(List<RegionFilter> regionFilters) {
		this.regionFilters = regionFilters;
	}
	public List<VerticalFilter> getVerticalFilters() {
		return verticalFilters;
	}
	public void setVerticalFilters(List<VerticalFilter> verticalFilters) {
		this.verticalFilters = verticalFilters;
	}
	public List<SubVerticalFilter> getSubVerticalFilters() {
		return subVerticalFilters;
	}
	public void setSubVerticalFilters(List<SubVerticalFilter> subVerticalFilters) {
		this.subVerticalFilters = subVerticalFilters;
	}
	public List<RiskFilter> getRiskFilters() {
		return riskFilters;
	}
	public void setRiskFilters(List<RiskFilter> riskFilters) {
		this.riskFilters = riskFilters;
	}
	public List<ProjectIdFilter> getProjectIdFilters() {
		return projectIdFilters;
	}
	public void setProjectIdFilters(List<ProjectIdFilter> projectIdFilters) {
		this.projectIdFilters = projectIdFilters;
	}
	public List<ProjectNameFilter> getProjectNameFilters() {
		return projectNameFilters;
	}
	public void setProjectNameFilters(List<ProjectNameFilter> projectNameFilters) {
		this.projectNameFilters = projectNameFilters;
	}
	public List<ProjectManagerFilter> getProjectManagerFilters() {
		return projectManagerFilters;
	}
	public void setProjectManagerFilters(List<ProjectManagerFilter> projectManagerFilters) {
		this.projectManagerFilters = projectManagerFilters;
	}
	public List<OTDStatusFilter> getOtdStatusFilters() {
		return otdStatusFilters;
	}
	public void setOtdStatusFilters(List<OTDStatusFilter> otdStatusFilters) {
		this.otdStatusFilters = otdStatusFilters;
	}
	

}
