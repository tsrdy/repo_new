package genpact.pmr.start.dto;

public class BillingTimelineDTO {
	private long billingValue;
	private String billingDate;
	private String billmonth;
	private String billingmonthYear;
	private int index;
	
	
	public long getBillingValue() {
		return billingValue;
	}
	public void setBillingValue(long billingValue) {
		this.billingValue = billingValue;
	}
	public String getBillingDate() {
		return billingDate;
	}
	public void setBillingDate(String billingDate) {
		this.billingDate = billingDate;
	}
	
	public String getBillmonth() {
		return billmonth;
	}
	public String getBillingmonthYear() {
		return billingmonthYear;
	}
	public void setBillingmonthYear(String billingmonthYear) {
		this.billingmonthYear = billingmonthYear;
	}
	public void setBillmonth(String billmonth) {
		this.billmonth = billmonth;
	}
	
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public BillingTimelineDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BillingTimelineDTO(long billingValue, String billingDate) {
		super();
		this.billingValue = billingValue;
		this.billingDate = billingDate;
		
	}
	public BillingTimelineDTO(long billingValue, String billingDate, String billmonth,String billingmonthYear) {
		super();
		this.billingValue = billingValue;
		this.billingDate = billingDate;
		this.billmonth = billmonth;
		this.billingmonthYear=billingmonthYear;
	}
	public BillingTimelineDTO(long billingValue, String billingDate, String billmonth) {
		super();
		this.billingValue = billingValue;
		this.billingDate = billingDate;
		this.billmonth = billmonth;
	}
	@Override
	public String toString() {
		return "BillingTimelineDTO [billingValue=" + billingValue + ", billingDate=" + billingDate + ", billmonth="
				+ billmonth + ", billingmonthYear=" + billingmonthYear + ", index=" + index + "]";
	}
	
	
	
	
	
}
