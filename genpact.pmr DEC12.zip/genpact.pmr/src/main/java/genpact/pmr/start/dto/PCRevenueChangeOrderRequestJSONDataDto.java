package genpact.pmr.start.dto;

import java.util.List;

public class PCRevenueChangeOrderRequestJSONDataDto {

	private String quarter;
	private List<FormatDataDto> regions;
	private List<FormatDataDto> regionalManagers;
	private List<FormatDataDto> projectManagers;
	public PCRevenueChangeOrderRequestJSONDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PCRevenueChangeOrderRequestJSONDataDto(String quarter, List<FormatDataDto> regions,
			List<FormatDataDto> regionalManagers, List<FormatDataDto> projectManagers) {
		super();
		this.quarter = quarter;
		this.regions = regions;
		this.regionalManagers = regionalManagers;
		this.projectManagers = projectManagers;
	}
	public String getQuarter() {
		return quarter;
	}
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}
	public List<FormatDataDto> getRegions() {
		return regions;
	}
	public void setRegions(List<FormatDataDto> regions) {
		this.regions = regions;
	}
	public List<FormatDataDto> getRegionalManagers() {
		return regionalManagers;
	}
	public void setRegionalManagers(List<FormatDataDto> regionalManagers) {
		this.regionalManagers = regionalManagers;
	}
	public List<FormatDataDto> getProjectManagers() {
		return projectManagers;
	}
	public void setProjectManagers(List<FormatDataDto> projectManagers) {
		this.projectManagers = projectManagers;
	}
	
	
	
	
	
}
