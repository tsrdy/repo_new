package genpact.pmr.start.dto;

public class BillingChartDto {

	private long billing_value;
	private String billing_date;
	private String dueDate;
	
	
	public String getBilling_date() {
		return billing_date;
	}
	public void setBilling_date(String billing_date) {
		this.billing_date = billing_date;
	}
	public long getBilling_value() {
		return billing_value;
	}
	public void setBilling_value(long billing_value) {
		this.billing_value = billing_value;
	}
	
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public BillingChartDto(long billing_value, String billing_date,String dueDate) {
		super();
		this.billing_value = billing_value;
		this.billing_date = billing_date;
		this.dueDate = dueDate;
	}
	
}
