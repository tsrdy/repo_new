package genpact.pmr.start.dto;

public class PCRCOProjectManagerDataDto {

	
	private String region;
	private String regionalManager;
	private String projectManager;
	private double internalSales;
	private double externalSales;
	public PCRCOProjectManagerDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PCRCOProjectManagerDataDto(String region, String regionalManager, String projectManager,
			double internalSales, double externalSales) {
		super();
		this.region = region;
		this.regionalManager = regionalManager;
		this.projectManager = projectManager;
		this.internalSales = internalSales;
		this.externalSales = externalSales;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegionalManager() {
		return regionalManager;
	}
	public void setRegionalManager(String regionalManager) {
		this.regionalManager = regionalManager;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public double getInternalSales() {
		return internalSales;
	}
	public void setInternalSales(double internalSales) {
		this.internalSales = internalSales;
	}
	public double getExternalSales() {
		return externalSales;
	}
	public void setExternalSales(double externalSales) {
		this.externalSales = externalSales;
	}
	
	
	
	
}
