package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.ActivityOTDStatusDto;
import genpact.pmr.start.dto.ActivityStatusDto;
import genpact.pmr.start.dto.SchTableDataDTO;
import genpact.pmr.start.dto.SchedulingDto;

@Repository
public class SchedulingServiceDAO {
	@Autowired
	public JdbcTemplate jdbcTemplate;
	
	public SchedulingDto getSchedulingData(String str) { 
		String sql="select activity_name,variation from scheduling " +str;
		List<ActivityStatusDto> activityStatusList = jdbcTemplate.query(sql, new RowMapper<ActivityStatusDto>(){
			public ActivityStatusDto mapRow(ResultSet rs, int arg1) throws SQLException {
				return new ActivityStatusDto(rs.getString("activity_name"), rs.getString("variation"));
			}
		});
		
		List<SchTableDataDTO> tableList  = getScheTableData(str);
		List<ActivityOTDStatusDto> pieList =  getSchedulinPieData(str);
		SchedulingDto schedulingDto = new SchedulingDto(activityStatusList,tableList,pieList);
		return schedulingDto;
	}
	
	
	public List<SchTableDataDTO> getScheTableData(String str) { 
		String sql="select project_id,project_manager,sold_to_party_name,act_milestone,activity_name,act_otd_status,act_bl_finish,act_finish,prj_schedule_date,variation from scheduling " +str;
		List<SchTableDataDTO> schTableDataDTOList = jdbcTemplate.query(sql, new RowMapper<SchTableDataDTO>() {
			public SchTableDataDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchTableDataDTO schTableDataDTO = new SchTableDataDTO();
				schTableDataDTO.setProjectId(rs.getString("project_id"));
				schTableDataDTO.setProjectManager(rs.getString("project_manager"));
				schTableDataDTO.setSoldToPartyName(rs.getString("sold_to_party_name"));
				schTableDataDTO.setActMilestone(rs.getString("act_milestone"));
				schTableDataDTO.setActivityName(rs.getString("activity_name"));
				schTableDataDTO.setActOtdStatus(rs.getString("act_otd_status"));
				schTableDataDTO.setActBlFinish(rs.getString("act_bl_finish"));
				schTableDataDTO.setActFinish(rs.getString("act_finish"));
				schTableDataDTO.setPrjScheduleDate(rs.getString("prj_schedule_date"));
				schTableDataDTO.setVariation(rs.getString("variation"));
				return schTableDataDTO;
			}
		});

		return schTableDataDTOList;
	}
	
	public List<ActivityOTDStatusDto> getSchedulinPieData(String str) {
        int totalCout = 0;
        double pastOnTimeCnt = 0f;
        double futureLateCnt = 0f;
        double noBaselineCnt = 0f;
        double pastLateCnt = 0f;
        double futureOnTimeCnt = 0f;
        double pastBacklogCnt = 0f;

        // ActivityOTDStatusDto actStatus = new ActivityOTDStatusDto();
        String sql = "select act_otd_status,count(act_otd_status) actcount from scheduling" + str;
        sql += " group by act_otd_status";
        
        List<ActivityOTDStatusDto> acStatusDtoList = jdbcTemplate.query(sql, new RowMapper<ActivityOTDStatusDto>() {
               public ActivityOTDStatusDto mapRow(ResultSet rs, int arg1) throws SQLException {
                     return new ActivityOTDStatusDto(rs.getString("act_otd_status"), rs.getInt("actcount"));
               }
        });
        String[] strarray = {"Past on time","Future late","No Baseline","Past late","Future on time","Past backlog"};
        List<String> status = new ArrayList<String>();
        for (ActivityOTDStatusDto actStatusDto : acStatusDtoList) {
               totalCout += actStatusDto.getStatusCount();
        }

        for (ActivityOTDStatusDto actStatusDto : acStatusDtoList) {
               String otdStatus = actStatusDto.getActOtdStatus();
               status.add(otdStatus.trim());
               
               int count = actStatusDto.getStatusCount();
               switch (otdStatus.trim()) {
               case "Past on time":
                     pastOnTimeCnt = (float) count / totalCout * 100;
                     actStatusDto.setActivityStatusCnt(pastOnTimeCnt);
                     break;
               case "Future late":
                     futureLateCnt = (float) count / totalCout * 100;
                     actStatusDto.setActivityStatusCnt(futureLateCnt);
                     break;
               case "No Baseline":
                     noBaselineCnt = (float) count / totalCout * 100;
                     actStatusDto.setActivityStatusCnt(noBaselineCnt);
                     break;
               case "Past late":
                     pastLateCnt = (float) count / totalCout * 100;
                     actStatusDto.setActivityStatusCnt(pastLateCnt);
                     break;
               case "Future on time":
                     futureOnTimeCnt = (float) count / totalCout * 100;
                     actStatusDto.setActivityStatusCnt(futureOnTimeCnt);
                     break;

               default:
                     pastBacklogCnt = (float) count / totalCout * 100;
                     actStatusDto.setActivityStatusCnt(pastBacklogCnt);
               }
        }
        for (int i = 0; i < strarray.length; i++) {
               if (!status.contains(strarray[i])) {
                     ActivityOTDStatusDto actStatusDto = new ActivityOTDStatusDto();
                     actStatusDto.setActOtdStatus(strarray[i]);
                     acStatusDtoList.add(actStatusDto); 
               }
        }
        return acStatusDtoList;
 }

}