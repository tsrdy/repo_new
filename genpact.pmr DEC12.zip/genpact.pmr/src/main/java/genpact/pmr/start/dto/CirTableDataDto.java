package genpact.pmr.start.dto;

public class CirTableDataDto {

	private String customer;
	private String project;
	private String case_;
	private String issue_and_containment;
	private String response;
	private String commit;
	private String forecast;
	private String cir_operational_risk;
	private int cir_risk_score;
	private int age;
	private int cir_staleness;
	private int min_cir_openitemssortbyaging;
	
		
	public CirTableDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public CirTableDataDto(String customer, String project, String case_, String issue_and_containment, String response,
			String commit, String forecast, String cir_operational_risk, int cir_risk_score, int age, int cir_staleness,
			int min_cir_openitemssortbyaging) {
		super();
		this.customer = customer;
		this.project = project;
		this.case_ = case_;
		this.issue_and_containment = issue_and_containment;
		this.response = response;
		this.commit = commit;
		this.forecast = forecast;
		this.cir_operational_risk = cir_operational_risk;
		this.cir_risk_score = cir_risk_score;
		this.age = age;
		this.cir_staleness = cir_staleness;
		this.min_cir_openitemssortbyaging = min_cir_openitemssortbyaging;
	}



	public String getCustomer() {
		return customer;
	}


	public void setCustomer(String customer) {
		this.customer = customer;
	}


	public String getProject() {
		return project;
	}


	public void setProject(String project) {
		this.project = project;
	}


	public String getCase_() {
		return case_;
	}


	public void setCase_(String case_) {
		this.case_ = case_;
	}


	public String getIssue_and_containment() {
		return issue_and_containment;
	}


	public void setIssue_and_containment(String issue_and_containment) {
		this.issue_and_containment = issue_and_containment;
	}


	public String getResponse() {
		return response;
	}


	public void setResponse(String response) {
		this.response = response;
	}


	public String getCommit() {
		return commit;
	}


	public void setCommit(String commit) {
		this.commit = commit;
	}


	public String getForecast() {
		return forecast;
	}


	public void setForecast(String forecast) {
		this.forecast = forecast;
	}


	public String getCir_operational_risk() {
		return cir_operational_risk;
	}


	public void setCir_operational_risk(String cir_operational_risk) {
		this.cir_operational_risk = cir_operational_risk;
	}


	public int getCir_risk_score() {
		return cir_risk_score;
	}


	public void setCir_risk_score(int cir_risk_score) {
		this.cir_risk_score = cir_risk_score;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public int getCir_staleness() {
		return cir_staleness;
	}


	public void setCir_staleness(int cir_staleness) {
		this.cir_staleness = cir_staleness;
	}


	public int getMin_cir_openitemssortbyaging() {
		return min_cir_openitemssortbyaging;
	}


	public void setMin_cir_openitemssortbyaging(int min_cir_openitemssortbyaging) {
		this.min_cir_openitemssortbyaging = min_cir_openitemssortbyaging;
	}
	
	

//customer,project,case_,issue_and_containment,response,commit  ,forecast  ,	cir_operational_risk  ,	cir_risk_score  ,age  ,cir_staleness, min_cir_openitemssortbyaging

}
