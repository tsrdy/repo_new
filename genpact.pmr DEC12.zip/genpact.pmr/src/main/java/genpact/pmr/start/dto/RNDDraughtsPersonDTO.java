package genpact.pmr.start.dto;

public class RNDDraughtsPersonDTO {
	  private String name ; 
	  private long rnddraTotalCbl;
	  private long rnddraTotalPreviousEac;
	  private long rnddraTotalEac;
	  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getRnddraTotalCbl() {
		return rnddraTotalCbl;
	}
	public void setRnddraTotalCbl(long rnddraTotalCbl) {
		this.rnddraTotalCbl = rnddraTotalCbl;
	}
	public long getRnddraTotalPreviousEac() {
		return rnddraTotalPreviousEac;
	}
	public void setRnddraTotalPreviousEac(long rnddraTotalPreviousEac) {
		this.rnddraTotalPreviousEac = rnddraTotalPreviousEac;
	}
	public long getRnddraTotalEac() {
		return rnddraTotalEac;
	}
	public void setRnddraTotalEac(long rnddraTotalEac) {
		this.rnddraTotalEac = rnddraTotalEac;
	}
	

}
