package genpact.pmr.start.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.PowerConversionBillingSummaryDao;
import genpact.pmr.start.dao.PowerConversionPastDueDao;
import genpact.pmr.start.dto.PowerConversionBillingSummaryRequestJSONDataDto;
import genpact.pmr.start.dto.PowerConversionBillingSummaryResponseJSONDataDto;
import genpact.pmr.start.dto.PowerConversionPastDueRequestJSONDataDto;
import genpact.pmr.start.dto.PowerConversionPastDueResponseJSONDataDto;

@CrossOrigin
@RestController

public class PowerConversionPastDueService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private PowerConversionPastDueDao powerConversionPastDueDao;

	// just to check
	@RequestMapping(value = "/pastdue", method = RequestMethod.GET)
	public String msg() {
		return "Running Succesfully";
	}

	// To retrive info
	@RequestMapping(value = "/getpastdue", method = RequestMethod.GET)
	public PowerConversionPastDueResponseJSONDataDto getInfo() {
		PowerConversionPastDueResponseJSONDataDto conversionPastDueResponseJSONDataDto = null;

		conversionPastDueResponseJSONDataDto = powerConversionPastDueDao.getRegions();

		return conversionPastDueResponseJSONDataDto;

	}

	// populated of region dropdown values
	/* input paramaters are Billing Quarter */
	@RequestMapping(value = "/getpastdue/region/regionalmanager/projectmanager/billingquarter", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PowerConversionPastDueResponseJSONDataDto getTableDataByBillingQuarter(
			@RequestBody PowerConversionPastDueRequestJSONDataDto[] requestJSONDataDtos) {

		PowerConversionPastDueResponseJSONDataDto powerConversionPastDueResponseJSONDataDto = null;

		PowerConversionPastDueRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		powerConversionPastDueResponseJSONDataDto = powerConversionPastDueDao
				.getTableDataByBillingQuarterFilter(requestJSONDataDto);
		return powerConversionPastDueResponseJSONDataDto;
	}

	// populated of regional managers dropdown values
	/* input paramaters are billing qurater and regions */
	@RequestMapping(value = "/getpastdue/region", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PowerConversionPastDueResponseJSONDataDto getRegionalManager(
			@RequestBody PowerConversionPastDueRequestJSONDataDto[] requestJSONDataDtos) {

		PowerConversionPastDueResponseJSONDataDto conversionPastDueResponseJSONDataDto = null;

		PowerConversionPastDueRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		conversionPastDueResponseJSONDataDto = powerConversionPastDueDao.getRegionalManager(requestJSONDataDto);

		return conversionPastDueResponseJSONDataDto;
	}

	// populated of Project managers dropdown values
	/* input paramaters are billing qurater and regions and regional manager */
	@RequestMapping(value = "/getpastdue/region/regionalmanager", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PowerConversionPastDueResponseJSONDataDto getProjectManager(
			@RequestBody PowerConversionPastDueRequestJSONDataDto[] requestJSONDataDtos) {

		PowerConversionPastDueResponseJSONDataDto powerConversionPastDueResponseJSONDataDto = null;

		PowerConversionPastDueRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		powerConversionPastDueResponseJSONDataDto = powerConversionPastDueDao.getProjectManager(requestJSONDataDto);

		return powerConversionPastDueResponseJSONDataDto;

	}
	// populated of Project managers dropdown values
		/* input paramaters are billing qurater and regions and regional manager and projectmanager*/
	@RequestMapping(value = "/getpastdue/region/regionalmanager/projectmanager", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PowerConversionPastDueResponseJSONDataDto getTableDataByAllFilter(
			@RequestBody PowerConversionPastDueRequestJSONDataDto[] requestJSONDataDtos) {

		PowerConversionPastDueResponseJSONDataDto powerConversionPastDueResponseJSONDataDto = null;

		PowerConversionPastDueRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		powerConversionPastDueResponseJSONDataDto = powerConversionPastDueDao
				.getTableDataByAllFilter(requestJSONDataDto);

		return powerConversionPastDueResponseJSONDataDto;
	}

}
