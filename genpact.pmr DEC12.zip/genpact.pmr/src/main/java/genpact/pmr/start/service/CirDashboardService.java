package genpact.pmr.start.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.CirDashboardDao;
import genpact.pmr.start.dto.CirCaseStatusFilter;
import genpact.pmr.start.dto.CirDashboardJSONDataDto;
import genpact.pmr.start.dto.CirFunctionalAreaFilter;
import genpact.pmr.start.dto.CirProjectFilter;
import genpact.pmr.start.dto.CirRequestFilter;
import genpact.pmr.start.dto.CirSummaryDataDto;
import genpact.pmr.start.dto.CirTableDataDto;
import genpact.pmr.start.dto.FormatDataDto;
@CrossOrigin
@RestController
public class CirDashboardService {


	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
private CirDashboardDao cirDashboardDao;

	// just to check
	@RequestMapping(value = "/cir", method = RequestMethod.GET)
	public String msg() {
		return "Running Succesfully";
	}
	
	
	// To retrive info
		@RequestMapping(value = "/getcir", method = RequestMethod.GET)
		public CirDashboardJSONDataDto getInfo() {
			CirDashboardJSONDataDto cirDashboardJSONDataDto=new CirDashboardJSONDataDto();
			List<FormatDataDto> formatDataDtos = null;
					
			String str="";
			String sql = "select distinct(project) from cirdashboard "; 
		
			formatDataDtos = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
				int counter;

				public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

					return new FormatDataDto(++counter, rs.getString("project"));
				}

			});
		
			cirDashboardJSONDataDto.setFormatDataDtos(formatDataDtos);
			
			CirSummaryDataDto cirSummaryDataDto = cirDashboardDao.getCirSummary(str);
			cirDashboardJSONDataDto.setCirSummaryDataDtos(cirSummaryDataDto);
			
			List<CirTableDataDto> cirTableDataDtos = cirDashboardDao.getCirTableData(str);
			cirDashboardJSONDataDto.setCirTableDataDtos(cirTableDataDtos);
			return cirDashboardJSONDataDto;

		}

		// // retrieve info with Region

		@RequestMapping(value = "/getcir/projectid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
		public CirDashboardJSONDataDto getFunctionalArea(@RequestBody CirRequestFilter[] cirFilterArr) {
			CirDashboardJSONDataDto cirDashboardJSONDataDto = new CirDashboardJSONDataDto();
			CirRequestFilter cirFilter = cirFilterArr[0];
			
			List<CirProjectFilter> cirProjectFilters = cirFilter.getCirProjectFilters();

			String project = "";
			String str="";
			int i = 0;
			for (CirProjectFilter cirProjectFilter : cirProjectFilters) {

				if ((i + 1) == cirProjectFilters.size()) {
					project += cirProjectFilter.getLabel() + ",";
					
					break;
				} else if (i < cirProjectFilters.size()) {
					project += cirProjectFilter.getLabel() + ",";
					
				}
				i++;
			}

			System.out.println("===============================11");
		String segment = "select distinct(cir_functional_area_of_defect_cause) from cirdashboard where project in ( ";

		segment+=createSql(project);

			segment += ")";

			List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

				int counter;

				public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {


					return new FormatDataDto(++counter, rs.getString("cir_functional_area_of_defect_cause"));

				}

			});
			System.out.println("===============================12");
			cirDashboardJSONDataDto.setFormatDataDtos(formatDataDtos);
			str+="where project in ("+ createSql(project)+ ")";
			System.out.println(str+"hcbjkw");
			CirSummaryDataDto cirSummaryDataDto = cirDashboardDao.getCirSummary(str);
			cirDashboardJSONDataDto.setCirSummaryDataDtos(cirSummaryDataDto);
			
			List<CirTableDataDto> cirTableDataDtos = cirDashboardDao.getCirTableData(str);
			cirDashboardJSONDataDto.setCirTableDataDtos(cirTableDataDtos);
			
			return cirDashboardJSONDataDto;
		}

		// // retrieve info with Region

				@RequestMapping(value = "/getcir/projectid/functionalarea", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
				public CirDashboardJSONDataDto getCaseStatus(@RequestBody CirRequestFilter[] cirFilterArr) {
					CirDashboardJSONDataDto cirDashboardJSONDataDto = new CirDashboardJSONDataDto();
					CirRequestFilter cirFilter = cirFilterArr[0];
					
					List<CirProjectFilter> cirProjectFilters = cirFilter.getCirProjectFilters();
					List<CirFunctionalAreaFilter> cirFunctionalAreaFilters= cirFilter.getCirFunctionalAreaFilters();

					String str="";
					String project = "";
					String functionalArea = "";
					int i = 0;
					for (CirProjectFilter cirProjectFilter : cirProjectFilters) {

						if ((i + 1) == cirProjectFilters.size()) {
							project += cirProjectFilter.getLabel() + ",";
							
							break;
						} else if (i < cirProjectFilters.size()) {
							project += cirProjectFilter.getLabel() + ",";
							
						}
						i++;
					}
					i =0;
					for (CirFunctionalAreaFilter functionalAreaFilter : cirFunctionalAreaFilters) {

						if ((i + 1) == cirFunctionalAreaFilters.size()) {
							functionalArea+=functionalAreaFilter.getLabel()+",";
							break;
						} else if (i < cirFunctionalAreaFilters.size()) {
							functionalArea += functionalAreaFilter.getLabel()+",";
						}
						i++;
					}

				String segment = "select distinct(case_) from cirdashboard where project in ( ";

				segment+=createSql(project);
				segment+=") and cir_functional_area_of_defect_cause in (";

				segment += createSql(functionalArea);


					segment += ")";

					List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

						int counter;

						public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {


							return new FormatDataDto(++counter, rs.getString("case_"));

						}

					});
					cirDashboardJSONDataDto.setFormatDataDtos(formatDataDtos);
					
					str+="where project in ("+ createSql(project)+ ") and cir_functional_area_of_defect_cause in ("+ createSql(functionalArea)+")";
					
					CirSummaryDataDto cirSummaryDataDto = cirDashboardDao.getCirSummary(str);
					cirDashboardJSONDataDto.setCirSummaryDataDtos(cirSummaryDataDto);
					
					List<CirTableDataDto> cirTableDataDtos = cirDashboardDao.getCirTableData(str);
					cirDashboardJSONDataDto.setCirTableDataDtos(cirTableDataDtos);
					
					return cirDashboardJSONDataDto;
				}
				
				//  retrieve info with Region

				@RequestMapping(value = "/getcir/projectid/functionalarea/casestatus", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
				public CirDashboardJSONDataDto getCaseStatusWithCaseStatusSelection(@RequestBody CirRequestFilter[] cirFilterArr) {
					CirDashboardJSONDataDto cirDashboardJSONDataDto = new CirDashboardJSONDataDto();
					CirRequestFilter cirFilter = cirFilterArr[0];
					
					List<CirProjectFilter> cirProjectFilters = cirFilter.getCirProjectFilters();
					List<CirFunctionalAreaFilter> cirFunctionalAreaFilters= cirFilter.getCirFunctionalAreaFilters();
					List<CirCaseStatusFilter> caseStatusFilters= cirFilter.getCaseStatusFilters();

					String str="";
					String project = "";
					String functionalArea = "";
					String caseStatus = "";
					int i = 0;
					for (CirProjectFilter cirProjectFilter : cirProjectFilters) {

						if ((i + 1) == cirProjectFilters.size()) {
							project += cirProjectFilter.getLabel() + ",";
							
							break;
						} else if (i < cirProjectFilters.size()) {
							project += cirProjectFilter.getLabel() + ",";
							
						}
						i++;
					}
					i =0;
					for (CirFunctionalAreaFilter functionalAreaFilter : cirFunctionalAreaFilters) {

						if ((i + 1) == cirFunctionalAreaFilters.size()) {
							functionalArea+=functionalAreaFilter.getLabel()+",";
							break;
						} else if (i < cirFunctionalAreaFilters.size()) {
							functionalArea += functionalAreaFilter.getLabel()+",";
						}
						i++;
					}
					
					i =0;
					for (CirCaseStatusFilter caseStatusFilter : caseStatusFilters) {

						if ((i + 1) == caseStatusFilters.size()) {
							caseStatus+=caseStatusFilter.getLabel()+",";
							break;
						} else if (i < caseStatusFilters.size()) {
							caseStatus += caseStatusFilter.getLabel()+",";
						}
						i++;
					}

				String segment = "select distinct(case_) from cirdashboard where project in ( ";

				segment+=createSql(project);
				segment+=") and cir_functional_area_of_defect_cause in (";

				segment += createSql(functionalArea);
				
				segment+=") and case_ in (";

				segment += createSql(caseStatus);



					segment += ")";
					
					List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

						int counter;

						public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {


							return new FormatDataDto(++counter, rs.getString("case_"));

						}

					});
					cirDashboardJSONDataDto.setFormatDataDtos(formatDataDtos);
					
					str+="where project in ("+ createSql(project)+ ") and cir_functional_area_of_defect_cause in ("+ createSql(functionalArea)+") and case_ in ("+ createSql(caseStatus)+")";
					
					CirSummaryDataDto cirSummaryDataDto = cirDashboardDao.getCirSummary(str);
					cirDashboardJSONDataDto.setCirSummaryDataDtos(cirSummaryDataDto);
					
					List<CirTableDataDto> cirTableDataDtos = cirDashboardDao.getCirTableData(str);
					cirDashboardJSONDataDto.setCirTableDataDtos(cirTableDataDtos);
					
					return cirDashboardJSONDataDto;
				}

		private String createSql(String str) {
			String[] strArray = str.split(",");

			String seg = "";

			for (int i = 0; i <= strArray.length; i++) {

				seg += "'" + strArray[i] + "'";

				if ((i + 1) == strArray.length) {
					break;
				} else if (i < strArray.length) {
					seg += ",";
				}
			}
			return seg;
		}

}
