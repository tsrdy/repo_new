package genpact.pmr.start.dto;

public class TechnicalEngineerDTO {
	
	  private String name ; 
	  private long techTotalCbl;
	  private long techTotalPreviousEac;
	  private long techTotalEac;
	  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getTechTotalCbl() {
		return techTotalCbl;
	}
	public void setTechTotalCbl(long techTotalCbl) {
		this.techTotalCbl = techTotalCbl;
	}
	public long getTechTotalPreviousEac() {
		return techTotalPreviousEac;
	}
	public void setTechTotalPreviousEac(long techTotalPreviousEac) {
		this.techTotalPreviousEac = techTotalPreviousEac;
	}
	public long getTechTotalEac() {
		return techTotalEac;
	}
	public void setTechTotalEac(long techTotalEac) {
		this.techTotalEac = techTotalEac;
	}
	  
	

}
