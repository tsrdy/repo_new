package genpact.pmr.start.dto;

public class TotalRevenueCalcDto {
	private double cbl;
	private double actuals;
	private double etc;
	private double eac;
	private double previous_eac;
	private String cost_code;
	private String type;
	
	public TotalRevenueCalcDto(double cbl, double actuals, double etc, double eac, double previous_eac,
			String cost_code, String type) {
		super();
		this.cbl = cbl;
		this.actuals = actuals;
		this.etc = etc;
		this.eac = eac;
		this.previous_eac = previous_eac;
		this.cost_code = cost_code;
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public TotalRevenueCalcDto(){
	}

	public TotalRevenueCalcDto(double cbl, double actuals, double etc, double eac, double previous_eac, String cost_code) {
		super();
		this.cbl = cbl;
		this.actuals = actuals;
		this.etc = etc;
		this.eac = eac;
		this.previous_eac = previous_eac;
		this.cost_code = cost_code;
	}

	public double getCbl() {
		return cbl;
	}

	public void setCbl(double cbl) {
		this.cbl = cbl;
	}

	public double getActuals() {
		return actuals;
	}

	public void setActuals(double actuals) {
		this.actuals = actuals;
	}

	public double getEtc() {
		return etc;
	}

	public void setEtc(double etc) {
		this.etc = etc;
	}

	public double getEac() {
		return eac;
	}

	public void setEac(double eac) {
		this.eac = eac;
	}

	public double getPrevious_eac() {
		return previous_eac;
	}

	public void setPrevious_eac(double previous_eac) {
		this.previous_eac = previous_eac;
	}

	public String getCost_code() {
		return cost_code;
	}

	public void setCost_code(String cost_code) {
		this.cost_code = cost_code;
	}
	
	
	

}
