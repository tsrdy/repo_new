package genpact.pmr.start.dto;

public class ActivityOTDStatusDto {

	private String actOtdStatus;
	private int statusCount;
	private double activityStatusCnt;
	
	public String getActOtdStatus() {
		return actOtdStatus;
	}
	public void setActOtdStatus(String actOtdStatus) {
		this.actOtdStatus = actOtdStatus;
	}
	public int getStatusCount() {
		return statusCount;
	}
	public void setStatusCount(int statusCount) {
		this.statusCount = statusCount;
	}
	public double getActivityStatusCnt() {
		return activityStatusCnt;
	}
	public void setActivityStatusCnt(double activityStatusCnt) {
		this.activityStatusCnt = activityStatusCnt;
	}
	public ActivityOTDStatusDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ActivityOTDStatusDto(String actOtdStatus, int statusCount) {
		super();
		this.actOtdStatus = actOtdStatus;
		this.statusCount = statusCount;
	}
	
}
