package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.PCPastDueProjectId3Q2016Dto;
import genpact.pmr.start.dto.PCPastDueProjectIdDto;
import genpact.pmr.start.dto.PCPastDueProjectManager3Q2016Dto;
import genpact.pmr.start.dto.PCPastDueProjectManagerDto;
import genpact.pmr.start.dto.PCPastDueRegion3Q2016Dto;
import genpact.pmr.start.dto.PCPastDueRegionDto;
import genpact.pmr.start.dto.PowerConversionBillingSummaryRequestJSONDataDto;
import genpact.pmr.start.dto.PowerConversionPastDueRequestJSONDataDto;
import genpact.pmr.start.dto.PowerConversionPastDueResponseJSONDataDto;

@Repository
public class PowerConversionPastDueDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	

	public PowerConversionPastDueResponseJSONDataDto getRegions() {

		PowerConversionPastDueResponseJSONDataDto responseJSON = new PowerConversionPastDueResponseJSONDataDto();

		String billing_quarter = "'Q3-2016'";
		String sqlRegion = "select distinct(region) from past_due where billing_quarter=" + billing_quarter;// bydefault

		// select distinct(region) from past_due where billing_quarter='Q3-2016'

		List<FormatDataDto> regionList = null;
		regionList = jdbcTemplate.query(sqlRegion, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("region"));
			}

		});

		responseJSON.setFormatData(regionList);// all regions
		// =================================================================================

		// ========preparing query for Region wise
		// Data=============================

		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		String region_data=createSql(getFormatForSql(regionList));
		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("+region_data+")  group by region,regional_manager";

		String SQL_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("+region_data+") group by region,regional_manager";

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("+region_data+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_3Q_2016List = getRegion(SQL_INTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_2Q_2016List = getRegion(SQL_INTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_2Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_3Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager";

		String SQL_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager";

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_3Q_2016List = getRegion(SQL_EXTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_2Q_2016List = getRegion(SQL_EXTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_2Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_3Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		responseJSON.setRegions(calculatedRegionDataList);

		// ===============preparing query for Project
		// Manager========================================

		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("+region_data+") group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("+region_data+")  group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("+region_data+")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_3Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_2Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_3Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		responseJSON.setProjectMansgers(calculatedProjectManagerDataList);

		// ===============preparing query for Project
		// Id========================================

		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();

		/*
		 * double internalPD_2016 = 0.0; double internalPD_3Q_2016 = 0.0;
		 * 
		 * double externalPD_3Q_2016 = 0.0; double externalPD_2016 = 0.0;
		 * 
		 * double totalPD_3Q_2016 = 0.0; double totalPD_2016 = 0.0;
		 */

		String SQL_PId_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("+region_data+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("+region_data+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("+region_data+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_3Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("+region_data+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_2Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_3Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		responseJSON.setProjectIds(calculatedProjectIdDataList);

		return responseJSON;
	}

	public PowerConversionPastDueResponseJSONDataDto getTableDataByBillingQuarterFilter(PowerConversionPastDueRequestJSONDataDto requestJSON){
		PowerConversionPastDueResponseJSONDataDto responseJSON = new PowerConversionPastDueResponseJSONDataDto();
		
		List<FormatDataDto> billingQuarterList=requestJSON.getBillingQuarterFilters();
		String billing_quarter ="'"+ billingQuarterList.get(0).getLabel()+"'";
		String sqlRegion = "select distinct(region) from past_due where billing_quarter = " + billing_quarter;// bydefault

		// select distinct(region) from past_due where billing_quarter='Q3-2016'

		List<FormatDataDto> regionList = null;
		
		regionList = jdbcTemplate.query(sqlRegion, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("region"));
			}

		});

		responseJSON.setFormatData(regionList);// all regions
		String all_regions = createSql(getFormatForSql(regionList));
	
		// =================================================================================

		// ========preparing query for Region wise
		// Data=============================

		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in ("+all_regions+") group by region,regional_manager";

		String SQL_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in ("+all_regions+")  group by region,regional_manager";

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in ("+all_regions+")  group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_3Q_2016List = getRegion(SQL_INTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_2Q_2016List = getRegion(SQL_INTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_2Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_3Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in ("+all_regions+")  group by region,regional_manager";

		String SQL_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in ("+all_regions+")  group by region,regional_manager";

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in ("+all_regions+")  group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_3Q_2016List = getRegion(SQL_EXTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_2Q_2016List = getRegion(SQL_EXTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_2Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_3Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		responseJSON.setRegions(calculatedRegionDataList);

		// ===============preparing query for Project
		// Manager========================================

		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in ("+all_regions+") group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in ("+all_regions+") group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in ("+all_regions+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_3Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in ("+all_regions+") group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in ("+all_regions+") group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in ("+all_regions+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_2Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_3Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		responseJSON.setProjectMansgers(calculatedProjectManagerDataList);

		// ===============preparing query for Project
		// Id========================================

		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();

		/*
		 * double internalPD_2016 = 0.0; double internalPD_3Q_2016 = 0.0;
		 * 
		 * double externalPD_3Q_2016 = 0.0; double externalPD_2016 = 0.0;
		 * 
		 * double totalPD_3Q_2016 = 0.0; double totalPD_2016 = 0.0;
		 */

		String SQL_PId_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in ("+all_regions+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in ("+all_regions+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in ("+all_regions+")  group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_3Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in ("+all_regions+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in ("+all_regions+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in ("+all_regions+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_2Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_3Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		responseJSON.setProjectIds(calculatedProjectIdDataList);

		return responseJSON;
	}
	private void calculatePD_2016DataListForResionWise(List<PCPastDueRegion3Q2016Dto> list,
			Map<String, PCPastDueRegion3Q2016Dto> map, Set<String> set) {
		
		for (PCPastDueRegion3Q2016Dto pcr : list) {
			String key = pcr.getRegion() + "," + pcr.getRegionalManager();
			if (set.add(key)) {

				map.put(key, pcr);
			} else {
				PCPastDueRegion3Q2016Dto pcr2 = map.get(key);
				pcr2.setSum(pcr2.getSum() + pcr.getSum());
				map.put(key, pcr2);

			}
		}
	}

	private void calculatePD_2016DataListForProjectId(List<PCPastDueProjectId3Q2016Dto> list,
			Map<String, PCPastDueProjectId3Q2016Dto> map, Set<String> set) {
		for (PCPastDueProjectId3Q2016Dto pcr : list) {
			String key = pcr.getRegion() + "," + pcr.getRegionalManager() + "," + pcr.getProjectManager() + ","
					+ pcr.getProjectId();
			if (set.add(key)) {

				map.put(key, pcr);
			} else {
				PCPastDueProjectId3Q2016Dto pcr2 = map.get(key);
				pcr2.setSum(pcr2.getSum() + pcr.getSum());
				map.put(key, pcr2);

			}
		}
	}

	private void calculatePD_2016DataListForProjectManager(List<PCPastDueProjectManager3Q2016Dto> list,
			Map<String, PCPastDueProjectManager3Q2016Dto> map, Set<String> set) {
		for (PCPastDueProjectManager3Q2016Dto pcr : list) {
			String key = pcr.getRegion() + "," + pcr.getRegionalManager() + "," + pcr.getProjectManager();
			if (set.add(key)) {

				map.put(key, pcr);
			} else {
				PCPastDueProjectManager3Q2016Dto pcr2 = map.get(key);
				pcr2.setSum(pcr2.getSum() + pcr.getSum());
				map.put(key, pcr2);

			}
		}
	}

	private List<PCPastDueProjectId3Q2016Dto> getProjectIdData(String sql) {

		return jdbcTemplate.query(sql, new RowMapper<PCPastDueProjectId3Q2016Dto>() {

			@Override
			public PCPastDueProjectId3Q2016Dto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new PCPastDueProjectId3Q2016Dto(rs.getString("region"), rs.getString("regional_manager"),
						rs.getString("project_manager"), rs.getString("project_number"), rs.getInt("sum"));
				// new PCPastDueProjectManager3Q2016Dto(rs.getString("region"),
				// rs.getString("regional_manager"),
				// rs.getString("project_manager"), rs.getInt("sum"));

			}

		});
	}

	private List<PCPastDueProjectManager3Q2016Dto> getProjectManagerData(String sql) {

		return jdbcTemplate.query(sql, new RowMapper<PCPastDueProjectManager3Q2016Dto>() {

			@Override
			public PCPastDueProjectManager3Q2016Dto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new PCPastDueProjectManager3Q2016Dto(rs.getString("region"), rs.getString("regional_manager"),
						rs.getString("project_manager"), rs.getInt("sum"));

			}

		});
	}

	private List<PCPastDueRegion3Q2016Dto> getRegion(String sql) {

		return jdbcTemplate.query(sql, new RowMapper<PCPastDueRegion3Q2016Dto>() {

			@Override
			public PCPastDueRegion3Q2016Dto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new PCPastDueRegion3Q2016Dto(rs.getString("region"), rs.getString("regional_manager"),
						rs.getInt("sum"));
			}

		});
	}

	public PowerConversionPastDueResponseJSONDataDto getRegionalManager(
			PowerConversionPastDueRequestJSONDataDto requestJSON) {

		PowerConversionPastDueResponseJSONDataDto responseJSON = new PowerConversionPastDueResponseJSONDataDto();

		List<FormatDataDto> billingQuarterList = requestJSON.getBillingQuarterFilters();
		List<FormatDataDto> regionFilters = requestJSON.getRegionFilters();

		String sqlRegionFormat = getFormatForSql(regionFilters);
		String sqlQuarterFormat = getFormatForSql(billingQuarterList);

		String sql = "select distinct(regional_manager) from past_due where region in(";

		sql += createSql(sqlRegionFormat);
		sql += ") and billing_quarter in(";
		sql += createSql(sqlQuarterFormat);
		sql += ")";

		// System.out.println("sql 88888 " + sql);

		List<FormatDataDto> regionalManagersList = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter;
			

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("regional_manager"));
			}

		});

		responseJSON.setFormatData(regionalManagersList);

		// ===================================================----------------------==================================================================================

		// =================================================================================

		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = null;
		String billingQuarter = billingQuarterList.get(0).getLabel();
		if (billingQuarter.equals("Q3-2016")) {
			calculatedRegionDataList = getQ3_2016DataByRegions(regionFilters);
		}
		if (billingQuarter.equals("Q2-2016")) {
			calculatedRegionDataList = getQ2_2016DataByRegions(regionFilters);
		}
		if (billingQuarter.equals("Q1-2016")) {
			calculatedRegionDataList = getQ1_2016DataByRegions(regionFilters);
		}

		responseJSON.setRegions(calculatedRegionDataList);
		// ====================end=====================

		// ===============preparing query for Project
		// Manager========================================

		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = null;

		if (billingQuarter.equals("Q3-2016")) {
			calculatedProjectManagerDataList = getQ3_2016DataByProjectManager(regionFilters);
		}
		if (billingQuarter.equals("Q2-2016")) {
			calculatedProjectManagerDataList = getQ2_2016DataByProjectManager(regionFilters);
		}
		if (billingQuarter.equals("Q1-2016")) {
			calculatedProjectManagerDataList = getQ1_2016DataByProjectManager(regionFilters);
		}

		responseJSON.setProjectMansgers(calculatedProjectManagerDataList);

		// ===============preparing query for Project
		// Id========================================

		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = null;
		if (billingQuarter.equals("Q3-2016")) {
			calculatedProjectIdDataList = getQ3_2016DataByProjectId(regionFilters);
		}
		if (billingQuarter.equals("Q2-2016")) {
			calculatedProjectIdDataList = getQ2_2016DataByProjectId(regionFilters);
		}
		if (billingQuarter.equals("Q1-2016")) {
			calculatedProjectIdDataList = getQ1_2016DataByProjectId(regionFilters);
		}

		responseJSON.setProjectIds(calculatedProjectIdDataList);
		
		return responseJSON;
	}

	private List<PCPastDueRegionDto> getQ3_2016DataByRegions(List<FormatDataDto> regions) {
		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager";

		String SQL_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")   group by region,regional_manager";

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")    group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_3Q_2016List = getRegion(SQL_INTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_2Q_2016List = getRegion(SQL_INTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_2Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_3Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
				/*else{//=========================================
					pcp = new PCPastDueRegionDto();
					pcp.setRegion(cpd.getRegion());
					pcp.setRegionalManager(cpd.getRegionalManager());
					pcp.setInternalPD_3Q_2016(cpd.getSum());
					calculatedRegionDataList.add(pcp);
				}*/
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager";

		String SQL_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager";

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_3Q_2016List = getRegion(SQL_EXTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_2Q_2016List = getRegion(SQL_EXTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_2Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_3Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
				/*else{//=========================================
					pcp = new PCPastDueRegionDto();
					pcp.setRegion(cpd.getRegion());
					pcp.setRegionalManager(cpd.getRegionalManager());
					pcp.setExternalPD_3Q_2016(cpd.getSum());
					calculatedRegionDataList.add(pcp);
				}*/
			}
		}
		
		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
				/*else{//=========================================
					pc3 = externalPD_2016Map.get(key);
					pcp = new PCPastDueRegionDto();
					pcp.setRegion(pc3.getRegion());
					pcp.setRegionalManager(pc3.getRegionalManager());
					pcp.setExternalPD_2016(pc3.getSum());
					calculatedRegionDataList.add(pcp);
				}*/
				
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;

	}

	private List<PCPastDueRegionDto> getQ2_2016DataByRegions(List<FormatDataDto> regions) {

		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")   group by region,regional_manager";

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")    group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_2Q_2016List = getRegion(SQL_INTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_2Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager";

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_2Q_2016List = getRegion(SQL_EXTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_2Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;
	}

	private List<PCPastDueRegionDto> getQ1_2016DataByRegions(List<FormatDataDto> regions) {

		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")    group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;
	}

	private List<PCPastDueProjectManagerDto> getQ3_2016DataByProjectManager(List<FormatDataDto> regions) {

		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_3Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
				/*else{//=========================================
					pcpm = new PCPastDueProjectManagerDto();
					pcpm.setRegion(cpd.getRegion());
					pcpm.setProjectManager(cpd.getProjectManager());
					pcpm.setRegionalManager(cpd.getRegionalManager());
					pcpm.setInternalPD_3Q_2016(cpd.getSum());
					calculatedProjectManagerDataList.add(pcpm);
				}*/
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_2Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_3Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}/*else{//=========================================
					PCPastDueProjectManagerDto pcp = new PCPastDueProjectManagerDto();
					pcp.setRegion(cpd.getRegion());
					pcp.setRegionalManager(cpd.getRegionalManager());
					pcp.setProjectManager(cpd.getProjectManager());
					pcp.setExternalPD_3Q_2016(cpd.getSum());
					calculatedProjectManagerDataList.add(pcp);
				}*/
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}/*else{//=========================================
					pc33 = PM_externalPD_2016Map.get(key);
					PCPastDueProjectManagerDto pcp = new PCPastDueProjectManagerDto();
					pcp.setRegion(pc33.getRegion());
					pcp.setRegionalManager(pc33.getRegionalManager());
					pcp.setProjectManager(pc33.getProjectManager());
					pcp.setExternalPD_2016(pc33.getSum());
					calculatedProjectManagerDataList.add(pcp);
				}*/
				
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;

	}

	private List<PCPastDueProjectManagerDto> getQ2_2016DataByProjectManager(List<FormatDataDto> regions) {

		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_2Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;
	}

	private List<PCPastDueProjectManagerDto> getQ1_2016DataByProjectManager(List<FormatDataDto> regions) {

		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;
	}

	private List<PCPastDueProjectIdDto> getQ3_2016DataByProjectId(List<FormatDataDto> regions) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();
		String SQL_PId_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_3Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}/*else{//=========================================
					PCPastDueProjectIdDto pcpm = new PCPastDueProjectIdDto();
					pcpm.setRegion(cpd.getRegion());
					pcpm.setProjectManager(cpd.getProjectManager());
					pcpm.setRegionalManager(cpd.getRegionalManager());
					pcpm.setProjectId(cpd.getProjectId());
					pcpm.setInternalPD_3Q_2016(cpd.getSum());
					calculatedProjectIdDataList.add(pcpm);
				}*/
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_2Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_3Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}/*else{//=========================================
					PCPastDueProjectIdDto pcp = new PCPastDueProjectIdDto();
					pcp.setRegion(cpd.getRegion());
					pcp.setRegionalManager(cpd.getRegionalManager());
					pcp.setProjectManager(cpd.getProjectManager());
					pcp.setProjectId(cpd.getProjectId());
					pcp.setExternalPD_3Q_2016(cpd.getSum());
					calculatedProjectIdDataList.add(pcp);
				}*/
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}/*else{//=========================================
					pc333 = PId_externalPD_2016Map.get(key);
					PCPastDueProjectManagerDto pcp = new PCPastDueProjectManagerDto();
					pc.setRegion(pc333.getRegion());
					pc.setRegionalManager(pc333.getRegionalManager());
					pc.setProjectManager(pc333.getProjectManager());
					pc.setProjectId(pc333.getProjectId());
					pc.setExternalPD_2016(pc333.getSum());
					calculatedProjectIdDataList.add(pc);
				}*/
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}

	private List<PCPastDueProjectIdDto> getQ2_2016DataByProjectId(List<FormatDataDto> regions) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();

		String SQL_PId_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_2Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}

	private List<PCPastDueProjectIdDto> getQ1_2016DataByProjectId(List<FormatDataDto> regions) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions))
				+ ") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}
	// ==========================================================================================================================================

	public PowerConversionPastDueResponseJSONDataDto getProjectManager(
			PowerConversionPastDueRequestJSONDataDto requestJSONDataDto) {

		PowerConversionPastDueResponseJSONDataDto responseJson = new PowerConversionPastDueResponseJSONDataDto();

		List<FormatDataDto> regionFilters = requestJSONDataDto.getRegionFilters();
		List<FormatDataDto> regionalManagerFilters = requestJSONDataDto.getRegionalManagerFilter();
		List<FormatDataDto> billingQuarterList = requestJSONDataDto.getBillingQuarterFilters();

		String sqlRegionFormat = getFormatForSql(regionFilters);
		String sqlQuarterFormat = getFormatForSql(billingQuarterList);
		String sqlRegionalManagerFormat = getFormatForSql(regionalManagerFilters);

		// System.out.println("sqlRegionalManagerFormat " +
		// sqlRegionalManagerFormat);

		String sql = "select distinct(project_manager) from past_due where region in(";

		sql += createSql(sqlRegionFormat);
		sql += ") and regional_manager in(";
		sql += createSql(sqlRegionalManagerFormat);
		sql += ") and billing_quarter in(";
		sql += createSql(sqlQuarterFormat);
		sql += ")";
		// System.out.println("Sql "+ sql);

		List<FormatDataDto> projectManagerList = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("project_manager"));
			}

		});

		responseJson.setFormatData(projectManagerList);
		// ========================== preparing query for region wise Data

		List<PCPastDueRegionDto> calculatedRegionDataList = null;

		String billingQuarter = billingQuarterList.get(0).getLabel();

		if (billingQuarter.equals("Q3-2016")) {
			calculatedRegionDataList = getProjectManagerDatRegonForQ3_2016(regionFilters, regionalManagerFilters,projectManagerList);
		}
		if (billingQuarter.equals("Q2-2016")) {
			calculatedRegionDataList = getProjectManagerDatRegonForQ2_2016(regionFilters, regionalManagerFilters,projectManagerList);
		}
		if (billingQuarter.equals("Q1-2016")) {
			calculatedRegionDataList = getProjectManagerDatRegonForQ1_2016(regionFilters, regionalManagerFilters,projectManagerList);
		}

		responseJson.setRegions(calculatedRegionDataList);
		// ====================end=====================

		// ===============preparing query for Project Manager ========================================

		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = null;

		if (billingQuarter.equals("Q3-2016")) {
			calculatedProjectManagerDataList = getProjectManager1DataForQ3_2016(regionFilters, regionalManagerFilters,projectManagerList);
		}
		if (billingQuarter.equals("Q2-2016")) {
			calculatedProjectManagerDataList = getProjectManager1DataForQ2_2016(regionFilters, regionalManagerFilters,projectManagerList);
		}
		if (billingQuarter.equals("Q1-2016")) {
			calculatedProjectManagerDataList = getProjectManager1DataForQ1_2016(regionFilters, regionalManagerFilters,projectManagerList);
		}

		responseJson.setProjectMansgers(calculatedProjectManagerDataList);

		// ===============preparing query for Project
		// Id========================================

		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = null;
		if (billingQuarter.equals("Q3-2016")) {
			calculatedProjectIdDataList = getProjectManagerQ3_2016DataByProjectId(regionFilters,
					regionalManagerFilters,projectManagerList);
		}//and project_manager in("+createSql(getFormatForSql(projectManager))+") 
		if (billingQuarter.equals("Q2-2016")) {
			calculatedProjectIdDataList = getProjectManagerQ2_2016DataByProjectId(regionFilters,
					regionalManagerFilters,projectManagerList);
		}
		if (billingQuarter.equals("Q1-2016")) {
			calculatedProjectIdDataList = getProjectManagerQ1_2016DataByProjectId(regionFilters,
					regionalManagerFilters,projectManagerList);
		}
			
		
		
		responseJson.setProjectIds(calculatedProjectIdDataList);
			
		//======================pradeep
			projectManagerList = new ArrayList<FormatDataDto>();
			System.out.println(calculatedProjectManagerDataList.size());
		int count =0;
		for (int i = 0; i < calculatedProjectManagerDataList.size(); i++) {
			PCPastDueProjectManagerDto dueProjectManagerDto = calculatedProjectManagerDataList.get(i);
			System.out.println("projectmanagerslist"+dueProjectManagerDto);
			projectManagerList.add(new FormatDataDto(count++,dueProjectManagerDto.getProjectManager()));
			
			
		}
		
		responseJson.setFormatData(projectManagerList);

		// =============================end===========================

		return responseJson;

	}

	private List<PCPastDueProjectIdDto> getProjectManagerQ3_2016DataByProjectId(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto>  projectManager) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();
		String SQL_PId_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_3Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_2Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_3Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}

	private List<PCPastDueProjectIdDto> getProjectManagerQ2_2016DataByProjectId(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();

		String SQL_PId_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_2Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}

	private List<PCPastDueProjectIdDto> getProjectManagerQ1_2016DataByProjectId(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}

	private List<PCPastDueProjectManagerDto> getProjectManager1DataForQ2_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_2Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;

	}

	private List<PCPastDueProjectManagerDto> getProjectManager1DataForQ1_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;

	}

	private List<PCPastDueProjectManagerDto> getProjectManager1DataForQ3_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);
		
		
		//==============================================================confusion logic ==============

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_3Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

					if (key.equals(key2)) {
						pc.setInternalPD_3Q_2016(cpd.getSum());
					}
					/*else{//=========================================
					pcpm = new PCPastDueProjectManagerDto();
					pcpm.setRegion(cpd.getRegion());
					pcpm.setProjectManager(cpd.getProjectManager());
					pcpm.setRegionalManager(cpd.getRegionalManager());
					pcpm.setInternalPD_3Q_2016(cpd.getSum());
					calculatedProjectManagerDataList.add(pcpm);
				}*/
			}
		}
		
		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_2Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_3Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

					if (key.equals(key2)) {
						pc.setExternalPD_3Q_2016(cpd.getSum());
					}
					/*else{//=========================================
						PCPastDueProjectManagerDto pcp = new PCPastDueProjectManagerDto();
					pcp.setRegion(cpd.getRegion());
					pcp.setRegionalManager(cpd.getRegionalManager());
					pcp.setProjectManager(cpd.getProjectManager());
					pcp.setExternalPD_3Q_2016(cpd.getSum());
					calculatedProjectManagerDataList.add(pcp);
				}*/
					
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
				/*else{//=========================================
				PCPastDueProjectManagerDto pcq = PM_externalPD_2016Map.get(key);
				pcp = new PCPastDueRegionDto();
				pcp.setRegion(pc3.getRegion());
				pcp.setRegionalManager(pc3.getRegionalManager());
				pcp.setExternalPD_2016(pc3.getSum());
				calculatedRegionDataList.add(pcp);
			}
				*/
			
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;

	}

	private List<PCPastDueRegionDto> getProjectManagerDatRegonForQ1_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;
	}

	private List<PCPastDueRegionDto> getProjectManagerDatRegonForQ2_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_2Q_2016List = getRegion(SQL_INTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_2Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_2Q_2016List = getRegion(SQL_EXTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_2Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;
	}

	private List<PCPastDueRegionDto> getProjectManagerDatRegonForQ3_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {

		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_3Q_2016List = getRegion(SQL_INTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_2Q_2016List = getRegion(SQL_INTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_2Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_3Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_3Q_2016List = getRegion(SQL_EXTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_2Q_2016List = getRegion(SQL_EXTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_2Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_3Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;
	}

	public PowerConversionPastDueResponseJSONDataDto getTableDataByAllFilter(PowerConversionPastDueRequestJSONDataDto requestJSONDataDto) {

		PowerConversionPastDueResponseJSONDataDto responseJson = new PowerConversionPastDueResponseJSONDataDto();

		List<FormatDataDto> regionFilters = requestJSONDataDto.getRegionFilters();
		List<FormatDataDto> regionalManagerFilters = requestJSONDataDto.getRegionalManagerFilter();
		List<FormatDataDto> billingQuarterList = requestJSONDataDto.getBillingQuarterFilters();
		List<FormatDataDto> projectManagerFilters = requestJSONDataDto.getProjectManagerFilters();//===

		String sql = "select distinct(project_number) from past_due where region in(";

		sql += createSql(getFormatForSql(regionFilters));
		sql += ") and regional_manager in(";
		sql += createSql(getFormatForSql(regionalManagerFilters));
		sql += ") and billing_quarter in(";
		sql += createSql(getFormatForSql(billingQuarterList));
		sql += ") and project_manager in(";
		sql += createSql(getFormatForSql(projectManagerFilters));
		sql += ")";


		System.out.println(sql);
		List<FormatDataDto> projectNumberList = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("project_number"));
			}

		});

		 responseJson.setFormatData(projectNumberList);
		 
		// ========================== preparing query for region wise Data

			List<PCPastDueRegionDto> calculatedRegionDataList = null;

			String billingQuarter = billingQuarterList.get(0).getLabel();

			if (billingQuarter.equals("Q3-2016")) {
				calculatedRegionDataList = getProjectIdDatRegonForQ3_2016(regionFilters, regionalManagerFilters,projectManagerFilters);
			}
			if (billingQuarter.equals("Q2-2016")) {
				calculatedRegionDataList = getProjectIdDatRegonForQ2_2016(regionFilters, regionalManagerFilters,projectManagerFilters);
			}
			if (billingQuarter.equals("Q1-2016")) {
				calculatedRegionDataList = getProjectIdDatRegonForQ1_2016(regionFilters, regionalManagerFilters,projectManagerFilters);
			}

			responseJson.setRegions(calculatedRegionDataList);
			// ====================end=====================

			// ===============preparing query for Project Manager========================================

			List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = null;

			if (billingQuarter.equals("Q3-2016")) {
				calculatedProjectManagerDataList = getProjectManagerDataForQ3_2016(regionFilters, regionalManagerFilters,projectManagerFilters);
			}
			if (billingQuarter.equals("Q2-2016")) {
				calculatedProjectManagerDataList = getProjectManagerDataForQ2_2016(regionFilters, regionalManagerFilters,projectManagerFilters);
			}
			if (billingQuarter.equals("Q1-2016")) {
				calculatedProjectManagerDataList = getProjectManagerDataForQ1_2016(regionFilters, regionalManagerFilters,projectManagerFilters);
			}

			responseJson.setProjectMansgers(calculatedProjectManagerDataList);
			
			// ===============preparing query for Project Id========================================

			List<PCPastDueProjectIdDto> calculatedProjectIdDataList = null;
			if (billingQuarter.equals("Q3-2016")) {
				calculatedProjectIdDataList = getProjectIdQ3_2016DataByProjectId(regionFilters,
						regionalManagerFilters,projectManagerFilters);
			}
			if (billingQuarter.equals("Q2-2016")) {
				calculatedProjectIdDataList = getProjectIdQ2_2016DataByProjectId(regionFilters,
						regionalManagerFilters,projectManagerFilters);
			}
			if (billingQuarter.equals("Q1-2016")) {
				calculatedProjectIdDataList = getProjectIdQ1_2016DataByProjectId(regionFilters,
						regionalManagerFilters,projectManagerFilters);
			}

			responseJson.setProjectIds(calculatedProjectIdDataList);

			// =============================end===========================

		return responseJson;
	}
	
	private List<PCPastDueProjectIdDto> getProjectIdQ1_2016DataByProjectId(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> project_manager) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}
	private List<PCPastDueProjectIdDto> getProjectIdQ2_2016DataByProjectId(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> project_manager) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();

		String SQL_PId_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ")  and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_2Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}
	private List<PCPastDueProjectIdDto> getProjectIdQ3_2016DataByProjectId(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> project_manager) {
		List<PCPastDueProjectIdDto> calculatedProjectIdDataList = new ArrayList<>();
		String SQL_PId_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_INTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_internalPD_2016Map = new HashMap<>();
		Set<String> PId_internalPD_2016Set = new HashSet<>();

		// Calculating PId_internalPD_2016
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_1Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_2Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_INTERNAL_PD_3Q_2016List, PId_internalPD_2016Map,
				PId_internalPD_2016Set);

		// setting PId_internalPD_2016
		PCPastDueProjectIdDto pcpid = null;
		PCPastDueProjectId3Q2016Dto pcdid = null;
		for (String key : PId_internalPD_2016Map.keySet()) {
			pcpid = new PCPastDueProjectIdDto();
			pcdid = PId_internalPD_2016Map.get(key);

			pcpid.setRegion(pcdid.getRegion());
			pcpid.setRegionalManager(pcdid.getRegionalManager());
			pcpid.setProjectManager(pcdid.getProjectManager());
			pcpid.setProjectId(pcdid.getProjectId());
			pcpid.setInternalPD_2016(pcdid.getSum());

			calculatedProjectIdDataList.add(pcpid);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PId_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		String SQL_PId_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager,project_number from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager))
				+ ") and project_manager in("+createSql(getFormatForSql(project_manager))+") group by region,regional_manager,project_manager,project_number";

		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_3Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_2Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectId3Q2016Dto> PId_EXTERNAL_PD_1Q_2016List = getProjectIdData(SQL_PId_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectId3Q2016Dto> PId_externalPD_2016Map = new HashMap<>();
		Set<String> PId_externalPD_2016Set = new HashSet<>();

		// Calculating PId_externalPD_2016
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_1Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_2Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);
		calculatePD_2016DataListForProjectId(PId_EXTERNAL_PD_3Q_2016List, PId_externalPD_2016Map,
				PId_externalPD_2016Set);

		// setting for PId_externalPD_3Q_2016

		for (PCPastDueProjectId3Q2016Dto cpd : PId_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager() + ","
					+ cpd.getProjectId();
			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for PId_externalPD_2016
		PCPastDueProjectId3Q2016Dto pc333 = null;

		for (String key : PId_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager() + ","
						+ pc.getProjectId();
				if (key.equals(key2)) {
					pc333 = PId_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc333.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectIdDto pc : calculatedProjectIdDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectIdDataList;
	}
	private List<PCPastDueProjectManagerDto> getProjectManagerDataForQ1_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;

	}

	private List<PCPastDueProjectManagerDto> getProjectManagerDataForQ2_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")   and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_2Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;

	}
	private List<PCPastDueProjectManagerDto> getProjectManagerDataForQ3_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		List<PCPastDueProjectManagerDto> calculatedProjectManagerDataList = new ArrayList<>();

		String SQL_PM_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")   and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_INTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_internalPD_2016Map = new HashMap<>();
		Set<String> PM_internalPD_2016Set = new HashSet<>();

		// Calculating PM_internalPD_2016
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_1Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_2Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_INTERNAL_PD_3Q_2016List, PM_internalPD_2016Map,
				PM_internalPD_2016Set);

		// setting PM_internalPD_2016
		PCPastDueProjectManagerDto pcpm = null;
		PCPastDueProjectManager3Q2016Dto pcdm = null;
		for (String key : PM_internalPD_2016Map.keySet()) {
			pcpm = new PCPastDueProjectManagerDto();
			pcdm = PM_internalPD_2016Map.get(key);

			pcpm.setRegion(pcdm.getRegion());
			pcpm.setRegionalManager(pcdm.getRegionalManager());
			pcpm.setProjectManager(pcdm.getProjectManager());
			pcpm.setInternalPD_2016(pcdm.getSum());

			calculatedProjectManagerDataList.add(pcpm);
		}

		// setting for PM_internalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_PM_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		String SQL_PM_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager,project_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External'  and region in("
				+ createSql(getFormatForSql(regions)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")   and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager,project_manager";

		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_3Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_3Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_2Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_2Q_2016);
		List<PCPastDueProjectManager3Q2016Dto> PM_EXTERNAL_PD_1Q_2016List = getProjectManagerData(
				SQL_PM_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueProjectManager3Q2016Dto> PM_externalPD_2016Map = new HashMap<>();
		Set<String> PM_externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_1Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_2Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);
		calculatePD_2016DataListForProjectManager(PM_EXTERNAL_PD_3Q_2016List, PM_externalPD_2016Map,
				PM_externalPD_2016Set);

		// setting for PM_externalPD_3Q_2016

		for (PCPastDueProjectManager3Q2016Dto cpd : PM_EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager() + "," + cpd.getProjectManager();
			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueProjectManager3Q2016Dto pc33 = null;

		for (String key : PM_externalPD_2016Map.keySet()) {

			for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

				String key2 = pc.getRegion() + "," + pc.getRegionalManager() + "," + pc.getProjectManager();
				if (key.equals(key2)) {
					pc33 = PM_externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc33.getSum());
				}
			}
		}

		// ==================================================================

		// calculating data for Total data

		for (PCPastDueProjectManagerDto pc : calculatedProjectManagerDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedProjectManagerDataList;

	}

	private List<PCPastDueRegionDto> getProjectIdDatRegonForQ1_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ") and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_1Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;
	}
	private List<PCPastDueRegionDto> getProjectIdDatRegonForQ2_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {
		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data
		String SQL_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_2Q_2016List = getRegion(SQL_INTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_2Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_2Q_2016List = getRegion(SQL_EXTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_2Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_2Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;
	}
	private List<PCPastDueRegionDto> getProjectIdDatRegonForQ3_2016(List<FormatDataDto> regions,
			List<FormatDataDto> regionalManager,List<FormatDataDto> projectManager) {

		// ========preparing query for Region wise
		// Data=============================
		List<PCPastDueRegionDto> calculatedRegionDataList = new ArrayList<>();

		// *1 preparing qury for Internal data

		String SQL_INTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'Internal' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_INTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_INTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'Internal'  and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+")  group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_3Q_2016List = getRegion(SQL_INTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_2Q_2016List = getRegion(SQL_INTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> INTERNAL_PD_1Q_2016List = getRegion(SQL_INTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> internalPD_2016Map = new HashMap<>();
		Set<String> internalPD_2016Set = new HashSet<>();

		// Calculating internalPD_2016
		calculatePD_2016DataListForResionWise(INTERNAL_PD_1Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_2Q_2016List, internalPD_2016Map, internalPD_2016Set);
		calculatePD_2016DataListForResionWise(INTERNAL_PD_3Q_2016List, internalPD_2016Map, internalPD_2016Set);

		// setting internalPD_2016
		PCPastDueRegionDto pcp = null;
		PCPastDueRegion3Q2016Dto pcd = null;
		for (String key : internalPD_2016Map.keySet()) {
			pcp = new PCPastDueRegionDto();
			pcd = internalPD_2016Map.get(key);

			pcp.setRegion(pcd.getRegion());
			pcp.setRegionalManager(pcd.getRegionalManager());
			pcp.setInternalPD_2016(pcd.getSum());

			calculatedRegionDataList.add(pcp);
		}

		// setting for internalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : INTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setInternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// ===================================================
		// *2 preparing query for External data

		String SQL_EXTERNAL_PD_3Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q3-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_EXTERNAL_PD_2Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q2-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		String SQL_EXTERNAL_PD_1Q_2016 = "select sum(usd_open_inv_amt) as sum,region,regional_manager from past_due where billing_quarter in('Q1-2016') and internal_external like 'External' and region in("
				+ createSql(getFormatForSql(regions)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManager)) + ")  and project_manager in("+createSql(getFormatForSql(projectManager))+") group by region,regional_manager";

		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_3Q_2016List = getRegion(SQL_EXTERNAL_PD_3Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_2Q_2016List = getRegion(SQL_EXTERNAL_PD_2Q_2016);
		List<PCPastDueRegion3Q2016Dto> EXTERNAL_PD_1Q_2016List = getRegion(SQL_EXTERNAL_PD_1Q_2016);

		Map<String, PCPastDueRegion3Q2016Dto> externalPD_2016Map = new HashMap<>();
		Set<String> externalPD_2016Set = new HashSet<>();

		// Calculating externalPD_2016
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_1Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_2Q_2016List, externalPD_2016Map, externalPD_2016Set);
		calculatePD_2016DataListForResionWise(EXTERNAL_PD_3Q_2016List, externalPD_2016Map, externalPD_2016Set);

		// setting for externalPD_3Q_2016

		for (PCPastDueRegion3Q2016Dto cpd : EXTERNAL_PD_3Q_2016List) {

			String key = cpd.getRegion() + "," + cpd.getRegionalManager();
			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc.setExternalPD_3Q_2016(cpd.getSum());
				}
			}
		}

		// setting for externalPD_2016
		PCPastDueRegion3Q2016Dto pc3 = null;

		for (String key : externalPD_2016Map.keySet()) {

			for (PCPastDueRegionDto pc : calculatedRegionDataList) {
				String key2 = pc.getRegion() + "," + pc.getRegionalManager();

				if (key.equals(key2)) {
					pc3 = externalPD_2016Map.get(key);
					pc.setExternalPD_2016(pc3.getSum());
				}
			}
		}
		// ==================================================================

		// calculating data for Total data

		for (PCPastDueRegionDto pc : calculatedRegionDataList) {

			pc.setTotalDuesPD_2016(pc.getExternalPD_2016() + pc.getInternalPD_2016());
			pc.setTotalDuesPD_3Q_2016(pc.getExternalPD_3Q_2016() + pc.getInternalPD_3Q_2016());

		}

		return calculatedRegionDataList;
	}
private String getFormatForSql(List<FormatDataDto> regionFilters) {

		String regions = "";

		int i = 0;
		for (FormatDataDto regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				regions += regionFilter.getLabel() + ",";

				break;
			} else if (i < regionFilters.size()) {
				regions += regionFilter.getLabel() + ",";

			}
			i++;
		}
		return regions;
	}

	private String createSql(String str) {
		String[] strArray = str.split(",");

		String seg = "";

		for (int i = 0; i <= strArray.length; i++) {

			seg += "'" + strArray[i] + "'";

			if ((i + 1) == strArray.length) {
				break;
			} else if (i < strArray.length) {
				seg += ",";
			}
		}

		System.out.println(seg);
		return seg;
	}

}
