package genpact.pmr.start.dto;

import java.util.Arrays;
import java.util.List;

public class ManufacturingGeneralDTO {
	
	
	private String projectManager;
	private String projectID;
	private String[] costType;
	
	
	public String[] getCostType() {
		return costType;
	}
	public void setCostType(String[] costType) {
		this.costType = costType;
	}
	
	public ManufacturingGeneralDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getProjectID() {
		return projectID;
	}
	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}
	@Override
	public String toString() {
		return "ManufacturingGeneralDTO [projectManager=" + projectManager + ", projectID=" + projectID + ", costType="
				+ Arrays.toString(costType) + "]";
	}
	
	
	
}