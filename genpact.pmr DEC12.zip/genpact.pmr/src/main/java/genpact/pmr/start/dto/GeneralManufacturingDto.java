package genpact.pmr.start.dto;

import java.util.List;

public class GeneralManufacturingDto {
	
	
	private int mcDto;;
	
	private int  lampressDTO;
	
		
	private  int  pinventDTO;
	private  int  rotorDTO;
	private  int statcoreDTO;
	private  int  coilsDTO;
	private  int  copperDTO;
	private  int statwindDTO;
	private  int  vpiDTO;
	private  int  assemblyDTO;
	private  int  testDTO;
	public int getMcDto() {
		return mcDto;
	}
	public void setMcDto(int mcDto) {
		this.mcDto = mcDto;
	}
	public int getLampressDTO() {
		return lampressDTO;
	}
	public void setLampressDTO(int lampressDTO) {
		this.lampressDTO = lampressDTO;
	}
	public int getPinventDTO() {
		return pinventDTO;
	}
	public void setPinventDTO(int pinventDTO) {
		this.pinventDTO = pinventDTO;
	}
	public int getRotorDTO() {
		return rotorDTO;
	}
	public void setRotorDTO(int rotorDTO) {
		this.rotorDTO = rotorDTO;
	}
	public int getStatcoreDTO() {
		return statcoreDTO;
	}
	public void setStatcoreDTO(int statcoreDTO) {
		this.statcoreDTO = statcoreDTO;
	}
	public int getCoilsDTO() {
		return coilsDTO;
	}
	public void setCoilsDTO(int coilsDTO) {
		this.coilsDTO = coilsDTO;
	}
	public int getCopperDTO() {
		return copperDTO;
	}
	public void setCopperDTO(int copperDTO) {
		this.copperDTO = copperDTO;
	}
	public int getStatwindDTO() {
		return statwindDTO;
	}
	public void setStatwindDTO(int statwindDTO) {
		this.statwindDTO = statwindDTO;
	}
	public int getVpiDTO() {
		return vpiDTO;
	}
	public void setVpiDTO(int vpiDTO) {
		this.vpiDTO = vpiDTO;
	}
	public int getAssemblyDTO() {
		return assemblyDTO;
	}
	public void setAssemblyDTO(int assemblyDTO) {
		this.assemblyDTO = assemblyDTO;
	}
	public int getTestDTO() {
		return testDTO;
	}
	public void setTestDTO(int testDTO) {
		this.testDTO = testDTO;
	}
	public GeneralManufacturingDto(int mcDto, int lampressDTO, int pinventDTO, int rotorDTO, int statcoreDTO,
			int coilsDTO, int copperDTO, int statwindDTO, int vpiDTO, int assemblyDTO, int testDTO) {
		super();
		this.mcDto = mcDto;
		this.lampressDTO = lampressDTO;
		this.pinventDTO = pinventDTO;
		this.rotorDTO = rotorDTO;
		this.statcoreDTO = statcoreDTO;
		this.coilsDTO = coilsDTO;
		this.copperDTO = copperDTO;
		this.statwindDTO = statwindDTO;
		this.vpiDTO = vpiDTO;
		this.assemblyDTO = assemblyDTO;
		this.testDTO = testDTO;
	}
	
}
