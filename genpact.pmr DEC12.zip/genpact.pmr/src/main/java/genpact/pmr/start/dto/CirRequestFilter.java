package genpact.pmr.start.dto;

import java.util.List;

public class CirRequestFilter {
	
	List<CirProjectFilter> cirProjectFilters;
	List<CirFunctionalAreaFilter> cirFunctionalAreaFilters;
	List<CirCaseStatusFilter> caseStatusFilters;
	
	public List<CirProjectFilter> getCirProjectFilters() {
		return cirProjectFilters;
	}
	public void setCirProjectFilters(List<CirProjectFilter> cirProjectFilters) {
		this.cirProjectFilters = cirProjectFilters;
	}
	public List<CirFunctionalAreaFilter> getCirFunctionalAreaFilters() {
		return cirFunctionalAreaFilters;
	}
	public void setCirFunctionalAreaFilters(List<CirFunctionalAreaFilter> cirFunctionalAreaFilters) {
		this.cirFunctionalAreaFilters = cirFunctionalAreaFilters;
	}
	public List<CirCaseStatusFilter> getCaseStatusFilters() {
		return caseStatusFilters;
	}
	public void setCaseStatusFilters(List<CirCaseStatusFilter> caseStatusFilters) {
		this.caseStatusFilters = caseStatusFilters;
	}
	
	@Override
	public String toString() {
		return "CirRequestFilter [cirProjectFilters=" + cirProjectFilters + ", cirFunctionalAreaFilters="
				+ cirFunctionalAreaFilters + ", caseStatusFilters=" + caseStatusFilters + "]";
	}
	
}
