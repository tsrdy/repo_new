package genpact.pmr.start.dto;

public class CostDetailGroupTypeChartTypeDto {
	private String group_;
	private String eac;
	private String grouped_type;
	private String cbl;
	private String previous_eac;

	private int id;
	public CostDetailGroupTypeChartTypeDto(String group_, String eac, String grouped_type, String cbl,
			String previous_eac, int id) {
		super();
		this.group_ = group_;
		this.eac = eac;
		this.grouped_type = grouped_type;
		this.cbl = cbl;
		this.previous_eac = previous_eac;
		this.id = id;
	}

	public String getGroup_() {
		return group_;
	}
	public void setGroup_(String group_) {
		this.group_ = group_;
	}

	public String getEac() {
		return eac;
	}

	public void setEac(String eac) {
		this.eac = eac;
	}

	public String getGrouped_type() {
		return grouped_type;
	}

	public void setGrouped_type(String grouped_type) {
		this.grouped_type = grouped_type;
	}

	public String getCbl() {
		return cbl;
	}
	public void setCbl(String cbl) {
		this.cbl = cbl;
	}

	public String getPrevious_eac() {
		return previous_eac;
	}

	public void setPrevious_eac(String previous_eac) {
		this.previous_eac = previous_eac;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public CostDetailGroupTypeChartTypeDto(int id,String group_,String grouped_type,String eac) {
		super();
		this.group_ = group_;
		this.grouped_type = grouped_type;
		this.eac=eac;
		this.id = id;
	}
}
