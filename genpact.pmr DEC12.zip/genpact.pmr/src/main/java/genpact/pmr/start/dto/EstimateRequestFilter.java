package genpact.pmr.start.dto;

import java.util.List;

public class EstimateRequestFilter {

	private String projectId ;
	private List<Integer> similarProject;
	private int timePercent;
	private int actualHours;
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public List<Integer> getSimilarProject() {
		return similarProject;
	}
	public void setSimilarProject(List<Integer> similarProject) {
		this.similarProject = similarProject;
	}
	public int getTimePercent() {
		return timePercent;
	}
	public void setTimePercent(int timePercent) {
		this.timePercent = timePercent;
	}
	public int getActualHours() {
		return actualHours;
	}
	public void setActualHours(int actualHours) {
		this.actualHours = actualHours;
	}
	public EstimateRequestFilter() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EstimateRequestFilter(String projectId, List<Integer> similarProject, int timePercent, int actualHours) {
		super();
		this.projectId = projectId;
		this.similarProject = similarProject;
		this.timePercent = timePercent;
		this.actualHours = actualHours;
	}
	
	
	
}
