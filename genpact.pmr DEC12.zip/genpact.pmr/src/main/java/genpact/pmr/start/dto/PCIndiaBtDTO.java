package genpact.pmr.start.dto;

public class PCIndiaBtDTO {
	
	  private String name ; 
	  private long pcindTotalCbl;
	  private long pcindTotalPreviousEac;
	  private long pcindTotalEac;
	  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPcindTotalCbl() {
		return pcindTotalCbl;
	}
	public void setPcindTotalCbl(long pcindTotalCbl) {
		this.pcindTotalCbl = pcindTotalCbl;
	}
	public long getPcindTotalPreviousEac() {
		return pcindTotalPreviousEac;
	}
	public void setPcindTotalPreviousEac(long pcindTotalPreviousEac) {
		this.pcindTotalPreviousEac = pcindTotalPreviousEac;
	}
	public long getPcindTotalEac() {
		return pcindTotalEac;
	}
	public void setPcindTotalEac(long pcindTotalEac) {
		this.pcindTotalEac = pcindTotalEac;
	}
	  
	  

}
