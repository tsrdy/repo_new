package genpact.pmr.start.dto;

import java.util.List;

public class EngineeringDTO {

	private TableEngineering tableEngineering;

	public TableEngineering getTableEngineering() {
		return tableEngineering;
	}

	public void setTableEngineering(TableEngineering tableEngineering) {
		this.tableEngineering = tableEngineering;
	}

	public EngineeringDTO(TableEngineering tableEngineering) {
		super();
		this.tableEngineering = tableEngineering;
	}

}
