package genpact.pmr.start.dto;

public class RiskAndOpportunityDto {

}
