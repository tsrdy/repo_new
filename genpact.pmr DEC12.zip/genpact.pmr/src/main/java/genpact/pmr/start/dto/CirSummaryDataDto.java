package genpact.pmr.start.dto;

public class CirSummaryDataDto {
	private long totalCase;
	private long totalAge;
	private double averageAge;
	private long oldestCase;
	
	
	
	
	
	public CirSummaryDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}





	public CirSummaryDataDto(long totalCase, long totalAge, double averageAge, long oldestCase) {
		super();
		this.totalCase = totalCase;
		this.totalAge = totalAge;
		this.averageAge = averageAge;
		this.oldestCase = oldestCase;
	}





	public long getTotalCase() {
		return totalCase;
	}





	public void setTotalCase(long totalCase) {
		this.totalCase = totalCase;
	}





	public long getTotalAge() {
		return totalAge;
	}





	public void setTotalAge(long totalAge) {
		this.totalAge = totalAge;
	}





	public double getAverageAge() {
		return averageAge;
	}





	public void setAverageAge(double averageAge) {
		this.averageAge = averageAge;
	}





	public long getOldestCase() {
		return oldestCase;
	}





	public void setOldestCase(long oldestCase) {
		this.oldestCase = oldestCase;
	}
	



}
