package genpact.pmr.start.dto;

public class BillingValueTotalDTO {
	
	private long billingtotal;

	public long getBillingtotal() {
		return billingtotal;
	}

	public void setBillingtotal(long billingtotal) {
		this.billingtotal = billingtotal;
	}

	public BillingValueTotalDTO(long billingtotal) {
		super();
		this.billingtotal = billingtotal;
	}

	public BillingValueTotalDTO() {
		super();
	}

	@Override
	public String toString() {
		return "BillingValueTotalDTO [billingtotal=" + billingtotal + "]";
	}

	

	

}
