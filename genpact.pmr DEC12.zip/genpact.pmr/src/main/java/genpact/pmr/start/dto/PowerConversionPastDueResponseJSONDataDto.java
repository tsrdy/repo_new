package genpact.pmr.start.dto;

import java.util.List;

public class PowerConversionPastDueResponseJSONDataDto {
	private List<FormatDataDto> formatData;
	private List<PCPastDueRegionDto> regions;
	private List<PCPastDueProjectManagerDto> projectMansgers;
	private List<PCPastDueProjectIdDto> projectIds;
	public List<FormatDataDto> getFormatData() {
		return formatData;
	}
	public void setFormatData(List<FormatDataDto> formatData) {
		this.formatData = formatData;
	}
	public List<PCPastDueRegionDto> getRegions() {
		return regions;
	}
	public void setRegions(List<PCPastDueRegionDto> regions) {
		this.regions = regions;
	}
	public List<PCPastDueProjectManagerDto> getProjectMansgers() {
		return projectMansgers;
	}
	public void setProjectMansgers(List<PCPastDueProjectManagerDto> projectMansgers) {
		this.projectMansgers = projectMansgers;
	}
	public List<PCPastDueProjectIdDto> getProjectIds() {
		return projectIds;
	}
	public void setProjectIds(List<PCPastDueProjectIdDto> projectIds) {
		this.projectIds = projectIds;
	}
	public PowerConversionPastDueResponseJSONDataDto(List<FormatDataDto> formatData, List<PCPastDueRegionDto> regions,
			List<PCPastDueProjectManagerDto> projectMansgers, List<PCPastDueProjectIdDto> projectIds) {
		super();
		this.formatData = formatData;
		this.regions = regions;
		this.projectMansgers = projectMansgers;
		this.projectIds = projectIds;
	}
	public PowerConversionPastDueResponseJSONDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
