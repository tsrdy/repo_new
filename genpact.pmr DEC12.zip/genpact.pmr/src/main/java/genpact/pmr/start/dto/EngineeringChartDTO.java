package genpact.pmr.start.dto;

public class EngineeringChartDTO {
	TechnicalEngineerDTO     technicalEngineerDTO;
	DraughtsPersonDTO        draughtsPersonDTO;
	RNDTechnicalEngDTO		 technicalEngDTO;
	RNDDraughtsPersonDTO     rndDraughtsPersonDTO;
	AgencyDraughtpersonDTO   agencyDraughtpersonDTO;
	PCIndiaBtDTO             pcIndiaBtDTO;
	
	public TechnicalEngineerDTO getTechnicalEngineerDTO() {
		return technicalEngineerDTO;
	}
	public void setTechnicalEngineerDTO(TechnicalEngineerDTO technicalEngineerDTO) {
		this.technicalEngineerDTO = technicalEngineerDTO;
	}
	public DraughtsPersonDTO getDraughtsPersonDTO() {
		return draughtsPersonDTO;
	}
	public void setDraughtsPersonDTO(DraughtsPersonDTO draughtsPersonDTO) {
		this.draughtsPersonDTO = draughtsPersonDTO;
	}
	public RNDTechnicalEngDTO getTechnicalEngDTO() {
		return technicalEngDTO;
	}
	public void setTechnicalEngDTO(RNDTechnicalEngDTO technicalEngDTO) {
		this.technicalEngDTO = technicalEngDTO;
	}
	public RNDDraughtsPersonDTO getRndDraughtsPersonDTO() {
		return rndDraughtsPersonDTO;
	}
	public void setRndDraughtsPersonDTO(RNDDraughtsPersonDTO rndDraughtsPersonDTO) {
		this.rndDraughtsPersonDTO = rndDraughtsPersonDTO;
	}
	public AgencyDraughtpersonDTO getAgencyDraughtpersonDTO() {
		return agencyDraughtpersonDTO;
	}
	public void setAgencyDraughtpersonDTO(AgencyDraughtpersonDTO agencyDraughtpersonDTO) {
		this.agencyDraughtpersonDTO = agencyDraughtpersonDTO;
	}
	public PCIndiaBtDTO getPcIndiaBtDTO() {
		return pcIndiaBtDTO;
	}
	public void setPcIndiaBtDTO(PCIndiaBtDTO pcIndiaBtDTO) {
		this.pcIndiaBtDTO = pcIndiaBtDTO;
	}
	public EngineeringChartDTO(TechnicalEngineerDTO technicalEngineerDTO, DraughtsPersonDTO draughtsPersonDTO,
			RNDTechnicalEngDTO technicalEngDTO, RNDDraughtsPersonDTO rndDraughtsPersonDTO,
			AgencyDraughtpersonDTO agencyDraughtpersonDTO, PCIndiaBtDTO pcIndiaBtDTO) {
		super();
		this.technicalEngineerDTO = technicalEngineerDTO;
		this.draughtsPersonDTO = draughtsPersonDTO;
		this.technicalEngDTO = technicalEngDTO;
		this.rndDraughtsPersonDTO = rndDraughtsPersonDTO;
		this.agencyDraughtpersonDTO = agencyDraughtpersonDTO;
		this.pcIndiaBtDTO = pcIndiaBtDTO;
	}
	
	
}
