package genpact.pmr.start.dto;

public class PendingEscalations {
	
	
	private int SYS_ENG;
	private int EQU_GSC;
	private int PE_ENG;
	private int PE_GSC;
	private int PE_MFG;
	private int IandC;
	private int QUA;
	private int CON_MGT;
	private int LEG;
	private int OTR_FIN;
	private int ITO;
	
	
	public int getSYS_ENG() {
		return SYS_ENG;
	}
	public void setSYS_ENG(int sYS_ENG) {
		SYS_ENG = sYS_ENG;
	}
	public int getEQU_GSC() {
		return EQU_GSC;
	}
	public void setEQU_GSC(int eQU_GSC) {
		EQU_GSC = eQU_GSC;
	}
	public int getPE_ENG() {
		return PE_ENG;
	}
	public void setPE_ENG(int pE_ENG) {
		PE_ENG = pE_ENG;
	}
	public int getPE_GSC() {
		return PE_GSC;
	}
	public void setPE_GSC(int pE_GSC) {
		PE_GSC = pE_GSC;
	}
	public int getPE_MFG() {
		return PE_MFG;
	}
	public void setPE_MFG(int pE_MFG) {
		PE_MFG = pE_MFG;
	}
	public int getIandC() {
		return IandC;
	}
	public void setIandC(int iandC) {
		IandC = iandC;
	}
	public int getQUA() {
		return QUA;
	}
	public void setQUA(int qUA) {
		QUA = qUA;
	}
	public int getCON_MGT() {
		return CON_MGT;
	}
	public void setCON_MGT(int cON_MGT) {
		CON_MGT = cON_MGT;
	}
	public int getLEG() {
		return LEG;
	}
	public void setLEG(int lEG) {
		LEG = lEG;
	}
	public int getOTR_FIN() {
		return OTR_FIN;
	}
	public void setOTR_FIN(int oTR_FIN) {
		OTR_FIN = oTR_FIN;
	}
	public int getITO() {
		return ITO;
	}
	public void setITO(int iTO) {
		ITO = iTO;
	}
	public PendingEscalations() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PendingEscalations(int sYS_ENG, int eQU_GSC, int pE_ENG, int pE_GSC, int pE_MFG, int iandC, int qUA,
			int cON_MGT, int lEG, int oTR_FIN, int iTO) {
		super();
		SYS_ENG = sYS_ENG;
		EQU_GSC = eQU_GSC;
		PE_ENG = pE_ENG;
		PE_GSC = pE_GSC;
		PE_MFG = pE_MFG;
		IandC = iandC;
		QUA = qUA;
		CON_MGT = cON_MGT;
		LEG = lEG;
		OTR_FIN = oTR_FIN;
		ITO = iTO;
	}
	
	
	
	

}
