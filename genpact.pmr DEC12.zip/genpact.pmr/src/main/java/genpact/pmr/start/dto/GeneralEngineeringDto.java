package genpact.pmr.start.dto;

import java.util.List;

public class GeneralEngineeringDto {
	
	private int rdtechnicaleng;
	private int gencyDraughtperson;
	private int rdDraughtsperson;
	private int draughtsperson;
	private int technicalEngineer;
	private int pcIndiaBtinServ;
	public GeneralEngineeringDto(int rdtechnicaleng, int gencyDraughtperson, int rdDraughtsperson, int draughtsperson,
			 int technicalEngineer, int pcIndiaBtinServ) {
		super();
		this.rdtechnicaleng = rdtechnicaleng;
		this.gencyDraughtperson = gencyDraughtperson;
		this.rdDraughtsperson = rdDraughtsperson;
		this.draughtsperson = draughtsperson;
		this.technicalEngineer = technicalEngineer;
		this.pcIndiaBtinServ = pcIndiaBtinServ;
	}
	public int getRdtechnicaleng() {
		return rdtechnicaleng;
	}
	public void setRdtechnicaleng(int rdtechnicaleng) {
		this.rdtechnicaleng = rdtechnicaleng;
	}
	public int getGencyDraughtperson() {
		return gencyDraughtperson;
	}
	public void setGencyDraughtperson(int gencyDraughtperson) {
		this.gencyDraughtperson = gencyDraughtperson;
	}
	public int getRdDraughtsperson() {
		return rdDraughtsperson;
	}
	public void setRdDraughtsperson(int rdDraughtsperson) {
		this.rdDraughtsperson = rdDraughtsperson;
	}
	public int getDraughtsperson() {
		return draughtsperson;
	}
	public void setDraughtsperson(int draughtsperson) {
		this.draughtsperson = draughtsperson;
	}
	
	public int getTechnicalEngineer() {
		return technicalEngineer;
	}
	public void setTechnicalEngineer(int technicalEngineer) {
		this.technicalEngineer = technicalEngineer;
	}
	public int getPcIndiaBtinServ() {
		return pcIndiaBtinServ;
	}
	public void setPcIndiaBtinServ(int pcIndiaBtinServ) {
		this.pcIndiaBtinServ = pcIndiaBtinServ;
	}
	public GeneralEngineeringDto() {
		super();
	}

}
