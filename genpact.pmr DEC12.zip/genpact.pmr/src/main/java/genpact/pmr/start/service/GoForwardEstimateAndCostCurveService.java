package genpact.pmr.start.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.EstimateDao;
import genpact.pmr.start.dto.EstimateRequestFilter;
import genpact.pmr.start.dto.EstimateResponseJsonDataDto;
import genpact.pmr.start.dto.GoForwardCalcList;

@CrossOrigin
@RestController
public class GoForwardEstimateAndCostCurveService {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private EstimateDao estimateDao;

	// just to check
	@RequestMapping(value = "/estimate", method = RequestMethod.GET)
	public String msg() {
		// estimateDao.getEstimateData();
		// getAllData();
		return "Running Succesfully";
	}

	/*@RequestMapping(value = "/getestimatecurve/projectid/similar_Project/percentage_completion/actualhours", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public EstimateResponseJsonDataDto getAllData(@RequestBody EstimateRequestFilter[] estimateRequestFilterArr) {

		double totalHours = 0.0;
		EstimateResponseJsonDataDto estimateResponseJsonDataDto = null;
		EstimateRequestFilter estimateRequestFilter = estimateRequestFilterArr[0];
		List<GoForwardCalcList> goForwardCalcLists;
		//List<GoForwardCalcList> costCurveLists = null;
		
		//String projectId = estimateRequestFilter.getProjectId();
		int actualHours = estimateRequestFilter.getActualHours(); //////////////////////////////
		System.out.println(actualHours);
		int timePercent = estimateRequestFilter.getTimePercent();
		List<Integer> similarProjects = estimateRequestFilter.getSimilarProject();
		String sql = createSql(similarProjects, timePercent);

		System.out.println(sql + "    iefhf");

		goForwardCalcLists = estimateDao.getAverageList(sql);
		//costCurveLists = estimateDao.getCostCurveAverageList(projectId, timePercent); /// Cost
																						/// Curve

		//double CostCurveTotalHours;
	//	CostCurveTotalHours = getTotalHours(actualHours, timePercent, costCurveLists);
		totalHours = getTotalHours(actualHours, timePercent, goForwardCalcLists);

		// System.out.println("TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT "+totalHours);

		estimateResponseJsonDataDto = new EstimateResponseJsonDataDto();
		estimateResponseJsonDataDto.setTotalHours(totalHours);
		List<Integer> timeGapCategories = new ArrayList<>();
		for (GoForwardCalcList calcList : goForwardCalcLists) {

			timeGapCategories.add(calcList.getTimepercent());
		//	System.out.println(timeGapCategories + "     kvh");

		}
		// goForwardCalcLists.set
		
		 * for (GoForwardCalcList goForwardCalcList : goForwardCalcLists) {
		 * goForwardCalcList.setActualHours(actualHours); }
		 

		List<GoForwardCalcList> actualHoursCummulativeList = null;
		
		 * for (GoForwardCalcList goForwardCalcList : goForwardCalcLists) {
		 * 
		 * 
		 * 
		 * System.out.println(goForwardCalcList.getActualHours() +
		 * "        ghksahvoisdvjspo         " +
		 * goForwardCalcList.getTimepercent()); }
		 

		List<GoForwardCalcList> costCurveActualHoursCummulativeList = null;
		costCurveActualHoursCummulativeList = CalculateActualHours(costCurveLists, CostCurveTotalHours, actualHours);// Cost
																														// Curve
		estimateResponseJsonDataDto.setCostCurve(costCurveActualHoursCummulativeList);

		actualHoursCummulativeList = CalculateActualHours(goForwardCalcLists, totalHours, actualHours);//
		estimateResponseJsonDataDto.setGoForwardEstimate(actualHoursCummulativeList);

		estimateResponseJsonDataDto.setTimeGapCategories(timeGapCategories);

		return estimateResponseJsonDataDto;

	}*/
	
	@RequestMapping(value = "/getestimatecurve/projectid/similar_Project/percentage_completion/actualhours", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public EstimateResponseJsonDataDto getAllData(@RequestBody EstimateRequestFilter[] estimateRequestFilterArr) {
		
		
		
		EstimateResponseJsonDataDto estimateResponseJsonDataDto = null;
		EstimateRequestFilter estimateRequestFilter = estimateRequestFilterArr[0];
		
		List<Integer> similarProjects = estimateRequestFilter.getSimilarProject();
		int actualHours = estimateRequestFilter.getActualHours();
		int timePercent = estimateRequestFilter.getTimePercent();
		
		//System.out.println(actualHours);
		
		List<GoForwardCalcList> goForwardCalcLists=null;
		double totalHours = 0.0;
		
		
		
		String sql = createSql(similarProjects);

		goForwardCalcLists = estimateDao.getAverageList(sql);

		totalHours = getTotalHours(actualHours, timePercent, goForwardCalcLists);


		estimateResponseJsonDataDto = new EstimateResponseJsonDataDto();
		
		estimateResponseJsonDataDto.setTotalHours(totalHours);
		
		List<Integer> timeGapCategories = new ArrayList<>();
		
		for (GoForwardCalcList calcList : goForwardCalcLists) {

			timeGapCategories.add(calcList.getTimepercent());

		}
		
		 

		//List<GoForwardCalcList> actualHoursCummulativeList = null;
		
		 

		List<GoForwardCalcList> costCurveActualHoursCummulativeList = null;
		//costCurveActualHoursCummulativeList = CalculateActualHours(costCurveLists, CostCurveTotalHours, actualHours);// Cost
																														// Curve

		//actualHoursCummulativeList = 
		CalculateActualHours(goForwardCalcLists, totalHours,timePercent);//
		estimateResponseJsonDataDto.setGoForwardEstimate(goForwardCalcLists);

		estimateResponseJsonDataDto.setTimeGapCategories(timeGapCategories);

		return estimateResponseJsonDataDto;
	}

	/// =======================================
	private String createSql(List<Integer> similarProjects) {
		String sql = "select time_,(";
		String estimateColumnArray[] = { "uk_c_y_20200_01", "uk_c_y_20223_01", "uk_c_y_20243_01", "uk_c_y_20266_01" };
		for (Integer i : similarProjects) {

			if ((similarProjects.indexOf(i) + 1) == similarProjects.size()) {
				sql += estimateColumnArray[i];
				break;
			} else {
				sql += estimateColumnArray[i] + "+";
			}
		}
		sql += ")/" + similarProjects.size() + " as average from cost_curve where time_ between "; // timePercent
		sql += "1 and 100";

		return sql;
	}

	// ================
	private double getTotalHours(int actualHours, int timePercent, List<GoForwardCalcList> goForwardCalcLists) {

		GoForwardCalcList goForwardCalcList = null;

		for (GoForwardCalcList calcList : goForwardCalcLists) {

			if (calcList.getTimepercent() == timePercent) {
				goForwardCalcList = calcList;
			}
		}
System.out.println("HHHHHHHHIEEEEEEEEEEEEEEEEEEEE      " + goForwardCalcList.getAverage() + "nnlkhv   " + actualHours); 
		double totalHours = (actualHours / goForwardCalcList.getAverage()) * 100;

		return totalHours;

	}

	// ================

	/*private List<GoForwardCalcList> CalculateActualHours(List<GoForwardCalcList> withoutActualHours, double totalHours,
			double actualHours1) {
		// List<GoForwardCalcList> withActualHours = null;

		int leastIndexOfTimePercent = 0;
		double actualHours = 0.0;

		leastIndexOfTimePercent = withoutActualHours.get(0).getTimepercent();// initial
																				// time
																				// value

		System.err.println("Least Index : "+leastIndexOfTimePercent);
		List<Double> actualCummulative = new ArrayList<>();

		boolean flag = true;

		GoForwardCalcList goForwardCalcList = new GoForwardCalcList();
		goForwardCalcList.setTimepercent(100);
		goForwardCalcList.setActualHours(totalHours);

		GoForwardCalcList goForwardCalcList4 = null;

		for (GoForwardCalcList goForwardCalcList2 : withoutActualHours) {
			if (goForwardCalcList2.getTimepercent() == 100)
				goForwardCalcList4 = goForwardCalcList2;
		}
		for (int i = 99; i >= leastIndexOfTimePercent; i -= 2) {

			for (GoForwardCalcList goForwardCalcList2 : withoutActualHours) {
				if (flag) {

					int index = withoutActualHours.indexOf(goForwardCalcList4);
					GoForwardCalcList goForwardCalcList3 = withoutActualHours.get(index);
					//
					if (goForwardCalcList3.getTimepercent() == 100) {
						goForwardCalcList3.setActualHours(totalHours);
						flag = false;
					}
				}
				
				
				if (flag == false) {
					if (goForwardCalcList2.getTimepercent() == i && i != leastIndexOfTimePercent) {
						actualHours = ((totalHours * i) / 100);
						goForwardCalcList2.setActualHours(actualHours);
						
					}
					if (goForwardCalcList2.getTimepercent() == i && i == leastIndexOfTimePercent) {
						goForwardCalcList2.setActualHours(actualHours1);
					}
				}

			}
		}
		return withoutActualHours;
	}*/
	
	private void CalculateActualHours(List<GoForwardCalcList> withoutActualHours, double totalHours,
			double timePercent) {
		int currentTimePercent=0;
		for(GoForwardCalcList gfc:withoutActualHours){
			currentTimePercent=gfc.getTimepercent();
			if(timePercent <= currentTimePercent && currentTimePercent !=100 ){
				gfc.setActualHours((totalHours*gfc.getTimepercent())/100);
			}
			if(currentTimePercent ==100){
				gfc.setActualHours(totalHours);
			}
		}
		
	}

}
