package genpact.pmr.start.dto;

import java.util.List;

public class BillingTotalJsonDTO {
	
	List<BillingTableDataDto> billingTableDataDto;
	BillingValueTotalDTO billingValueTotalDTO;
	
	
	public List<BillingTableDataDto> getBillingTableDataDto() {
		return billingTableDataDto;
	}
	public void setBillingTableDataDto(List<BillingTableDataDto> billingTableDataDto) {
		this.billingTableDataDto = billingTableDataDto;
	}
	public BillingValueTotalDTO getBillingValueTotalDTO() {
		return billingValueTotalDTO;
	}
	public void setBillingValueTotalDTO(BillingValueTotalDTO billingValueTotalDTO) {
		this.billingValueTotalDTO = billingValueTotalDTO;
	}
	@Override
	public String toString() {
		return "BillingTotalJsonDTO [billingTableDataDto=" + billingTableDataDto + ", billingValueTotalDTO="
				+ billingValueTotalDTO + "]";
	}
	
	

}
