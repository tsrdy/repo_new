package genpact.pmr.start.dto;

public class EngineeringGeneral1DTO {

	private GeneralEngineeringDto cBL;

	private GeneralEngineeringDto eAC;

	private GeneralEngineeringDto pEAC;

	public EngineeringGeneral1DTO(GeneralEngineeringDto cBL, GeneralEngineeringDto eAC, GeneralEngineeringDto pEAC) {
		super();
		this.cBL = cBL;
		this.eAC = eAC;
		this.pEAC = pEAC;
	}

	public GeneralEngineeringDto getcBL() {
		return cBL;
	}

	public void setcBL(GeneralEngineeringDto cBL) {
		this.cBL = cBL;
	}

	public GeneralEngineeringDto geteAC() {
		return eAC;
	}

	public void seteAC(GeneralEngineeringDto eAC) {
		this.eAC = eAC;
	}

	public GeneralEngineeringDto getpEAC() {
		return pEAC;
	}

	public void setpEAC(GeneralEngineeringDto pEAC) {
		this.pEAC = pEAC;
	}

	public EngineeringGeneral1DTO() {
		super();
	}

}
