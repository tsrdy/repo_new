package genpact.pmr.start.dto;

public class FormatDataDto {

	private int id;
	private String label;
	
	
	public FormatDataDto() {
		//no op
	}
	
	
	public FormatDataDto(int id, String label) {
		this.id = id;
		this.label = label;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}


	@Override
	public String toString() {
		return "FormatDataDto [id=" + id + ", label=" + label + "]";
	}
	
	
}
