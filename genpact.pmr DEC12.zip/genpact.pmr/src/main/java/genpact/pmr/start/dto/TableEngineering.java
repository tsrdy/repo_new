package genpact.pmr.start.dto;

import java.util.List;

public class TableEngineering {

    private List<MCShopDTO> rdtechnicaleng;
    private List<MCShopDTO> gencyDraughtperson;
    private List<MCShopDTO> rdDraughtsperson;
    private List<MCShopDTO> draughtsperson;
    private List<MCShopDTO> total;
    private List<MCShopDTO> technicalEngineer;
    private List<MCShopDTO> pcIndiaBtinServ;

    public List<MCShopDTO> getRdtechnicaleng() {
        return rdtechnicaleng;
    }

    public TableEngineering(List<MCShopDTO> rdtechnicaleng, List<MCShopDTO> gencyDraughtperson,
            List<MCShopDTO> rdDraughtsperson, List<MCShopDTO> draughtsperson, List<MCShopDTO> total,
            List<MCShopDTO> technicalEngineer, List<MCShopDTO> pcIndiaBtinServ) {
        super();
        this.rdtechnicaleng = rdtechnicaleng;
        this.gencyDraughtperson = gencyDraughtperson;
        this.rdDraughtsperson = rdDraughtsperson;
        this.draughtsperson = draughtsperson;
        this.total = total;
        this.technicalEngineer = technicalEngineer;
        this.pcIndiaBtinServ = pcIndiaBtinServ;
    }

    public void setRdtechnicaleng(List<MCShopDTO> rdtechnicaleng) {
        this.rdtechnicaleng = rdtechnicaleng;
    }

    public List<MCShopDTO> getGencyDraughtperson() {
        return gencyDraughtperson;
    }

    public void setGencyDraughtperson(List<MCShopDTO> gencyDraughtperson) {
        this.gencyDraughtperson = gencyDraughtperson;
    }

    public List<MCShopDTO> getRdDraughtsperson() {
        return rdDraughtsperson;
    }

    public void setRdDraughtsperson(List<MCShopDTO> rdDraughtsperson) {
        this.rdDraughtsperson = rdDraughtsperson;
    }

    public List<MCShopDTO> getDraughtsperson() {
        return draughtsperson;
    }

    public void setDraughtsperson(List<MCShopDTO> draughtsperson) {
        this.draughtsperson = draughtsperson;
    }

    public List<MCShopDTO> getTotal() {
        return total;
    }

    public void setTotal(List<MCShopDTO> total) {
        this.total = total;
    }

    public List<MCShopDTO> getTechnicalEngineer() {
        return technicalEngineer;
    }

    public void setTechnicalEngineer(List<MCShopDTO> technicalEngineer) {
        this.technicalEngineer = technicalEngineer;
    }

    public List<MCShopDTO> getPcIndiaBtinServ() {
        return pcIndiaBtinServ;
    }

    public void setPcIndiaBtinServ(List<MCShopDTO> pcIndiaBtinServ) {
        this.pcIndiaBtinServ = pcIndiaBtinServ;
    }

}
