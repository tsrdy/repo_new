package genpact.pmr.start.dto;

import java.util.List;

public class CirDashboardJSONDataDto {

	List<FormatDataDto> formatDataDtos;
	CirSummaryDataDto cirSummaryDataDtos;
	List<CirTableDataDto> cirTableDataDtos;
	
	
	
	

	

	public List<CirTableDataDto> getCirTableDataDtos() {
		return cirTableDataDtos;
	}

	public void setCirTableDataDtos(List<CirTableDataDto> cirTableDataDtos) {
		this.cirTableDataDtos = cirTableDataDtos;
	}

	public CirSummaryDataDto getCirSummaryDataDtos() {
		return cirSummaryDataDtos;
	}

	public void setCirSummaryDataDtos(CirSummaryDataDto cirSummaryDataDtos) {
		this.cirSummaryDataDtos = cirSummaryDataDtos;
	}

	public List<FormatDataDto> getFormatDataDtos() {
		return formatDataDtos;
	}

	public void setFormatDataDtos(List<FormatDataDto> formatDataDtos) {
		this.formatDataDtos = formatDataDtos;
	}

	public CirDashboardJSONDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}

}
