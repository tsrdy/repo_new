package genpact.pmr.start.dto;

public class CountData {

	private String refernceDate;
	private Double count;
	public String getRefernceDate() {
		return refernceDate;
	}
	public void setRefernceDate(String refernceDate) {
		this.refernceDate = refernceDate;
	}
	public Double getCount() {
		return count;
	}
	public void setCount(Double count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "CountData [refernceDate=" + refernceDate + ", count=" + count + "]";
	}

}
