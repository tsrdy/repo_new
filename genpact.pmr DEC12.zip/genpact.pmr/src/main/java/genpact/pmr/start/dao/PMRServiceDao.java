package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.ChartDto;
import genpact.pmr.start.dto.CostDetailGroupTypeChartTypeDto;
import genpact.pmr.start.dto.Group_Chart;
import genpact.pmr.start.dto.JSONDataDto;
import genpact.pmr.start.dto.PMRDto;
import genpact.pmr.start.dto.RevenueChartDto;
import genpact.pmr.start.dto.RevenueChartName;
import genpact.pmr.start.dto.TableDataDto;
import genpact.pmr.start.dto.TotalCostCalcDto;
import genpact.pmr.start.dto.TotalMarginCalcDto;
import genpact.pmr.start.dto.TotalRevenueCalcDto;

@Repository
public class PMRServiceDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	double totalStaffCost = 0;
	double totalAllowance = 0;
	double totalTaxes = 0;
	double totalMisc = 0;
	double totalPrice = 0;
	double totalMat_Services = 0;
	double totalCal = 0;

	DecimalFormat formatter = new DecimalFormat("0.0000");

	public JSONDataDto getTotalTableData(String str) {
		System.out.println("in revenue");

		JSONDataDto jsonDataDto = null;

		TableDataDto tableDataDto = null;
		RevenueChartName revenueChartName = null;
		TotalRevenueCalcDto totalRevenueCalcDto = null;
		TotalCostCalcDto totalCostCalcDto = null;
		TotalMarginCalcDto totalMarginCalcDto = null;

		RevenueChartDto revenueChartDto = null;

		double totalRevenue_Cbl = 0;
		double totalRevenue_Actuals = 0;
		double totalRevenue_Eac = 0;
		double totalRevenue_Etc = 0;
		double totalRevenue_Previous_Eac = 0;

		double totalCost_Cbl = 0;
		double totalCost_Actuals = 0;
		double totalCost_Eac = 0;
		double totalCost_Etc = 0;
		double totalCost_Previous_Eac = 0;

		double totalMargin_Cbl = 0;
		double totalMargin_Actuals = 0;
		double totalMargin_Eac = 0;
		double totalMargin_Etc = 0;
		double totalMargin_Previous_Eac = 0;

		double totalV1 = 0d;
		double totalV2 = 0d;
		double totalV3 = 0d;
		double totalV4 = 0d;
		double totalV5 = 0d;
		double totalV6 = 0d;
		double totalV7 = 0d;

		double commonV = 0d;

		// String sql = "select cost_code,cbl,actuals,etc,eac,previous_eac,type
		// from pmrdata " + str;

		String vertical_sql = "";
		String cost_sql = "";
		if ("".equals(str)) {
			vertical_sql = "select cost_code,sum(cast(cbl as double precision)) cbl,sum(cast(etc as double precision)) etc,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac,sum(cast(actuals as double precision)) actuals from pmrdata where cost_code in ('V1','V2','V3','V4','V5','V6','V7') group by cost_code order by cost_code";
			cost_sql = "select cost_code,sum(cast(cbl as double precision)) cbl,sum(cast(etc as double precision)) etc,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac,sum(cast(actuals as double precision)) actuals from pmrdata where cost_code not in ('V1','V2','V3','V4','V5','V6','V7','4','5','6','7','8','V8','V9','V','cal') group by cost_code order by cost_code";
		} else {
			vertical_sql = "select cost_code,sum(cast(cbl as double precision)) cbl,sum(cast(etc as double precision)) etc,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac,sum(cast(actuals as double precision)) actuals from pmrdata "
					+ str
					+ " and cost_code in ('V1','V2','V3','V4','V5','V6','V7') group by cost_code order by cost_code";
			cost_sql = "select cost_code,sum(cast(cbl as double precision)) cbl,sum(cast(etc as double precision)) etc,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac,sum(cast(actuals as double precision)) actuals from pmrdata "
					+ str
					+ " and cost_code not in ('V1','V2','V3','V4','V5','V6','V7','4','5','6','7','8','V8','V9','V','cal') group by cost_code order by cost_code";
		}

		// ================================================

		// ==============================================================

		// for Revenue only
		List<PMRDto> revenueDataList = jdbcTemplate.query(vertical_sql, new RevenueRowMapper());

		// System.err.println("revenue 2 : " );
		for (PMRDto pmr : revenueDataList) {
			
			System.err.println("Cost code : "+pmr.getCost_code());

			totalRevenue_Cbl += Double.parseDouble(pmr.getCbl());
			totalRevenue_Actuals += Double.parseDouble(pmr.getActuals());
			totalRevenue_Eac += Double.parseDouble(pmr.getEac());System.err.println(pmr.getEac());
			totalRevenue_Etc += Double.parseDouble(pmr.getEtc());
			totalRevenue_Previous_Eac += Double.parseDouble(pmr.getPrevious_eac());
		}
		
		System.err.println(totalRevenue_Eac+" totalRevenue_Eac");
		

		// calculating Revenue chart Data( dat is Only Eac of v1,sum of v2,...)
		String costCode = "";
		for (PMRDto pmr : revenueDataList) {
			costCode = pmr.getCost_code();
			switch (costCode.trim()) {

			case "V1":
				totalV1 += Double.parseDouble(pmr.getEac());

				break;
			case "V2":
				totalV2 += Double.parseDouble(pmr.getEac());

				break;
			case "V3":
				totalV3 += Double.parseDouble(pmr.getEac());

				break;
			case "V4":
				totalV4 += Double.parseDouble(pmr.getEac());

				break;
			case "V5":
				totalV5 += Double.parseDouble(pmr.getEac());

				break;
			case "V6":
				totalV6 += Double.parseDouble(pmr.getEac());

				break;
			case "V7":
				totalV7 += Double.parseDouble(pmr.getEac());
				break;

			}

		}
		
		System.err.println("Sum of Eac v1-v7 : "+(totalV1+totalV2+totalV3+totalV4+totalV5+totalV6+totalV7));


		// for cost calculation
		List<PMRDto> costDataList = jdbcTemplate.query(cost_sql, new RevenueRowMapper());

		for (PMRDto pmr : costDataList) {
			totalCost_Cbl += Double.parseDouble(pmr.getCbl());
			totalCost_Actuals += Double.parseDouble(pmr.getActuals());
			totalCost_Eac += Double.parseDouble(pmr.getEac());
			totalCost_Etc += Double.parseDouble(pmr.getEtc());
			totalCost_Previous_Eac += Double.parseDouble(pmr.getPrevious_eac());

		}

		/*
		 * totalV2+=totalV1; totalV3+=totalV2; totalV4+=totalV3;
		 * totalV5+=totalV4; totalV6+=totalV5; totalV7+=totalV6;
		 */

		revenueChartName = new RevenueChartName("Initial Order", "Penalties/LDs (negative figure)",
				"Ineffective Hedging Impact", "Change Orders signed", "Almost Certain Change Orders",
				"Change Orders/Claims in Discussion", "Change Orders/Claims in Discussion");
		revenueChartDto = new RevenueChartDto(totalV1, totalV2, totalV3, totalV4, totalV5, totalV6, totalV7);

		System.out.println(revenueChartName);
		System.out.println(totalMargin_Cbl);
		totalMargin_Actuals = ((totalRevenue_Actuals - totalCost_Actuals) / totalRevenue_Actuals) * 100;// totalRevenue_Actuals
																										// -
																										// totalCost_Actuals/totalRevenue_Actuals;
		totalMargin_Eac = ((totalRevenue_Eac - totalCost_Eac) / totalRevenue_Eac) * 100;
		totalMargin_Etc = ((totalRevenue_Etc - totalCost_Etc) / totalRevenue_Etc) * 100;
		totalMargin_Cbl = ((totalRevenue_Cbl - totalCost_Cbl) / totalRevenue_Cbl) * 100;
		totalMargin_Previous_Eac = ((totalRevenue_Previous_Eac - totalCost_Previous_Eac) / totalRevenue_Previous_Eac)
				* 100;

		// setting revenue data
		totalRevenueCalcDto = new TotalRevenueCalcDto(totalRevenue_Cbl, totalRevenue_Actuals, totalRevenue_Etc,
				totalRevenue_Eac, totalRevenue_Previous_Eac, null);
		// setting cost data
		totalCostCalcDto = new TotalCostCalcDto(totalCost_Cbl, totalCost_Actuals, totalCost_Etc, totalCost_Eac,
				totalCost_Previous_Eac, null);
		// setting marginData data
		totalMarginCalcDto = new TotalMarginCalcDto(totalMargin_Cbl, totalMargin_Actuals, totalMargin_Etc,
				totalMargin_Eac, totalMargin_Previous_Eac, null);

		tableDataDto = new TableDataDto(totalRevenueCalcDto, totalCostCalcDto, totalMarginCalcDto);
		// jsonDataDto.setRevenueChartName(revenueChartName);
		jsonDataDto = new JSONDataDto(tableDataDto, revenueChartDto, revenueChartName);

		return jsonDataDto;
	}

	// inner class

	private static class RevenueRowMapper implements RowMapper<PMRDto> {

		public PMRDto mapRow(ResultSet resultSet, int rowCount) throws SQLException {

			return new PMRDto(resultSet.getString("cbl"), resultSet.getString("actuals"), resultSet.getString("etc"), resultSet.getString("eac"), resultSet.getString("previous_eac"), resultSet.getString("cost_code"));
			
					
					//new PMRDto(resultSet.getString("cbl"), resultSet.getString("actuals"), resultSet.getString("etc"),
					//resultSet.getString("eac"), resultSet.getString("previous_eac"), resultSet.getString("cost_code"));
		}

	}

	//old code
	/*public JSONDataDto getChartDetailGroupDetailData1(String str) {
		System.out.println("in chart");
		JSONDataDto jsonDataDto = new JSONDataDto();
		CostDetailGroupTypeChartTypeDto costDetailGroup = null;

		String sql = "select group_,eac,cbl,previous_eac,grouped_type from pmrdata " + str;
		System.out.println(sql);
		
		List<CostDetailGroupTypeChartTypeDto> list = jdbcTemplate.query(sql,
				new RowMapper<CostDetailGroupTypeChartTypeDto>() {
					int counter;

					public CostDetailGroupTypeChartTypeDto mapRow(ResultSet rs, int rowNum) throws SQLException {

						return new CostDetailGroupTypeChartTypeDto(rs.getString("group_"), rs.getString("eac"),
								rs.getString("grouped_type"), rs.getString("cbl"), rs.getString("previous_eac"),
								++counter);

					}
				});

		String[] groups = { "Allowance", "Price", "Mat/Service", "Misc", "StaffCost", "Taxes", "Cal" };

		Map<String, List<Group_Chart>> map_cost = new HashMap<String, List<Group_Chart>>();//====

		Map<String, List<ChartDto>> map_chart_dto = new HashMap<String, List<ChartDto>>();

		for (int i = 0; i < groups.length; i++) {
			map_cost.put(groups[i], new ArrayList<Group_Chart>());
			map_chart_dto.put(groups[i], new ArrayList<ChartDto>());
		}

		for (CostDetailGroupTypeChartTypeDto pmr : list) {
			String group = pmr.getGroup_();
			if (group.equals("Allowance") || group.equals("Price") || group.equals("Mat/Service")
					|| group.equals("Misc") || group.equals("StaffCost") || group.equals("Taxes")
					|| group.equals("Cal")) {
				List<ChartDto> lst_chart;
				List<Group_Chart> lst_group_chart;
				Group_Chart obj_group_chart;

				ChartDto obj;
				boolean flag = true;
				boolean groupChartflag = true;
				
				switch (group) {
				
				case "Allowance":

					// map_cost.put("Allowance",
					// map_cost.get("Allowance")+Double.parseDouble(pmr.getEac()));

					lst_group_chart = map_cost.get("Allowance");
					flag = true;
					for (int i = 0; i < lst_group_chart.size(); i++) {
						obj_group_chart = lst_group_chart.get(i);
						if (obj_group_chart.getName().equals(pmr.getGroup_())) {
							obj_group_chart.setEac(obj_group_chart.getEac() + Double.parseDouble(pmr.getEac()));
							obj_group_chart.setCbl(obj_group_chart.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj_group_chart.setPrevious_eac(
									obj_group_chart.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj_group_chart = new Group_Chart();
						obj_group_chart.setName(pmr.getGroup_());
						obj_group_chart.setEac(Double.parseDouble(pmr.getEac()));
						obj_group_chart.setCbl(Double.parseDouble(pmr.getCbl()));
						obj_group_chart.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_group_chart.add(obj_group_chart);
					}

					lst_chart = map_chart_dto.get("Allowance");
					flag = true;
					for (int i = 0; i < lst_chart.size(); i++) {
						obj = lst_chart.get(i);
						if (obj.getName().equals(pmr.getGrouped_type())) {
							obj.setCost(obj.getCost() + Double.parseDouble(pmr.getEac()));
							obj.setCbl(obj.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj.setPrevious_eac(obj.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj = new ChartDto();
						obj.setName(pmr.getGrouped_type());
						obj.setCost(Double.parseDouble(pmr.getEac()));
						obj.setCbl(Double.parseDouble(pmr.getCbl()));
						obj.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_chart.add(obj);
					}
					break;
				case "Mat/Service":

					lst_group_chart = map_cost.get("Mat/Service");
					flag = true;
					for (int i = 0; i < lst_group_chart.size(); i++) {
						obj_group_chart = lst_group_chart.get(i);
						if (obj_group_chart.getName().equals(pmr.getGroup_())) {
							obj_group_chart.setEac(obj_group_chart.getEac() + Double.parseDouble(pmr.getEac()));
							obj_group_chart.setCbl(obj_group_chart.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj_group_chart.setPrevious_eac(
									obj_group_chart.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj_group_chart = new Group_Chart();
						obj_group_chart.setName(pmr.getGroup_());
						obj_group_chart.setEac(Double.parseDouble(pmr.getEac()));
						obj_group_chart.setCbl(Double.parseDouble(pmr.getCbl()));
						obj_group_chart.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_group_chart.add(obj_group_chart);
					}

					lst_chart = map_chart_dto.get("Mat/Service");
					flag = true;
					for (int i = 0; i < lst_chart.size(); i++) {
						obj = lst_chart.get(i);
						if (obj.getName().equals(pmr.getGrouped_type())) {
							obj.setCost(obj.getCost() + Double.parseDouble(pmr.getEac()));
							obj.setCbl(obj.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj.setPrevious_eac(obj.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj = new ChartDto();
						obj.setName(pmr.getGrouped_type());
						obj.setCost(Double.parseDouble(pmr.getEac()));
						obj.setCbl(Double.parseDouble(pmr.getCbl()));
						obj.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_chart.add(obj);
					}
					;
					break;
				case "Misc":

					lst_group_chart = map_cost.get("Misc");
					flag = true;
					for (int i = 0; i < lst_group_chart.size(); i++) {
						obj_group_chart = lst_group_chart.get(i);
						if (obj_group_chart.getName().equals(pmr.getGroup_())) {
							obj_group_chart.setEac(obj_group_chart.getEac() + Double.parseDouble(pmr.getEac()));
							obj_group_chart.setCbl(obj_group_chart.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj_group_chart.setPrevious_eac(
									obj_group_chart.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj_group_chart = new Group_Chart();
						obj_group_chart.setName(pmr.getGroup_());
						obj_group_chart.setEac(Double.parseDouble(pmr.getEac()));
						obj_group_chart.setCbl(Double.parseDouble(pmr.getCbl()));
						obj_group_chart.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_group_chart.add(obj_group_chart);
					}

					lst_chart = map_chart_dto.get("Misc");
					flag = true;
					for (int i = 0; i < lst_chart.size(); i++) {
						obj = lst_chart.get(i);
						if (obj.getName().equals(pmr.getGrouped_type())) {
							obj.setCost(obj.getCost() + Double.parseDouble(pmr.getEac()));
							obj.setCbl(obj.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj.setPrevious_eac(obj.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj = new ChartDto();
						obj.setName(pmr.getGrouped_type());
						obj.setCost(Double.parseDouble(pmr.getEac()));
						obj.setCbl(Double.parseDouble(pmr.getCbl()));
						obj.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_chart.add(obj);
					}
					break;
				case "StaffCost":

					lst_group_chart = map_cost.get("StaffCost");
					flag = true;
					for (int i = 0; i < lst_group_chart.size(); i++) {
						obj_group_chart = lst_group_chart.get(i);
						if (obj_group_chart.getName().equals(pmr.getGroup_())) {
							obj_group_chart.setEac(obj_group_chart.getEac() + Double.parseDouble(pmr.getEac()));
							obj_group_chart.setCbl(obj_group_chart.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj_group_chart.setPrevious_eac(
									obj_group_chart.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj_group_chart = new Group_Chart();
						obj_group_chart.setName(pmr.getGroup_());
						obj_group_chart.setEac(Double.parseDouble(pmr.getEac()));
						obj_group_chart.setCbl(Double.parseDouble(pmr.getCbl()));
						obj_group_chart.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_group_chart.add(obj_group_chart);
					}

					lst_chart = map_chart_dto.get("StaffCost");
					flag = true;
					for (int i = 0; i < lst_chart.size(); i++) {
						obj = lst_chart.get(i);
						if (obj.getName().equals(pmr.getGrouped_type())) {
							obj.setCost(obj.getCost() + Double.parseDouble(pmr.getEac()));
							obj.setCbl(obj.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj.setPrevious_eac(obj.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj = new ChartDto();
						obj.setName(pmr.getGrouped_type());
						obj.setCost(Double.parseDouble(pmr.getEac()));
						obj.setCbl(Double.parseDouble(pmr.getCbl()));
						obj.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_chart.add(obj);
					}
					break;
				case "Taxes":

					lst_group_chart = map_cost.get("Taxes");
					flag = true;
					for (int i = 0; i < lst_group_chart.size(); i++) {
						obj_group_chart = lst_group_chart.get(i);
						if (obj_group_chart.getName().equals(pmr.getGroup_())) {
							obj_group_chart.setEac(obj_group_chart.getEac() + Double.parseDouble(pmr.getEac()));
							obj_group_chart.setCbl(obj_group_chart.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj_group_chart.setPrevious_eac(
									obj_group_chart.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj_group_chart = new Group_Chart();
						obj_group_chart.setName(pmr.getGroup_());
						obj_group_chart.setEac(Double.parseDouble(pmr.getEac()));
						obj_group_chart.setCbl(Double.parseDouble(pmr.getCbl()));
						obj_group_chart.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_group_chart.add(obj_group_chart);
					}

					lst_chart = map_chart_dto.get("Taxes");
					flag = true;
					for (int i = 0; i < lst_chart.size(); i++) {
						obj = lst_chart.get(i);
						if (obj.getName().equals(pmr.getGrouped_type())) {
							obj.setCost(obj.getCost() + Double.parseDouble(pmr.getEac()));
							obj.setCbl(obj.getCbl() + Double.parseDouble(pmr.getCbl()));
							obj.setPrevious_eac(obj.getPrevious_eac() + Double.parseDouble(pmr.getPrevious_eac()));
							flag = false;
						}
					}
					if (flag) {
						obj = new ChartDto();
						obj.setName(pmr.getGrouped_type());
						obj.setCost(Double.parseDouble(pmr.getEac()));
						obj.setCbl(Double.parseDouble(pmr.getCbl()));
						obj.setPrevious_eac(Double.parseDouble(pmr.getPrevious_eac()));
						lst_chart.add(obj);
					}

					break;
				}

			}

		}
		System.out.println(map_cost);
		System.out.println(map_chart_dto);

		jsonDataDto.setGroup_cost(map_cost);
		jsonDataDto.setGroupedtype_cost(map_chart_dto);
		jsonDataDto.setCostDetailGroupTypeChartTypeDto(costDetailGroup);
		System.out.println(costDetailGroup);
		return jsonDataDto;
	}
*/
	public JSONDataDto getChartDetailGroupDetailData(String str) {

		JSONDataDto jsonDataDto = new JSONDataDto();
		String SQL_GROUP="";
		
		//String SQL_GROUPED_TYPE="select grouped_type,sum(cast(cbl as double precision)) cbl,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac from pmrdata where cost_code not in ('V1','V2','V3','V4','V5','V6','V7','4','5','6','7','8','V8','V9','V','cal') and group_='Allowance' group by grouped_type order by grouped_type";
		
		if("".equals(str)){
			SQL_GROUP="select group_,sum(cast(cbl as double precision)) cbl,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac from pmrdata where cost_code not in ('V1','V2','V3','V4','V5','V6','V7','4','5','6','7','8','V8','V9','V','cal') group by group_ order by group_";
		}else
		{
			SQL_GROUP="select group_,sum(cast(cbl as double precision)) cbl,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac from pmrdata "+str+" and cost_code not in ('V1','V2','V3','V4','V5','V6','V7','4','5','6','7','8','V8','V9','V','cal') group by group_ order by group_";
			
		}
		
		
		List<Group_Chart> costGroupChart=getCostGroupChat(SQL_GROUP);
		
		
		//due to UI people I m unable to change JSON, dats y now i m applying For JSON format
		Map<String, List<Group_Chart>> map_cost = new HashMap<String, List<Group_Chart>>();
		List<Group_Chart> l=null;
		for(Group_Chart gc:costGroupChart){
			
			l=new ArrayList<>();
			l.add(gc);
			map_cost.put(gc.getName(),l);
		}
		
		
		
		//for grouped_type based on group

		Map<String, List<ChartDto>> grouped_typeBasedOnGroupMap = new HashMap<String, List<ChartDto>>();
		
		for(String group_key:map_cost.keySet()){
			grouped_typeBasedOnGroupMap.put(group_key, getCostGroupedTypeDataByGroup(str,group_key));
		}
		
		//========================================================================================================================
		//for adding total for map_cost 
		double eac=0.0;
		double cbl=0.0;
		double previous_eac=0.0;
		for(Group_Chart gc:costGroupChart){
			eac+=gc.getEac();
			cbl+=gc.getCbl();
			previous_eac+=gc.getPrevious_eac();
		}
		
		Group_Chart totalCostGroupChatValue=new Group_Chart();
		totalCostGroupChatValue.setName("Total");
		totalCostGroupChatValue.setCbl(cbl);
		totalCostGroupChatValue.setEac(eac);
		totalCostGroupChatValue.setPrevious_eac(previous_eac);
		
		l=new ArrayList<>();
		l.add(totalCostGroupChatValue);
		map_cost.put("Total", l);
		
		//for adding total for grouped_typeBasedOnGroupMap
		List<ChartDto> totalValueOfgrouped_typeBasedOnGroupList=new ArrayList<>();
		
		for(String key:grouped_typeBasedOnGroupMap.keySet()){
			List<ChartDto> lst=grouped_typeBasedOnGroupMap.get(key);
			for(ChartDto cd:lst){
				totalValueOfgrouped_typeBasedOnGroupList.add(cd);//if same grouped_type name will come then we need to combine the value and make it one object in the list ,bt I m not check dat logic 
			}
		}
		grouped_typeBasedOnGroupMap.put("Total", totalValueOfgrouped_typeBasedOnGroupList);
		
		//setting all data into response json
		
		jsonDataDto.setGroup_cost(map_cost);
		jsonDataDto.setGroupedtype_cost(grouped_typeBasedOnGroupMap);
		
		return jsonDataDto;
		
	}
	
	private List<Group_Chart> getCostGroupChat(String sql){
		return jdbcTemplate.query(sql, new RowMapper<Group_Chart>(){

			@Override
			public Group_Chart mapRow(ResultSet rs, int rowCount) throws SQLException {
				
				return new Group_Chart(rs.getString("group_"), rs.getDouble("eac"), rs.getDouble("cbl"), rs.getDouble("previous_eac"));
			}
			
			
		});
	}
	
	private List<ChartDto> getCostGroupedTypeDataByGroup(String sqlFilters,String group){
		
		
		String SQL_GROUPED_TYPE="";
		if("".equals(sqlFilters)){
			SQL_GROUPED_TYPE="select grouped_type,sum(cast(cbl as double precision)) cbl,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac from pmrdata where cost_code not in ('V1','V2','V3','V4','V5','V6','V7','4','5','6','7','8','V8','V9','V','cal') and group_='"+group+"' group by grouped_type order by grouped_type";
		}else
		{
			SQL_GROUPED_TYPE="select grouped_type,sum(cast(cbl as double precision)) cbl,sum(cast(eac as double precision)) eac,sum(cast(previous_eac as double precision)) previous_eac from pmrdata "+sqlFilters+" and cost_code not in ('V1','V2','V3','V4','V5','V6','V7','4','5','6','7','8','V8','V9','V','cal') and group_='"+group+"' group by grouped_type order by grouped_type";
			
		}
		
		return jdbcTemplate.query(SQL_GROUPED_TYPE, new RowMapper<ChartDto>(){

			@Override
			public ChartDto mapRow(ResultSet rs, int rowCount) throws SQLException {
				
				return new ChartDto(rs.getString("grouped_type"), rs.getDouble("eac"), rs.getDouble("cbl"), rs.getDouble("previous_eac"));
			}
		});
	}
}
