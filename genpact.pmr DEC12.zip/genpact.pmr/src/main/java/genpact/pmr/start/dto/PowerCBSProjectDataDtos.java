package genpact.pmr.start.dto;

public class PowerCBSProjectDataDtos {

	private String projectManager;
	private String projectNumber;
	private double internalBilled;
	private double internalToBeBilled;
	private double externalBilled;
	private double externalToBeBilled;
	private double totalToBeBilled;
	private double total;
	private double totalBilled;
	public PowerCBSProjectDataDtos() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PowerCBSProjectDataDtos(String projectManager, String projectNumber, double internalBilled,
			double internalToBeBilled, double externalBilled, double externalToBeBilled, double totalToBeBilled,
			double total, double totalBilled) {
		super();
		this.projectManager = projectManager;
		this.projectNumber = projectNumber;
		this.internalBilled = internalBilled;
		this.internalToBeBilled = internalToBeBilled;
		this.externalBilled = externalBilled;
		this.externalToBeBilled = externalToBeBilled;
		this.totalToBeBilled = totalToBeBilled;
		this.total = total;
		this.totalBilled = totalBilled;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	public double getInternalBilled() {
		return internalBilled;
	}
	public void setInternalBilled(double internalBilled) {
		this.internalBilled = internalBilled;
	}
	public double getInternalToBeBilled() {
		return internalToBeBilled;
	}
	public void setInternalToBeBilled(double internalToBeBilled) {
		this.internalToBeBilled = internalToBeBilled;
	}
	public double getExternalBilled() {
		return externalBilled;
	}
	public void setExternalBilled(double externalBilled) {
		this.externalBilled = externalBilled;
	}
	public double getExternalToBeBilled() {
		return externalToBeBilled;
	}
	public void setExternalToBeBilled(double externalToBeBilled) {
		this.externalToBeBilled = externalToBeBilled;
	}
	public double getTotalToBeBilled() {
		return totalToBeBilled;
	}
	public void setTotalToBeBilled(double totalToBeBilled) {
		this.totalToBeBilled = totalToBeBilled;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public double getTotalBilled() {
		return totalBilled;
	}
	public void setTotalBilled(double totalBilled) {
		this.totalBilled = totalBilled;
	}
	
   

}
