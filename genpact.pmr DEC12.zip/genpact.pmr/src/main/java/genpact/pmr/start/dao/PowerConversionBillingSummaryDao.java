package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.PowerCBSRegionWiseDataDto;
import genpact.pmr.start.dto.PowerConversionBillingSummaryRequestJSONDataDto;
import genpact.pmr.start.dto.PowerConversionBillingSummaryResponseJSONDataDto;
import genpact.pmr.start.dto.ProjectManagerDataDto;
import genpact.pmr.start.dto.RegionSumDto;

@Repository
public class PowerConversionBillingSummaryDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public PowerConversionBillingSummaryResponseJSONDataDto getRegions() {

		PowerConversionBillingSummaryResponseJSONDataDto conversionBillingSummaryResponseJSONDataDto = new PowerConversionBillingSummaryResponseJSONDataDto();

		String billing_quarter = "'Q3-2016'";
		String sqlRegion = "select distinct(region) from billingsummary where billing_quarter=" + billing_quarter;// bydefault

		List<FormatDataDto> regionList = null;
		regionList = jdbcTemplate.query(sqlRegion, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("region"));
			}

		});

		conversionBillingSummaryResponseJSONDataDto.setFormatDataDtos(regionList);
		// =================================================================================

		// ========preparing query for Region wise Data

		List<FormatDataDto> billingQuarterList = new ArrayList<>();
		billingQuarterList.add(new FormatDataDto(1, "Q3-2016"));

		//

		String sqlInternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in(";

		sqlInternalToBeBilled += createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A')  group by region,regional_manager";

		String sqlInternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B')  group by region,regional_manager";

		String sqlExternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A')  group by region,regional_manager";

		String sqlExternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B')  group by region,regional_manager";

		// ===

		List<PowerCBSRegionWiseDataDto> regionwiseBillingDataList = getRegionWiseData(sqlInternalToBeBilled,
				sqlInternalBilled, sqlExternalToBeBilled, sqlExternalBilled);
		conversionBillingSummaryResponseJSONDataDto.setBillingByRegion(regionwiseBillingDataList);// ====

		// ========================================================

		// ===========================================================================================

		// preparing query for project manager

		String sqlInternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A')  group by region,regional_manager,project_manager";

		String sqlInternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B')  group by region,regional_manager,project_manager";

		String sqlExternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A')  group by region,regional_manager,project_manager";

		String sqlExternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B')  group by region,regional_manager,project_manager";

		List<PowerCBSRegionWiseDataDto> projectManagerWise = getProjectManagerWiseDataList(sqlInternalToBeBilled2,
				sqlInternalBilled2, sqlExternalToBeBilled2, sqlExternalBilled2);

		conversionBillingSummaryResponseJSONDataDto.setCbsProjectManagerSummaryDataDtos(projectManagerWise);
		// =========================================
		// preparing query for project id

		String sqlInternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A')  group by region,regional_manager,project_manager,project_number";

		String sqlInternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B')  group by region,regional_manager,project_manager,project_number";

		String sqlExternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A')  group by region,regional_manager,project_manager,project_number";

		String sqlExternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B')  group by region,regional_manager,project_manager,project_number";

		List<PowerCBSRegionWiseDataDto> projectIdDataList = getProjectIdDataList(sqlInternalToBeBilled3,
				sqlInternalBilled3, sqlExternalToBeBilled3, sqlExternalBilled3);

		conversionBillingSummaryResponseJSONDataDto.setCbsProjectDataDtos(projectIdDataList);

		return conversionBillingSummaryResponseJSONDataDto;
	}

	private List<RegionSumDto> getRegionSumDtoGroupByRegionalManagerAndRegion(String sql) {

		return jdbcTemplate.query(sql, new RowMapper<RegionSumDto>() {

			public RegionSumDto mapRow(ResultSet resultSet, int rowCount) throws SQLException {

				return new RegionSumDto(resultSet.getDouble("sum"), resultSet.getString("region"),
						resultSet.getString("regional_manager"));
			}

		});
	}

	private List<PowerCBSRegionWiseDataDto> getRegionWiseData(String sqlInternalToBeBilled, String sqlInternalBilled,
			String sqlExternalToBeBilled, String sqlExternalBilled) {// List<FormatDataDto>
																		// billingQuarterList)
																		// {

		/*
		 * String sqlInternalToBeBilled1 =
		 * "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
		 * ;
		 * 
		 * sqlInternalToBeBilled +=
		 * createSql(getFormatForSql(billingQuarterList)) +
		 * ") and internalnexternal like 'Internal' and billing_status in('A')  group by region,regional_manager"
		 * ;
		 */
		List<RegionSumDto> regionWiseInternalToBeBilledList = getRegionSumDtoGroupByRegionalManagerAndRegion(
				sqlInternalToBeBilled);
		/*
		 * String sqlInternalBilled =
		 * "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
		 * + createSql(getFormatForSql(billingQuarterList)) +
		 * ") and internalnexternal like 'Internal' and billing_status in('C','B')  group by region,regional_manager"
		 * ;
		 */
		List<RegionSumDto> regionWiseInternalBilledList = getRegionSumDtoGroupByRegionalManagerAndRegion(
				sqlInternalBilled);

		/*
		 * String sqlExternalToBeBilled =
		 * "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
		 * + createSql(getFormatForSql(billingQuarterList)) +
		 * ") and internalnexternal like 'External' and billing_status in('A')  group by region,regional_manager"
		 * ;
		 */
		List<RegionSumDto> regionWisesqlExternalToBeBilledList = getRegionSumDtoGroupByRegionalManagerAndRegion(
				sqlExternalToBeBilled);

		/*
		 * String sqlExternalBilled =
		 * "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
		 * + createSql(getFormatForSql(billingQuarterList)) +
		 * ") and internalnexternal like 'External' and billing_status in('C','B')  group by region,regional_manager"
		 * ;
		 */
		List<RegionSumDto> regionWiseExternalBilledList = getRegionSumDtoGroupByRegionalManagerAndRegion(
				sqlExternalBilled);

		// info abt calculation
		// totalBilled = (internalBilled + externalBilled);
		List<RegionSumDto> regionWiseTotalBilledList = new ArrayList<>();

		RegionSumDto internalBilledRegionSumDto = null;

		// Map<String,RegionSumDto>

		for (int i = 0; i < regionWiseInternalBilledList.size(); i++) {

			internalBilledRegionSumDto = regionWiseInternalBilledList.get(i);
			for (RegionSumDto externalBilledRegionSumDto : regionWiseExternalBilledList) {

				if (internalBilledRegionSumDto.getName().equals(externalBilledRegionSumDto.getName())) {

					regionWiseTotalBilledList.add(new RegionSumDto(
							internalBilledRegionSumDto.getSum() + externalBilledRegionSumDto.getSum(),
							internalBilledRegionSumDto.getName(), internalBilledRegionSumDto.getRegionalManager()));

				}

			}
		}

		// totalToBeBilled = (internalToBeBilled + externalToBeBilled);

		List<RegionSumDto> regionWiseTotalToBeBilledList = new ArrayList<>();

		RegionSumDto internalToBeBilledRegionSumDto = null;
		for (int i = 0; i < regionWiseInternalToBeBilledList.size(); i++) {

			internalToBeBilledRegionSumDto = regionWiseInternalToBeBilledList.get(i);
			for (RegionSumDto externalToBeBilledRegionSumDto : regionWisesqlExternalToBeBilledList) {

				if (internalToBeBilledRegionSumDto.getName().equals(externalToBeBilledRegionSumDto.getName())) {

					regionWiseTotalToBeBilledList.add(new RegionSumDto(
							internalToBeBilledRegionSumDto.getSum() + externalToBeBilledRegionSumDto.getSum(),
							internalToBeBilledRegionSumDto.getName(),
							internalToBeBilledRegionSumDto.getRegionalManager()));

				}

			}
		}

		// totalBilling = (totalBilled + totalToBeBilled);

		List<RegionSumDto> totalBillings = new ArrayList<>();

		RegionSumDto totalBilling = null;
		for (int i = 0; i < regionWiseTotalBilledList.size(); i++) {

			totalBilling = regionWiseTotalBilledList.get(i);
			for (RegionSumDto totalToBeBilled : regionWiseTotalToBeBilledList) {

				if (totalBilling.getName().equals(totalToBeBilled.getName())) {

					totalBillings.add(new RegionSumDto(totalBilling.getSum() + totalToBeBilled.getSum(),
							totalBilling.getName(), totalBilling.getRegionalManager()));

				}

			}
		}

		// billedPercent = (totalBilled / totalBilling);

		List<RegionSumDto> billedPercents = new ArrayList<>();

		RegionSumDto totalBillingDto = null;
		for (int i = 0; i < totalBillings.size(); i++) {

			totalBillingDto = totalBillings.get(i);
			for (RegionSumDto totalBilled : regionWiseTotalBilledList) {

				if (totalBillingDto.getName().equals(totalBilled.getName())) {

					try {
						billedPercents.add(new RegionSumDto(totalBilled.getSum() / totalBillingDto.getSum(),
								totalBillingDto.getName(), totalBillingDto.getRegionalManager()));
					} catch (ArithmeticException e) {

						billedPercents.add(new RegionSumDto(totalBilled.getSum() / 0.1, totalBillingDto.getName(),
								totalBillingDto.getRegionalManager()));
					}

				}

			}
		}

		// =======================================================

		Map<String, PowerCBSRegionWiseDataDto> regionwiseBillingDataMap = new HashMap<>();
		Set<String> regionwiseBillingDataSet = new HashSet<>();
		List<PowerCBSRegionWiseDataDto> regionwiseBillingDataList = new ArrayList<>();

		PowerCBSRegionWiseDataDto pwd = null;

		// billedPercent
		for (RegionSumDto billedPercent : billedPercents) {

			String key = billedPercent.getName() + "," + billedPercent.getRegionalManager();
			if (regionwiseBillingDataSet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(billedPercent.getName());
				pwd.setRegionalmanager(billedPercent.getRegionalManager());
				pwd.setBilledPercent(billedPercent.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			} else {
				pwd = regionwiseBillingDataMap.get(key);

				pwd.setBilledPercent(pwd.getBilledPercent() + billedPercent.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			}
		}

		// externalToBeBilled
		for (RegionSumDto externalToBeBilled : regionWisesqlExternalToBeBilledList) {

			String key = externalToBeBilled.getName() + "," + externalToBeBilled.getRegionalManager();
			if (regionwiseBillingDataSet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(externalToBeBilled.getName());
				pwd.setRegionalmanager(externalToBeBilled.getRegionalManager());
				pwd.setExternalToBeBilled(externalToBeBilled.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			} else {
				pwd = regionwiseBillingDataMap.get(key);

				pwd.setExternalToBeBilled(pwd.getExternalToBeBilled() + externalToBeBilled.getSum());
				regionwiseBillingDataMap.put(key, pwd);
			}

		}

		// externalBilled

		for (RegionSumDto externalBilled : regionWiseExternalBilledList) {

			String key = externalBilled.getName() + "," + externalBilled.getRegionalManager();
			if (regionwiseBillingDataSet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(externalBilled.getName());
				pwd.setRegionalmanager(externalBilled.getRegionalManager());
				pwd.setExternalBilled(externalBilled.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			} else {
				pwd = regionwiseBillingDataMap.get(key);

				pwd.setExternalBilled(pwd.getExternalBilled() + externalBilled.getSum());
				regionwiseBillingDataMap.put(key, pwd);
			}
		}

		// internalBilled
		for (RegionSumDto internalBilled : regionWiseInternalBilledList) {

			String key = internalBilled.getName() + "," + internalBilled.getRegionalManager();
			if (regionwiseBillingDataSet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(internalBilled.getName());
				pwd.setRegionalmanager(internalBilled.getRegionalManager());
				pwd.setInternalBilled(internalBilled.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			} else {
				pwd = regionwiseBillingDataMap.get(key);

				pwd.setInternalBilled(pwd.getInternalBilled() + internalBilled.getSum());
				regionwiseBillingDataMap.put(key, pwd);
			}

		}

		// internalToBeBilled
		for (RegionSumDto internalToBeBilled : regionWiseInternalToBeBilledList) {

			String key = internalToBeBilled.getName() + "," + internalToBeBilled.getRegionalManager();
			if (regionwiseBillingDataSet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(internalToBeBilled.getName());
				pwd.setRegionalmanager(internalToBeBilled.getRegionalManager());
				pwd.setInternalToBeBilled(internalToBeBilled.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			} else {
				pwd = regionwiseBillingDataMap.get(key);

				pwd.setInternalToBeBilled(pwd.getInternalToBeBilled() + internalToBeBilled.getSum());
				regionwiseBillingDataMap.put(key, pwd);
			}

		}

		// totalToBeBilled
		for (RegionSumDto totalToBeBilled : regionWiseTotalToBeBilledList) {

			String key = totalToBeBilled.getName() + "," + totalToBeBilled.getRegionalManager();
			if (regionwiseBillingDataSet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(totalToBeBilled.getName());
				pwd.setRegionalmanager(totalToBeBilled.getRegionalManager());
				pwd.setTotalToBeBilled(totalToBeBilled.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			} else {
				pwd = regionwiseBillingDataMap.get(key);

				pwd.setTotalToBeBilled(pwd.getTotalToBeBilled() + totalToBeBilled.getSum());
				regionwiseBillingDataMap.put(key, pwd);
			}

		}

		// totalBilling
		for (RegionSumDto totalBilling1 : totalBillings) {

			String key = totalBilling1.getName() + "," + totalBilling1.getRegionalManager();
			if (regionwiseBillingDataSet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(totalBilling1.getName());
				pwd.setRegionalmanager(totalBilling1.getRegionalManager());
				pwd.setTotalBilling(totalBilling1.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			} else {
				pwd = regionwiseBillingDataMap.get(key);

				pwd.setTotalBilling(pwd.getTotalBilling() + totalBilling1.getSum());
				regionwiseBillingDataMap.put(key, pwd);
			}

		}

		// totalBilled
		for (RegionSumDto totalBilled : regionWiseTotalBilledList) {

			String key = totalBilled.getName() + "," + totalBilled.getRegionalManager();
			if (regionwiseBillingDataSet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(totalBilled.getName());
				pwd.setRegionalmanager(totalBilled.getRegionalManager());
				pwd.setTotalBilled(totalBilled.getSum());

				regionwiseBillingDataMap.put(key, pwd);
			} else {
				pwd = regionwiseBillingDataMap.get(key);

				pwd.setTotalBilled(pwd.getTotalBilled() + totalBilled.getSum());
				regionwiseBillingDataMap.put(key, pwd);
			}
		}

		for (String key : regionwiseBillingDataMap.keySet()) {
			regionwiseBillingDataList.add(regionwiseBillingDataMap.get(key));
		}

		return regionwiseBillingDataList;

	}

	private List<ProjectManagerDataDto> getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManager(String sql) {

		return jdbcTemplate.query(sql, new RowMapper<ProjectManagerDataDto>() {

			public ProjectManagerDataDto mapRow(ResultSet resultSet, int rowCount) throws SQLException {

				return new ProjectManagerDataDto(resultSet.getDouble("sum"), resultSet.getString("region"),
						resultSet.getString("regional_manager"), resultSet.getString("project_manager"));
			}

		});

	}

	private List<PowerCBSRegionWiseDataDto> getProjectManagerWiseDataList(String sqlInternalToBeBilled,
			String sqlInternalBilled, String sqlExternalToBeBilled, String sqlExternalBilled) {

		List<ProjectManagerDataDto> regionWiseInternalToBeBilledList = getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManager(
				sqlInternalToBeBilled);

		List<ProjectManagerDataDto> regionWiseInternalBilledList = getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManager(
				sqlInternalBilled);
		List<ProjectManagerDataDto> regionWisesqlExternalToBeBilledList = getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManager(
				sqlExternalToBeBilled);

		List<ProjectManagerDataDto> regionWiseExternalBilledList = getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManager(
				sqlExternalBilled);

		// info abt calculation
		// totalBilled = (internalBilled + externalBilled);

		List<ProjectManagerDataDto> regionWiseTotalBilledList = new ArrayList<>();

		ProjectManagerDataDto internalBilledRegionSumDto = null;
		for (int i = 0; i < regionWiseInternalBilledList.size(); i++) {

			internalBilledRegionSumDto = regionWiseInternalBilledList.get(i);
			for (ProjectManagerDataDto externalBilledRegionSumDto : regionWiseExternalBilledList) {

				if (internalBilledRegionSumDto.getName().equals(externalBilledRegionSumDto.getName())
						&& internalBilledRegionSumDto.getProjectManager()
								.equals(externalBilledRegionSumDto.getProjectManager())) {

					regionWiseTotalBilledList.add(new ProjectManagerDataDto(
							internalBilledRegionSumDto.getSum() + externalBilledRegionSumDto.getSum(),
							internalBilledRegionSumDto.getName(), internalBilledRegionSumDto.getRegionalManager(),
							internalBilledRegionSumDto.getProjectManager()));

				}

			}
		}

		// System.out.println("regionWiseTotalBilledList : 5 " +
		// regionWiseTotalBilledList);

		// totalToBeBilled = (internalToBeBilled + externalToBeBilled);

		List<ProjectManagerDataDto> regionWiseTotalToBeBilledList = new ArrayList<>();

		ProjectManagerDataDto internalToBeBilledRegionSumDto = null;
		for (int i = 0; i < regionWiseInternalToBeBilledList.size(); i++) {

			internalToBeBilledRegionSumDto = regionWiseInternalToBeBilledList.get(i);
			for (ProjectManagerDataDto externalToBeBilledRegionSumDto : regionWisesqlExternalToBeBilledList) {

				if (internalToBeBilledRegionSumDto.getName().equals(externalToBeBilledRegionSumDto.getName())
						&& internalToBeBilledRegionSumDto.getProjectManager()
								.equals(externalToBeBilledRegionSumDto.getProjectManager())) {

					regionWiseTotalToBeBilledList.add(new ProjectManagerDataDto(
							internalToBeBilledRegionSumDto.getSum() + externalToBeBilledRegionSumDto.getSum(),
							internalToBeBilledRegionSumDto.getName(),
							internalToBeBilledRegionSumDto.getRegionalManager(),
							internalToBeBilledRegionSumDto.getProjectManager()));

				}

			}
		}

		// System.out.println("regionWiseTotalToBeBilledList : 6 " +
		// regionWiseTotalToBeBilledList);

		// totalBilling = (totalBilled + totalToBeBilled);

		List<ProjectManagerDataDto> totalBillings = new ArrayList<>();

		ProjectManagerDataDto totalBilling = null;
		for (int i = 0; i < regionWiseTotalBilledList.size(); i++) {

			totalBilling = regionWiseTotalBilledList.get(i);
			for (ProjectManagerDataDto totalToBeBilled : regionWiseTotalToBeBilledList) {

				if (totalBilling.getName().equals(totalToBeBilled.getName())
						&& totalBilling.getProjectManager().equals(totalToBeBilled.getProjectManager())) {

					totalBillings.add(new ProjectManagerDataDto(totalBilling.getSum() + totalToBeBilled.getSum(),
							totalBilling.getName(), totalBilling.getRegionalManager(),
							totalBilling.getProjectManager()));

				}

			}
		}
		// System.out.println("totalBillings : 7 " + totalBillings);
		// billedPercent = (totalBilled / totalBilling);

		List<ProjectManagerDataDto> billedPercents = new ArrayList<>();

		ProjectManagerDataDto totalBillingDto = null;
		for (int i = 0; i < totalBillings.size(); i++) {

			totalBillingDto = totalBillings.get(i);
			for (ProjectManagerDataDto totalBilled : regionWiseTotalBilledList) {

				if (totalBillingDto.getName().equals(totalBilled.getName())
						&& totalBillingDto.getProjectManager().equals(totalBilled.getProjectManager())) {

					try {
						billedPercents.add(new ProjectManagerDataDto(totalBilled.getSum() / totalBillingDto.getSum(),
								totalBillingDto.getName(), totalBillingDto.getRegionalManager(),
								totalBillingDto.getProjectManager()));
					} catch (ArithmeticException e) {

						billedPercents
								.add(new ProjectManagerDataDto(totalBilled.getSum() / 0.1, totalBillingDto.getName(),
										totalBillingDto.getRegionalManager(), totalBillingDto.getProjectManager()));
					}

				}

			}
		}

		// System.out.println("billedPercents : 8 " + billedPercents);

		List<PowerCBSRegionWiseDataDto> regionwiseBillingList = new ArrayList<>();

		PowerCBSRegionWiseDataDto powerCBSRegionWiseDataDto = null;

		String region = null;

		String sqlProjectManager = "select distinct(project_manager) from billingsummary";

		List<String> pmList = jdbcTemplate.query(sqlProjectManager, new RowMapper<String>() {
			public String mapRow(ResultSet resultSet, int rowCount) throws SQLException {

				return resultSet.getString("project_manager");
			}

		});

		Map<String, PowerCBSRegionWiseDataDto> projectManagerDataMap = new HashMap<>();

		Set<String> projectManagerDataKeySet = new HashSet<>();

		List<PowerCBSRegionWiseDataDto> projectManagerDataList = new ArrayList<>();

		PowerCBSRegionWiseDataDto pwd = null;

		// Santosh
		// =================================================================

		// =================================================================

		// billedPercent
		for (ProjectManagerDataDto billedPercent : billedPercents) {

			String key = billedPercent.getName() + "," + billedPercent.getProjectManager() + ","
					+ billedPercent.getRegionalManager();

			if (projectManagerDataKeySet.add(key)) {

				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(billedPercent.getName());
				pwd.setRegionalmanager(billedPercent.getRegionalManager());
				pwd.setProjectManager(billedPercent.getProjectManager());
				pwd.setBilledPercent(billedPercent.getSum());
				projectManagerDataMap.put(key, pwd);

			} else {
				pwd = projectManagerDataMap.get(key);

				pwd.setBilledPercent(pwd.getBilledPercent() + billedPercent.getSum());
				projectManagerDataMap.put(key, pwd);
			}

		}

		// externalToBeBilled
		for (ProjectManagerDataDto externalToBeBilled : regionWisesqlExternalToBeBilledList) {

			String key = externalToBeBilled.getName() + "," + externalToBeBilled.getProjectManager() + ","
					+ externalToBeBilled.getRegionalManager();

			if (projectManagerDataKeySet.add(key)) {

				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(externalToBeBilled.getName());
				pwd.setRegionalmanager(externalToBeBilled.getRegionalManager());
				pwd.setProjectManager(externalToBeBilled.getProjectManager());
				pwd.setExternalToBeBilled(externalToBeBilled.getSum());
				projectManagerDataMap.put(key, pwd);

			} else {
				pwd = projectManagerDataMap.get(key);

				pwd.setExternalToBeBilled(pwd.getExternalToBeBilled() + externalToBeBilled.getSum());
				projectManagerDataMap.put(key, pwd);
			}

		}

		// externalBilled

		for (ProjectManagerDataDto externalBilled : regionWiseExternalBilledList) {

			String key = externalBilled.getName() + "," + externalBilled.getProjectManager() + ","
					+ externalBilled.getRegionalManager();

			if (projectManagerDataKeySet.add(key)) {

				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(externalBilled.getName());
				pwd.setRegionalmanager(externalBilled.getRegionalManager());
				pwd.setProjectManager(externalBilled.getProjectManager());
				pwd.setExternalBilled(externalBilled.getSum());
				projectManagerDataMap.put(key, pwd);

			} else {
				pwd = projectManagerDataMap.get(key);

				pwd.setExternalBilled(pwd.getExternalBilled() + externalBilled.getSum());
				projectManagerDataMap.put(key, pwd);
			}

		}

		// internalBilled
		for (ProjectManagerDataDto internalBilled : regionWiseInternalBilledList) {

			String key = internalBilled.getName() + "," + internalBilled.getProjectManager() + ","
					+ internalBilled.getRegionalManager();

			if (projectManagerDataKeySet.add(key)) {

				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(internalBilled.getName());
				pwd.setRegionalmanager(internalBilled.getRegionalManager());
				pwd.setProjectManager(internalBilled.getProjectManager());
				pwd.setInternalBilled(internalBilled.getSum());
				projectManagerDataMap.put(key, pwd);

			} else {
				pwd = projectManagerDataMap.get(key);

				pwd.setInternalBilled(pwd.getInternalBilled() + internalBilled.getSum());
				projectManagerDataMap.put(key, pwd);
			}

		}

		// internalToBeBilled

		for (ProjectManagerDataDto internalToBeBilled : regionWiseInternalToBeBilledList) {

			String key = internalToBeBilled.getName() + "," + internalToBeBilled.getProjectManager() + ","
					+ internalToBeBilled.getRegionalManager();

			if (projectManagerDataKeySet.add(key)) {

				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(internalToBeBilled.getName());
				pwd.setRegionalmanager(internalToBeBilled.getRegionalManager());
				pwd.setProjectManager(internalToBeBilled.getProjectManager());
				pwd.setInternalToBeBilled(internalToBeBilled.getSum());
				projectManagerDataMap.put(key, pwd);

			} else {
				pwd = projectManagerDataMap.get(key);

				pwd.setInternalToBeBilled(pwd.getInternalToBeBilled() + internalToBeBilled.getSum());
				projectManagerDataMap.put(key, pwd);
			}

		}

		// totalToBeBilled
		for (ProjectManagerDataDto totalToBeBilled : regionWiseTotalToBeBilledList) {

			String key = totalToBeBilled.getName() + "," + totalToBeBilled.getProjectManager() + ","
					+ totalToBeBilled.getRegionalManager();

			if (projectManagerDataKeySet.add(key)) {

				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(totalToBeBilled.getName());
				pwd.setRegionalmanager(totalToBeBilled.getRegionalManager());
				pwd.setProjectManager(totalToBeBilled.getProjectManager());
				pwd.setTotalToBeBilled(totalToBeBilled.getSum());
				projectManagerDataMap.put(key, pwd);

			} else {
				pwd = projectManagerDataMap.get(key);

				pwd.setTotalToBeBilled(pwd.getTotalToBeBilled() + totalToBeBilled.getSum());
				projectManagerDataMap.put(key, pwd);
			}
		}

		// totalBilling
		for (ProjectManagerDataDto totalBilling1 : totalBillings) {

			String key = totalBilling1.getName() + "," + totalBilling1.getProjectManager() + ","
					+ totalBilling1.getRegionalManager();

			if (projectManagerDataKeySet.add(key)) {

				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(totalBilling1.getName());
				pwd.setRegionalmanager(totalBilling1.getRegionalManager());
				pwd.setProjectManager(totalBilling1.getProjectManager());
				pwd.setTotalBilling(totalBilling1.getSum());
				projectManagerDataMap.put(key, pwd);

			} else {
				pwd = projectManagerDataMap.get(key);

				pwd.setTotalBilling(pwd.getTotalBilling() + totalBilling1.getSum());
				projectManagerDataMap.put(key, pwd);
			}
		}

		// totalBilled
		for (ProjectManagerDataDto totalBilled : regionWiseTotalBilledList) {

			String key = totalBilled.getName() + "," + totalBilled.getProjectManager() + ","
					+ totalBilled.getRegionalManager();

			if (projectManagerDataKeySet.add(key)) {

				pwd = new PowerCBSRegionWiseDataDto();
				pwd.setRegion(totalBilled.getName());
				pwd.setRegionalmanager(totalBilled.getRegionalManager());
				pwd.setProjectManager(totalBilled.getProjectManager());
				pwd.setTotalBilled(totalBilled.getSum());
				projectManagerDataMap.put(key, pwd);

			} else {
				pwd = projectManagerDataMap.get(key);

				pwd.setTotalBilled(pwd.getTotalBilled() + totalBilled.getSum());
				projectManagerDataMap.put(key, pwd);
			}
		}

		for (String key : projectManagerDataMap.keySet()) {
			PowerCBSRegionWiseDataDto hh1 = projectManagerDataMap.get(key);
			projectManagerDataList.add(hh1);
		}

		return projectManagerDataList;

	}

	private List<ProjectManagerDataDto> getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManagerAndProjectId(
			String sql) {
		return jdbcTemplate.query(sql, new RowMapper<ProjectManagerDataDto>() {

			public ProjectManagerDataDto mapRow(ResultSet resultSet, int rowCount) throws SQLException {

				return new ProjectManagerDataDto(resultSet.getDouble("sum"), resultSet.getString("region"),
						resultSet.getString("regional_manager"), resultSet.getString("project_manager"),
						resultSet.getString("project_number"));

			}

		});
	}

	private List<PowerCBSRegionWiseDataDto> getProjectIdDataList(String sqlInternalToBeBilled, String sqlInternalBilled,
			String sqlExternalToBeBilled, String sqlExternalBilled) {

		List<ProjectManagerDataDto> regionWiseInternalToBeBilledList = getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManagerAndProjectId(
				sqlInternalToBeBilled);

		List<ProjectManagerDataDto> regionWiseInternalBilledList = getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManagerAndProjectId(
				sqlInternalBilled);

		List<ProjectManagerDataDto> regionWisesqlExternalToBeBilledList = getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManagerAndProjectId(
				sqlExternalToBeBilled);

		List<ProjectManagerDataDto> regionWiseExternalBilledList = getRegionSumDtoGroupByRegionalManagerAndRegionAndProjectManagerAndProjectId(
				sqlExternalBilled);

		// info abt calculation
		// totalBilled = (internalBilled + externalBilled);
		List<ProjectManagerDataDto> regionWiseTotalBilledList = new ArrayList<>();

		ProjectManagerDataDto internalBilledRegionSumDto = null;

		for (int i = 0; i < regionWiseInternalBilledList.size(); i++) {

			internalBilledRegionSumDto = regionWiseInternalBilledList.get(i);
			for (ProjectManagerDataDto externalBilledRegionSumDto : regionWiseExternalBilledList) {

				/*
				 * if (internalBilledRegionSumDto.getName().equals(
				 * externalBilledRegionSumDto.getName()) &&
				 * internalBilledRegionSumDto.getProjectManager()
				 * .equals(externalBilledRegionSumDto.getProjectManager())) {
				 */
				if (internalBilledRegionSumDto.getProjectManager()
						.equals(externalBilledRegionSumDto.getProjectManager())
						&& internalBilledRegionSumDto.getProjectId()
								.equals(externalBilledRegionSumDto.getProjectId())) {

					regionWiseTotalBilledList.add(new ProjectManagerDataDto(
							internalBilledRegionSumDto.getSum() + externalBilledRegionSumDto.getSum(),
							internalBilledRegionSumDto.getName(), internalBilledRegionSumDto.getRegionalManager(),
							internalBilledRegionSumDto.getProjectManager(), internalBilledRegionSumDto.getProjectId()));

				}

			}
		}

		// System.out.println("regionWiseTotalBilledList : 5 " +
		// regionWiseTotalBilledList);

		// totalToBeBilled = (internalToBeBilled + externalToBeBilled);

		List<ProjectManagerDataDto> regionWiseTotalToBeBilledList = new ArrayList<>();

		ProjectManagerDataDto internalToBeBilledRegionSumDto = null;
		for (int i = 0; i < regionWiseInternalToBeBilledList.size(); i++) {

			internalToBeBilledRegionSumDto = regionWiseInternalToBeBilledList.get(i);
			for (ProjectManagerDataDto externalToBeBilledRegionSumDto : regionWisesqlExternalToBeBilledList) {

				if (internalToBeBilledRegionSumDto.getProjectManager()
						.equals(externalToBeBilledRegionSumDto.getProjectManager())
						&& internalToBeBilledRegionSumDto.getProjectId()
								.equals(externalToBeBilledRegionSumDto.getProjectId())) {

					regionWiseTotalToBeBilledList.add(new ProjectManagerDataDto(
							internalToBeBilledRegionSumDto.getSum() + externalToBeBilledRegionSumDto.getSum(),
							internalToBeBilledRegionSumDto.getName(),
							internalToBeBilledRegionSumDto.getRegionalManager(),
							internalToBeBilledRegionSumDto.getProjectManager(),
							internalToBeBilledRegionSumDto.getProjectId()));

				}

			}
		}

		// System.out.println("regionWiseTotalToBeBilledList : 6 " +
		// regionWiseTotalToBeBilledList);

		// totalBilling = (totalBilled + totalToBeBilled);

		List<ProjectManagerDataDto> totalBillings = new ArrayList<>();

		ProjectManagerDataDto totalBilling = null;
		for (int i = 0; i < regionWiseTotalBilledList.size(); i++) {

			totalBilling = regionWiseTotalBilledList.get(i);
			for (ProjectManagerDataDto totalToBeBilled : regionWiseTotalToBeBilledList) {

				if (totalBilling.getProjectManager().equals(totalToBeBilled.getProjectManager())
						&& totalBilling.getProjectId().equals(totalToBeBilled.getProjectId())) {

					totalBillings.add(new ProjectManagerDataDto(totalBilling.getSum() + totalToBeBilled.getSum(),
							totalBilling.getName(), totalBilling.getRegionalManager(), totalBilling.getProjectManager(),
							totalBilling.getProjectId()));

				}

			}
		}
		// System.out.println("totalBillings : 7 " + totalBillings);
		// billedPercent = (totalBilled / totalBilling);

		List<ProjectManagerDataDto> billedPercents = new ArrayList<>();

		ProjectManagerDataDto totalBillingDto = null;
		for (int i = 0; i < totalBillings.size(); i++) {

			totalBillingDto = totalBillings.get(i);
			for (ProjectManagerDataDto totalBilled : regionWiseTotalBilledList) {

				if (totalBillingDto.getProjectManager().equals(totalBilled.getProjectManager())
						&& totalBillingDto.getProjectId().equals(totalBilled.getProjectId())) {

					try {
						billedPercents.add(new ProjectManagerDataDto(totalBilled.getSum() / totalBillingDto.getSum(),
								totalBillingDto.getName(), totalBillingDto.getRegionalManager(),
								totalBillingDto.getProjectManager(), totalBillingDto.getProjectId()));
					} catch (ArithmeticException e) {

						billedPercents.add(new ProjectManagerDataDto(totalBilled.getSum() / 0.1,
								totalBillingDto.getName(), totalBillingDto.getRegionalManager(),
								totalBillingDto.getProjectManager(), totalBillingDto.getProjectId()));
					}

				}

			}
		}

		// System.out.println("billedPercents : "+billedPercents);

		Map<String, PowerCBSRegionWiseDataDto> projectIdDataMap = new HashMap<>();
		Set<String> projectIdDataKeySet = new HashSet<>();
		List<PowerCBSRegionWiseDataDto> projectIdDataList = new ArrayList<>();

		PowerCBSRegionWiseDataDto pwd = null;
		// billedPercent
		for (ProjectManagerDataDto billedPercent : billedPercents) {
			String key = billedPercent.getName() + "," + billedPercent.getProjectManager() + ","
					+ billedPercent.getProjectId() + "," + billedPercent.getRegionalManager();

			if (projectIdDataKeySet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();

				pwd.setRegion(billedPercent.getName());
				pwd.setRegionalmanager(billedPercent.getRegionalManager());
				pwd.setProjectManager(billedPercent.getProjectManager());
				pwd.setProjectId(billedPercent.getProjectId());
				pwd.setBilledPercent(billedPercent.getSum());
				projectIdDataMap.put(key, pwd);

			} else {
				pwd = projectIdDataMap.get(key);

				pwd.setBilledPercent(pwd.getBilledPercent() + billedPercent.getSum());
				projectIdDataMap.put(key, pwd);
			}

		}

		// externalToBeBilled
		for (ProjectManagerDataDto externalToBeBilled : regionWisesqlExternalToBeBilledList) {

			String key = externalToBeBilled.getName() + "," + externalToBeBilled.getProjectManager() + ","
					+ externalToBeBilled.getProjectId() + "," + externalToBeBilled.getRegionalManager();

			if (projectIdDataKeySet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();

				pwd.setRegion(externalToBeBilled.getName());
				pwd.setRegionalmanager(externalToBeBilled.getRegionalManager());
				pwd.setProjectManager(externalToBeBilled.getProjectManager());
				pwd.setProjectId(externalToBeBilled.getProjectId());
				pwd.setExternalToBeBilled(externalToBeBilled.getSum());
				projectIdDataMap.put(key, pwd);

			} else {
				pwd = projectIdDataMap.get(key);

				pwd.setExternalToBeBilled(pwd.getExternalToBeBilled() + externalToBeBilled.getSum());
				projectIdDataMap.put(key, pwd);
			}

		}

		// externalBilled

		for (ProjectManagerDataDto externalBilled : regionWiseExternalBilledList) {

			String key = externalBilled.getName() + "," + externalBilled.getProjectManager() + ","
					+ externalBilled.getProjectId() + "," + externalBilled.getRegionalManager();

			if (projectIdDataKeySet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();

				pwd.setRegion(externalBilled.getName());
				pwd.setRegionalmanager(externalBilled.getRegionalManager());
				pwd.setProjectManager(externalBilled.getProjectManager());
				pwd.setProjectId(externalBilled.getProjectId());
				pwd.setExternalBilled(externalBilled.getSum());
				projectIdDataMap.put(key, pwd);

			} else {
				pwd = projectIdDataMap.get(key);

				pwd.setExternalBilled(pwd.getExternalBilled() + externalBilled.getSum());
				projectIdDataMap.put(key, pwd);
			}

		}

		// internalBilled
		for (ProjectManagerDataDto internalBilled : regionWiseInternalBilledList) {

			String key = internalBilled.getName() + "," + internalBilled.getProjectManager() + ","
					+ internalBilled.getProjectId() + "," + internalBilled.getRegionalManager();

			if (projectIdDataKeySet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();

				pwd.setRegion(internalBilled.getName());
				pwd.setRegionalmanager(internalBilled.getRegionalManager());
				pwd.setProjectManager(internalBilled.getProjectManager());
				pwd.setProjectId(internalBilled.getProjectId());
				pwd.setInternalBilled(internalBilled.getSum());
				projectIdDataMap.put(key, pwd);

			} else {
				pwd = projectIdDataMap.get(key);

				pwd.setInternalBilled(pwd.getInternalBilled() + internalBilled.getSum());
				projectIdDataMap.put(key, pwd);
			}
		}

		// internalToBeBilled

		for (ProjectManagerDataDto internalToBeBilled : regionWiseInternalToBeBilledList) {

			String key = internalToBeBilled.getName() + "," + internalToBeBilled.getProjectManager() + ","
					+ internalToBeBilled.getProjectId() + "," + internalToBeBilled.getRegionalManager();

			if (projectIdDataKeySet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();

				pwd.setRegion(internalToBeBilled.getName());
				pwd.setRegionalmanager(internalToBeBilled.getRegionalManager());
				pwd.setProjectManager(internalToBeBilled.getProjectManager());
				pwd.setProjectId(internalToBeBilled.getProjectId());
				pwd.setInternalToBeBilled(internalToBeBilled.getSum());
				projectIdDataMap.put(key, pwd);

			} else {
				pwd = projectIdDataMap.get(key);

				pwd.setInternalToBeBilled(pwd.getInternalToBeBilled() + internalToBeBilled.getSum());
				projectIdDataMap.put(key, pwd);
			}

		}

		// totalToBeBilled
		for (ProjectManagerDataDto totalToBeBilled : regionWiseTotalToBeBilledList) {

			String key = totalToBeBilled.getName() + "," + totalToBeBilled.getProjectManager() + ","
					+ totalToBeBilled.getProjectId() + "," + totalToBeBilled.getRegionalManager();

			if (projectIdDataKeySet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();

				pwd.setRegion(totalToBeBilled.getName());
				pwd.setRegionalmanager(totalToBeBilled.getRegionalManager());
				pwd.setProjectManager(totalToBeBilled.getProjectManager());
				pwd.setProjectId(totalToBeBilled.getProjectId());
				pwd.setTotalToBeBilled(totalToBeBilled.getSum());
				projectIdDataMap.put(key, pwd);

			} else {
				pwd = projectIdDataMap.get(key);

				pwd.setTotalToBeBilled(pwd.getTotalToBeBilled() + totalToBeBilled.getSum());
				projectIdDataMap.put(key, pwd);
			}

		}

		// totalBilling
		for (ProjectManagerDataDto totalBilling1 : totalBillings) {

			String key = totalBilling1.getName() + "," + totalBilling1.getProjectManager() + ","
					+ totalBilling1.getProjectId() + "," + totalBilling1.getRegionalManager();

			if (projectIdDataKeySet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();

				pwd.setRegion(totalBilling1.getName());
				pwd.setRegionalmanager(totalBilling1.getRegionalManager());
				pwd.setProjectManager(totalBilling1.getProjectManager());
				pwd.setProjectId(totalBilling1.getProjectId());
				pwd.setTotalBilling(totalBilling1.getSum());
				projectIdDataMap.put(key, pwd);

			} else {
				pwd = projectIdDataMap.get(key);

				pwd.setTotalBilling(pwd.getTotalBilling() + totalBilling1.getSum());
				projectIdDataMap.put(key, pwd);
			}

		}

		// totalBilled
		for (ProjectManagerDataDto totalBilled : regionWiseTotalBilledList) {

			String key = totalBilled.getName() + "," + totalBilled.getProjectManager() + ","
					+ totalBilled.getProjectId() + "," + totalBilled.getRegionalManager();

			if (projectIdDataKeySet.add(key)) {
				pwd = new PowerCBSRegionWiseDataDto();

				pwd.setRegion(totalBilled.getName());
				pwd.setRegionalmanager(totalBilled.getRegionalManager());
				pwd.setProjectManager(totalBilled.getProjectManager());
				pwd.setProjectId(totalBilled.getProjectId());
				pwd.setTotalBilled(totalBilled.getSum());
				projectIdDataMap.put(key, pwd);

			} else {
				pwd = projectIdDataMap.get(key);

				pwd.setTotalBilled(pwd.getTotalBilled() + totalBilled.getSum());
				projectIdDataMap.put(key, pwd);
			}

		}

		for (String key : projectIdDataMap.keySet()) {
			PowerCBSRegionWiseDataDto hh = projectIdDataMap.get(key);
			projectIdDataList.add(hh);
		}
		return projectIdDataList;

	}

	public PowerConversionBillingSummaryResponseJSONDataDto getRegionalManager(
			PowerConversionBillingSummaryRequestJSONDataDto requestJSONDataDto) {

		PowerConversionBillingSummaryResponseJSONDataDto responseJson = new PowerConversionBillingSummaryResponseJSONDataDto();

		List<FormatDataDto> regionFilters = requestJSONDataDto.getRegionFilters();
		List<FormatDataDto> billingQuarterList = requestJSONDataDto.getBillingQuarterFilters();

		String sqlRegionFormat = getFormatForSql(regionFilters);
		String sqlQuarterFormat = getFormatForSql(billingQuarterList);

		String sql = "select distinct(regional_manager) from billingsummary where region in(";

		sql += createSql(sqlRegionFormat);
		sql += ") and billing_quarter in(";
		sql += createSql(sqlQuarterFormat);
		sql += ")";

		// System.out.println("sql " + sql);

		List<FormatDataDto> regionalManagersList = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("regional_manager"));
			}

		});

		responseJson.setFormatDataDtos(regionalManagersList);

		// =================================================================================
		// preparing query for Region wise Data

		String sqlInternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in(";

		sqlInternalToBeBilled += createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in(";
		sqlInternalToBeBilled += createSql(getFormatForSql(regionFilters)) + ") group by region,regional_manager";

		String sqlInternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") group by region,regional_manager";

		String sqlExternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") group by region,regional_manager";

		String sqlExternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") group by region,regional_manager";

		// ===

		List<PowerCBSRegionWiseDataDto> regionwiseBillingDataList = getRegionWiseData(sqlInternalToBeBilled,
				sqlInternalBilled, sqlExternalToBeBilled, sqlExternalBilled);
		responseJson.setBillingByRegion(regionwiseBillingDataList);

		// =====================================================

		// preparing query for project manager

		String sqlInternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ")  group by region,regional_manager,project_manager";

		String sqlInternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ")   group by region,regional_manager,project_manager";

		String sqlExternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ")   group by region,regional_manager,project_manager";

		String sqlExternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ")   group by region,regional_manager,project_manager";

		List<PowerCBSRegionWiseDataDto> projectManagerWise = getProjectManagerWiseDataList(sqlInternalToBeBilled2,
				sqlInternalBilled2, sqlExternalToBeBilled2, sqlExternalBilled2);

		responseJson.setCbsProjectManagerSummaryDataDtos(projectManagerWise);
		// =========================================
		// preparing query for project id

		String sqlInternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters))
				+ ")   group by region,regional_manager,project_manager,project_number";

		String sqlInternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters))
				+ ")   group by region,regional_manager,project_manager,project_number";

		String sqlExternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters))
				+ ")   group by region,regional_manager,project_manager,project_number";

		String sqlExternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters))
				+ ")   group by region,regional_manager,project_manager,project_number";

		List<PowerCBSRegionWiseDataDto> projectIdDataList = getProjectIdDataList(sqlInternalToBeBilled3,
				sqlInternalBilled3, sqlExternalToBeBilled3, sqlExternalBilled3);

		responseJson.setCbsProjectDataDtos(projectIdDataList);

		return responseJson;

	}

	public PowerConversionBillingSummaryResponseJSONDataDto getProjectManager(
			PowerConversionBillingSummaryRequestJSONDataDto requestJSONDataDto) {

		PowerConversionBillingSummaryResponseJSONDataDto responseJson = new PowerConversionBillingSummaryResponseJSONDataDto();

		List<FormatDataDto> regionFilters = requestJSONDataDto.getRegionFilters();
		List<FormatDataDto> regionalManagerFilters = requestJSONDataDto.getRegionalManagerFilter();
		List<FormatDataDto> billingQuarterList = requestJSONDataDto.getBillingQuarterFilters();

		String sqlRegionFormat = getFormatForSql(regionFilters);
		String sqlQuarterFormat = getFormatForSql(billingQuarterList);
		String sqlRegionalManagerFormat = getFormatForSql(regionalManagerFilters);

		// System.out.println("sqlRegionalManagerFormat " +
		// sqlRegionalManagerFormat);
		String sql = "select distinct(project_manager) from billingsummary where region in(";

		sql += createSql(sqlRegionFormat);
		sql += ") and regional_manager in(";
		sql += createSql(sqlRegionalManagerFormat);
		sql += ") and billing_quarter in(";
		sql += createSql(sqlQuarterFormat);
		sql += ")";
		System.out.println("Sql   " + sql);
		// select distinct(project_manager) from billingsummary where
		// regional_manager in('ANDY COOPER','HUMBERTO ESOUZA') and region
		// in('Belo','Vilebon');

		List<FormatDataDto> projectManagerList = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("project_manager"));
			}

		});

		responseJson.setFormatDataDtos(projectManagerList);
		// ==========================
		// preparing query for region wise Data
		String sqlInternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in(";

		sqlInternalToBeBilled += createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in(";
		sqlInternalToBeBilled += createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ") group by region,regional_manager";

		String sqlInternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")  group by region,regional_manager";

		String sqlExternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")  group by region,regional_manager";

		String sqlExternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")  group by region,regional_manager";

		List<PowerCBSRegionWiseDataDto> regionwiseBillingDataList = getRegionWiseData(sqlInternalToBeBilled,
				sqlInternalBilled, sqlExternalToBeBilled, sqlExternalBilled);

		responseJson.setBillingByRegion(regionwiseBillingDataList);

		// ==========================================================

		// preparing query for project manager

		String sqlInternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")  group by region,regional_manager,project_manager";

		String sqlInternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")    group by region,regional_manager,project_manager";

		String sqlExternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")    group by region,regional_manager,project_manager";

		String sqlExternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")    group by region,regional_manager,project_manager";

		List<PowerCBSRegionWiseDataDto> projectManagerWise = getProjectManagerWiseDataList(sqlInternalToBeBilled2,
				sqlInternalBilled2, sqlExternalToBeBilled2, sqlExternalBilled2);

		responseJson.setCbsProjectManagerSummaryDataDtos(projectManagerWise);
		// =========================================
		// preparing query for project id

		String sqlInternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")    group by region,regional_manager,project_manager,project_number";

		String sqlInternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")   group by region,regional_manager,project_manager,project_number";

		String sqlExternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")    group by region,regional_manager,project_manager,project_number";

		String sqlExternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")    group by region,regional_manager,project_manager,project_number";

		List<PowerCBSRegionWiseDataDto> projectIdDataList = getProjectIdDataList(sqlInternalToBeBilled3,
				sqlInternalBilled3, sqlExternalToBeBilled3, sqlExternalBilled3);

		responseJson.setCbsProjectDataDtos(projectIdDataList);

		return responseJson;

	}

	public PowerConversionBillingSummaryResponseJSONDataDto getTableDataByAllFilter(
			PowerConversionBillingSummaryRequestJSONDataDto requestJSONDataDto) {

		PowerConversionBillingSummaryResponseJSONDataDto responseJSON = new PowerConversionBillingSummaryResponseJSONDataDto();

		List<FormatDataDto> regionFilters = requestJSONDataDto.getRegionFilters();
		List<FormatDataDto> regionalManagerFilters = requestJSONDataDto.getRegionalManagerFilter();
		List<FormatDataDto> billingQuarterList = requestJSONDataDto.getBillingQuarterFilters();
		List<FormatDataDto> projectManagerFilters = requestJSONDataDto.getProjectManagerFilters();

		String sql = "select distinct(project_number) from billingsummary where region in(";

		sql += createSql(getFormatForSql(regionFilters));
		sql += ") and regional_manager in(";
		sql += createSql(getFormatForSql(regionalManagerFilters));
		sql += ") and billing_quarter in(";
		sql += createSql(getFormatForSql(billingQuarterList));
		sql += ") and project_manager in(";
		sql += createSql(getFormatForSql(projectManagerFilters));
		sql += ")";

		// System.out.println("Sql 22222222 : " + sql);
		// select distinct(project_manager) from billingsummary where
		// regional_manager in('ANDY COOPER','HUMBERTO ESOUZA') and region
		// in('Belo','Vilebon');

		List<FormatDataDto> projectNumberList = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("project_number"));
			}

		});

		responseJSON.setFormatDataDtos(projectNumberList);

		// ==================
		// preparing query for region wise Data

		String sqlInternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in(";

		sqlInternalToBeBilled += createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in(";
		sqlInternalToBeBilled += createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ") and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters)) + ") group by region,regional_manager";

		String sqlInternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")  and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters)) + ")  group by region,regional_manager";

		String sqlExternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")  and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters)) + ") group by region,regional_manager";

		String sqlExternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")  and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters)) + ") group by region,regional_manager";

		List<PowerCBSRegionWiseDataDto> regionwiseBillingDataList = getRegionWiseData(sqlInternalToBeBilled,
				sqlInternalBilled, sqlExternalToBeBilled, sqlExternalBilled);
		responseJSON.setBillingByRegion(regionwiseBillingDataList);

		// ===============================================================================

		// preparing query for project manager

		String sqlInternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")   and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters))
				+ ")  group by region,regional_manager,project_manager";

		String sqlInternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")    and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters))
				+ ")   group by region,regional_manager,project_manager";

		String sqlExternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")    and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters))
				+ ")   group by region,regional_manager,project_manager";

		String sqlExternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters)) + ")    and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters))
				+ ")   group by region,regional_manager,project_manager";

		List<PowerCBSRegionWiseDataDto> projectManagerWise = getProjectManagerWiseDataList(sqlInternalToBeBilled2,
				sqlInternalBilled2, sqlExternalToBeBilled2, sqlExternalBilled2);

		responseJSON.setCbsProjectManagerSummaryDataDtos(projectManagerWise);
		// =========================================
		// preparing query for project id
		String sqlInternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")   and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters)) + ")    group by region,regional_manager,project_manager,project_number";

		String sqlInternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ")  and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")   and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters)) + ")   group by region,regional_manager,project_manager,project_number";

		String sqlExternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")    and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters)) + ")   group by region,regional_manager,project_manager,project_number";

		String sqlExternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B') and region in("
				+ createSql(getFormatForSql(regionFilters)) + ") and regional_manager in("
				+ createSql(getFormatForSql(regionalManagerFilters))
				+ ")    and project_manager in("
				+ createSql(getFormatForSql(projectManagerFilters)) + ")   group by region,regional_manager,project_manager,project_number";

		List<PowerCBSRegionWiseDataDto> projectIdDataList = getProjectIdDataList(sqlInternalToBeBilled3,
				sqlInternalBilled3, sqlExternalToBeBilled3, sqlExternalBilled3);

		responseJSON.setCbsProjectDataDtos(projectIdDataList);

		return responseJSON;
	}


	public PowerConversionBillingSummaryResponseJSONDataDto getTableDataByBillingQuarterFilter(PowerConversionBillingSummaryRequestJSONDataDto requestJSON) {

		PowerConversionBillingSummaryResponseJSONDataDto responseJSON = new PowerConversionBillingSummaryResponseJSONDataDto();

		List<FormatDataDto> billingQuarterList = requestJSON.getBillingQuarterFilters();
		String sqlRegion = "select distinct(region) from billingsummary where billing_quarter in("+createSql(getFormatForSql(billingQuarterList)) +")";

		List<FormatDataDto> regionList = null;
		regionList = jdbcTemplate.query(sqlRegion, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("region"));
			}

		});

		responseJSON.setFormatDataDtos(regionList);
		// =================================================================================

		// ========preparing query for Region wise Data


		//

		String sqlInternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in(";

		sqlInternalToBeBilled += createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A')  group by region,regional_manager";

		String sqlInternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B')  group by region,regional_manager";

		String sqlExternalToBeBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A')  group by region,regional_manager";

		String sqlExternalBilled = "select sum(net_billing_value) as sum,region,regional_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B')  group by region,regional_manager";

		// ===

		List<PowerCBSRegionWiseDataDto> regionwiseBillingDataList = getRegionWiseData(sqlInternalToBeBilled,
				sqlInternalBilled, sqlExternalToBeBilled, sqlExternalBilled);
		responseJSON.setBillingByRegion(regionwiseBillingDataList);// ====

		// ========================================================

		// ===========================================================================================

		// preparing query for project manager

		String sqlInternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A')  group by region,regional_manager,project_manager";

		String sqlInternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B')  group by region,regional_manager,project_manager";

		String sqlExternalToBeBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A')  group by region,regional_manager,project_manager";

		String sqlExternalBilled2 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B')  group by region,regional_manager,project_manager";

		List<PowerCBSRegionWiseDataDto> projectManagerWise = getProjectManagerWiseDataList(sqlInternalToBeBilled2,
				sqlInternalBilled2, sqlExternalToBeBilled2, sqlExternalBilled2);

		responseJSON.setCbsProjectManagerSummaryDataDtos(projectManagerWise);
		// =========================================
		// preparing query for project id

		String sqlInternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('A')  group by region,regional_manager,project_manager,project_number";

		String sqlInternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'Internal' and billing_status in('C','B')  group by region,regional_manager,project_manager,project_number";

		String sqlExternalToBeBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('A')  group by region,regional_manager,project_manager,project_number";

		String sqlExternalBilled3 = "select sum(net_billing_value) as sum,region,regional_manager,project_manager,project_number from billingsummary where billing_quarter in("
				+ createSql(getFormatForSql(billingQuarterList))
				+ ") and internalnexternal like 'External' and billing_status in('C','B')  group by region,regional_manager,project_manager,project_number";

		List<PowerCBSRegionWiseDataDto> projectIdDataList = getProjectIdDataList(sqlInternalToBeBilled3,
				sqlInternalBilled3, sqlExternalToBeBilled3, sqlExternalBilled3);

		responseJSON.setCbsProjectDataDtos(projectIdDataList);
		
		return responseJSON;
	}
	private String getFormatForSql(List<FormatDataDto> regionFilters) {

		String regions = "";

		int i = 0;
		for (FormatDataDto regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				regions += regionFilter.getLabel() + ",";

				break;
			} else if (i < regionFilters.size()) {
				regions += regionFilter.getLabel() + ",";

			}
			i++;
		}
		return regions;
	}

	private String createSql(String str) {
		String[] strArray = str.split(",");

		String seg = "";

		for (int i = 0; i <= strArray.length; i++) {

			seg += "'" + strArray[i] + "'";

			if ((i + 1) == strArray.length) {
				break;
			} else if (i < strArray.length) {
				seg += ",";
			}
		}

		System.out.println(seg);
		return seg;
	}

}
