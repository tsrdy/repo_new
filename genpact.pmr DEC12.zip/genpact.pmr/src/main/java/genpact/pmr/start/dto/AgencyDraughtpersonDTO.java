package genpact.pmr.start.dto;

public class AgencyDraughtpersonDTO {
	
	  private String name ; 
	  private long agndraTotalCbl;
	  private long agndraTotalPreviousEac;
	  private long agndraTotalEac;
	  
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAgndraTotalCbl() {
		return agndraTotalCbl;
	}
	public void setAgndraTotalCbl(long agndraTotalCbl) {
		this.agndraTotalCbl = agndraTotalCbl;
	}
	public long getAgndraTotalPreviousEac() {
		return agndraTotalPreviousEac;
	}
	public void setAgndraTotalPreviousEac(long agndraTotalPreviousEac) {
		this.agndraTotalPreviousEac = agndraTotalPreviousEac;
	}
	public long getAgndraTotalEac() {
		return agndraTotalEac;
	}
	public void setAgndraTotalEac(long agndraTotalEac) {
		this.agndraTotalEac = agndraTotalEac;
	}
	  
	  

}
