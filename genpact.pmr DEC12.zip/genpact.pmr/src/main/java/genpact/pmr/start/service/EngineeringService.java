package genpact.pmr.start.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.EngineeringDAO;
import genpact.pmr.start.dto.EngineeringDTO;
import genpact.pmr.start.dto.EngineeringGeneral1DTO;
import genpact.pmr.start.dto.EngineeringGeneralDTO;
import genpact.pmr.start.dto.EngineeringTableDTO;
import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.ManufacturingGeneralDTO;
import genpact.pmr.start.dto.MaufacturingGeneral1DTO;
import genpact.pmr.start.dto.ProjectIdFilter;

@RestController
public class EngineeringService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	EngineeringDAO engineeringDAO;

	@RequestMapping(value = "/getengineeringmanagers", method = RequestMethod.GET)
	public EngineeringTableDTO getEngineeringProjectManagers() {
		
		EngineeringTableDTO engineeringDTO = new EngineeringTableDTO();
		List<FormatDataDto> formatDataDto = new ArrayList<FormatDataDto>();
		String sql = "select distinct(project_manager) from engineeringscorecard";
		formatDataDto = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter = 0;

			@Override
			public FormatDataDto mapRow(ResultSet rs, int arg1) throws SQLException {
				return new FormatDataDto(++counter, rs.getString("project_manager"));
			}
		});
		String str = "";
		/*
		 * manufacturingDTO.setManufacturingTableDTOs(manufacturingDAO.
		 * getManufacturing(str));
		 */
		engineeringDTO.setFormatDataDto(formatDataDto);
		return engineeringDTO;
	}

	@RequestMapping(value = "/getengineeringprojecid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public EngineeringTableDTO getEngineeringProjecid(@RequestBody ProjectIdFilter projectIdFilter) {
		EngineeringTableDTO engineeringDTO = new EngineeringTableDTO();
		List<FormatDataDto> formatDataDto = new ArrayList<FormatDataDto>();
		String projectManager = projectIdFilter.getLabel();
		String sql = "select distinct(project) from engineeringscorecard where project_manager= " + "'" + projectManager
				+ "'";
		System.out.println(sql);
		formatDataDto = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter = 0;

			@Override
			public FormatDataDto mapRow(ResultSet rs, int arg1) throws SQLException {
				return new FormatDataDto(++counter, rs.getString("project"));
			}
		});
		engineeringDTO.setFormatDataDto(formatDataDto);
		return engineeringDTO;
	}

	@RequestMapping(value = "/getengineeringtabledataonprojectid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public EngineeringDTO getEngineeringOnProject(@RequestBody ProjectIdFilter projectIdFilter) {
		String project = projectIdFilter.getLabel();

		return engineeringDAO.getEngineering(project);
	}
	
	@RequestMapping(value = "/gettabledataonprojectallengineeringid", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public EngineeringGeneral1DTO getEngineeringOnProjectIds(
			@RequestBody EngineeringGeneralDTO EngineeringGeneralDTO) {

		return engineeringDAO.getEngineeringAll(EngineeringGeneralDTO);
	}

}
