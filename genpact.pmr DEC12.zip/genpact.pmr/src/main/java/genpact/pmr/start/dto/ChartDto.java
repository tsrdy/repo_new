package genpact.pmr.start.dto;

public class ChartDto {
	

	private String name;
	private double cost;     //EAC
	private double cbl;
	private double previous_eac;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public double getCbl() {
		return cbl;
	}
	public void setCbl(double cbl) {
		this.cbl = cbl;
	}
	public double getPrevious_eac() {
		return previous_eac;
	}
	public void setPrevious_eac(double previous_eac) {
		this.previous_eac = previous_eac;
	}
	public ChartDto(String name, double cost, double cbl, double previous_eac) {
		super();
		this.name = name;
		this.cost = cost;
		this.cbl = cbl;
		this.previous_eac = previous_eac;
	}
	public ChartDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	


	

}
