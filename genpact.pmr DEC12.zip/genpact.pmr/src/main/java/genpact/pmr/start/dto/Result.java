package genpact.pmr.start.dto;

import java.util.List;

public class Result {
	
	private List<String> allVerticals;
	private double totalCBL;
	private double cost;
	private double margin;
	
	

}
