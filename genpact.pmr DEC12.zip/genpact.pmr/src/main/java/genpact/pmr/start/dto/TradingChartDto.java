package genpact.pmr.start.dto;

import java.util.Date;

public class TradingChartDto {

	private String milestone_description;
	private double trading_value;
//	private double cummulative_trading_value;
	private String today_date;
	private Date actual_plan_date;
	
	

	public TradingChartDto(String milestone_description, double trading_value, Date actual_plan_date) {
		super();
		this.milestone_description = milestone_description;
		this.trading_value = trading_value;
		this.actual_plan_date = actual_plan_date;
	}



	public TradingChartDto(String milestone_description, double trading_value, String today_date,
			Date actual_plan_date) {
		super();
		this.milestone_description = milestone_description;
		this.trading_value = trading_value;
		this.today_date = today_date;
		this.actual_plan_date = actual_plan_date;
	}



	public TradingChartDto() {
		super();
		// TODO Auto-generated constructor stub
	}



	public String getMilestone_description() {
		return milestone_description;
	}



	public void setMilestone_description(String milestone_description) {
		this.milestone_description = milestone_description;
	}



	public double getTrading_value() {
		return trading_value;
	}



	public void setTrading_value(double trading_value) {
		this.trading_value = trading_value;
	}



	public String getToday_date() {
		return today_date;
	}



	public void setToday_date(String today_date) {
		this.today_date = today_date;
	}



	public Date getActual_plan_date() {
		return actual_plan_date;
	}



	public void setActual_plan_date(Date actual_plan_date) {
		this.actual_plan_date = actual_plan_date;
	}



	@Override
	public String toString() {
		return "TradingChartDto [actual_plan_date=" + actual_plan_date + "]";
	}
	
	
	
	
	

	
}
