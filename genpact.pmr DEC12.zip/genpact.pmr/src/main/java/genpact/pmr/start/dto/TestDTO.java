package genpact.pmr.start.dto;

public class TestDTO {
	private String name ;
	 private long Cbl ;
	  private long previousEac ;
	  private long Eac ;
	public TestDTO(String name, long cbl, long previouEac, long eac) {
		super();
		this.name = name;
		Cbl = cbl;
		this.previousEac = previouEac;
		Eac = eac;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getCbl() {
		return Cbl;
	}
	public void setCbl(long cbl) {
		Cbl = cbl;
	}
	public long getPreviousEac() {
		return previousEac;
	}
	public void setPreviousEac(long previouEac) {
		this.previousEac = previouEac;
	}
	public long getEac() {
		return Eac;
	}
	public void setEac(long eac) {
		Eac = eac;
	}
	public TestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	  
	
	  
}
