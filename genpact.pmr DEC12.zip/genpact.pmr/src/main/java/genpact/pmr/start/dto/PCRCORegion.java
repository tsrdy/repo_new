package genpact.pmr.start.dto;

public class PCRCORegion {

	private String region;
	private String regional_manager;
	private String externalninternal;
	private String project_id;
	private String project_manager;
	private double quarter;
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegional_manager() {
		return regional_manager;
	}
	public void setRegional_manager(String regional_manager) {
		this.regional_manager = regional_manager;
	}
	public String getExternalninternal() {
		return externalninternal;
	}
	public void setExternalninternal(String externalninternal) {
		this.externalninternal = externalninternal;
	}
	public String getProject_id() {
		return project_id;
	}
	public void setProject_id(String project_id) {
		this.project_id = project_id;
	}
	public String getProject_manager() {
		return project_manager;
	}
	public void setProject_manager(String project_manager) {
		this.project_manager = project_manager;
	}
	public double getQuarter() {
		return quarter;
	}
	public void setQuarter(double quarter) {
		this.quarter = quarter;
	}
	public PCRCORegion() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PCRCORegion(String region, String regional_manager, String externalninternal, String project_id,
			String project_manager, double quarter) {
		super();
		this.region = region;
		this.regional_manager = regional_manager;
		this.externalninternal = externalninternal;
		this.project_id = project_id;
		this.project_manager = project_manager;
		this.quarter = quarter;
	}
	
	
	
}
