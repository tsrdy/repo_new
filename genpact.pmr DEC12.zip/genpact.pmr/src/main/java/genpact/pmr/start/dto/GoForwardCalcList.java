package genpact.pmr.start.dto;

import java.util.List;

public class GoForwardCalcList {

	
	private Double average;
	private Integer timepercent;
	private Double actualHours;
	public Double getAverage() {
		return average;
	}
	public void setAverage(Double average) {
		this.average = average;
	}
	public Integer getTimepercent() {
		return timepercent;
	}
	public void setTimepercent(Integer timepercent) {
		this.timepercent = timepercent;
	}
	public Double getActualHours() {
		return actualHours;
	}
	public void setActualHours(Double actualHours) {
		this.actualHours = actualHours;
	}
	public GoForwardCalcList() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GoForwardCalcList(Double average, Integer timepercent, Double actualHours) {
		super();
		this.average = average;
		this.timepercent = timepercent;
		this.actualHours = actualHours;
	}
	public GoForwardCalcList(Double average, Integer timepercent) {
		super();
		this.average = average;
		this.timepercent = timepercent;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((actualHours == null) ? 0 : actualHours.hashCode());
		result = prime * result + ((average == null) ? 0 : average.hashCode());
		result = prime * result + ((timepercent == null) ? 0 : timepercent.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GoForwardCalcList other = (GoForwardCalcList) obj;
		if (actualHours == null) {
			if (other.actualHours != null)
				return false;
		} else if (!actualHours.equals(other.actualHours))
			return false;
		if (average == null) {
			if (other.average != null)
				return false;
		} else if (!average.equals(other.average))
			return false;
		if (timepercent == null) {
			if (other.timepercent != null)
				return false;
		} else if (!timepercent.equals(other.timepercent))
			return false;
		return true;
	}
	
	

}
