package genpact.pmr.start.dto;

public class ColourIndex {

	private int count;

	public ColourIndex(int count) {
		super();
		this.count = count;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public ColourIndex() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ColourIndex [count=" + count + "]";
	}
	
	
}
