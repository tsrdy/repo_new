package genpact.pmr.start.dto;

public class ActivityStatusDto {
	
	private String activity_name;
	private String variation;
	
	public String getActivity_name() {
		return activity_name;
	}
	public void setActivity_name(String activity_name) {
		this.activity_name = activity_name;
	}
	public String getVariation() {
		return variation;
	}
	public void setVariation(String variation) {
		this.variation = variation;
	}
	
	public ActivityStatusDto(String activity_name, String variation) {
		super();
		this.activity_name = activity_name;
		this.variation = variation;
	}
	public ActivityStatusDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "ActivityStatusDto [activity_name=" + activity_name + ", variation=" + variation + "]";
	}
	

}
