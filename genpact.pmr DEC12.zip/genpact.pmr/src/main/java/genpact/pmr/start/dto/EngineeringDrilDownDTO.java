package genpact.pmr.start.dto;

public class EngineeringDrilDownDTO {
	
	  private String machine;
	  private long totalCbl ;
	  private long totalPreviousEac ;
	  private long totalEac ;
	  
	public String getMachine() {
		return machine;
	}
	public void setMachine(String machine) {
		this.machine = machine;
	}
	public long getTotalCbl() {
		return totalCbl;
	}
	public void setTotalCbl(long totalCbl) {
		this.totalCbl = totalCbl;
	}
	public long getTotalPreviousEac() {
		return totalPreviousEac;
	}
	public void setTotalPreviousEac(long totalPreviousEac) {
		this.totalPreviousEac = totalPreviousEac;
	}
	public long getTotalEac() {
		return totalEac;
	}
	public void setTotalEac(long totalEac) {
		this.totalEac = totalEac;
	}
	public EngineeringDrilDownDTO(String machine, long totalCbl, long totalPreviousEac, long totalEac) {
		super();
		this.machine = machine;
		this.totalCbl = totalCbl;
		this.totalPreviousEac = totalPreviousEac;
		this.totalEac = totalEac;
	}
	public EngineeringDrilDownDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
}
