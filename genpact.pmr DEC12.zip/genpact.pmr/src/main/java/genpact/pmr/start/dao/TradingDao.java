package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.TradingChartDto;
import genpact.pmr.start.dto.TradingTableDataDto;

@Repository
public class TradingDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<TradingTableDataDto> getTotalTradingTableData(String str) {
		String sql = "select project_id,milestone_description,milestone_ownership,milestone_product,milestone_type,original_plan_date,to_date(actual_plan,'DD-Mon-YY') actual_plan,actual_date,trading_value from trading "+ str+" order by actual_plan";
		List<TradingTableDataDto> tradingTableDataDto = jdbcTemplate.query(sql, new TradingTableRowMapper());
		return tradingTableDataDto;
	}

	public List<TradingChartDto> getMilestoneChart(String str) {
		String sql ="select milestone_description,trading_value,to_date(actual_plan,'DD-Mon-YY') actual_plan from trading "+ str+ "order by actual_plan"; 
		List<TradingChartDto> tradingChartDtos = jdbcTemplate.query(sql, new MilestoneChartRowMapper());

		return tradingChartDtos;

	}

	private static class TradingTableRowMapper implements RowMapper<TradingTableDataDto> {
		int count = 10000;

		public TradingTableDataDto mapRow(ResultSet resultSet, int rowCount) throws SQLException {

			return new TradingTableDataDto(count++, resultSet.getString("project_id"),
					resultSet.getString("milestone_description"), resultSet.getString("milestone_ownership"),
					resultSet.getString("milestone_product"), resultSet.getString("milestone_type"),
					resultSet.getString("original_plan_date"), resultSet.getString("actual_plan"),
					resultSet.getString("actual_date"), resultSet.getString("trading_value"));
		}

	}

	private static class MilestoneChartRowMapper implements RowMapper<TradingChartDto> {

		public TradingChartDto mapRow(ResultSet resultSet, int rowCount) throws SQLException {

			return new TradingChartDto(resultSet.getString("milestone_description"),
					Double.parseDouble(resultSet.getString("trading_value")),resultSet.getDate("actual_plan"));
		}
	}

}