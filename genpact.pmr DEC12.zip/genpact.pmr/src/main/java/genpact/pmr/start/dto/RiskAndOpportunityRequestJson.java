package genpact.pmr.start.dto;

import java.util.List;

public class RiskAndOpportunityRequestJson {

	private List<FormatDataDto> regions;
	private List<FormatDataDto> projectManagers;
	private List<FormatDataDto> markets;
	private List<FormatDataDto> jobNumbers;
	private List<FormatDataDto> jobNames;
	public List<FormatDataDto> getRegions() {
		return regions;
	}
	public void setRegions(List<FormatDataDto> regions) {
		this.regions = regions;
	}
	public List<FormatDataDto> getProjectManagers() {
		return projectManagers;
	}
	public void setProjectManagers(List<FormatDataDto> projectManagers) {
		this.projectManagers = projectManagers;
	}
	public List<FormatDataDto> getMarkets() {
		return markets;
	}
	public void setMarkets(List<FormatDataDto> markets) {
		this.markets = markets;
	}
	public List<FormatDataDto> getJobNumbers() {
		return jobNumbers;
	}
	public void setJobNumbers(List<FormatDataDto> jobNumbers) {
		this.jobNumbers = jobNumbers;
	}
	public List<FormatDataDto> getJobNames() {
		return jobNames;
	}
	public void setJobNames(List<FormatDataDto> jobNames) {
		this.jobNames = jobNames;
	}
	public RiskAndOpportunityRequestJson() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RiskAndOpportunityRequestJson(List<FormatDataDto> regions, List<FormatDataDto> projectManagers,
			List<FormatDataDto> markets, List<FormatDataDto> jobNumbers, List<FormatDataDto> jobNames) {
		super();
		this.regions = regions;
		this.projectManagers = projectManagers;
		this.markets = markets;
		this.jobNumbers = jobNumbers;
		this.jobNames = jobNames;
	}
	
	
	
}
