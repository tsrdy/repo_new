package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.CirSummaryDataDto;
import genpact.pmr.start.dto.CirTableDataDto;

@Repository
public class CirDashboardDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	public CirSummaryDataDto getCirSummary(String str) {

		long totalCase = 0l;
		long totalAge = 0l;
		double averageAge = 0d;
		long oldestAge =0l;
		CirSummaryDataDto cirSummaryDataDto =new CirSummaryDataDto();
		String sql = "select count(cir_case_id ) from cirdashboard " + str ;
		
		System.out.println(sql);
		totalCase = jdbcTemplate.queryForInt(sql);

		String sql2 = "select sum(CAST(age AS INT)) from cirdashboard " + str ;
		System.out.println(sql2);
		totalAge = jdbcTemplate.queryForInt(sql2);

		String sql3 = "select MAX(CAST(age AS INT)) from cirdashboard " + str ;
		System.out.println(sql3);
		oldestAge = jdbcTemplate.queryForInt(sql3);

		averageAge = (totalAge/totalCase);

		cirSummaryDataDto.setTotalCase(totalCase);
		cirSummaryDataDto.setTotalAge(totalAge);
		cirSummaryDataDto.setAverageAge(averageAge);
		cirSummaryDataDto.setOldestCase(oldestAge);
		return cirSummaryDataDto;
	}

	public List<CirTableDataDto> getCirTableData(String str) {

		List<CirTableDataDto> cirTableDataDtos = new ArrayList<>();
		String sql = "select customer,project,case_,issue_and_containment,response,commit,forecast,cir_operational_risk,CAST(cir_risk_score AS INT),CAST(age AS INT),CAST(cir_staleness AS INT),CAST(min_cir_openitemssortbyaging AS INT) from cirdashboard " + str ;
		cirTableDataDtos = jdbcTemplate.query(sql, new RowMapper<CirTableDataDto>(){

			@Override
			public CirTableDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return new CirTableDataDto(rs.getString("customer"), rs.getString("project"),rs.getString("case_"),rs.getString("issue_and_containment"), rs.getString("response"), rs.getString("commit"), rs.getString("forecast"), rs.getString("cir_operational_risk"), rs.getInt("cir_risk_score"), rs.getInt("age"), rs.getInt("cir_staleness"), rs.getInt("min_cir_openitemssortbyaging"));
			}
			
		});


		
		
		return cirTableDataDtos;
	}


}




