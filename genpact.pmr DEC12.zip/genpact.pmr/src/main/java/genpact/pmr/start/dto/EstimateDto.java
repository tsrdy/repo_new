package genpact.pmr.start.dto;

public class EstimateDto {


	private int time_;
	private double uk_c_y_20200_01;
	private double uk_c_y_20223_01;
	private double uk_c_y_20243_01;
	private double uk_c_y_20266_01;
	public int getTime_() {
		return time_;
	}
	public void setTime_(int time_) {
		this.time_ = time_;
	}
	public double getUk_c_y_20200_01() {
		return uk_c_y_20200_01;
	}
	public void setUk_c_y_20200_01(double uk_c_y_20200_01) {
		this.uk_c_y_20200_01 = uk_c_y_20200_01;
	}
	public double getUk_c_y_20223_01() {
		return uk_c_y_20223_01;
	}
	public void setUk_c_y_20223_01(double uk_c_y_20223_01) {
		this.uk_c_y_20223_01 = uk_c_y_20223_01;
	}
	public double getUk_c_y_20243_01() {
		return uk_c_y_20243_01;
	}
	public void setUk_c_y_20243_01(double uk_c_y_20243_01) {
		this.uk_c_y_20243_01 = uk_c_y_20243_01;
	}
	public double getUk_c_y_20266_01() {
		return uk_c_y_20266_01;
	}
	public void setUk_c_y_20266_01(double uk_c_y_20266_01) {
		this.uk_c_y_20266_01 = uk_c_y_20266_01;
	}
	public EstimateDto(int time_, double uk_c_y_20200_01, double uk_c_y_20223_01, double uk_c_y_20243_01,
			double uk_c_y_20266_01) {
		super();
		this.time_ = time_;
		this.uk_c_y_20200_01 = uk_c_y_20200_01;
		this.uk_c_y_20223_01 = uk_c_y_20223_01;
		this.uk_c_y_20243_01 = uk_c_y_20243_01;
		this.uk_c_y_20266_01 = uk_c_y_20266_01;
	}
	public EstimateDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
