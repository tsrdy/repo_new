package genpact.pmr.start.dto;

public class PCRCORegionDataDto {

	private String region;
	private String regionalManager;
	private double internalSales;
	private double externalSales;
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegionalManager() {
		return regionalManager;
	}
	public void setRegionalManager(String regionalManager) {
		this.regionalManager = regionalManager;
	}
	public double getInternalSales() {
		return internalSales;
	}
	public void setInternalSales(double internalSales) {
		this.internalSales = internalSales;
	}
	public double getExternalSales() {
		return externalSales;
	}
	public void setExternalSales(double externalSales) {
		this.externalSales = externalSales;
	}
	public PCRCORegionDataDto(String region, String regionalManager, double internalSales, double externalSales) {
		super();
		this.region = region;
		this.regionalManager = regionalManager;
		this.internalSales = internalSales;
		this.externalSales = externalSales;
	}
	public PCRCORegionDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
