package genpact.pmr.start.dto;

public class PowerCBSRegionWiseDataDto {

	private String region;
	private String projectId;

	private String regionalmanager;
	private String projectManager;
	private double internalBilled;//
	private double internalToBeBilled;//

	private double externalBilled;//
	private double externalToBeBilled;//

	private double totalBilled;//
	private double totalBilling;
	private double totalToBeBilled;//
	private double billedPercent;//

	public PowerCBSRegionWiseDataDto(String region, String projectId, String regionalmanager, String projectManager,
			double internalBilled, double internalToBeBilled, double externalBilled, double externalToBeBilled,
			double totalBilled, double totalBilling, double totalToBeBilled, double billedPercent) {
		super();
		this.region = region;
		this.projectId = projectId;
		this.regionalmanager = regionalmanager;
		this.projectManager = projectManager;
		this.internalBilled = internalBilled;
		this.internalToBeBilled = internalToBeBilled;
		this.externalBilled = externalBilled;
		this.externalToBeBilled = externalToBeBilled;
		this.totalBilled = totalBilled;
		this.totalBilling = totalBilling;
		this.totalToBeBilled = totalToBeBilled;
		this.billedPercent = billedPercent;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public PowerCBSRegionWiseDataDto(String region, String regionalmanager, String projectManager,
			double internalBilled, double internalToBeBilled, double externalBilled, double externalToBeBilled,
			double totalBilled, double totalBilling, double totalToBeBilled, double billedPercent) {
		super();
		this.region = region;
		this.regionalmanager = regionalmanager;
		this.projectManager = projectManager;
		this.internalBilled = internalBilled;
		this.internalToBeBilled = internalToBeBilled;
		this.externalBilled = externalBilled;
		this.externalToBeBilled = externalToBeBilled;
		this.totalBilled = totalBilled;
		this.totalBilling = totalBilling;
		this.totalToBeBilled = totalToBeBilled;
		this.billedPercent = billedPercent;
	}

	public String getProjectManager() {
		return projectManager;
	}

	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getRegionalmanager() {
		return regionalmanager;
	}

	public void setRegionalmanager(String regionalmanager) {
		this.regionalmanager = regionalmanager;
	}

	public double getInternalBilled() {
		return internalBilled;
	}

	public void setInternalBilled(double internalBilled) {
		this.internalBilled = internalBilled;
	}

	public double getInternalToBeBilled() {
		return internalToBeBilled;
	}

	public void setInternalToBeBilled(double internalToBeBilled) {
		this.internalToBeBilled = internalToBeBilled;
	}

	public double getExternalBilled() {
		return externalBilled;
	}

	public void setExternalBilled(double externalBilled) {
		this.externalBilled = externalBilled;
	}

	public double getExternalToBeBilled() {
		return externalToBeBilled;
	}

	public void setExternalToBeBilled(double externalToBeBilled) {
		this.externalToBeBilled = externalToBeBilled;
	}

	public double getTotalBilled() {
		return totalBilled;
	}

	public void setTotalBilled(double totalBilled) {
		this.totalBilled = totalBilled;
	}

	public double getTotalBilling() {
		return totalBilling;
	}

	public void setTotalBilling(double totalBilling) {
		this.totalBilling = totalBilling;
	}

	public double getTotalToBeBilled() {
		return totalToBeBilled;
	}

	public void setTotalToBeBilled(double totalToBeBilled) {
		this.totalToBeBilled = totalToBeBilled;
	}

	public double getBilledPercent() {
		return billedPercent;
	}

	public void setBilledPercent(double billedPercent) {
		this.billedPercent = billedPercent;
	}

	public PowerCBSRegionWiseDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PowerCBSRegionWiseDataDto(String region, String regionalmanager, double internalBilled,
			double internalToBeBilled, double externalBilled, double externalToBeBilled, double totalBilled,
			double totalBilling, double totalToBeBilled, double billedPercent) {
		super();
		this.region = region;
		this.regionalmanager = regionalmanager;
		this.internalBilled = internalBilled;
		this.internalToBeBilled = internalToBeBilled;
		this.externalBilled = externalBilled;
		this.externalToBeBilled = externalToBeBilled;
		this.totalBilled = totalBilled;
		this.totalBilling = totalBilling;
		this.totalToBeBilled = totalToBeBilled;
		this.billedPercent = billedPercent;
	}

	@Override
	public String toString() {
		return "PowerCBSRegionWiseDataDto [region=" + region + ", regionalmanager=" + regionalmanager
				+ ", projectManager=" + projectManager + ", internalBilled=" + internalBilled + ", internalToBeBilled="
				+ internalToBeBilled + ", externalBilled=" + externalBilled + ", externalToBeBilled="
				+ externalToBeBilled + ", totalBilled=" + totalBilled + ", totalBilling=" + totalBilling
				+ ", totalToBeBilled=" + totalToBeBilled + ", billedPercent=" + billedPercent + "]";
	}

	/*
	 * "region": "uk", "regionalmanager": "Andy Copper", "internalbilled": 20,
	 * "internaltobebilled": 30, "internaltotal": 50, "externalbilled": 30,
	 * "externaltobebilled": 20, "externaltotal": 50, "billed": 50,
	 * "tobebilled": 50, "total": 100, "billedpercent": 45, "billedtarget": 75
	 */

}
