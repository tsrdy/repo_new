package genpact.pmr.start.dto;

public class PCPastDueRegion3Q2016Dto {
	private String region;
	private String regionalManager;
	private double sum;
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegionalManager() {
		return regionalManager;
	}
	public void setRegionalManager(String regionalManager) {
		this.regionalManager = regionalManager;
	}
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public PCPastDueRegion3Q2016Dto(String region, String regionalManager, double sum) {
		super();
		this.region = region;
		this.regionalManager = regionalManager;
		this.sum = sum;
	}
	public PCPastDueRegion3Q2016Dto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((region == null) ? 0 : region.hashCode());
		result = prime * result + ((regionalManager == null) ? 0 : regionalManager.hashCode());
		long temp;
		temp = Double.doubleToLongBits(sum);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PCPastDueRegion3Q2016Dto other = (PCPastDueRegion3Q2016Dto) obj;
		if (region == null) {
			if (other.region != null)
				return false;
		} else if (!region.equals(other.region))
			return false;
		if (regionalManager == null) {
			if (other.regionalManager != null)
				return false;
		} else if (!regionalManager.equals(other.regionalManager))
			return false;
		if (Double.doubleToLongBits(sum) != Double.doubleToLongBits(other.sum))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PCPastDueRegion3Q2016Dto [region=" + region + ", regionalManager=" + regionalManager + ", sum=" + sum
				+ "]";
	}
	

}
