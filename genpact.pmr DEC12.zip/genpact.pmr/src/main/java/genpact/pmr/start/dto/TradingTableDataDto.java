package genpact.pmr.start.dto;

public class TradingTableDataDto {

	private int uid;
	private String project_id;
	private String milestone_description;
	private String milestone_ownership;
	private String milestone_product;
	private String milestone_type;
	private String original_plan_date;
	private String actual_plan;
	private String actual_date;
	private String trading_value;


	public TradingTableDataDto(int uid, String project_id, String milestone_description, String milestone_ownership,
			String milestone_product, String milestone_type, String original_plan_date, String actual_plan,
			String actual_date, String trading_value) {
		super();
		this.uid = uid;
		this.project_id = project_id;
		this.milestone_description = milestone_description;
		this.milestone_ownership = milestone_ownership;
		this.milestone_product = milestone_product;
		this.milestone_type = milestone_type;
		this.original_plan_date = original_plan_date;
		this.actual_plan = actual_plan;
		this.actual_date = actual_date;
		this.trading_value = trading_value;
	}
	public TradingTableDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getProject_id() {
		return project_id;
	}
	public void setProject_id(String project_id) {
		this.project_id = project_id;
	}
	public String getMilestone_description() {
		return milestone_description;
	}
	public void setMilestone_description(String milestone_description) {
		this.milestone_description = milestone_description;
	}
	public String getMilestone_ownership() {
		return milestone_ownership;
	}
	public void setMilestone_ownership(String milestone_ownership) {
		this.milestone_ownership = milestone_ownership;
	}
	public String getMilestone_product() {
		return milestone_product;
	}
	public void setMilestone_product(String milestone_product) {
		this.milestone_product = milestone_product;
	}
	public String getMilestone_type() {
		return milestone_type;
	}
	public void setMilestone_type(String milestone_type) {
		this.milestone_type = milestone_type;
	}
	public String getOriginal_plan_date() {
		return original_plan_date;
	}
	public void setOriginal_plan_date(String original_plan_date) {
		this.original_plan_date = original_plan_date;
	}
	public String getActual_plan() {
		return actual_plan;
	}
	public void setActual_plan(String actual_plan) {
		this.actual_plan = actual_plan;
	}
	public String getActual_date() {
		return actual_date;
	}
	public void setActual_date(String actual_date) {
		this.actual_date = actual_date;
	}
	public String getTrading_value() {
		return trading_value;
	}
	public void setTrading_value(String trading_value) {
		this.trading_value = trading_value;
	}
	
}
