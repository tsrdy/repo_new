package genpact.pmr.start.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import genpact.pmr.start.dto.AssemblyDTO;
import genpact.pmr.start.dto.CoilsDTO;
import genpact.pmr.start.dto.CopperDTO;
import genpact.pmr.start.dto.GeneralManufacturingDto;
import genpact.pmr.start.dto.LampressDTO;
import genpact.pmr.start.dto.MCShopDTO;
import genpact.pmr.start.dto.ManufacturingGeneralDTO;
import genpact.pmr.start.dto.ManufacturingGeneralFreeDTO;
import genpact.pmr.start.dto.ManufacturingTableDTO;
import genpact.pmr.start.dto.MaufacturingGeneral1DTO;
import genpact.pmr.start.dto.PinventDTO;
import genpact.pmr.start.dto.RegionFilter;
import genpact.pmr.start.dto.RotorDTO;
import genpact.pmr.start.dto.StatcoreDTO;
import genpact.pmr.start.dto.StatwindDTO;
import genpact.pmr.start.dto.TableManufacturing;
import genpact.pmr.start.dto.TestDTO;
import genpact.pmr.start.dto.TotalDTO;
import genpact.pmr.start.dto.VpiDTO;

@Repository
public class ManufacturingDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	String sql = "";

	public ManufacturingTableDTO getManufacturing(String str) {
		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + " and  group_=('MC Shop') group by machine";

		List<MCShopDTO> mcShopDTOList = jdbcTemplate.query(sql, new RowMapper<MCShopDTO>() {
			public MCShopDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				MCShopDTO mc = new MCShopDTO();
				mc.setName(rs.getString("machine"));
				mc.setCbl(rs.getInt("CBL"));
				mc.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				mc.setEac(rs.getInt("EAC"));
				return mc;
			}
		});
		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + "  and  group_=('LAMPRESS') group by machine";

		List<LampressDTO> lampressDTOList = jdbcTemplate.query(sql, new RowMapper<LampressDTO>() {
			public LampressDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				LampressDTO lp = new LampressDTO();
				lp.setName(rs.getString("machine"));
				lp.setCbl(rs.getInt("CBL"));
				lp.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				lp.setEac(rs.getInt("EAC"));

				return lp;
			}
		});
		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project = "
				+ "'" + str + "'" + " and  group_=('PINVENT') group by machine";

		List<PinventDTO> pinvenDTOList = jdbcTemplate.query(sql, new RowMapper<PinventDTO>() {
			public PinventDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				PinventDTO pin = new PinventDTO();
				pin.setName(rs.getString("machine"));
				pin.setCbl(rs.getInt("CBL"));
				pin.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				pin.setCbl(rs.getInt("EAC"));
				return pin;
			}
		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + "  and  group_=('ROTOR') group by machine";
		List<RotorDTO> rotorDTOList = jdbcTemplate.query(sql, new RowMapper<RotorDTO>() {
			public RotorDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				RotorDTO rot = new RotorDTO();
				rot.setName(rs.getString("machine"));
				rot.setEac(rs.getInt("CBL"));
				rot.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				rot.setEac(rs.getInt("EAC"));

				return rot;
			}

		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + "  and  group_=('STATCORE') group by machine";
		List<StatcoreDTO> statcoreDTOList = jdbcTemplate.query(sql, new RowMapper<StatcoreDTO>() {
			public StatcoreDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				StatcoreDTO sat = new StatcoreDTO();
				sat.setName(rs.getString("machine"));
				sat.setCbl(rs.getInt("CBL"));
				sat.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				sat.setEac(rs.getInt("EAC"));

				return sat;

			}

		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + "  and  group_=('Coils') group by machine";

		List<CoilsDTO> coilsDTOList = jdbcTemplate.query(sql, new RowMapper<CoilsDTO>() {
			public CoilsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				CoilsDTO coi = new CoilsDTO();
				coi.setName(rs.getString("machine"));
				coi.setCbl(rs.getInt("CBL"));
				coi.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				coi.setEac(rs.getInt("EAC"));

				return coi;

			}

		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + "  and  group_=('COPPER') group by machine";

		List<CopperDTO> copperDTOList = jdbcTemplate.query(sql, new RowMapper<CopperDTO>() {
			public CopperDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				CopperDTO cop = new CopperDTO();
				cop.setName(rs.getString("machine"));
				cop.setCbl(rs.getInt("CBL"));
				cop.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				cop.setEac(rs.getInt("EAC"));

				return cop;

			}

		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + "  and  group_=('STATWIND') group by machine";

		List<StatwindDTO> statwindDTOList = jdbcTemplate.query(sql, new RowMapper<StatwindDTO>() {
			public StatwindDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				StatwindDTO stat = new StatwindDTO();
				stat.setName(rs.getString("machine"));
				stat.setCbl(rs.getInt("CBL"));
				stat.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				stat.setEac(rs.getInt("EAC"));

				return stat;

			}
		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + "  and  group_=('VPI') group by machine";

		List<VpiDTO> vpiDTOList = jdbcTemplate.query(sql, new RowMapper<VpiDTO>() {
			public VpiDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				VpiDTO vpi = new VpiDTO();
				vpi.setName(rs.getString("machine"));
				vpi.setCbl(rs.getInt("CBL"));
				vpi.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				vpi.setEac(rs.getInt("EAC"));

				return vpi;

			}
		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + "  and  group_=('ASSEMBLY') group by machine";

		List<AssemblyDTO> assemblyDTOList = jdbcTemplate.query(sql, new RowMapper<AssemblyDTO>() {
			public AssemblyDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				AssemblyDTO ass = new AssemblyDTO();
				ass.setName(rs.getString("machine"));
				ass.setCbl(rs.getInt("CBL"));
				ass.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				ass.setEac(rs.getInt("EAC"));

				return ass;

			}

		});

		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + " and  group_=('Test') group by machine";

		List<TestDTO> testDTODTOList = jdbcTemplate.query(sql, new RowMapper<TestDTO>() {
			public TestDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				TestDTO test = new TestDTO();
				test.setName(rs.getString("machine"));
				test.setCbl(rs.getInt("CBL"));
				test.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				test.setEac(rs.getInt("EAC"));

				return test;

			}
		});
		sql = "select distinct(machine),sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac)as EAC from manufacturing where project ="
				+ "'" + str + "'" + " and  group_=('TOTAL') group by machine";

		List<TotalDTO> totalDTOList = jdbcTemplate.query(sql, new RowMapper<TotalDTO>() {
			public TotalDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				TotalDTO total = new TotalDTO ();
				total.setName(rs.getString("machine"));
				total.setCbl(rs.getInt("CBL"));
				total.setPreviousEac(rs.getInt("PREVIOUS_EAC"));
				total.setEac(rs.getInt("EAC"));

				return total;

			}
		});

		return new ManufacturingTableDTO(
				new TableManufacturing(mcShopDTOList, lampressDTOList, pinvenDTOList, rotorDTOList, statcoreDTOList,
						coilsDTOList, copperDTOList, statwindDTOList, vpiDTOList, assemblyDTOList, testDTODTOList, totalDTOList));

	}
	
	private String createSql(String str) {
		String[] strArray = str.split(",");
		String seg = "";
		for (int i = 0; i <= strArray.length; i++) {
			seg += "'" + strArray[i] + "'";
			if ((i + 1) == strArray.length) {
				break;
			} else if (i < strArray.length) {
				seg += ",";
			}
		}
		return seg;
	}

	public MaufacturingGeneral1DTO getManufacturingAll(ManufacturingGeneralDTO str) {

		String projectid = str.getProjectID();
		String projectmanager = str.getProjectManager();
		String[] machine = str.getCostType();
		List<String> regionFilters = Arrays.asList(machine);

		String region = "";

		int i = 0;
		for (String regionFilter : regionFilters) {

			region += regionFilter + ",";
		}

		String sql1 = createSql(region);

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='MC Shop'";

		ManufacturingGeneralFreeDTO mcShopDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						// TODO Auto-generated method stub
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='LAMPRESS'";

		ManufacturingGeneralFreeDTO lampressDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});
		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='PINVENT'";

		ManufacturingGeneralFreeDTO pinvenDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='ROTOR'";
		ManufacturingGeneralFreeDTO rotorDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});
		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ")and  group_='STATCORE'";
		;

		ManufacturingGeneralFreeDTO statcoreDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});
		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='Coils'";

		ManufacturingGeneralFreeDTO CoilsDTO = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='COPPER'";

		ManufacturingGeneralFreeDTO copperDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ")and  group_='STATWIND'";

		ManufacturingGeneralFreeDTO statwindDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='VPI'";

		ManufacturingGeneralFreeDTO vpiDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='ASSEMBLY'";

		ManufacturingGeneralFreeDTO assemblyDTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});

		sql = "select sum(cbl) as CBL,sum(previous_eac) as PREVIOUS_EAC,sum(eac) as EAC from manufacturing where project_manager = "
				+ "'" + projectmanager + "'" + " and project = " + "'" + projectid + "'" + "" + " and machine in("
				+ sql1 + ") and  group_='Test'";

		ManufacturingGeneralFreeDTO testDTODTOList = jdbcTemplate.query(sql,
				new ResultSetExtractor<ManufacturingGeneralFreeDTO>() {
					@Override
					public ManufacturingGeneralFreeDTO extractData(ResultSet rs)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
						ManufacturingGeneralFreeDTO manufacturingGeneralFreeDTO = new ManufacturingGeneralFreeDTO();
						while (rs.next()) {
							manufacturingGeneralFreeDTO.setSumsbl(rs.getInt("CBL"));
							manufacturingGeneralFreeDTO.setSumpeac(rs.getInt("PREVIOUS_EAC"));
							manufacturingGeneralFreeDTO.setSumeac(rs.getInt("EAC"));

						}
						return manufacturingGeneralFreeDTO;

					}
				});

		return new MaufacturingGeneral1DTO(
				new GeneralManufacturingDto(mcShopDTOList.getSumsbl(), lampressDTOList.getSumsbl(),
						pinvenDTOList.getSumsbl(), rotorDTOList.getSumsbl(), statcoreDTOList.getSumsbl(),
						CoilsDTO.getSumsbl(), copperDTOList.getSumsbl(), statwindDTOList.getSumsbl(),
						vpiDTOList.getSumsbl(), assemblyDTOList.getSumsbl(), testDTODTOList.getSumsbl()),
				new GeneralManufacturingDto(mcShopDTOList.getSumeac(), lampressDTOList.getSumeac(),
						pinvenDTOList.getSumeac(), rotorDTOList.getSumeac(), statcoreDTOList.getSumeac(),
						CoilsDTO.getSumeac(), copperDTOList.getSumeac(), statwindDTOList.getSumeac(),
						vpiDTOList.getSumeac(), assemblyDTOList.getSumeac(), testDTODTOList.getSumeac()),
				new GeneralManufacturingDto(mcShopDTOList.getSumpeac(), lampressDTOList.getSumpeac(),
						pinvenDTOList.getSumpeac(), rotorDTOList.getSumpeac(), statcoreDTOList.getSumpeac(),
						CoilsDTO.getSumpeac(), copperDTOList.getSumpeac(), statwindDTOList.getSumpeac(),
						vpiDTOList.getSumpeac(), assemblyDTOList.getSumpeac(), testDTODTOList.getSumpeac()));

	}
}
