package genpact.pmr.start.dto;

import java.util.List;
import java.util.Map;

public class RiskAndOpportunityResponseJSON {
	
	private  List<FormatDataDto>   nextFiletrDatas;
	private	 RiskDataDto  riskDataDto;
	private  RiskDataDto  opportunityDataDto;
	private  PendingActionsDataDto  pendingActionsDataDto;
	
	private  Map<String,PendingEscalations>  significantMap;
	private  Map<String,PendingEscalations>  mediumMap;
	private  Map<String,PendingEscalations>  smallMap;
	public List<FormatDataDto> getNextFiletrDatas() {
		return nextFiletrDatas;
	}
	public void setNextFiletrDatas(List<FormatDataDto> nextFiletrDatas) {
		this.nextFiletrDatas = nextFiletrDatas;
	}
	public RiskDataDto getRiskDataDto() {
		return riskDataDto;
	}
	public void setRiskDataDto(RiskDataDto riskDataDto) {
		this.riskDataDto = riskDataDto;
	}
	public RiskDataDto getOpportunityDataDto() {
		return opportunityDataDto;
	}
	public void setOpportunityDataDto(RiskDataDto opportunityDataDto) {
		this.opportunityDataDto = opportunityDataDto;
	}
	public PendingActionsDataDto getPendingActionsDataDto() {
		return pendingActionsDataDto;
	}
	public void setPendingActionsDataDto(PendingActionsDataDto pendingActionsDataDto) {
		this.pendingActionsDataDto = pendingActionsDataDto;
	}
	public Map<String, PendingEscalations> getSignificantMap() {
		return significantMap;
	}
	public void setSignificantMap(Map<String, PendingEscalations> significantMap) {
		this.significantMap = significantMap;
	}
	public Map<String, PendingEscalations> getMediumMap() {
		return mediumMap;
	}
	public void setMediumMap(Map<String, PendingEscalations> mediumMap) {
		this.mediumMap = mediumMap;
	}
	public Map<String, PendingEscalations> getSmallMap() {
		return smallMap;
	}
	public void setSmallMap(Map<String, PendingEscalations> smallMap) {
		this.smallMap = smallMap;
	}
	public RiskAndOpportunityResponseJSON(List<FormatDataDto> nextFiletrDatas, RiskDataDto riskDataDto,
			RiskDataDto opportunityDataDto, PendingActionsDataDto pendingActionsDataDto,
			Map<String, PendingEscalations> significantMap, Map<String, PendingEscalations> mediumMap,
			Map<String, PendingEscalations> smallMap) {
		super();
		this.nextFiletrDatas = nextFiletrDatas;
		this.riskDataDto = riskDataDto;
		this.opportunityDataDto = opportunityDataDto;
		this.pendingActionsDataDto = pendingActionsDataDto;
		this.significantMap = significantMap;
		this.mediumMap = mediumMap;
		this.smallMap = smallMap;
	}
	public RiskAndOpportunityResponseJSON() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	//==============================
	/*private  PendingEscalations  significant;
	private  PendingEscalations  medium;
	private  PendingEscalations  small;
	public List<FormatDataDto> getNextFiletrDatas() {
		return nextFiletrDatas;
	}
	public void setNextFiletrDatas(List<FormatDataDto> nextFiletrDatas) {
		this.nextFiletrDatas = nextFiletrDatas;
	}
	public RiskDataDto getRiskDataDto() {
		return riskDataDto;
	}
	public void setRiskDataDto(RiskDataDto riskDataDto) {
		this.riskDataDto = riskDataDto;
	}
	public RiskDataDto getOpportunityDataDto() {
		return opportunityDataDto;
	}
	public void setOpportunityDataDto(RiskDataDto opportunityDataDto) {
		this.opportunityDataDto = opportunityDataDto;
	}
	public PendingActionsDataDto getPendingActionsDataDto() {
		return pendingActionsDataDto;
	}
	public void setPendingActionsDataDto(PendingActionsDataDto pendingActionsDataDto) {
		this.pendingActionsDataDto = pendingActionsDataDto;
	}
	public PendingEscalations getSignificant() {
		return significant;
	}
	public void setSignificant(PendingEscalations significant) {
		this.significant = significant;
	}
	public PendingEscalations getMedium() {
		return medium;
	}
	public void setMedium(PendingEscalations medium) {
		this.medium = medium;
	}
	public PendingEscalations getSmall() {
		return small;
	}
	public void setSmall(PendingEscalations small) {
		this.small = small;
	}
	public RiskAndOpportunityResponseJSON() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RiskAndOpportunityResponseJSON(List<FormatDataDto> nextFiletrDatas, RiskDataDto riskDataDto,
			RiskDataDto opportunityDataDto, PendingActionsDataDto pendingActionsDataDto, PendingEscalations significant,
			PendingEscalations medium, PendingEscalations small) {
		super();
		this.nextFiletrDatas = nextFiletrDatas;
		this.riskDataDto = riskDataDto;
		this.opportunityDataDto = opportunityDataDto;
		this.pendingActionsDataDto = pendingActionsDataDto;
		this.significant = significant;
		this.medium = medium;
		this.small = small;
	}
	*/
	
	
	
	
}
