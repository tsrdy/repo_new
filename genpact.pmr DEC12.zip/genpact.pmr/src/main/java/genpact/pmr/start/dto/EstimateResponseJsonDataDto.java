package genpact.pmr.start.dto;

import java.util.List;

public class EstimateResponseJsonDataDto {

	private double totalHours;
	private List<Integer> timeGapCategories; //timePercent
	//private List<GoForwardCalcList> costCurve;  /// for one project Id
	private List<GoForwardCalcList> goForwardEstimate; /// for all selected project Id
	public double getTotalHours() {
		return totalHours;
	}
	public void setTotalHours(double totalHours) {
		this.totalHours = totalHours;
	}
	public List<Integer> getTimeGapCategories() {
		return timeGapCategories;
	}
	public void setTimeGapCategories(List<Integer> timeGapCategories) {
		this.timeGapCategories = timeGapCategories;
	}
	/*public List<GoForwardCalcList> getCostCurve() {
		return costCurve;
	}
	public void setCostCurve(List<GoForwardCalcList> costCurve) {
		this.costCurve = costCurve;
	}*/
	public List<GoForwardCalcList> getGoForwardEstimate() {
		return goForwardEstimate;
	}
	public void setGoForwardEstimate(List<GoForwardCalcList> goForwardEstimate) {
		this.goForwardEstimate = goForwardEstimate;
	}
	public EstimateResponseJsonDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public EstimateResponseJsonDataDto(double totalHours, List<Integer> timeGapCategories,
			List<GoForwardCalcList> goForwardEstimate) {
		super();
		this.totalHours = totalHours;
		this.timeGapCategories = timeGapCategories;
		this.goForwardEstimate = goForwardEstimate;
	}
	
	
}
