package genpact.pmr.start.dto;

public class EngineeringGeneralFreeDTO {
	
	private int sumsbl;
	private int sumeac;
	private int sumpeac;
	
	
	public int getSumsbl() {
		return sumsbl;
	}
	public void setSumsbl(int sumsbl) {
		this.sumsbl = sumsbl;
	}
	public int getSumeac() {
		return sumeac;
	}
	public void setSumeac(int sumeac) {
		this.sumeac = sumeac;
	}
	public int getSumpeac() {
		return sumpeac;
	}
	public void setSumpeac(int sumpeac) {
		this.sumpeac = sumpeac;
	}
	public EngineeringGeneralFreeDTO(int sumsbl, int sumeac, int sumpeac) {
		super();
		this.sumsbl = sumsbl;
		this.sumeac = sumeac;
		this.sumpeac = sumpeac;
	}
	public EngineeringGeneralFreeDTO() {
		super();
	}
	

}
