package genpact.pmr.start.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.PMRServiceDao;
import genpact.pmr.start.dto.FormatDataDto;
import genpact.pmr.start.dto.JSONDataDto;
import genpact.pmr.start.dto.ProjectIdFilter;
import genpact.pmr.start.dto.ProjectManagerFilter;
import genpact.pmr.start.dto.RegionFilter;
import genpact.pmr.start.dto.RequestFilter;
import genpact.pmr.start.dto.RiskFilter;
import genpact.pmr.start.dto.SubVerticalFilter;
import genpact.pmr.start.dto.VerticalFilter;

@CrossOrigin
@RestController
public class PmrService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private PMRServiceDao pMRServiceDao;

	// just to check
	@RequestMapping(value = "/pmr", method = RequestMethod.GET)
	public String msg() {
		return "Running Succesfully";
	}

	// To retrive info
	@RequestMapping(value = "/getpmr", method = RequestMethod.GET)
	public JSONDataDto getInfo() {

		JSONDataDto jsonDataDto = new JSONDataDto();
		List<FormatDataDto> formatDataDtos = null;
				
		String a = "";
		String sql = "select distinct(region_business_unit) from pmrdata "; 
	
		formatDataDtos = jdbcTemplate.query(sql, new RowMapper<FormatDataDto>() {
			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("region_business_unit"));
			}

		});
	
		
		jsonDataDto = pMRServiceDao.getTotalTableData(a);
		jsonDataDto.setFormatDataDtos(formatDataDtos);
		
		JSONDataDto obj_chartdetails =pMRServiceDao.getChartDetailGroupDetailData("");
		jsonDataDto.setGroup_cost(obj_chartdetails.getGroup_cost());
		jsonDataDto.setGroupedtype_cost(obj_chartdetails.getGroupedtype_cost());
		jsonDataDto.setCostDetailGroupTypeChartTypeDto(obj_chartdetails.getCostDetailGroupTypeChartTypeDto());
		
		
		return jsonDataDto;

	}

	// // retrieve info with Region

	@RequestMapping(value = "/getpmr/region_business_unit", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public JSONDataDto getVertical(@RequestBody RequestFilter[] requestFilterArr) {
		
		RequestFilter requestFilter = requestFilterArr[0];
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();

		String region_business_unit = "";

		JSONDataDto jsonDataDto = null;
		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
				
				break;
			} else if (i < regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
				
			}
			i++;
		}



	String segment = "select distinct(vertical) from pmrdata where region_business_unit in ( ";

	segment+=createSql(region_business_unit);

		segment += ")";

		List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {


				return new FormatDataDto(++counter, rs.getString("vertical"));

			}

		});
		jsonDataDto = pMRServiceDao.getTotalTableData("where region_business_unit in("+ createSql(region_business_unit)+ ")");
		jsonDataDto.setFormatDataDtos(formatDataDtos);
		JSONDataDto obj_chartdetails =pMRServiceDao.getChartDetailGroupDetailData("where region_business_unit in("+ createSql(region_business_unit)+ ")");
		jsonDataDto.setGroup_cost(obj_chartdetails.getGroup_cost());
		jsonDataDto.setGroupedtype_cost(obj_chartdetails.getGroupedtype_cost());
		jsonDataDto.setCostDetailGroupTypeChartTypeDto(obj_chartdetails.getCostDetailGroupTypeChartTypeDto());
		return jsonDataDto;
	}

	
	// retrieving information with region_business_unit and vertical
	@RequestMapping(value = "/getpmr/region_business_unit/vertical", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	
	public JSONDataDto getSubVertical(@RequestBody RequestFilter[] requestFilterArr) {

		JSONDataDto jsonDataDto = null;
		RequestFilter requestFilter = requestFilterArr[0];
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();
		List<VerticalFilter> verticalFilters = requestFilter.getVerticalFilters();

		String region_business_unit ="";
		String vertical ="" ;
		
		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
				break;
			} else if (i < regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;
		
		for (VerticalFilter verticalFilter : verticalFilters) {

			if ((i + 1) == verticalFilters.size()) {
				vertical+=verticalFilter.getLabel()+",";
				break;
			} else if (i < verticalFilters.size()) {
				vertical += verticalFilter.getLabel()+",";
			}
			i++;
		}
		
		String segment = "select distinct(sub_vertical) from pmrdata where region_business_unit in (";

		segment+=createSql(region_business_unit);

		segment+=") and vertical in (";

		segment += createSql(vertical);


		segment += ")";


		List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {
			int counter;
			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new FormatDataDto(++counter, rs.getString("sub_vertical"));

			}
		});

		jsonDataDto = pMRServiceDao.getTotalTableData("where region_business_unit in("+createSql(region_business_unit)+ ") and vertical in ("+createSql(vertical)+")");
		jsonDataDto.setFormatDataDtos(formatDataDtos);
		
		JSONDataDto obj_chartdetails =pMRServiceDao.getChartDetailGroupDetailData("where region_business_unit in("+createSql(region_business_unit)+ ") and vertical in ("+createSql(vertical)+")");
		jsonDataDto.setGroup_cost(obj_chartdetails.getGroup_cost());
		jsonDataDto.setGroupedtype_cost(obj_chartdetails.getGroupedtype_cost());
		jsonDataDto.setCostDetailGroupTypeChartTypeDto(obj_chartdetails.getCostDetailGroupTypeChartTypeDto());
		return jsonDataDto;
	}

	private String createSql(String str) {
		String[] strArray = str.split(",");

		String seg = "";

		for (int i = 0; i <= strArray.length; i++) {

			seg += "'" + strArray[i] + "'";

			if ((i + 1) == strArray.length) {
				break;
			} else if (i < strArray.length) {
				seg += ",";
			}
		}
		return seg;
	}

	// retrieving information with region_business_unit and vertical,
	// sub-vertical
	@RequestMapping(value = "/getpmr/region_business_unit/vertical/sub_vertical", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	
	public JSONDataDto getProjectRisk(@RequestBody RequestFilter[] requestFilterArr) {
			

		JSONDataDto jsonDataDto = null;
		RequestFilter requestFilter=requestFilterArr[0];
		
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();
		List<VerticalFilter> verticalFilters = requestFilter.getVerticalFilters();
		List<SubVerticalFilter> subVerticalFilters = requestFilter.getSubVerticalFilters();

		String region_business_unit ="";
		String sub_vertical ="";
		String vertical ="" ;
		
		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
				break;
			} else if (i < regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;
		
		for (VerticalFilter verticalFilter : verticalFilters) {

			if ((i + 1) == verticalFilters.size()) {
				vertical += verticalFilter.getLabel() + ",";
				break;
			} else if (i < verticalFilters.size()) {
				vertical += verticalFilter.getLabel() + ",";
			}
			i++;
		}
		
i =0;
		
		for (SubVerticalFilter	subVerticalFilter : subVerticalFilters) {

			if ((i + 1) == subVerticalFilters.size()) {
				sub_vertical += subVerticalFilter.getLabel() + ",";
				break;
			} else if (i < subVerticalFilters.size()) {
				sub_vertical += subVerticalFilter.getLabel() + ",";
			}
			i++;
		}

		String segment = "select distinct(project_risk) from pmrdata where region_business_unit in ( ";

		segment += createSql(region_business_unit);

		segment += " ) and vertical in (";

		segment += createSql(vertical);

		segment += " ) and sub_vertical in (";
		segment += createSql(sub_vertical);


		segment += ")";


		List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new FormatDataDto(++counter, rs.getString("project_risk"));

			}
		});

		jsonDataDto = pMRServiceDao.getTotalTableData("where region_business_unit in(" + createSql(region_business_unit) + ") and vertical in ("+ createSql(vertical) + ") and sub_vertical in (" + createSql(sub_vertical) + ")");
		jsonDataDto.setFormatDataDtos(formatDataDtos);
		JSONDataDto obj_chartdetails =pMRServiceDao.getChartDetailGroupDetailData("where region_business_unit in(" + createSql(region_business_unit) + ") and vertical in ("+ createSql(vertical) + ") and sub_vertical in (" + createSql(sub_vertical) + ")");
		jsonDataDto.setGroup_cost(obj_chartdetails.getGroup_cost());
		jsonDataDto.setGroupedtype_cost(obj_chartdetails.getGroupedtype_cost());
		jsonDataDto.setCostDetailGroupTypeChartTypeDto(obj_chartdetails.getCostDetailGroupTypeChartTypeDto());
		return jsonDataDto;
	}

	// retrieving information with region_business_unit and vertical,
	// sub-vertical, project ID
	@RequestMapping(value = "/getpmr/region_business_unit/vertical/sub_vertical/project_risk", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	
	public JSONDataDto getProjectManager(@RequestBody RequestFilter[] requestFilterArr) {
		JSONDataDto jsonDataDto = null;
		
		
		RequestFilter requestFilter=requestFilterArr[0];
		
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();
		List<VerticalFilter> verticalFilters = requestFilter.getVerticalFilters();
		List<SubVerticalFilter> subVerticalFilters = requestFilter.getSubVerticalFilters();
		List<RiskFilter> riskFilters = requestFilter.getRiskFilters();

		String region_business_unit ="";
		String sub_vertical ="";
		String vertical ="" ;
		String project_risk ="" ;
		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
				break;
			} else if (i < regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;
		
		for (VerticalFilter verticalFilter : verticalFilters) {

			if ((i + 1) == verticalFilters.size()) {
				vertical += verticalFilter.getLabel() + ",";
				break;
			} else if (i < verticalFilters.size()) {
				vertical += verticalFilter.getLabel() + ",";
			}
			i++;
		}
		
i =0;
		
		for (SubVerticalFilter	subVerticalFilter : subVerticalFilters) {

			if ((i + 1) == subVerticalFilters.size()) {
				sub_vertical += subVerticalFilter.getLabel() + ",";
				break;
			} else if (i < subVerticalFilters.size()) {
				sub_vertical += subVerticalFilter.getLabel() + ",";
			}
			i++;
		}

i =0;
		
		for (RiskFilter	riskFilter : riskFilters) {

			if ((i + 1) == riskFilters.size()) {
				project_risk+= riskFilter.getLabel() + ",";
				break;
			} else if (i < riskFilters.size()) {
				project_risk += riskFilter.getLabel() + ",";
			}
			i++;
		}
		String segment = "select distinct(project_manager) from pmrdata where region_business_unit in ( ";

		segment += createSql(region_business_unit);

		segment += " ) and vertical in (";

		segment += createSql(vertical);

		segment += " ) and sub_vertical in (";
		segment += createSql(sub_vertical);

		segment += " ) and project_risk in (";
		segment += createSql(project_risk);
		segment += ")";
		
		System.out.println("SQL for project manager : "+segment);

		List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("project_manager"));

			}
		});

		jsonDataDto = pMRServiceDao.getTotalTableData("where region_business_unit in(" + createSql(region_business_unit)
				+ ") and vertical in (" + createSql(vertical) + ") and sub_vertical in (" + createSql(sub_vertical)
				+ ") and project_risk in (" + createSql(project_risk) + ")");
		jsonDataDto.setFormatDataDtos(formatDataDtos);
		JSONDataDto obj_chartdetails =pMRServiceDao.getChartDetailGroupDetailData("where region_business_unit in(" + createSql(region_business_unit)
				+ ") and vertical in (" + createSql(vertical) + ") and sub_vertical in (" + createSql(sub_vertical)
				+ ") and project_risk in (" + createSql(project_risk) + ")");
		jsonDataDto.setGroup_cost(obj_chartdetails.getGroup_cost());
		jsonDataDto.setGroupedtype_cost(obj_chartdetails.getGroupedtype_cost());
		jsonDataDto.setCostDetailGroupTypeChartTypeDto(obj_chartdetails.getCostDetailGroupTypeChartTypeDto());

		return jsonDataDto;
	}

	// retrieving information with region_business_unit and vertical,
	// sub-vertical, project ID, Project name
	@RequestMapping(value = "/getpmr/region_business_unit/vertical/sub_vertical/project_risk/project_manager",method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	
	public JSONDataDto getProjectId(@RequestBody RequestFilter[] requestFilterArr) {
		JSONDataDto jsonDataDto = null;
		
		
RequestFilter requestFilter=requestFilterArr[0];
		
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();
		List<VerticalFilter> verticalFilters = requestFilter.getVerticalFilters();
		List<SubVerticalFilter> subVerticalFilters = requestFilter.getSubVerticalFilters();
		List<RiskFilter> riskFilters = requestFilter.getRiskFilters();
		List<ProjectManagerFilter> projectManagerFilters = requestFilter.getProjectManagerFilters();

		String region_business_unit ="";
		String sub_vertical ="";
		String vertical ="" ;
		String project_risk ="" ;
		String project_manager ="" ;
		String project_id="" ;
		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
				break;
			} else if (i < regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;
		
		for (VerticalFilter verticalFilter : verticalFilters) {

			if ((i + 1) == verticalFilters.size()) {
				vertical += verticalFilter.getLabel() + ",";
				break;
			} else if (i < verticalFilters.size()) {
				vertical += verticalFilter.getLabel() + ",";
			}
			i++;
		}
		
i =0;
		
		for (SubVerticalFilter	subVerticalFilter : subVerticalFilters) {

			if ((i + 1) == subVerticalFilters.size()) {
				sub_vertical += subVerticalFilter.getLabel() + ",";
				break;
			} else if (i < subVerticalFilters.size()) {
				sub_vertical += subVerticalFilter.getLabel() + ",";
			}
			i++;
		}

i =0;
		
		for (RiskFilter	riskFilter : riskFilters) {

			if ((i + 1) == riskFilters.size()) {
				project_risk+= riskFilter.getLabel() + ",";
				break;
			} else if (i < riskFilters.size()) {
				project_risk += riskFilter.getLabel() + ",";
			}
			i++;
		}
i =0;
		
		for (ProjectManagerFilter	projectManagerFilter : projectManagerFilters) {

			if ((i + 1) == projectManagerFilters.size()) {
				project_manager+= projectManagerFilter.getLabel() + ",";
				break;
			} else if (i < projectManagerFilters.size()) {
				project_manager += projectManagerFilter.getLabel() + ",";
			}
			i++;
		}
		String segment = "select distinct(project_id) from pmrdata where region_business_unit in ( ";

		segment += createSql(region_business_unit);

		segment += " ) and vertical in (";

		segment += createSql(vertical);

		segment += " ) and sub_vertical in (";
		segment += createSql(sub_vertical);

		segment += " ) and project_risk in (";
		segment += createSql(project_risk);

		segment += " ) and project_manager in (";
		segment += createSql(project_manager);

		segment += ")";

		

		List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {

			int counter;

			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("project_id"));

			}
		});

		jsonDataDto = pMRServiceDao.getTotalTableData("where region_business_unit in(" + createSql(region_business_unit)
				+ ") and vertical in (" + createSql(vertical) + ") and sub_vertical in (" + createSql(sub_vertical)
				+ ") and project_risk in (" + createSql(project_risk) + ") and project_manager in("
				+ createSql(project_manager) + ")");
		jsonDataDto.setFormatDataDtos(formatDataDtos);
		
		JSONDataDto obj_chartdetails =pMRServiceDao.getChartDetailGroupDetailData("where region_business_unit in(" + createSql(region_business_unit)
				+ ") and vertical in (" + createSql(vertical) + ") and sub_vertical in (" + createSql(sub_vertical)
				+ ") and project_risk in (" + createSql(project_risk) + ") and project_manager in("
				+ createSql(project_manager) + ")");
jsonDataDto.setGroup_cost(obj_chartdetails.getGroup_cost());
jsonDataDto.setGroupedtype_cost(obj_chartdetails.getGroupedtype_cost());
jsonDataDto.setCostDetailGroupTypeChartTypeDto(obj_chartdetails.getCostDetailGroupTypeChartTypeDto());


		return jsonDataDto;

	}
	// region,vertical,sub_vertical,project_id,project_name,project_manager

	@RequestMapping(value = "/getpmr/region_business_unit/vertical/sub_vertical/project_risk/project_manager/project_id",method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	
	public JSONDataDto getProjectName(@RequestBody RequestFilter[] requestFilterArr) {
		JSONDataDto jsonDataDto = null;
		
		
RequestFilter requestFilter=requestFilterArr[0];
		
		List<RegionFilter> regionFilters = requestFilter.getRegionFilters();
		List<VerticalFilter> verticalFilters = requestFilter.getVerticalFilters();
		List<SubVerticalFilter> subVerticalFilters = requestFilter.getSubVerticalFilters();
		List<RiskFilter> riskFilters = requestFilter.getRiskFilters();
		List<ProjectManagerFilter> projectManagerFilters = requestFilter.getProjectManagerFilters();
		List<ProjectIdFilter> projectIdFilters = requestFilter.getProjectIdFilters();

		String region_business_unit ="";
		String sub_vertical ="";
		String vertical ="" ;
		String project_risk ="" ;
		String project_manager ="" ;
		String project_id="" ;
		int i = 0;
		for (RegionFilter regionFilter : regionFilters) {

			if ((i + 1) == regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
				break;
			} else if (i < regionFilters.size()) {
				region_business_unit += regionFilter.getLabel() + ",";
			}
			i++;
		}

		i =0;
		
		for (VerticalFilter verticalFilter : verticalFilters) {

			if ((i + 1) == verticalFilters.size()) {
				vertical += verticalFilter.getLabel() + ",";
				break;
			} else if (i < verticalFilters.size()) {
				vertical += verticalFilter.getLabel() + ",";
			}
			i++;
		}
		
i =0;
		
		for (SubVerticalFilter	subVerticalFilter : subVerticalFilters) {

			if ((i + 1) == subVerticalFilters.size()) {
				sub_vertical += subVerticalFilter.getLabel() + ",";
				break;
			} else if (i < subVerticalFilters.size()) {
				sub_vertical += subVerticalFilter.getLabel() + ",";
			}
			i++;
		}

i =0;
		
		for (RiskFilter	riskFilter : riskFilters) {

			if ((i + 1) == riskFilters.size()) {
				project_risk+= riskFilter.getLabel() + ",";
				break;
			} else if (i < riskFilters.size()) {
				project_risk += riskFilter.getLabel() + ",";
			}
			i++;
		}
i =0;
		
		for (ProjectManagerFilter	projectManagerFilter : projectManagerFilters) {

			if ((i + 1) == projectManagerFilters.size()) {
				project_manager+= projectManagerFilter.getLabel() + ",";
				break;
			} else if (i < projectManagerFilters.size()) {
				project_manager += projectManagerFilter.getLabel() + ",";
			}
			i++;
		}
i =0;
		
		for (ProjectIdFilter	projectIdFilter : projectIdFilters) {

			if ((i + 1) == projectIdFilters.size()) {
				project_id+= projectIdFilter.getLabel() + ",";
				break;
			} else if (i < projectIdFilters.size()) {
				project_id += projectIdFilter.getLabel() + ",";
			}
			i++;
		}
		String segment = "select distinct(project_name) from pmrdata where region_business_unit in ( ";

		segment += createSql(region_business_unit);

		segment += " ) and vertical in (";

		segment += createSql(vertical);

		segment += " ) and sub_vertical in (";
		segment += createSql(sub_vertical);

		segment += " ) and project_risk in (";
		segment += createSql(project_risk);

		segment += " ) and project_manager in (";
		segment += createSql(project_manager);

		segment += " ) and project_id in (";
		segment += createSql(project_id);
		segment += ")";

		List<FormatDataDto> formatDataDtos = jdbcTemplate.query(segment, new RowMapper<FormatDataDto>() {
			int counter;
			public FormatDataDto mapRow(ResultSet rs, int rowNum) throws SQLException {

				return new FormatDataDto(++counter, rs.getString("project_name"));

			}
		});
		jsonDataDto = pMRServiceDao.getTotalTableData("where region_business_unit in(" + createSql(region_business_unit)
				+ ") and vertical in (" + createSql(vertical) + ") and sub_vertical in (" + createSql(sub_vertical)
				+ ") and project_risk in (" + createSql(project_risk) + ") and project_manager in("
				+ createSql(project_manager) + ")");
		jsonDataDto.setFormatDataDtos(formatDataDtos);
		
		JSONDataDto obj_chartdetails =pMRServiceDao.getChartDetailGroupDetailData("where region_business_unit in(" + createSql(region_business_unit)
				+ ") and vertical in (" + createSql(vertical) + ") and sub_vertical in (" + createSql(sub_vertical)
				+ ") and project_risk in (" + createSql(project_risk) + ") and project_manager in("
				+ createSql(project_manager) + ")");
jsonDataDto.setGroup_cost(obj_chartdetails.getGroup_cost());
jsonDataDto.setGroupedtype_cost(obj_chartdetails.getGroupedtype_cost());
jsonDataDto.setCostDetailGroupTypeChartTypeDto(obj_chartdetails.getCostDetailGroupTypeChartTypeDto());


		return jsonDataDto;

	}

	

	
}
