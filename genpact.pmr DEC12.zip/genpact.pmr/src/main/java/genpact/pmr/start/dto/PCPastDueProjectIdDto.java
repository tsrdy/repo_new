package genpact.pmr.start.dto;

public class PCPastDueProjectIdDto {

	private String region;
	private String regionalManager;
	private String projectManager;
	private String projectId;
	private double internalPD_3Q_2016;
	private double internalPD_2016;
	private double externalPD_3Q_2016;
	private double externalPD_2016;
	private double totalDuesPD_3Q_2016;
	private double totalDuesPD_2016;
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getRegionalManager() {
		return regionalManager;
	}
	public void setRegionalManager(String regionalManager) {
		this.regionalManager = regionalManager;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public double getInternalPD_3Q_2016() {
		return internalPD_3Q_2016;
	}
	public void setInternalPD_3Q_2016(double internalPD_3Q_2016) {
		this.internalPD_3Q_2016 = internalPD_3Q_2016;
	}
	public double getInternalPD_2016() {
		return internalPD_2016;
	}
	public void setInternalPD_2016(double internalPD_2016) {
		this.internalPD_2016 = internalPD_2016;
	}
	public double getExternalPD_3Q_2016() {
		return externalPD_3Q_2016;
	}
	public void setExternalPD_3Q_2016(double externalPD_3Q_2016) {
		this.externalPD_3Q_2016 = externalPD_3Q_2016;
	}
	public double getExternalPD_2016() {
		return externalPD_2016;
	}
	public void setExternalPD_2016(double externalPD_2016) {
		this.externalPD_2016 = externalPD_2016;
	}
	public double getTotalDuesPD_3Q_2016() {
		return totalDuesPD_3Q_2016;
	}
	public void setTotalDuesPD_3Q_2016(double totalDuesPD_3Q_2016) {
		this.totalDuesPD_3Q_2016 = totalDuesPD_3Q_2016;
	}
	public double getTotalDuesPD_2016() {
		return totalDuesPD_2016;
	}
	public void setTotalDuesPD_2016(double totalDuesPD_2016) {
		this.totalDuesPD_2016 = totalDuesPD_2016;
	}
	public PCPastDueProjectIdDto(String region, String regionalManager, String projectManager, String projectId,
			double internalPD_3Q_2016, double internalPD_2016, double externalPD_3Q_2016, double externalPD_2016,
			double totalDuesPD_3Q_2016, double totalDuesPD_2016) {
		super();
		this.region = region;
		this.regionalManager = regionalManager;
		this.projectManager = projectManager;
		this.projectId = projectId;
		this.internalPD_3Q_2016 = internalPD_3Q_2016;
		this.internalPD_2016 = internalPD_2016;
		this.externalPD_3Q_2016 = externalPD_3Q_2016;
		this.externalPD_2016 = externalPD_2016;
		this.totalDuesPD_3Q_2016 = totalDuesPD_3Q_2016;
		this.totalDuesPD_2016 = totalDuesPD_2016;
	}
	public PCPastDueProjectIdDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(externalPD_2016);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(externalPD_3Q_2016);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(internalPD_2016);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(internalPD_3Q_2016);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((projectId == null) ? 0 : projectId.hashCode());
		result = prime * result + ((projectManager == null) ? 0 : projectManager.hashCode());
		result = prime * result + ((region == null) ? 0 : region.hashCode());
		result = prime * result + ((regionalManager == null) ? 0 : regionalManager.hashCode());
		temp = Double.doubleToLongBits(totalDuesPD_2016);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(totalDuesPD_3Q_2016);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PCPastDueProjectIdDto other = (PCPastDueProjectIdDto) obj;
		if (Double.doubleToLongBits(externalPD_2016) != Double.doubleToLongBits(other.externalPD_2016))
			return false;
		if (Double.doubleToLongBits(externalPD_3Q_2016) != Double.doubleToLongBits(other.externalPD_3Q_2016))
			return false;
		if (Double.doubleToLongBits(internalPD_2016) != Double.doubleToLongBits(other.internalPD_2016))
			return false;
		if (Double.doubleToLongBits(internalPD_3Q_2016) != Double.doubleToLongBits(other.internalPD_3Q_2016))
			return false;
		if (projectId == null) {
			if (other.projectId != null)
				return false;
		} else if (!projectId.equals(other.projectId))
			return false;
		if (projectManager == null) {
			if (other.projectManager != null)
				return false;
		} else if (!projectManager.equals(other.projectManager))
			return false;
		if (region == null) {
			if (other.region != null)
				return false;
		} else if (!region.equals(other.region))
			return false;
		if (regionalManager == null) {
			if (other.regionalManager != null)
				return false;
		} else if (!regionalManager.equals(other.regionalManager))
			return false;
		if (Double.doubleToLongBits(totalDuesPD_2016) != Double.doubleToLongBits(other.totalDuesPD_2016))
			return false;
		if (Double.doubleToLongBits(totalDuesPD_3Q_2016) != Double.doubleToLongBits(other.totalDuesPD_3Q_2016))
			return false;
		return true;
	}
	
	
	
}
