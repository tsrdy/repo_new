package genpact.pmr.start.dto;

import java.util.List;

public class BillingTimeGraphDTO {
	
	private List<String> xCordinatesList;
	private List<Long> yCordinatesList;
	public List<String> getxCordinatesList() {
		return xCordinatesList;
	}
	public void setxCordinatesList(List<String> xCordinatesList) {
		this.xCordinatesList = xCordinatesList;
	}
	public List<Long> getyCordinatesList() {
		return yCordinatesList;
	}
	public void setyCordinatesList(List<Long> yCordinatesList) {
		this.yCordinatesList = yCordinatesList;
	}
	
	

}
