package genpact.pmr.start.dto;

public class BillingTableDataDto {

	private int uid;
	private String project_id ;
	private String   sold_to_party_name ;
	private String   sold_to_party_country ;
	private String   sales_order_number ;
	private long  billing_number ;
	private String   customer_po_no ;
	private String   billing_status ;
	private String   billing_date ;
	private String  due_date ;
	private long  billing_value ;
	
	
	public BillingTableDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BillingTableDataDto(int uid, String project_id, String sold_to_party_name, String sold_to_party_country,
			String sales_order_number, long billing_number, String customer_po_no, String billing_status,
			String billing_date, String due_date, long billing_value) {
		super();
		this.uid = uid;
		this.project_id = project_id;
		this.sold_to_party_name = sold_to_party_name;
		this.sold_to_party_country = sold_to_party_country;
		this.sales_order_number = sales_order_number;
		this.billing_number = billing_number;
		this.customer_po_no = customer_po_no;
		this.billing_status = billing_status;
		this.billing_date = billing_date;
		this.due_date = due_date;
		this.billing_value = billing_value;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getProject_id() {
		return project_id;
	}
	public void setProject_id(String project_id) {
		this.project_id = project_id;
	}
	public String getSold_to_party_name() {
		return sold_to_party_name;
	}
	public void setSold_to_party_name(String sold_to_party_name) {
		this.sold_to_party_name = sold_to_party_name;
	}
	public String getSold_to_party_country() {
		return sold_to_party_country;
	}
	public void setSold_to_party_country(String sold_to_party_country) {
		this.sold_to_party_country = sold_to_party_country;
	}
	public String getSales_order_number() {
		return sales_order_number;
	}
	public void setSales_order_number(String sales_order_number) {
		this.sales_order_number = sales_order_number;
	}
	public long getBilling_number() {
		return billing_number;
	}
	public void setBilling_number(long billing_number) {
		this.billing_number = billing_number;
	}
	public String getCustomer_po_no() {
		return customer_po_no;
	}
	public void setCustomer_po_no(String customer_po_no) {
		this.customer_po_no = customer_po_no;
	}
	public String getBilling_status() {
		return billing_status;
	}
	public void setBilling_status(String billing_status) {
		this.billing_status = billing_status;
	}
	public String getBilling_date() {
		return billing_date;
	}
	public void setBilling_date(String billing_date) {
		this.billing_date = billing_date;
	}
	public String getDue_date() {
		return due_date;
	}
	public void setDue_date(String due_date) {
		this.due_date = due_date;
	}
	public long getBilling_value() {
		return billing_value;
	}
	public void setBilling_value(long billing_value) {
		this.billing_value = billing_value;
	}
	@Override
	public String toString() {
		return "BillingTableDataDto [uid=" + uid + ", project_id=" + project_id + ", sold_to_party_name="
				+ sold_to_party_name + ", sold_to_party_country=" + sold_to_party_country + ", sales_order_number="
				+ sales_order_number + ", billing_number=" + billing_number + ", customer_po_no=" + customer_po_no
				+ ", billing_status=" + billing_status + ", billing_date=" + billing_date + ", due_date=" + due_date
				+ ", billing_value=" + billing_value + "]";
	}
	

}
