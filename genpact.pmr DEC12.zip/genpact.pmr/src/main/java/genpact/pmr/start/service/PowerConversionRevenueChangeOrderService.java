package genpact.pmr.start.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import genpact.pmr.start.dao.PowerConversionRevenueChangeOrderDao;
import genpact.pmr.start.dto.PCRevenueChangeOrderRequestJSONDataDto;
import genpact.pmr.start.dto.PCRevenueChangeOrderResponseJSONDataDto;
import genpact.pmr.start.dto.PowerConversionBillingSummaryRequestJSONDataDto;
import genpact.pmr.start.dto.PowerConversionBillingSummaryResponseJSONDataDto;

@CrossOrigin
@RestController
public class PowerConversionRevenueChangeOrderService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private PowerConversionRevenueChangeOrderDao rcoDao;

	// just to check
	@RequestMapping(value = "/billingsummaryrevenuechangeorder", method = RequestMethod.GET)
	public String msg() {
		return "Running Succesfully";
	}

	// To retrive info
	@RequestMapping(value = "/getrevenuechangeorder", method = RequestMethod.GET)
	public PCRevenueChangeOrderResponseJSONDataDto getInfo() {
		PCRevenueChangeOrderResponseJSONDataDto revenueChangeOrderResponseJSONDataDto = null;

		revenueChangeOrderResponseJSONDataDto = rcoDao.getAllData();

		
		return revenueChangeOrderResponseJSONDataDto;

	}

	@RequestMapping(value = "/getrevenuechangeorder/region", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PCRevenueChangeOrderResponseJSONDataDto getRegionalManager(
			@RequestBody PCRevenueChangeOrderRequestJSONDataDto[] requestJSONDataDtos) {

		PCRevenueChangeOrderResponseJSONDataDto revenueChangeOrderResponseJSONDataDto = null;

		PCRevenueChangeOrderRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		revenueChangeOrderResponseJSONDataDto = rcoDao.getRegionData(requestJSONDataDto);

		return revenueChangeOrderResponseJSONDataDto;
	}

	@RequestMapping(value = "/getrevenuechangeorder/region/regionalmanager", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PCRevenueChangeOrderResponseJSONDataDto getProjectManager(
			@RequestBody PCRevenueChangeOrderRequestJSONDataDto[] requestJSONDataDtos) {

		PCRevenueChangeOrderResponseJSONDataDto revenueChangeOrderResponseJSONDataDto = null;

		PCRevenueChangeOrderRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		revenueChangeOrderResponseJSONDataDto = rcoDao.getRegionalManagerData(requestJSONDataDto);

		return revenueChangeOrderResponseJSONDataDto;

		
	}

	@RequestMapping(value = "/getrevenuechangeorder/region/regionalmanager/projectmanager", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PCRevenueChangeOrderResponseJSONDataDto getTableDataByAllFilter(
			@RequestBody PCRevenueChangeOrderRequestJSONDataDto[] requestJSONDataDtos) {
		
		
		PCRevenueChangeOrderResponseJSONDataDto revenueChangeOrderResponseJSONDataDto = null;

		PCRevenueChangeOrderRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		revenueChangeOrderResponseJSONDataDto = rcoDao.getProjectManagerData(requestJSONDataDto);

		return revenueChangeOrderResponseJSONDataDto;
	}
	
	@RequestMapping(value = "/getrevenuechangeorder/region/regionalmanager/projectmanager/quarter", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public PCRevenueChangeOrderResponseJSONDataDto getTableDataByQuarter(
			@RequestBody PCRevenueChangeOrderRequestJSONDataDto[] requestJSONDataDtos) {
		
		//here we will send region with all data that as get
		
		PCRevenueChangeOrderResponseJSONDataDto revenueChangeOrderResponseJSONDataDto = null;
		
		PCRevenueChangeOrderRequestJSONDataDto requestJSONDataDto = requestJSONDataDtos[0];
		revenueChangeOrderResponseJSONDataDto = rcoDao.getAllDataByQuarter(requestJSONDataDto);

		
		return revenueChangeOrderResponseJSONDataDto;
	}

	
	
	
}
