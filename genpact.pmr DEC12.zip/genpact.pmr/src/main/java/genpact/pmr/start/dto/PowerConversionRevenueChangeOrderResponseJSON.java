package genpact.pmr.start.dto;

import java.util.List;

public class PowerConversionRevenueChangeOrderResponseJSON {

	private List<FormatDataDto> formatDataDtos;
	private List<PowerCBSRegionWiseDataDto> billingByRegion;
	private List<PowerCBSRegionWiseDataDto> cbsProjectDataDtos;
	private List<PowerCBSRegionWiseDataDto> cbsProjectManagerSummaryDataDtos;
	
	public List<FormatDataDto> getFormatDataDtos() {
		return formatDataDtos;
	}
	public void setFormatDataDtos(List<FormatDataDto> formatDataDtos) {
		this.formatDataDtos = formatDataDtos;
	}
	public List<PowerCBSRegionWiseDataDto> getBillingByRegion() {
		return billingByRegion;
	}
	public void setBillingByRegion(List<PowerCBSRegionWiseDataDto> billingByRegion) {
		this.billingByRegion = billingByRegion;
	}

	public List<PowerCBSRegionWiseDataDto> getCbsProjectManagerSummaryDataDtos() {
		return cbsProjectManagerSummaryDataDtos;
	}
	public void setCbsProjectManagerSummaryDataDtos(List<PowerCBSRegionWiseDataDto> cbsProjectManagerSummaryDataDtos) {
		this.cbsProjectManagerSummaryDataDtos = cbsProjectManagerSummaryDataDtos;
	}
	public PowerConversionRevenueChangeOrderResponseJSON() {
		super();
		// TODO Auto-generated constructor stub
	}
	public List<PowerCBSRegionWiseDataDto> getCbsProjectDataDtos() {
		return cbsProjectDataDtos;
	}
	public void setCbsProjectDataDtos(List<PowerCBSRegionWiseDataDto> cbsProjectDataDtos) {
		this.cbsProjectDataDtos = cbsProjectDataDtos;
	}
	public PowerConversionRevenueChangeOrderResponseJSON(List<FormatDataDto> formatDataDtos,
			List<PowerCBSRegionWiseDataDto> billingByRegion, List<PowerCBSRegionWiseDataDto> cbsProjectDataDtos,
			List<PowerCBSRegionWiseDataDto> cbsProjectManagerSummaryDataDtos) {
		super();
		this.formatDataDtos = formatDataDtos;
		this.billingByRegion = billingByRegion;
		this.cbsProjectDataDtos = cbsProjectDataDtos;
		this.cbsProjectManagerSummaryDataDtos = cbsProjectManagerSummaryDataDtos;
	}
	
	
}
