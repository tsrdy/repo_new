package genpact.pmr.start.dto;

public class ProjectManagerDataDto {
	private double sum;
	private String name;//region
	private String regionalManager;
	private String projectManager;
	private String projectId;
	
	
	public ProjectManagerDataDto(double sum, String name, String regionalManager, String projectManager,
			String projectId) {
		super();
		this.sum = sum;
		this.name = name;
		this.regionalManager = regionalManager;
		this.projectManager = projectManager;
		this.projectId = projectId;
	}
	
	
	public String getProjectId() {
		return projectId;
	}


	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}


	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRegionalManager() {
		return regionalManager;
	}
	public void setRegionalManager(String regionalManager) {
		this.regionalManager = regionalManager;
	}
	public String getProjectManager() {
		return projectManager;
	}
	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}
	public ProjectManagerDataDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProjectManagerDataDto(double sum, String name, String regionalManager, String projectManager) {
		super();
		this.sum = sum;
		this.name = name;
		this.regionalManager = regionalManager;
		this.projectManager = projectManager;
	}
	@Override
	public String toString() {
		return "ProjectManagerDataDto [sum=" + sum + ", name=" + name + ", regionalManager=" + regionalManager
				+ ", projectManager=" + projectManager + "]";
	}
	
	
	
	
}
