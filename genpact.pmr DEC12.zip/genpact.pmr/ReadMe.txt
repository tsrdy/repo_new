http://localhost:2225/getdata/Berlin,UK/Power,Industry

http://localhost:2225/getdata/Berlin,UK/Power,Industry/GE%20O&G,Metals/P84P-000011,UK.C.Y.20261.01