 var app=angular.module('myApp',['routeModule']);
  
   var routeApp=angular.module('routeModule',['ngRoute']);


  app.controller('mainController',['$scope','$http',function($scope,$http){
    $http.get('lib/tablejson.js').then(function success(response){
    	
      $scope.incidentId=response.data[0].Number;
      $scope.records=response.data;
      //$scope.pno=response.data[0].Number;
    })
      
  }]);

   app.controller('dataSetController',['$scope','$http','$routeParams',function($scope,$http,$routeParams){
                    
            $scope.textModel1='';
            $scope.textModel='';

             $scope.value=$routeParams.No;
             $scope.val=$routeParams.shtDesc;
             console.log($scope.val)

            /*

				Potentially Impacted Application-  impactedData

				Confirmed application Impacted-  appData


				Potentially Impacted Assets-   impactedAssetData

				Confirmed Assets Impacted-  assetData

            */
            $scope.movePAtoCA= function(index){
					/*Push to Confirmed Affected*/
            	$scope.appData.push($scope.impactedData[index])

            	/*Delete from Array using Index*/
            	 $scope.impactedData.splice(index,1);

                /*Push to Confirmed Affected*/
            	$scope.applicationData.push($scope.impactedData1[index])

            	/*Delete from Array using Index*/
            	 $scope.impactedData1.splice(index,1);

		      }

		      $scope.movePAssettoCAsset= function(index){
					/*Push to Confirmed Affected*/
            	$scope.assetData.push($scope.impactedAssetData[index])

            	/*Delete from Array using Index*/
            	 $scope.impactedAssetData.splice(index,1);

            	 /*Push to Confirmed Affected*/
            	$scope.assetDatum.push($scope.impactedAssetData1[index])

            	/*Delete from Array using Index*/
            	 $scope.impactedAssetData1.splice(index,1);
                  
		      }



		      /*
					Applications Impacted-  applicationData

				Potentially Impacted Applications-  impactedData1


				Assests Impacted-   assetDatum

				Potentially Impacted Assests-  impactedAssetData1
		      */


		      /*$scope.hyperionMovePAtoCA= function(index){
					
		      }

		      $scope.hyperionMovePAssettoCAsset= function(index){
					

		      }*/



				    $http.get('lib/'+$routeParams.No+'appData.js').then(function success(response){
				    	$scope.appData=response.data;
				    	$scope.countCAppfn1();
				    })
				    $http.get('lib/'+$routeParams.No+'assetData.js').then(function success(response){
				    	$scope.assetData=response.data;
				    	$scope.countCAppfn1();
				    })
				    $http.get('lib/'+$routeParams.No+'ImpactedData.js').then(function success(response){
				    	$scope.impactedData=response.data;
				    	 var List=[]
				        angular.forEach($scope.impactedData,function(value,key){
				    	    List.push(value.appName);
				    	    $scope.appList=List;
				    	})
				    	//$scope.countImpactedData();    	
				    })
				    $http.get('lib/'+$routeParams.No+'ImpactedAsset.js').then(function success(response){
				    	$scope.impactedAssetData=response.data;
				    	console.log(response.data.length);
				    	//console.log($scope.impactedAssetData);
                         var arrayList=[]
				        angular.forEach($scope.impactedAssetData,function(value,key){
				    	   arrayList.push(value.assetName);
				    	    $scope.listToUpdate=arrayList;
				    	})
	                })
                   



				    $scope.countCAppfn1= function(){
                    	 $scope.countCApp1=$scope.appData;
                    	 $scope.countCAsset1=$scope.assetData;
                    	// $scope.countPApp=$scope.impactedData1;
                    	 //$scope.countPAsset=$scope.impactedAssetData1;
                    }


				    $http.get('lib/'+$routeParams.No+'appData.js').then(function success(response){
				    	$scope.applicationData=response.data;
				    	$scope.countCAppfn()
				    })
				     $http.get('lib/'+$routeParams.No+'assetData.js').then(function success(response){
				    	$scope.assetDatum=response.data;
				    	$scope.countCAppfn()

				    })
				     $http.get('lib/'+$routeParams.No+'ImpactedData.js').then(function success(response){
				    	$scope.impactedData1=response.data;  
				    	$scope.lengthOfImpactedApp=$scope.impactedData1.length;

				    	console.log($scope.lengthOfImpacted);
				    	$scope.countCAppfn()	
				    }) 
				    $http.get('lib/'+$routeParams.No+'impactedAsset.js').then(function success(response){
				    	$scope.impactedAssetData1=response.data;
				    	$scope.countCAppfn()	
				    })



				    $scope.countCAppfn= function(){
                    	 $scope.countCApp=$scope.applicationData;
                    	 $scope.countCAsset=$scope.assetDatum;
                    	 $scope.countPApp=$scope.impactedData1;
                    	 $scope.countPAsset=$scope.impactedAssetData1;
                    	// $scope.countPApp=$scope.impactedData1;
                    	 //$scope.countPAsset=$scope.impactedAssetData1;
                    }
                    //$scope.countCAppfn();
               
                   $scope.addToListAsset1=function(val){
                     var len=$scope.listToUpdate.length;
                     var str=$scope.textModel
                     console.log(str.length);
                   	  if(str.length!==0){    	  	
	                     //$scope.listToUpdate.push($scope.textModel);
                   	  	var addData=$scope.textModel;
                   	  	$scope.impactedAssetData.push({'assetId':len+1,'assetName':addData});
                   	  	//console.log($scope.impactedAssetData)
                   	  }
                   }
                  
                   $scope.addToListApp1=function(val){
                   	console.log(val.length);

                   	var len=$scope.appList.length;
                   
                   	if(val.length!==0){
                   		$scope.appList.push();
                   		$scope.impactedData.push({'appId':00,'appName':val});
                   	}
                   }
                  $scope.addToAppList2=function(val){    
                     console.log(val.length);
                   	  if(val.length!==0){   	
                   	  	$scope.impactedData1.push({'appId':00,'appName':val});
                   	  	
                   	  }
                   }
		        
		        $scope.addToAssetList2=function(val){    
                     console.log(val);
                   	  if(val.length!==0){   	
                   	  	$scope.impactedAssetData1.push({'assetId':00,'assetName':val});
                   	  	
                   	  }
                   }
            
		  }]);

	        routeApp.config(['$routeProvider',function($routeProvider) {
	        $routeProvider

	            // route for the home page
	            .when('/', {
	                templateUrl : 'partials/table.html',
	                controller  : 'mainController'
	            })

	            // route for the first 
	            .when('/dataSet1/:No/:shtDesc', {
	                
	                controller  : 'dataSetController',
	                templateUrl:'partials/template.html' /*function(params){
	                	        // console.log(params)
	                	         return 'partials/' + params.CI +'.html'; 
	                	        }*/
	            })
	            .otherwise({
	                    redirectTo: '/'
	                });
	        }]);


	   

	             
				


	      