requirejs.config({
    baseUrl: "./",
    paths: {
        "brandkit": "js/hdx-brandkit"
    }
})
