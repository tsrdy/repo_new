requirejs.config({
    baseUrl: "./",
    paths: {
        "brandkit": "js/iidx-brandkit"
    }
})
