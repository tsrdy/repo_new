package main.java.org.genpact.veta.fileCopyData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class FileCopyDataApplication {

	 public static void main(String[] args) {
	        SpringApplication.run(FileCopyDataApplication.class, args);
	        //System.out.println("Copy FIle Method");
	    }

}
