package com.gehc.wire.home.form;

import com.gehc.wire.common.service.CommonService;


/**
 * @author 703092428
 * @FileName LoginForm.java
 * @CreateDate Nov 26, 2012
 */
public class LoginForm {
	public LoginForm(){}
    private String userName;
    private String password;
    private String ssoId;
    private String fullName;
    private String emailId;
    private String role;
    
   
   
	public String getUserName() {
		return CommonService.replaceEmptyWithNull(userName);
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getSsoId() {
		return ssoId;
	}
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}
	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
