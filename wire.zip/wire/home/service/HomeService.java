package com.gehc.wire.home.service;

import com.gehc.wire.home.dto.HomeDto;


/**
 * @author 703092428
 * @FileName HomeService.java
 * @CreateDate Nov 26, 2012
 */
public interface HomeService {

	HomeDto getLandingData(HomeDto oHomeDto) throws Exception;

    HomeDto getNewUserData(HomeDto oHomeDto)throws Exception;
    
    HomeDto getRegionDependents(HomeDto oHomeDto)throws Exception;
    
    HomeDto getCountryData(HomeDto oHomeDto)throws Exception;
    
    HomeDto getStatesData(HomeDto oHomeDto)throws Exception;
    
    HomeDto getModalityTwoData(HomeDto oHomeDto)throws Exception;
    
    HomeDto getNewUser(HomeDto oHomeDto)throws Exception;

	HomeDto getTurboDynValues(HomeDto oHomeDto)throws Exception;
    
	HomeDto getTurbineReliabilityDrillToPi(HomeDto oHomeDto)throws Exception;
	
	HomeDto getWeiBull(HomeDto oHomeDto)throws Exception;
	
	HomeDto failureByPartLife(HomeDto oHomeDto)throws Exception;
	
	
	HomeDto getTurbineWiseList(HomeDto oHomeDto)throws Exception;

	HomeDto getCriticalForecastList(HomeDto oHomeDto)throws Exception;

	HomeDto getSiteComparision(HomeDto oHomeDto)throws Exception;
	
	HomeDto getEGTData(HomeDto oHomeDto) throws Exception;
}
