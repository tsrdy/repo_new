package com.gehc.wire.home.service;

import java.sql.Connection;

import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.home.dto.LoginDto;



/**
 * @author 703092428
 * @FileName LoginService.java
 * @CreateDate Nov 26, 2012
 */
public interface LoginService {

	boolean isValidUser(Connection conn, LoginDto oLoginDto) throws Exception;

	UserDto getUserDetails(Connection conn, LoginDto oLoginDto) throws Exception;

}
