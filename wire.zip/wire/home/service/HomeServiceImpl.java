package com.gehc.wire.home.service;


import java.sql.Connection;

import org.springframework.beans.factory.annotation.Autowired;

import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.dao.PickListDao;
import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.common.service.BaseService;
import com.gehc.wire.common.service.CommonService;
import com.gehc.wire.common.service.DBService;
import com.gehc.wire.home.dao.HomeDAO;
import com.gehc.wire.home.dto.HomeDto;


/**
 * @author 703092428
 * @FileName HomeServiceImpl.java
 * @CreateDate Nov 26, 2012
 */
public class HomeServiceImpl extends BaseService  implements HomeService{
	@Autowired
	HomeDAO homeDAO;
	
	@Autowired
	PickListDao oPickListDao;
	
	@Autowired
	private DBService  dBService;
	
	@Autowired
	public void setDBService(DBService dBService) {
		this.dBService = dBService;
	}
	
	@Autowired
	public void setHomeDAO(HomeDAO homeDAO) {
		this.homeDAO = homeDAO;
	}
	
	
	
	@Autowired
	public void setPickListDAO(PickListDao oPickListDao) {		
		this.oPickListDao = oPickListDao;
	}

	//@Override
	public HomeDto getLandingData(HomeDto oHomeDto) throws Exception {
		Connection conn = null;
		UserDto oUserDto = null;
		try{
			conn = dBService.getDBConnection();
			
			//oHomeDto = homeDAO.getLandingData(conn,oHomeDto);
			/*oHomeDto = homeDAO.getProductivityData(conn,oHomeDto);
			oHomeDto = homeDAO.getIBData(conn,oHomeDto);
			oHomeDto = homeDAO.getRemoteData(conn,oHomeDto);
			oHomeDto = homeDAO.getFEData(conn,oHomeDto);
			oHomeDto = homeDAO.getOpsData(conn,oHomeDto);
			oHomeDto = homeDAO.getQualityData(conn,oHomeDto);
			oHomeDto = homeDAO.getRefreshDetails(conn,oHomeDto);
			
			oHomeDto.setHmYear(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_YEAR, null, null, null,null,oHomeDto.getSso()));
			oHomeDto.setHmQtr(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_QTR, null, null, null,null,oHomeDto.getSso()));
			oHomeDto.setHmMonth(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_MONTH,  CommonService.getMultiList(oHomeDto.getQtr()), null, null,null,oHomeDto.getSso()));
			oHomeDto.setHmFWeek(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_FWEEK, CommonService.getMultiList(oHomeDto.getYear()),  CommonService.getMultiList(oHomeDto.getQtr()),CommonService.getMultiList(oHomeDto.getMonth()),null,oHomeDto.getSso()));
			
			oHomeDto.setHmBusiness(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_BUSINESS, null, null, null,null,oHomeDto.getSso()));
			oHomeDto.setHmModality(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_MODALITY, CommonService.getMultiList(oHomeDto.getBusiness()), null, null,null,oHomeDto.getSso()));
			oHomeDto.setHmSubModality(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_SUBMODALITY, CommonService.getMultiList(oHomeDto.getBusiness()), CommonService.getMultiList(oHomeDto.getModality()), null,null,oHomeDto.getSso()));
			oHomeDto.setHmSegment(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_SEGMENT, CommonService.getMultiList(oHomeDto.getBusiness()), CommonService.getMultiList(oHomeDto.getModality()), CommonService.getMultiList(oHomeDto.getSubModality()),null,oHomeDto.getSso()));
			oHomeDto.setHmProduct(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_PRODUCT, CommonService.getMultiList(oHomeDto.getBusiness()), CommonService.getMultiList(oHomeDto.getModality()), CommonService.getMultiList(oHomeDto.getSubModality()),CommonService.getMultiList(oHomeDto.getSegment()),oHomeDto.getSso()));
			
			oHomeDto.setHmServiceRegion(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_SERVICE_REGION, null, null, null,null,oHomeDto.getSso()));
			oHomeDto.setHmSubRegion(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_SUB_REGION,  CommonService.getMultiList(oHomeDto.getServiceRegion()), null, null,null,oHomeDto.getSso()));
			oHomeDto.setHmCountryZone(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_COUNTRY_ZONE, CommonService.getMultiList(oHomeDto.getServiceRegion()), CommonService.getMultiList(oHomeDto.getSubRegion()), null,null,oHomeDto.getSso()));
			oHomeDto.setHmLct(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_LCT, CommonService.getMultiList(oHomeDto.getServiceRegion()), CommonService.getMultiList(oHomeDto.getSubRegion()), CommonService.getMultiList(oHomeDto.getCountryZone()),null,oHomeDto.getSso()));
			
			oHomeDto.setHmReportType(oPickListDao.getStaticListValues(MPRConstants.APP_PICKLIST_REPORT_TYPE));*/
			
		}catch (Exception e) {
			throw e;
		}finally{
			try{
				dBService.releaseResources(conn);
			}catch (Exception e) {
				throw e;
			}
		}
		
		return oHomeDto;
	}
	
	
	

		@Override
		public HomeDto getNewUserData(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();
				//oHomeDto.setHmServiceRegion(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_SERVICE_REGION, null, null, null,null,null,oHomeDto.getSso()));
				//oHomeDto.setHmModality(oPickListDao.getListValues(conn,MPRConstants.APP_PICKLIST_GROUP, null, null, null,null,null,null));
			
				//oHomeDto = homeDAO.getNewUserRegisterData(conn,oHomeDto);
				//oHomeDto = homeDAO.getModalityOne(conn,oHomeDto);
				oHomeDto.setUserSso(oHomeDto.getSso());
				oHomeDto.setUserName("");
				oHomeDto.setEmail("");
				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}
			
			return oHomeDto;
		}

		@Override
		public HomeDto getRegionDependents(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getSubRegionHome(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}

		@Override
		public HomeDto getCountryData(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getCountryHome(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}

		@Override
		public HomeDto getStatesData(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getStatesHome(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}

		@Override
		public HomeDto getModalityTwoData(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getModalityTwoData(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}

		@Override
		public HomeDto getNewUser(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.addNewUser(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}

		@Override
		public HomeDto getTurboDynValues(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getTurbDynaValues(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}
		@Override
		public HomeDto getTurbineReliabilityDrillToPi(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getTurbineReliabilityDrillToPi(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}	

		
		@Override
		public HomeDto getWeiBull(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getWeiBull(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}
		
		@Override
		public HomeDto failureByPartLife(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.failureByPartLife(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}
		@Override
		public HomeDto getTurbineWiseList(HomeDto oHomeDto) throws Exception {
			Connection conn = null;
			UserDto oUserDto = null;
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getTurbineWiseList(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}

		@Override
		public HomeDto getCriticalForecastList(HomeDto oHomeDto)
				throws Exception {
			Connection conn = null;
			
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getCriticalForecastList(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}

		@Override
		public HomeDto getSiteComparision(HomeDto oHomeDto) throws Exception {
			
			Connection conn = null;
			
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getSiteComparision(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}	
		
		
		@Override
		public HomeDto getEGTData(HomeDto oHomeDto) throws Exception{
		
            Connection conn = null;
			
			try{
				conn = dBService.getDBConnection();				
				oHomeDto = homeDAO.getEGTData(conn,oHomeDto);				
			}catch (Exception e) {
				throw e;
			}finally{
				try{
					dBService.releaseResources(conn);
				}catch (Exception e) {
					throw e;
				}
			}			
			return oHomeDto;
		}	
}
