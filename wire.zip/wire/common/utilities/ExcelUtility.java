package com.gehc.wire.common.utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFConditionalFormatting;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;

public class ExcelUtility {
	
public static HSSFWorkbook getExcelFile(ResultSet rs,String sFileName, String sheetName, int sheetNum, String excelType) throws SQLException, IOException {
		
		ResultSetMetaData rsmd = null;
		FileOutputStream oFileOutputStream = null;

		sFileName = sFileName + ".xls";

		File oFile = new File(sFileName);
		oFileOutputStream = new FileOutputStream(oFile);
		
		HSSFWorkbook wb  = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet(sheetName);
		HSSFRow row  = null;
		HSSFRow row1  = null;
		HSSFConditionalFormatting formati = null;
		sheet.autoSizeColumn(0); 
/*
 * Style for Header
 */
		HSSFCellStyle styleHeader = wb.createCellStyle();
		styleHeader.setBorderTop((short) 6); // double lines border
		styleHeader.setBorderBottom((short) 1); // single line border
		styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
		styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
		styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
		styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
		styleHeader.setWrapText(true);
		styleHeader.setVerticalAlignment(CellStyle.ALIGN_JUSTIFY);
		
        
        HSSFFont fontHeader = wb.createFont();
        fontHeader.setFontName(HSSFFont.FONT_ARIAL);
        fontHeader.setFontHeightInPoints((short) 9);
        fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        fontHeader.setColor(HSSFColor.WHITE.index);
        styleHeader.setFont(fontHeader);
        
 /*
  * Style for rest
  *        
  */
        HSSFCellStyle styleList = wb.createCellStyle();
        HSSFCellStyle styleSpecList = wb.createCellStyle();
        styleSpecList.setAlignment(CellStyle.ALIGN_CENTER);
        HSSFFont fontList = wb.createFont();
        fontList.setFontName(HSSFFont.FONT_ARIAL);
        fontList.setFontHeightInPoints((short) 8);
        styleList.setFont(fontList);
        styleSpecList.setFont(fontList);
		
		
		if(rs!=null){
			rsmd = rs.getMetaData();
			int iColumnCount = rsmd.getColumnCount();
			int iRowCount = 0;
			int iSheetNo = 1;
			
			String[] sColumnNames = new String[iColumnCount];
			String[] sValues = new String[iColumnCount];
			 row = sheet.createRow((short)0); 
			 
			
				
				for(int i=1;i<=iColumnCount;i++){
					row.createCell(i-1).setCellValue(rsmd.getColumnName(i));
					row.getCell(i-1).setCellStyle(styleHeader);
					
					row.setHeightInPoints((2*sheet.getDefaultRowHeightInPoints()));
				    //adjust column width to fit the content
					sheet.setDefaultColumnWidth(20);
				    
				}
			
			
			
			while(rs.next())
			{
				iRowCount++;
				row = sheet.createRow(iRowCount); 
				
				sValues = new String[iColumnCount];
				for (int i=1;i<=iColumnCount;i++){
					createCell(wb,row,i, HSSFCellStyle.ALIGN_CENTER, rs.getString(i));
				}
			}
				
			}
		rsmd = null;
		
		wb.write(oFileOutputStream);
		return wb;
	}





		private static void createCell(HSSFWorkbook wb, HSSFRow row, int column, short align,String value)
		{
			//Float f = Float.valueOf(value.trim()).floatValue();
			HSSFCell cell = row.createCell(column-1);
			cell.setCellValue(value);
			cell.setCellType(cell.CELL_TYPE_STRING);
			
			HSSFCellStyle cellStyle = wb.createCellStyle();
			cellStyle.setAlignment(align);
			cell.setCellStyle(cellStyle);
			cell.removeCellComment();
		}

}
