package com.gehc.wire.common.utilities;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.gehc.wire.common.dto.UserDto;


public class SendMailUtility {
	public void sendMail(String recipients[], String subject, String message, String from) throws MessagingException {
		boolean debug = false;

	     //Set the host smtp address
	     Properties props = new Properties();
	     props.put("mail.smtp.host", "mail.ad.ge.com");

	    // create some properties and get the default Session
	    Session session = Session.getDefaultInstance(props, null);
	    session.setDebug(debug);

	    // create a message
	    Message msg = new MimeMessage(session);

	    // set the from and to address
	    InternetAddress addressFrom = new InternetAddress(from);
	    msg.setFrom(addressFrom);

	    InternetAddress[] addressTo = new InternetAddress[recipients.length]; 
	    for (int i = 0; i < recipients.length; i++)
	    {
	        addressTo[i] = new InternetAddress(recipients[i]);
	    }
	    msg.setRecipients(Message.RecipientType.TO, addressTo);

	    // Optional : You can also set your custom headers in the Email if you Want
	    msg.addHeader("MyHeaderName", "myHeaderValue");

	    // Setting the Subject and Content Type
	    msg.setSubject(subject);
	    //msg.setContent(message, "text/plain");
	    msg.setContent(message, "text/html");
	    Transport.send(msg);
	}
	
/*	public void sendLoggedBugViaEmail(BugDto oBugDto) throws Exception {
          
          //String recipients[ ] = {"gauravgupta.gupta@ge.com" };
          String sSubject=""; 
          String sMessage ="";
          if(oBugDto.getIssueAddressedTo().equalsIgnoreCase("Data"))
        	  sSubject = "Data Issue: "+oBugDto.getIssueSubject();
          if(oBugDto.getIssueAddressedTo().equalsIgnoreCase("Func"))
        	  sSubject = "Functional/IT Issue: "+oBugDto.getIssueSubject();
          if(oBugDto.getIssueAddressedTo().equalsIgnoreCase("Feedback"))
        	  sSubject = "User Experience Issue : "+oBugDto.getIssueSubject();
          
          
          //String message = "this is a test mail"; 
          StringBuffer sb = new StringBuffer();
              sb.append("<html>");
              sb.append("<table>");
              sb.append("<tr>");
              sb.append("<td style=\"font-family:arial\">");
              sb.append("\""+sSubject+"\" has been raised by "+oBugDto.getLoggedByName()+" as mentioned below. ");
              sb.append("</td>");
              sb.append("</tr><br>");
             
              sb.append("<tr>");
              sb.append("<td style=\"font-family:arial;\">");
              sb.append("<b><u>Issue:</b></u>");
              sb.append("</td>");
              sb.append("</tr><br>");
              sb.append("<tr>");
              sb.append("<td style=\"font-family:arial\">");
              sb.append(oBugDto.getIssueDescription());
              sb.append("</td>");
              sb.append("</tr><br>");
              
              sb.append("<tr>");
              sb.append("<td style=\"font-family:arial;\">");
              sb.append("<b><u>Severity:</b></u>");
              sb.append("</td>");
              sb.append("</tr><br>");
              sb.append("<tr>");
              sb.append("<td style=\"font-family:arial\">");
              sb.append(oBugDto.getIssueSeverity());
              sb.append("</td>");
              sb.append("</tr><br>");
              
              sb.append("<tr>");
              sb.append("<td style=\"font-family:arial;\">");
              sb.append("<b><u>TAT:</b></u> We'll Revert back to you in next 48 hours");
              sb.append("</td>");
              sb.append("</tr><br>");

              sb.append("<tr>");
              sb.append("<td style=\"font-family:arial\">");
              sb.append("<B>Thanks - Team Double Or Bust Tool.<B>");
              sb.append("</td>");
              sb.append("</tr><br>");
               sb.append("<tr>");
              sb.append("<td style=\"font-family:arial\">");
              sb.append("(Note: Please do not reply, its an unattended mailbox.)");
              sb.append("</td>");
              sb.append("</tr>");
              sb.append("</table>");
              sb.append("</html>");

              sMessage = sb.toString();
          
              String sFrom = "DoBAdmin@ge.com";
              String[] sTo = new String[4]; 
              sTo[0] = "501760497@ge.com";
              sTo[1] = "203000615@ge.com";
              sTo[2] = "212023009@ge.com";
         //     sTo[3] = "arun.k@genpact.com";
              sTo[3] = "kalyan.chakravarthi@ge.com";
             
           
              sendMail(sTo,sSubject,sMessage,sFrom);
              
      }*/
	public void sendMail(String recipients[], String CCrecipients[],String subject, String message, String from) throws MessagingException {
		boolean debug = false;

	     //Set the host smtp address
	     Properties props = new Properties();
	     props.put("mail.smtp.host", "mail.ad.ge.com");

	    // create some properties and get the default Session
	    Session session = Session.getDefaultInstance(props, null);
	    session.setDebug(debug);

	    // create a message
	    Message msg = new MimeMessage(session);

	    // set the from and to address
	    InternetAddress addressFrom = new InternetAddress(from);
	    msg.setFrom(addressFrom);

	    InternetAddress[] addressTo = new InternetAddress[recipients.length]; 
	    for (int i = 0; i < recipients.length; i++)
	    {
	        addressTo[i] = new InternetAddress(recipients[i]);
	    }
	    msg.setRecipients(Message.RecipientType.TO, addressTo);
	    
	    InternetAddress[] addressCC = new InternetAddress[CCrecipients.length]; 
	    for (int i = 0; i < CCrecipients.length; i++)
	    {
	    	addressCC[i] = new InternetAddress(CCrecipients[i]);
	    }
	    msg.setRecipients(Message.RecipientType.CC, addressCC);

	    // Optional : You can also set your custom headers in the Email if you Want
	    msg.addHeader("MyHeaderName", "myHeaderValue");

	    // Setting the Subject and Content Type
	    msg.setSubject(subject);
	    //msg.setContent(message, "text/plain");
	    msg.setContent(message, "text/html");
	    Transport.send(msg);
	}
	
public void sendUserRequestEmail(UserDto oUserDto) throws Exception {
        
        String sSubject=""; 
        String sMessage ="";
      
      	  sSubject = "Access Request to Double or Bust Application";
        
        
        //String message = "this is a test mail"; 
        StringBuffer sb = new StringBuffer();
            sb.append("<html>");
            sb.append("<table valign=\"top\">");
            sb.append("<tr>");
            sb.append("<td style=\"font-family:arial\">");
            sb.append(sSubject+" has been raised by "+oUserDto.getLastName()+","+oUserDto.getFirstName()+" ("+oUserDto.getSSO() +") as mentioned below. ");
            sb.append("</td>");
            sb.append("</tr><br>");
           
            sb.append("<tr>");
            sb.append("<td style=\"font-family:arial;\">");
            sb.append("<b><u>For Modality(ies):</b></u>");
            sb.append("</td>");
            sb.append("</tr><br>");
            sb.append("<tr>");
            sb.append("<td style=\"font-family:arial\">");
            sb.append(oUserDto.getModality());
            sb.append("</td>");
            sb.append("</tr><br>");
            
            sb.append("<tr>");
            sb.append("<td style=\"font-family:arial;\">");
            sb.append("<b><u>Comments mentioned:</b></u>");
            sb.append("</td>");
            sb.append("</tr><br>");
            sb.append("<tr>");
            sb.append("<td style=\"font-family:arial\">");
            sb.append(oUserDto.getComments());
            sb.append("</td>");
            sb.append("</tr><br>");
           
            
            sb.append("<tr>");
            sb.append("<td style=\"font-family:arial\">");
            sb.append("<B>Thanks - Team Double or Bust Tool.<B>");
            sb.append("</td>");
            sb.append("</tr><br>");
             sb.append("<tr>");
            sb.append("<td style=\"font-family:arial\">");
            sb.append("(Note: Please do not reply, its an unattended mailbox.)");
            sb.append("</td>");
            sb.append("</tr>");
            sb.append("</table>");
            sb.append("</html>");

            sMessage = sb.toString();
        
            
            String sFrom = "DoBAdmin@ge.com";
            String[] sTo = new String[4]; 
            sTo[0] = "501760497@ge.com";
            sTo[1] = "203000615@ge.com";
            sTo[2] = "212023009@ge.com";
            sTo[3] = "kalyan.chakravarthi@ge.com";
            
            sendMail(sTo,sSubject,sMessage,sFrom);
            
    }
	public void sendApproveUserRequestEmail(UserDto oUserDto) throws Exception {
        
        String sSubject=""; 
        String sMessage ="";
      
      	  sSubject = "Your Access Request to Double or Bust Application has been approved";
        
        
        //String message = "this is a test mail"; 
        StringBuffer sb = new StringBuffer();
            sb.append("<html>");
            sb.append("<table valign=\"top\">");
            sb.append("<tr>");
            sb.append("<td style=\"font-family:arial\">");
            sb.append(sSubject);
            sb.append("</td>");
            sb.append("</tr><br>");
           
             
            sb.append("<tr>");
            sb.append("<td style=\"font-family:arial\">");
            sb.append("<B>Thanks,<br>Team Double or Bust Tool.<B>");
            sb.append("</td>");
            sb.append("</tr><br>");
             sb.append("<tr>");
            sb.append("<td style=\"font-family:arial\">");
            sb.append("(Note: Please do not reply, its an unattended mailbox.)");
            sb.append("</td>");
            sb.append("</tr>");
            sb.append("</table>");
            sb.append("</html>");

            sMessage = sb.toString();
        
            String[] sTo = {oUserDto.getSSO()+"@ge.com"};
            String sFrom = "DoBAdmin@ge.com";
            sTo[0] = "501760497@ge.com";
            sTo[1] = "203000615@ge.com";
            sTo[2] = "212023009@ge.com";
            sTo[3] = "kalyan.chakravarthi@ge.com";
            
            sendMail(sTo,sSubject,sMessage,sFrom);
            String[] sCC = {"kalyan.chakravarthi@ge.com","212023009@ge.com","203000615@ge.com","501760497@ge.com"};
            
            sendMail(sTo,sCC,sSubject,sMessage,sFrom);
            
    }
	
	public void sendRejectUserRequestEmail(UserDto oUserDto) throws Exception {
        
		  String sSubject=""; 
	        String sMessage ="";
	      
	      	  sSubject = "Your Access Request to Double or Bust Application has been rejected";
	        
	        
	        //String message = "this is a test mail"; 
	        StringBuffer sb = new StringBuffer();
	            sb.append("<html>");
	            sb.append("<table valign=\"top\">");
	            sb.append("<tr>");
	            sb.append("<td style=\"font-family:arial\">");
	            sb.append(sSubject);
	            sb.append("</td>");
	            sb.append("</tr><br>");
	           
	            sb.append("<tr>");
	            sb.append("<td style=\"font-family:arial;\">");
	            sb.append("<b><u>Comments for Rejection:</b></u>");
	            sb.append("</td>");
	            sb.append("</tr><br>");
	            sb.append("<tr>");
	            sb.append("<td style=\"font-family:arial\">");
	            sb.append(oUserDto.getComments());
	            sb.append("</td>");
	            sb.append("</tr><br>");
	             
	            sb.append("<tr>");
	            sb.append("<td style=\"font-family:arial\">");
	            sb.append("<B>Thanks,<br>Team Double or Bust Tool.<B>");
	            sb.append("</td>");
	            sb.append("</tr><br>");
	             sb.append("<tr>");
	            sb.append("<td style=\"font-family:arial\">");
	            sb.append("(Note: Please do not reply, its an unattended mailbox.)");
	            sb.append("</td>");
	            sb.append("</tr>");
	            sb.append("</table>");
	            sb.append("</html>");

	            sMessage = sb.toString();
	        
	            String[] sTo = {oUserDto.getSSO()+"@ge.com"};
	            String sFrom = "DoBAdmin@ge.com";
	            sTo[0] = "501760497@ge.com";
	            sTo[1] = "203000615@ge.com";
	            sTo[2] = "212023009@ge.com";
	            sTo[3] = "kalyan.chakravarthi@ge.com";
	            
	            sendMail(sTo,sSubject,sMessage,sFrom);
	            String[] sCC = {"kalyan.chakravarthi@ge.com","212023009@ge.com","203000615@ge.com","501760497@ge.com"};
	            
	            sendMail(sTo,sCC,sSubject,sMessage,sFrom);
            
    }
		
	}
	
	
	
	

