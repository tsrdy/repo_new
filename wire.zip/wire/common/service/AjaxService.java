package com.gehc.wire.common.service;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;

import com.gehc.wire.common.exceptions.BusinessDefinedException;
import com.gehc.wire.common.form.AjaxForm;

public interface AjaxService {
	
	StringBuffer onChangeYear(HttpServletRequest request)throws Exception;
	StringBuffer onChangeGroup(HttpServletRequest request)throws Exception;
	StringBuffer onChangeModality1(HttpServletRequest request)throws Exception;
	StringBuffer onChangeModality2(HttpServletRequest request)throws Exception;
	StringBuffer onChangeSubModality(HttpServletRequest request)throws Exception;
	StringBuffer onChangeSegment(HttpServletRequest request)throws Exception;
	StringBuffer onChangesRegion(HttpServletRequest request)throws Exception;
	
	StringBuffer onChangeRegion(HttpServletRequest request)throws Exception;
	StringBuffer onChangeSubRegion(HttpServletRequest request)throws Exception;
	StringBuffer onChangeCountry(HttpServletRequest request)throws Exception;
	String getProblemStatementForRead(String prepareDataID, String columnType)throws Exception;
	StringBuffer onChangePreAdjustSubRegion(HttpServletRequest request)throws Exception;
	
	StringBuffer getTurboDynValues(HttpServletRequest request)throws Exception;
	
}
