package com.gehc.wire.common.dto;

import java.awt.image.BufferedImage;

import com.gehc.wire.common.service.CommonService;


/**
 * @author 703092428
 * @FileName TableDto.java
 * @CreateDate Nov 26, 2012
 */
public class TableDto {
 
	public TableDto(String column1,String column2,String column3,String column4){
		this.column1 = column1;
		this.column2 = column2;
		this.column3 = column3;
		this.column4 = column4;
	}
	
	
	private String column1 = "";
	private String column2 = "";
	private String column3 = "";
	private String column4 = "";
	private String column5 = "";
	private String column6 = "";
	private String column7 = "";
	private String column8 = "";
	private String column9 = "";
	private String column10 = "";
	private String column11 = "";
	private String column12 = "";
	private String column13 = "";
	private String column14 = "";
	private String column15 = "";
	private String column16 = "";
	private String column17 = "";
	private String column18 = "";
	private String column19 = "";
	private String column20 = "";
	private String column21 = "";
	private String column22 = "";
	private String column23 = "";
	private String column24 = "";
	private String column25 = "";
	private String column26 = "";
	private String column27 = "";
	private String column28 = "";
	private String column29 = "";
	private String column30 = "";
	private String column31 = "";
	private String column32 = "";
	private String column33 = "";
	private String column34 = "";
	private String column35 = "";
	private String column36 = "";
	private String column37 = "";
	private String column38 = "";
	private String column39 = "";
	private String column40 = "";
	private String column41 = "";
	private String column42 = "";
	private String column43 = "";
	private String column44 = "";
	private String column45 = "";
	private String column46= "";
	private String column47 = "";
	private String column48 = "";
	private String column49 = "";
	private String column50 = "";
	private String column51 = "";
	private String column52 = "";
	private String column53 = "";
	private String column54 = "";
	private String column55 = "";
	private String column56 = "";
	private String column57 = "";
	private String column58 = "";
	private String column59 = "";
	private String column60 = "";
	
	
	private BufferedImage image = null;
	private String imageOrder = null;
	private String reportType = null;
	private int columnCount = 0;
	private int fixedCols = 0;
	private int noOfQtrs = 0;
	private String reportURL = null;
	private String status = null;
	private String validationMessage = null;
	
	
	
	
	
	
	
	
	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getValidationMessage() {
		return validationMessage;
	}


	public void setValidationMessage(String validationMessage) {
		this.validationMessage = validationMessage;
	}


	public int getFixedCols() {
		return fixedCols;
	}


	public void setFixedCols(int fixedCols) {
		this.fixedCols = fixedCols;
	}


	public int getNoOfQtrs() {
		return noOfQtrs;
	}


	public void setNoOfQtrs(int noOfQtrs) {
		this.noOfQtrs = noOfQtrs;
	}


	public TableDto() {
		super();
	}


	public TableDto(String column1,String column2,String column3,String column4,String column5,String column6,String column7,String column8,String column9,String column10,
			String column11,String column12,String column13,String column14,String column15,String column16,String column17,String column18,String column19,String column20,
			String column21,String column22,String column23,String column24,String column25,String column26)
			
		/*	,String column27,String column28,String column29,String column30,
			String column31,String column32,String column33,String column34,String column35,String column36,String column37,String column38,String column39,String column40,
			String column41,String column42,String column43,String column44,String column45,String column46,String column47,String column48,String column49,String column50,
			String column51,String column52,String column53,String column54,String column55,String column56,String column57,String column58,String column59,String column60) 
*/	{
		 this.column1 = column1;
		 this.column2 = column2;
		 this.column3 = column3;
		 this.column4 = column4;
		 this.column5 = column5;
		 this.column6 = column6;
		 this.column7 = column7;
		 this.column8 = column8;
		 this.column9 = column9;
		 this.column10 = column10;
		 this.column11 = column11;
		 this.column12 = column12;
		 this.column13 = column13;
		 this.column14 = column14;
		 this.column15 = column15;
		 this.column16 = column16;
		 this.column17 = column17;
		 this.column18 = column18;
		 this.column19 = column19;
		 this.column20 = column20;
		 this.column21 = column21;
		 this.column22 = column22;
		 this.column23 = column23;
		 this.column24 = column24;
		 this.column25 = column25;
		 this.column26 = column26;
		 /*this.column27 = column27;
		 this.column28 = column28;
		 this.column29 = column29;
		 this.column30 = column30;
		 this.column31 = column31;
		 this.column32 = column32;
		 this.column33 = column33;
		 this.column34 = column34;
		 this.column35 = column35;
		 this.column36 = column36;
		 this.column37 = column37;
		 this.column38 = column38;
		 this.column39 = column39;
		 this.column40 = column40;
		 this.column41 = column41;
		 this.column42 = column42;
		 this.column43 = column43;
		 this.column44 = column44;
		 this.column45 = column45;
		 this.column46 = column46;
		 this.column47 = column47;
		 this.column48 = column48;
		 this.column49 = column49;
		 this.column50 = column50;
		 this.column51 = column51;
		 this.column52 = column52;
		 this.column53 = column53;
		 this.column54 = column54;
		 this.column55 = column55;
		 this.column56 = column56;
		 this.column57 = column57;
		 this.column58 = column58;
		 this.column59 = column59;
		 this.column60 = column60;*/
	}
	
	
	
	
	
	
	
	
	
	public String getReportURL() {
		return reportURL;
	}
	public void setReportURL(String reportURL) {
		this.reportURL = reportURL;
	}
	public String getColumn1() {
		return CommonService.replaceEmptyWithNull(column1);
	}
	public void setColumn1(String column1) {
		this.column1 = column1;
	}
	public String getColumn2() {
		return CommonService.replaceEmptyWithNull(column2);
	}
	public void setColumn2(String column2) {
		this.column2 = column2;
	}
	public String getColumn3() {
		return CommonService.replaceEmptyWithNull(column3);
	}
	public void setColumn3(String column3) {
		this.column3 = column3;
	}
	public String getColumn4() {
		return CommonService.replaceEmptyWithNull(column4);
	}
	public void setColumn4(String column4) {
		this.column4 = column4;
	}
	public String getColumn5() {
		return CommonService.replaceEmptyWithNull(column5);
	}
	public void setColumn5(String column5) {
		this.column5 = column5;
	}
	public String getColumn6() {
		return CommonService.replaceEmptyWithNull(column6);
	}
	public void setColumn6(String column6) {
		this.column6 = column6;
	}
	public String getColumn7() {
		return CommonService.replaceEmptyWithNull(column7);
	}
	public void setColumn7(String column7) {
		this.column7 = column7;
	}
	public String getColumn8() {
		return CommonService.replaceEmptyWithNull(column8);
	}
	public void setColumn8(String column8) {
		this.column8 = column8;
	}
	public String getColumn9() {
		return CommonService.replaceEmptyWithNull(column9);
	}
	public void setColumn9(String column9) {
		this.column9 = column9;
	}
	public String getColumn10() {
		return CommonService.replaceEmptyWithNull(column10);
	}
	public void setColumn10(String column10) {
		this.column10 = column10;
	}
	public String getColumn11() {
		return CommonService.replaceEmptyWithNull(column11);
	}
	public void setColumn11(String column11) {
		this.column11 = column11;
	}
	public String getColumn12() {
		return CommonService.replaceEmptyWithNull(column12);
	}
	public void setColumn12(String column12) {
		this.column12 = column12;
	}
	public String getColumn13() {
		return CommonService.replaceEmptyWithNull(column13);
	}
	public void setColumn13(String column13) {
		this.column13 = column13;
	}
	public String getColumn14() {
		return CommonService.replaceEmptyWithNull(column14);
	}
	public void setColumn14(String column14) {
		this.column14 = column14;
	}
	public String getColumn15() {
		return CommonService.replaceEmptyWithNull(column15);
	}
	public void setColumn15(String column15) {
		this.column15 = column15;
	}
	public String getColumn16() {
		return CommonService.replaceEmptyWithNull(column16);
	}
	public void setColumn16(String column16) {
		this.column16 = column16;
	}
	public String getColumn17() {
		return CommonService.replaceEmptyWithNull(column17);
	}
	public void setColumn17(String column17) {
		this.column17 = column17;
	}
	public String getColumn18() {
		return CommonService.replaceEmptyWithNull(column18);
	}
	public void setColumn18(String column18) {
		this.column18 = column18;
	}
	public String getColumn19() {
		return CommonService.replaceEmptyWithNull(column19);
	}
	public void setColumn19(String column19) {
		this.column19 = column19;
	}
	public String getColumn20() {
		return CommonService.replaceEmptyWithNull(column20);
	}
	public void setColumn20(String column20) {
		this.column20 = column20;
	}
	/**
	 * @return the column21
	 */
	public String getColumn21() {
		return column21;
	}
	/**
	 * @param column21 the column21 to set
	 */
	public void setColumn21(String column21) {
		this.column21 = column21;
	}
	/**
	 * @return the column22
	 */
	public String getColumn22() {
		return column22;
	}
	/**
	 * @param column22 the column22 to set
	 */
	public void setColumn22(String column22) {
		this.column22 = column22;
	}
	/**
	 * @return the column23
	 */
	public String getColumn23() {
		return column23;
	}
	/**
	 * @param column23 the column23 to set
	 */
	public void setColumn23(String column23) {
		this.column23 = column23;
	}
	/**
	 * @return the column24
	 */
	public String getColumn24() {
		return column24;
	}
	/**
	 * @param column24 the column24 to set
	 */
	public void setColumn24(String column24) {
		this.column24 = column24;
	}
	/**
	 * @return the column25
	 */
	public String getColumn25() {
		return column25;
	}
	/**
	 * @param column25 the column25 to set
	 */
	public void setColumn25(String column25) {
		this.column25 = column25;
	}
	/**
	 * @return the column26
	 */
	public String getColumn26() {
		return column26;
	}
	/**
	 * @param column26 the column26 to set
	 */
	public void setColumn26(String column26) {
		this.column26 = column26;
	}
	/**
	 * @return the column28
	 */
	public String getColumn28() {
		return column28;
	}
	/**
	 * @param column28 the column28 to set
	 */
	public void setColumn28(String column28) {
		this.column28 = column28;
	}
	/**
	 * @return the column29
	 */
	public String getColumn29() {
		return column29;
	}
	/**
	 * @param column29 the column29 to set
	 */
	public void setColumn29(String column29) {
		this.column29 = column29;
	}
	/**
	 * @return the column30
	 */
	public String getColumn30() {
		return column30;
	}
	/**
	 * @param column30 the column30 to set
	 */
	public void setColumn30(String column30) {
		this.column30 = column30;
	}
	/**
	 * @return the column27
	 */
	public String getColumn27() {
		return column27;
	}
	/**
	 * @param column27 the column27 to set
	 */
	public void setColumn27(String column27) {
		this.column27 = column27;
	}
	
	
	
	/**
	 * @return the column31
	 */
	public String getColumn31() {
		return column31;
	}
	/**
	 * @param column31 the column31 to set
	 */
	public void setColumn31(String column31) {
		this.column31 = column31;
	}
	/**
	 * @return the column32
	 */
	public String getColumn32() {
		return column32;
	}
	/**
	 * @param column32 the column32 to set
	 */
	public void setColumn32(String column32) {
		this.column32 = column32;
	}
	/**
	 * @return the column33
	 */
	public String getColumn33() {
		return column33;
	}
	/**
	 * @param column33 the column33 to set
	 */
	public void setColumn33(String column33) {
		this.column33 = column33;
	}
	/**
	 * @return the column34
	 */
	public String getColumn34() {
		return column34;
	}
	/**
	 * @param column34 the column34 to set
	 */
	public void setColumn34(String column34) {
		this.column34 = column34;
	}
	/**
	 * @return the column35
	 */
	public String getColumn35() {
		return column35;
	}
	/**
	 * @param column35 the column35 to set
	 */
	public void setColumn35(String column35) {
		this.column35 = column35;
	}
	/**
	 * @return the column36
	 */
	public String getColumn36() {
		return column36;
	}
	/**
	 * @param column36 the column36 to set
	 */
	public void setColumn36(String column36) {
		this.column36 = column36;
	}
	/**
	 * @return the column37
	 */
	public String getColumn37() {
		return column37;
	}
	/**
	 * @param column37 the column37 to set
	 */
	public void setColumn37(String column37) {
		this.column37 = column37;
	}
	/**
	 * @return the column38
	 */
	public String getColumn38() {
		return column38;
	}
	/**
	 * @param column38 the column38 to set
	 */
	public void setColumn38(String column38) {
		this.column38 = column38;
	}
	/**
	 * @return the column39
	 */
	public String getColumn39() {
		return column39;
	}
	/**
	 * @param column39 the column39 to set
	 */
	public void setColumn39(String column39) {
		this.column39 = column39;
	}
	/**
	 * @return the column40
	 */
	public String getColumn40() {
		return column40;
	}
	/**
	 * @param column40 the column40 to set
	 */
	public void setColumn40(String column40) {
		this.column40 = column40;
	}
	/**
	 * @return the column41
	 */
	public String getColumn41() {
		return column41;
	}
	/**
	 * @param column41 the column41 to set
	 */
	public void setColumn41(String column41) {
		this.column41 = column41;
	}
	/**
	 * @return the column42
	 */
	public String getColumn42() {
		return column42;
	}
	/**
	 * @param column42 the column42 to set
	 */
	public void setColumn42(String column42) {
		this.column42 = column42;
	}
	/**
	 * @return the column43
	 */
	public String getColumn43() {
		return column43;
	}
	/**
	 * @param column43 the column43 to set
	 */
	public void setColumn43(String column43) {
		this.column43 = column43;
	}
	/**
	 * @return the column44
	 */
	public String getColumn44() {
		return column44;
	}
	/**
	 * @param column44 the column44 to set
	 */
	public void setColumn44(String column44) {
		this.column44 = column44;
	}
	/**
	 * @return the column45
	 */
	public String getColumn45() {
		return column45;
	}
	/**
	 * @param column45 the column45 to set
	 */
	public void setColumn45(String column45) {
		this.column45 = column45;
	}
	/**
	 * @return the column46
	 */
	public String getColumn46() {
		return column46;
	}
	/**
	 * @param column46 the column46 to set
	 */
	public void setColumn46(String column46) {
		this.column46 = column46;
	}
	/**
	 * @return the column47
	 */
	public String getColumn47() {
		return column47;
	}
	/**
	 * @param column47 the column47 to set
	 */
	public void setColumn47(String column47) {
		this.column47 = column47;
	}
	/**
	 * @return the column48
	 */
	public String getColumn48() {
		return column48;
	}
	/**
	 * @param column48 the column48 to set
	 */
	public void setColumn48(String column48) {
		this.column48 = column48;
	}
	/**
	 * @return the column49
	 */
	public String getColumn49() {
		return column49;
	}
	/**
	 * @param column49 the column49 to set
	 */
	public void setColumn49(String column49) {
		this.column49 = column49;
	}
	/**
	 * @return the column50
	 */
	public String getColumn50() {
		return column50;
	}
	/**
	 * @param column50 the column50 to set
	 */
	public void setColumn50(String column50) {
		this.column50 = column50;
	}
	/**
	 * @return the column51
	 */
	public String getColumn51() {
		return column51;
	}
	/**
	 * @param column51 the column51 to set
	 */
	public void setColumn51(String column51) {
		this.column51 = column51;
	}
	/**
	 * @return the column52
	 */
	public String getColumn52() {
		return column52;
	}
	/**
	 * @param column52 the column52 to set
	 */
	public void setColumn52(String column52) {
		this.column52 = column52;
	}
	/**
	 * @return the column53
	 */
	public String getColumn53() {
		return column53;
	}
	/**
	 * @param column53 the column53 to set
	 */
	public void setColumn53(String column53) {
		this.column53 = column53;
	}
	/**
	 * @return the column54
	 */
	public String getColumn54() {
		return column54;
	}
	/**
	 * @param column54 the column54 to set
	 */
	public void setColumn54(String column54) {
		this.column54 = column54;
	}
	/**
	 * @return the column55
	 */
	public String getColumn55() {
		return column55;
	}
	/**
	 * @param column55 the column55 to set
	 */
	public void setColumn55(String column55) {
		this.column55 = column55;
	}
	/**
	 * @return the column56
	 */
	public String getColumn56() {
		return column56;
	}
	/**
	 * @param column56 the column56 to set
	 */
	public void setColumn56(String column56) {
		this.column56 = column56;
	}
	/**
	 * @return the column57
	 */
	public String getColumn57() {
		return column57;
	}
	/**
	 * @param column57 the column57 to set
	 */
	public void setColumn57(String column57) {
		this.column57 = column57;
	}
	/**
	 * @return the column58
	 */
	public String getColumn58() {
		return column58;
	}
	/**
	 * @param column58 the column58 to set
	 */
	public void setColumn58(String column58) {
		this.column58 = column58;
	}
	/**
	 * @return the column59
	 */
	public String getColumn59() {
		return column59;
	}
	/**
	 * @param column59 the column59 to set
	 */
	public void setColumn59(String column59) {
		this.column59 = column59;
	}
	/**
	 * @return the column60
	 */
	public String getColumn60() {
		return column60;
	}
	/**
	 * @param column60 the column60 to set
	 */
	public void setColumn60(String column60) {
		this.column60 = column60;
	}
	/**
	 * @return the image
	 */
	public BufferedImage getImage() {
		return image;
	}
	/**
	 * @param image the image to set
	 */
	public void setImage(BufferedImage image) {
		this.image = image;
	}
	/**
	 * @return the imageOrder
	 */
	public String getImageOrder() {
		return imageOrder;
	}
	/**
	 * @param imageOrder the imageOrder to set
	 */
	public void setImageOrder(String imageOrder) {
		this.imageOrder = imageOrder;
	}
	/**
	 * @return the reportType
	 */
	public String getReportType() {
		return reportType;
	}
	/**
	 * @param reportType the reportType to set
	 */
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	public void setColumnValue (int columnCount,String columnValue) {
		columnValue =columnValue==null?"":columnValue;
		if(columnCount==1)this.column1 = columnValue;
		if(columnCount==2)this.column2 = columnValue;
		if(columnCount==3)this.column3 = columnValue;
		if(columnCount==4)this.column4 = columnValue;
		if(columnCount==5)this.column5 = columnValue;
		if(columnCount==6)this.column6 = columnValue;
		if(columnCount==7)this.column7 = columnValue;
		if(columnCount==8)this.column8 = columnValue;
		if(columnCount==9)this.column9= columnValue;
		if(columnCount==10)this.column10 = columnValue;
		if(columnCount==11)this.column11 = columnValue;
		if(columnCount==12)this.column12 = columnValue;
		if(columnCount==13)this.column13 = columnValue;
		if(columnCount==14)this.column14 = columnValue;
		if(columnCount==15)this.column15 = columnValue;
		if(columnCount==16)this.column16 = columnValue;
		if(columnCount==17)this.column17 = columnValue;
		if(columnCount==18)this.column18 = columnValue;
		if(columnCount==19)this.column19 = columnValue;
		if(columnCount==20)this.column20 = columnValue;
		if(columnCount==21)this.column21 = columnValue;
		if(columnCount==22)this.column22 = columnValue;
		if(columnCount==23)this.column23 = columnValue;
		if(columnCount==24)this.column24 = columnValue;
		if(columnCount==25)this.column25 = columnValue;
		if(columnCount==26)this.column26 = columnValue;
		if(columnCount==27)this.column27 = columnValue;
		if(columnCount==28)this.column28 = columnValue;
		if(columnCount==29)this.column29 = columnValue;
		if(columnCount==30)this.column30 = columnValue;
		if(columnCount==31)this.column31 = columnValue;
		if(columnCount==32)this.column32 = columnValue;
		if(columnCount==33)this.column33 = columnValue;
		if(columnCount==34)this.column34 = columnValue;
		if(columnCount==35)this.column35 = columnValue;
		if(columnCount==36)this.column36 = columnValue;
		if(columnCount==37)this.column37 = columnValue;
		if(columnCount==38)this.column38 = columnValue;
		if(columnCount==39)this.column39 = columnValue;
		if(columnCount==40)this.column40 = columnValue;
		if(columnCount==41)this.column41 = columnValue;
		if(columnCount==42)this.column42 = columnValue;
		if(columnCount==43)this.column43 = columnValue;
		if(columnCount==44)this.column44 = columnValue;
		if(columnCount==45)this.column45 = columnValue;
		if(columnCount==46)this.column46 = columnValue;
		if(columnCount==47)this.column47 = columnValue;
		if(columnCount==48)this.column48 = columnValue;
		if(columnCount==49)this.column49 = columnValue;
		if(columnCount==50)this.column50 = columnValue;
		if(columnCount==51)this.column51 = columnValue;
	}
	public String getColumnValue (int columnCount) {
		if(columnCount==1)return "ztotal".equalsIgnoreCase(this.column1)?"Total":this.column1==null?"":column1;
		else if(columnCount==2)return column2==null?"":column2;
		else if(columnCount==3)return column3==null?"":column3;
		else if(columnCount==4)return column4==null?"":column4;
		else if(columnCount==5)return column5==null?"":column5;
		else if(columnCount==6)return column6==null?"":column6;
		else if(columnCount==7)return column7==null?"":column7;
		else if(columnCount==8)return column8==null?"":column8;
		else if(columnCount==9)return column9==null?"":column9;
		else if(columnCount==10)return column10==null?"":column10;
		else if(columnCount==11)return column11==null?"":column11;
		else if(columnCount==12)return column12==null?"":column12;
		else if(columnCount==13)return column13==null?"":column13;
		else if(columnCount==14)return column14==null?"":column14;
		else if(columnCount==15)return column15==null?"":column15;
		else if(columnCount==16)return column16==null?"":column16;
		else if(columnCount==17)return column17==null?"":column17;
		else if(columnCount==18)return column18;
		else if(columnCount==19)return column19;
		else if(columnCount==20)return column20;
		else if(columnCount==21)return column21;
		else if(columnCount==22)return column22;
		else if(columnCount==23)return column23;
		else if(columnCount==24)return column24;
		else if(columnCount==25)return column25;
		else if(columnCount==26)return column26;
		else if(columnCount==27)return column27;
		else if(columnCount==28)return column28;
		else if(columnCount==29)return column29;
		else if(columnCount==30)return column30;
		else if(columnCount==31)return column31;
		else if(columnCount==32)return column32;
		else if(columnCount==33)return column33;
		else if(columnCount==34)return column34;
		else if(columnCount==35)return column35;
		else if(columnCount==36)return column36;
		else if(columnCount==37)return column37;
		else if(columnCount==38)return column38;
		else if(columnCount==39)return column39;
		else if(columnCount==40)return column40;
		else if(columnCount==41)return column41;
		else if(columnCount==42)return column42;
		else if(columnCount==43)return column43;
		else if(columnCount==44)return column44;
		else if(columnCount==45)return column45;
		else if(columnCount==46)return column46;
		else if(columnCount==47)return column47;
		else if(columnCount==48)return column48;
		else if(columnCount==49)return column49;
		else if(columnCount==50)return column50;
		else if(columnCount==51)return column51;
		else return "-";
		
	}
	public String getColumnValueAsNum (int columnCount) {
		if(columnCount==1)return (this.column1==null||"".equals(this.column1))?"-":this.column1;
		else if(columnCount==2)return (this.column2==null||"".equals(this.column2))?"-":this.column2;
		else if(columnCount==3)return (this.column3==null||"".equals(this.column3))?"-":this.column3;
		else if(columnCount==4)return(this.column4==null||"".equals(this.column4))?"-":this.column4;
		else if(columnCount==5)return (this.column5==null||"".equals(this.column5))?"-":this.column5;
		else if(columnCount==6)return (this.column6==null||"".equals(this.column6))?"-":this.column6;
		else if(columnCount==7)return (this.column7==null||"".equals(this.column7))?"-":this.column7;
		else if(columnCount==8)return (this.column8==null||"".equals(this.column8))?"-":this.column8;
		else if(columnCount==9)return (this.column9==null||"".equals(this.column9))?"-":this.column9;
		else if(columnCount==10)return (this.column10==null||"".equals(this.column10))?"-":this.column10;
		else if(columnCount==11)return (this.column11==null||"".equals(this.column11))?"-":this.column11;
		else if(columnCount==12)return (this.column12==null||"".equals(this.column12))?"-":this.column12;
		else if(columnCount==13)return (this.column13==null||"".equals(this.column13))?"-":this.column13;
		else if(columnCount==14)return (this.column14==null||"".equals(this.column14))?"-":this.column14;
		else if(columnCount==15)return (this.column15==null||"".equals(this.column15))?"-":this.column15;
		else if(columnCount==16)return (this.column16==null||"".equals(this.column16))?"-":this.column16;
		else if(columnCount==17)return (this.column17==null||"".equals(this.column17))?"-":this.column17;
		else if(columnCount==18)return (this.column18==null||"".equals(this.column18))?"-":this.column18;
		else if(columnCount==19)return (this.column19==null||"".equals(this.column19))?"-":this.column19;
		else if(columnCount==20)return (this.column20==null||"".equals(this.column20))?"-":this.column20;
		else if(columnCount==21)return (this.column21==null||"".equals(this.column21))?"-":this.column21;
		else if(columnCount==22)return (this.column22==null||"".equals(this.column22))?"-":this.column22;
		else if(columnCount==23)return (this.column23==null||"".equals(this.column23))?"-":this.column23;
		else if(columnCount==24)return (this.column24==null||"".equals(this.column24))?"-":this.column24;
		else if(columnCount==25)return (this.column25==null||"".equals(this.column25))?"-":this.column25;
		else if(columnCount==26)return (this.column26==null||"".equals(this.column26))?"-":this.column26;
		else if(columnCount==27)return (this.column27==null||"".equals(this.column27))?"-":this.column27;
		else if(columnCount==28)return (this.column28==null||"".equals(this.column28))?"-":this.column28;
		else if(columnCount==29)return (this.column29==null||"".equals(this.column29))?"-":this.column29;
		else if(columnCount==30)return (this.column30==null||"".equals(this.column30))?"-":this.column30;
		
		else if(columnCount==31)return (this.column31==null||"".equals(this.column31))?"-":this.column31;
		else if(columnCount==32)return (this.column32==null||"".equals(this.column32))?"-":this.column32;
		else if(columnCount==33)return (this.column33==null||"".equals(this.column33))?"-":this.column33;
		else if(columnCount==34)return (this.column34==null||"".equals(this.column34))?"-":this.column34;
		else if(columnCount==35)return (this.column35==null||"".equals(this.column35))?"-":this.column35;
		else if(columnCount==36)return (this.column36==null||"".equals(this.column36))?"-":this.column36;
		else if(columnCount==37)return (this.column37==null||"".equals(this.column37))?"-":this.column37;
		else if(columnCount==38)return (this.column38==null||"".equals(this.column38))?"-":this.column38;
		else if(columnCount==39)return (this.column39==null||"".equals(this.column39))?"-":this.column39;
		else if(columnCount==40)return (this.column40==null||"".equals(this.column40))?"-":this.column40;
		
		else if(columnCount==41)return (this.column41==null||"".equals(this.column41))?"-":this.column41;
		else if(columnCount==42)return (this.column42==null||"".equals(this.column42))?"-":this.column42;
		else if(columnCount==43)return (this.column43==null||"".equals(this.column43))?"-":this.column43;
		else if(columnCount==44)return (this.column44==null||"".equals(this.column44))?"-":this.column44;
		else if(columnCount==45)return (this.column45==null||"".equals(this.column45))?"-":this.column45;
		else if(columnCount==46)return (this.column46==null||"".equals(this.column46))?"-":this.column46;
		else if(columnCount==47)return (this.column47==null||"".equals(this.column47))?"-":this.column47;
		else if(columnCount==48)return (this.column48==null||"".equals(this.column48))?"-":this.column48;
		else if(columnCount==49)return (this.column49==null||"".equals(this.column49))?"-":this.column49;
		else if(columnCount==50)return (this.column50==null||"".equals(this.column50))?"-":this.column50;
		
		
		
		else return "-";
		
	}
	public int getColumnCount() {
		return columnCount;
	}
	public void setColumnCount(int columnCount) {
		this.columnCount = columnCount;
	}
	
}