package com.gehc.wire.common.dao;

import java.sql.Connection;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.gehc.wire.common.form.AjaxForm;


public interface ExcelDao{

	

	HSSFWorkbook writeTableData(Connection con,HSSFWorkbook sampleWorkbook, HSSFSheet sampleDataSheet,HSSFPatriarch patriarch)throws Exception;;
	
}
