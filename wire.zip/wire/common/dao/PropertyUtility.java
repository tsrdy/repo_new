package com.gehc.wire.common.dao;

import java.util.ResourceBundle;

public class PropertyUtility {

		  public static String getProperty(String sBundleName,String sPropsKey)
		                               {
		   try{
			   	ResourceBundle bundle = ResourceBundle.getBundle(sBundleName);
			   	return bundle.getString(sPropsKey); 
		   	}catch(Exception e){
		   		e.printStackTrace();
		   	}finally{
		   		
		   	}
		   	
		   	return null;
		  }


}
