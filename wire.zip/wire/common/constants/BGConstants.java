package com.gehc.wire.common.constants;

/**
 * @author 703092428
 * @FileName BGConstants.java
 * @DataOfCreation Jun 24, 2013
 */
public class BGConstants{

	/*
	 * The below constants are used in Ajax calls
	 */
	public static final Object APP_ADMINLOOKUP_TARGETTYPE_COMBO = "comboBox";
	public static final Object APP_ADMINLOOKUP_TARGETTYPE_TEXT = "textData";
	public static final String APP_ADMINLOOKUP_TARGETTYPE_DEFAULT = "comboBox";
	public static final String APP_ADMINLOOKUP_TARGETOBJECTS = "targetObjects";
	public static final String APP_REQUEST_CANINCLUDE_INACTIVE = "canIncludeInactive";
	public static final String APP_ADMINLOOKUP_SELECTEDOPTION = "selectedOption";

	
	
	/*
	 * The below Constant is user to identify user's session object
	 */
	public static final String APP_LOGINUSER_INFO = "loginUserInfo";
	
	/*
	 * Application properties file name
	 */
	public static final String APP_PRPPERTIES_FILE = "app";
	/*
	 * Data Source related constants
	 */
	public static final String APP_DS_NAME = "APP_DS_NAME";
	public static final String APP_DS_ENV = "APP_DS_ENV";
	public static final String APP_UPLOAD_PATH = "APP_UPLOAD_PATH";
	public static final String APP_DOWNLOAD_PATH = "APP_DOWNLOAD_PATH";
	public static final String APP_LOCAL_HEADER_PATH = "APP_LOCAL_HEADER_PATH";
	public static final String APP_LOCAL_FOOTER_PATH = "APP_LOCAL_FOOTER_PATH";

	public static final String APP_DB_SCHEMA = "APP_DB_SCHEMA";
	
	
	
	public static final String APP_SERVER = "APP_SERVER";
	public static final String APP_FILTER_YEAR = "YEAR";
	public static final String APP_FILTER_YEAR_DATE = "YEAR_DATE";
	public static final String APP_FILTER_REGION = "REGION";
	public static final String APP_FILTER_MODALITY = "MODALITY";
	public static final String APP_FILTER_VIEW = "VIEW";
	public static final String APP_FILTER_DATES_YEAR = "DATESYEAR";
	public static final String APP_FILTER_TIME_LINE_TYPE = "TIME_LINE_TYPE";
	public static final String APP_FILTER_BU_TIMELINE = "TIMELINE_BU";
	public static final String APP_MAIL_SERVER = "APP_MAIL_SERVER";
	public static final String APP_MAILSERVER_USERNAME = "APP_MAILSERVER_USERNAME";
	public static final String APP_MAILSERVER_PASSWORD = "APP_MAILSERVER_PASSWORD";
	public static final String APP_PICKLIST_HIGHLEVELGROUPING = "APP_PICKLIST_HIGHLEVELGROUPING";
	public static final String APP_PICKLIST_QUOTETERM = "APP_PICKLIST_QUOTETERM";
	public static final String APP_PICKLIST_NUMBEROFYEARS = "APP_PICKLIST_NUMBEROFYEARS";
	public static final String APP_PICKLIST_QUOTEPCSOPTIONS = "APP_PICKLIST_QUOTEPCSOPTIONS";
	public static final String APP_PICKLIST_TELEMETARYOPTIONS = "APP_PICKLIST_TELEMETARYOPTIONS";
	public static final String APP_PICKLIST_SQFT = "APP_PICKLIST_SQFT";
	public static final String APP_PICKLIST_MONTH = "APP_PICKLIST_MONTH";
	public static final String APP_PICKLIST_BILLINGTYPE = "APP_PICKLIST_BILLINGTYPE";
	public static final String APP_ADMINLOOKUP_TYPE = "type";
	public static final String APP_ADMINLOOKUP_SEVERITY = "severity";
	public static final String APP_ADMINLOOKUP_SUBJECT = "subject";
	public static final String APP_ADMINLOOKUP_FEEDBACKDESC = "feedIssiesDesc";
	public static final String APP_ADMINLOOKUP_ISSUEID = "issueId";
	public static final String APP_ADMINLOOKUP_COMMENTS = "comments";
	public static final String APP_ADMINLOOKUP_STATUS = "feedBackStatus";
	public static final String APP_FILTER_COMPETITIORS_LIST = "COMPETITIORS_LIST";
	public static final String APP_FILTER_VIEW_VARIABLE_LIST = "VIEW_VARIABLE_LIST";
	public static final String APP_FILTER_VIEW_VARIABLE_OP_LIST = "VIEW_VARIABLE_OP_LIST";
	public static final String APP_DB_DNS = "APP_DB_DNS";
	
	
	
	
	
}