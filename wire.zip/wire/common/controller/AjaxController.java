package com.gehc.wire.common.controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gehc.wire.common.service.AjaxService;
import com.gehc.wire.common.service.DBService;
import com.gehc.wire.home.dto.GraphDto;
import com.gehc.wire.home.form.GraphForm;
import com.gehc.wire.home.service.GraphService;


/**
 * @author 703092428
 * @FileName AjaxController.java
 * @DataOfCreation Jun 24, 2013
 */
@Controller 

public class AjaxController{
		private static final Logger logger = Logger.getLogger(AjaxController.class);
		
	@Autowired
	private AjaxService  ajaxService;
	
	@Autowired
	private GraphService  graphService;

	@Autowired
	private DBService dBService;
	
	@Autowired
	public void setAjaxService(AjaxService ajaxService) {
		this.ajaxService = ajaxService;
	}


	
	public void setdBService(DBService dBService) {
		this.dBService = dBService;
	}
	
	@Autowired
	public void setGraphService(GraphService graphService) {
		this.graphService = graphService;
	}

	
	
	@RequestMapping(value = "/getTurbineDynamic.jpage")
	public String TurbineDynaValues(@ModelAttribute("home") GraphForm oGraphForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		
		try{	
			
			
			GraphDto oGraphDto = new GraphDto();
			BeanUtils.copyProperties(oGraphDto, oGraphForm);
	
			oGraphDto = graphService.getTurboDynValues(oGraphDto);
			
			BeanUtils.copyProperties(oGraphForm, oGraphDto);
					
		    model.addAttribute("turboGraph", oGraphForm);
		    page = "turboGrpVals";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}


	
	@RequestMapping(value = "/getDTFailure.jpage")
	public String DTFailureDynaValues(@ModelAttribute("home") GraphForm oGraphForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		
		try{	
			
			
			GraphDto oGraphDto = new GraphDto();
			BeanUtils.copyProperties(oGraphDto, oGraphForm);
	
			oGraphDto = graphService.getDTFailureDynaValues(oGraphDto);
			
			BeanUtils.copyProperties(oGraphForm, oGraphDto);
					
		    model.addAttribute("DTFailureGraph", oGraphForm);
		    page = "DTFailureGraphVals";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}

	@RequestMapping(value = "/getAlarmDetectionValues.jpage" )
	public String getAlarmDetectionValues(@RequestParam("chartCase") String chartCase, @ModelAttribute("home") GraphForm oGraphForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		
		try{	
			
			
			GraphDto oGraphDto = new GraphDto();
			BeanUtils.copyProperties(oGraphDto, oGraphForm);
	
			oGraphDto = graphService.getAlarmDetectionValues(oGraphDto, chartCase);
			
			BeanUtils.copyProperties(oGraphForm, oGraphDto);
					
		    model.addAttribute("alarmDetectionValues", oGraphForm);
		    page = "alarmDetectionData";
			}
			catch (Exception e) {
				e.printStackTrace();
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}
	
	@RequestMapping(value = "/getEGTChartData.jpage" )
	@ResponseBody
	public GraphDto getEGTChartData(@RequestParam("chartCase") String chartCase, @ModelAttribute("home") GraphForm oGraphForm, HttpServletRequest request,HttpServletResponse response) {
		
		
		GraphDto oGraphDto = new GraphDto();
		try{	
			
			
			
			BeanUtils.copyProperties(oGraphDto, oGraphForm);
	
			oGraphDto = graphService.getEGTChartData(oGraphDto, chartCase);
			
			BeanUtils.copyProperties(oGraphForm, oGraphDto);
					
		   
			}
			catch (Exception e) {
				e.printStackTrace();
				
				logger.error(e.getMessage());
			}finally {
			}
			return oGraphDto;
	}

	

	@RequestMapping(value = "/getEGTChartDataFour.jpage" )
	@ResponseBody
	public GraphDto getEGTChartDataFour(@RequestParam("chartCase") String chartCase, @ModelAttribute("home") GraphForm oGraphForm, HttpServletRequest request,HttpServletResponse response) {
		
		
		GraphDto oGraphDto = new GraphDto();
		try{	
			
			
			
			BeanUtils.copyProperties(oGraphDto, oGraphForm);
	
			oGraphDto = graphService.getEGTChartDataFour(oGraphDto, chartCase);
			
			BeanUtils.copyProperties(oGraphForm, oGraphDto);
					
		   
			}
			catch (Exception e) {
				e.printStackTrace();
				
				logger.error(e.getMessage());
			}finally {
			}
			return oGraphDto;
	}

	

	
	@RequestMapping(value = "/getEGTChartData3.jpage" )
	@ResponseBody
	public GraphDto getEGTChartData3(@RequestParam("chartCase3") String chartCase, @ModelAttribute("home") GraphForm oGraphForm, HttpServletRequest request,HttpServletResponse response) {
		
		
		GraphDto oGraphDto = new GraphDto();
		try{	
			
			
			
			BeanUtils.copyProperties(oGraphDto, oGraphForm);
	
			oGraphDto = graphService.getEGTChartData3(oGraphDto, chartCase);
			
			BeanUtils.copyProperties(oGraphForm, oGraphDto);
					
		   
			}
			catch (Exception e) {
				e.printStackTrace();
				
				logger.error(e.getMessage());
			}finally {
			}
			return oGraphDto;
	}
	
	
	

	

	@RequestMapping(value = "/getEGTChartDataTwo.jpage" )
	@ResponseBody
	public GraphDto getEGTChartDataTwo(@RequestParam("chartCase") String chartCase, @ModelAttribute("home") GraphForm oGraphForm, HttpServletRequest request,HttpServletResponse response) {
		
		
		GraphDto oGraphDto = new GraphDto();
		try{	
			
			
			
			BeanUtils.copyProperties(oGraphDto, oGraphForm);
	
			oGraphDto = graphService.getEGTChartDataTwo(oGraphDto, chartCase);
			
			BeanUtils.copyProperties(oGraphForm, oGraphDto);
					
		   
			}
			catch (Exception e) {
				e.printStackTrace();
				
				logger.error(e.getMessage());
			}finally {
			}
			return oGraphDto;
	}
	

}
