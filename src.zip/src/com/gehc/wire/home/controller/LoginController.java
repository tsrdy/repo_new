package com.gehc.wire.home.controller;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.common.dto.UserSessionDto;
import com.gehc.wire.common.exceptions.BusinessDefinedException;
import com.gehc.wire.common.service.BaseService;
import com.gehc.wire.common.service.DBService;
import com.gehc.wire.home.dto.LoginDto;
import com.gehc.wire.home.form.LoginForm;
import com.gehc.wire.home.service.LoginService;


/**
 * @author 703092428
 * @FileName LoginController.java
 * @CreateDate Nov 26, 2012
 */

@Controller 

@SessionAttributes("oLoginForm")

public class LoginController extends  BaseService {
	private static final Logger logger = Logger.getLogger(LoginController.class);
	private LoginService loginService;
	private DBService  dBService;
	
	@Autowired
	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}
	@Autowired
	public void setDBService(DBService dBService) {
		this.dBService = dBService;
	}
	@RequestMapping(value = "/login.action",method = RequestMethod.POST)
	public String showUserForm(ModelMap model) {
		LoginForm oLoginForm = new LoginForm();
		model.addAttribute("login", oLoginForm);
		return "login";
	} 
	@RequestMapping(value = "/loginpage.jpage",method = RequestMethod.POST)
	public String showUserLoginForm(ModelMap model) {
		 
		return "loginPage";
	} 
	
	@RequestMapping(value = "/iaoItropage.jpage",method = RequestMethod.GET)
	public String showIAOIntroPage(ModelMap model) {
		 
		return "iaoIntroPage";
	} 
	@RequestMapping(value = "/login.jpage")
	public String onSubmit(@ModelAttribute("login") LoginForm oLoginForm,HttpServletRequest request,HttpServletResponse response,ModelMap model) {
		String page =null;
		Connection conn=null;
		boolean sValid = false;
		try{
			LoginDto oLoginDto = new LoginDto();
			UserDto oUserDto = new UserDto();
		
		BeanUtils.copyProperties(oLoginDto, oLoginForm);
		conn = dBService.getDBConnection();
		sValid = loginService.isValidUser(conn, oLoginDto);
 				
		if(sValid){
			 setUserInfo(request,oUserDto);
			 page = "redirect:landing.jpage";
		}
		
		}
		catch(BusinessDefinedException bde){
			model.addAttribute("error", bde.getMessage());
			page ="login";
		}
		catch (Exception e) {
			e.printStackTrace();
			page = "error";
			logger.error(e.getMessage());
		}finally {
			try {
				if ( conn != null )
					dBService.releaseResources(conn);
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
		  
		return page;
	}
	@RequestMapping(value = "/logout.jpage",method = RequestMethod.POST)
	public String logOut(ModelMap model,HttpServletRequest request,HttpServletResponse response) {
		Connection conn=null;
		String retunPage = null;
		LoginForm oLoginForm = new LoginForm();
		UserDto oUserDto = new UserDto();
		try{
			conn = dBService.getDBConnection();
		
		
			oUserDto = (UserDto)request.getSession().getAttribute("loginUserInfo");
			oUserDto = new UserDto();
			request.getSession().setAttribute("loginUserInfo", oUserDto);
			UserSessionDto oUserSessionDto = new UserSessionDto();
			oUserSessionDto.setSessionid(request.getSession().getId());
		//	boolean isValidate = loginService.invalidateUserSession(conn,oUserSessionDto);
			
		model.addAttribute("login", oLoginForm);
		retunPage = "login";
		}catch (Exception e) {
			e.printStackTrace();
			retunPage = "error";
			logger.error(e.getMessage());
		}finally {
			try {
				if ( conn != null )
					dBService.releaseResources(conn);
			} catch (Exception e) {
			}
		}
		return retunPage;
	}
}
