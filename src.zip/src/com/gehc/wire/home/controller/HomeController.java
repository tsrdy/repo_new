package com.gehc.wire.home.controller;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.common.service.BaseService;
import com.gehc.wire.common.service.DBService;
import com.gehc.wire.home.dto.HomeDto;
import com.gehc.wire.home.form.HomeForm;
import com.gehc.wire.home.form.LoginForm;
import com.gehc.wire.home.service.HomeService;




/**
 * @author 703092428
 * @FileName HomeController.java
 * @CreateDate Nov 26, 2012
 */
@Controller 

@SessionAttributes("oHomeForm")
public class HomeController extends BaseService {
	private static final Logger logger = Logger.getLogger(HomeController.class);
	private HomeService homeService;
	
	@Autowired
	public void setHomeService(HomeService homeService) {
		this.homeService = homeService;
	}
/*	@Autowired
	public void setDBService(DBService dBService) {
		this.dBService = dBService;
	}*/
	@RequestMapping(value = "/home.jpage")
	public String getHomePage(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model,HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		
		try{		
		HomeDto oHomeDto = new HomeDto();
		BeanUtils.copyProperties(oHomeDto, oHomeForm);
		oHomeDto.setSso(((UserDto)getUserInfo(request)).getSSO());
		
		oHomeDto = homeService.getLandingData(oHomeDto);
		
		BeanUtils.copyProperties(oHomeForm, oHomeDto);
	
		logger.info("Enter into HomeController");
	    model.addAttribute("home", oHomeForm);
	    page = "home";
		}catch(NullPointerException ne){
			page="login";
			return page;
		}
		catch (Exception e) {
			
			e.printStackTrace();// TODO: handle exception
			page = "error";
			logger.error(e.getMessage());
		}finally {
		}
		return page;
	}
	@RequestMapping(value = "/landing.jpage")
	public String getLandingPage(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model,HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		
		try{		
		HomeDto oHomeDto = new HomeDto();
		BeanUtils.copyProperties(oHomeDto, oHomeForm);
		oHomeDto.setSso(((UserDto)getUserInfo(request)).getSSO());
		
		oHomeDto = homeService.getLandingData(oHomeDto);
		
		BeanUtils.copyProperties(oHomeForm, oHomeDto);
	
		logger.info("Enter into HomeController");
	    model.addAttribute("home", oHomeForm);
	    page = "landing";
		}catch(NullPointerException ne){
			page="login";
			return page;
		}
		catch (Exception e) {
			
			e.printStackTrace();// TODO: handle exception
			page = "error";
			logger.error(e.getMessage());
		}finally {
		}
		return page;
	}
	
	
	@RequestMapping(value = "/homeNewUser.jpage")
	public String homeNewUserPage(ModelMap model,HttpServletRequest request,HttpServletResponse response) {
		
		String page = null;
		HomeForm oHomeForm = new HomeForm();
		
		String sso=request.getParameter("sso");
		String fullName=request.getParameter("fullName");
		String emailID=request.getParameter("emailID");
		
		try{
			
		HomeDto oHomeDto = new HomeDto();
		BeanUtils.copyProperties(oHomeDto, oHomeForm);
		oHomeDto.setSso(sso);
		oHomeDto.setUserName(fullName);
		oHomeDto.setEmail(emailID);
		
		logger.info("Enter into HomeController");
						
		oHomeDto = homeService.getNewUserData(oHomeDto);
		
		BeanUtils.copyProperties(oHomeForm, oHomeDto);
		model.addAttribute("home", oHomeForm);
	    page = "newUserRegister";
		}
		catch (Exception e) {
			e.printStackTrace();// TODO: handle exception
			page = "error";
			logger.error(e.getMessage());
		}
		
		return page;
		
	}	
		
	
	@RequestMapping(value = "/useraccessrequest.jpage", method = RequestMethod.POST)
	public String useraccessrequest(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		String returnPage = null;
		Connection conn = null;
		String region = request.getParameter("region");
		String subRegion = request.getParameter("subRegionList");
		String country = request.getParameter("countryList");
		String states = request.getParameter("statesList");
		String modality1 = request.getParameter("modality1List");
		String modality2 = request.getParameter("modality2List");
		
		
		try {
			HomeDto oHomeDto = new HomeDto();
			BeanUtils.copyProperties(oHomeDto, oHomeForm);
			
			oHomeDto.sethRegion(region);
			oHomeDto.sethSubRegion(subRegion);
			oHomeDto.sethCountry(country);
			oHomeDto.sethState(states);
			oHomeDto.sethModality1(modality1);
			oHomeDto.sethModality2(modality2);
			
			oHomeDto = homeService.getNewUser(oHomeDto);
			/*conn = dBService.getDBConnection();
			oHomeDto = homeService.useraccessrequest(conn,oHomeDto);
			new SendMailUtility().sendUserRequestToAdmin(oHomeDto);
			oHomeDto.setPageType("Macro");*/
			//oHomeDto.setRegion(region);
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
			request.setAttribute("page", "HomePage");
			model.addAttribute("home", oHomeForm);
			returnPage = "useraccessSubmitPage";
		} catch (Exception e) {
			e.printStackTrace();
			returnPage = "ajaxerror";
			logger.error(e.getMessage());
		}
		return returnPage;
	}	
		

@RequestMapping(value = "/getTurbineStatus.jpage")
public String getTurbineStatus(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("home", oHomeForm);
		returnPage = "turbineStatus";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	
	
	
@RequestMapping(value = "/getTurbineChart.jpage")
public String turbineChart(@ModelAttribute("turbineChart") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		String returnPage = null;
		Connection conn = null;
		
		try {
			
			model.addAttribute("turbineChart", oHomeForm);
			returnPage = "turboChartPage";
		} catch (Exception e) {
			e.printStackTrace();
			returnPage = "ajaxerror";
			logger.error(e.getMessage());
		}
		return returnPage;
}



@RequestMapping(value = "/getDTFailureChart.jpage")
public String DTFailureChart(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("home", oHomeForm);
		returnPage = "DTFailureChartPage";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	

@RequestMapping(value = "/getAlarmDetectionChart.jpage")
public String alarmDetectionChart(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("home", oHomeForm);
		returnPage = "AlarmDetectionChart";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	


@RequestMapping(value = "/getTurbinePerformanceChart.jpage")
public String turbinePerformanceChart(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("home", oHomeForm);
		returnPage = "TurbinePerformanceChart";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	



@RequestMapping(value = "/getPMQuadrantChart.jpage")
public String plannedMainQuadrantChart(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("pmQuardantChart", oHomeForm);
		returnPage = "PMQuadrantChart";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	

@RequestMapping(value = "/failureByPartLife.jpage")
public String failureByPartLifeChart(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		HomeDto oHomeDto = new HomeDto();
		BeanUtils.copyProperties(oHomeDto, oHomeForm);
		
		
		oHomeDto = homeService.failureByPartLife(oHomeDto);
		
		BeanUtils.copyProperties(oHomeForm, oHomeDto);
		
		logger.info("Enter into Drill ot Pie Controller");
	    model.addAttribute("pmQuardantChart", oHomeForm);
	    
		returnPage = "failureByPartLife";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	
@RequestMapping(value = "/downTime.jpage")
public String downTimeGraph(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("pmQuardantChart", oHomeForm);
		returnPage = "downTime";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	


@RequestMapping(value = "/getFailurev1.jpage")
public String failureChart(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("failureV1Form", oHomeForm);
		returnPage = "failureV1";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	
@RequestMapping(value = "/failure.jpage")
public String failure(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("failureAndMaintenanceCostForm", oHomeForm);
		returnPage = "failure";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	

@RequestMapping(value = "/failureAndMaintenanceCost.jpage")
public String failureAndMaintenanceCost(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("failureAndMaintenanceCostForm", oHomeForm);
		returnPage = "failureAndMaintenanceCost";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	
@RequestMapping(value = "/getFailurev2.jpage")
public String failureChartv2(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("failureV2Form", oHomeForm);
		returnPage = "failureV2";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	

@RequestMapping(value = "/MaintenanceCostAndDT.jpage")
public String MaintenanceCostAndDT(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
		HttpServletResponse response) {
	String returnPage = null;
	Connection conn = null;
	
	try {
		
		model.addAttribute("maintenaceCostAndDtForm", oHomeForm);
		returnPage = "MaintenanceCostAndDT";
	} catch (Exception e) {
		e.printStackTrace();
		returnPage = "ajaxerror";
		logger.error(e.getMessage());
	}
	return returnPage;
}	

/*
	@RequestMapping(value = "/getTurbineDynamic.jpage")
	public String loadRegionCheckBoxes(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		String region = request.getParameter("regionId");
		
		try{		
			HomeDto oHomeDto = new HomeDto();
			BeanUtils.copyProperties(oHomeDto, oHomeForm);
			
			oHomeDto = homeService.getTurboDynValues(oHomeDto);
			
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
					
		    model.addAttribute("home", oHomeForm);
		    page = "turboChartPage";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}*/
	@RequestMapping(value = "/loadCountryHomeData.jpage", method = RequestMethod.POST)
	public String loadCountryHomeData(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		String region = request.getParameter("region");
		String subRegion = request.getParameter("subRegion");
		
		try{		
			HomeDto oHomeDto = new HomeDto();
			BeanUtils.copyProperties(oHomeDto, oHomeForm);
			//oHomeDto.setSso(((UserDto)getUserInfo(request)).getSSO());
			oHomeDto.sethRegion(region);
			oHomeDto.sethSubRegion(subRegion);
			
			oHomeDto = homeService.getCountryData(oHomeDto);
			
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
					
			logger.info("Enter into Quarter Controller");
		    model.addAttribute("home", oHomeForm);
		    page = "loadCountry";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}
	@RequestMapping(value = "/loadStateHomeData.jpage", method = RequestMethod.POST)
	public String loadStatesHomeData(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		String region = request.getParameter("region");
		String subRegion = request.getParameter("subRegion");
		String country = request.getParameter("country");
		
		try{		
			HomeDto oHomeDto = new HomeDto();
			BeanUtils.copyProperties(oHomeDto, oHomeForm);
			//oHomeDto.setSso(((UserDto)getUserInfo(request)).getSSO());
			oHomeDto.sethRegion(region);
			oHomeDto.sethSubRegion(subRegion);
			oHomeDto.sethCountry(country);
			oHomeDto = homeService.getStatesData(oHomeDto);
			
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
					
			logger.info("Enter into Quarter Controller");
		    model.addAttribute("home", oHomeForm);
		    page = "loadStates";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}
	
	@RequestMapping(value = "/loadModalityTwoHomeData.jpage", method = RequestMethod.POST)
	public String loadModalityOneHomeData(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		String modality1 = request.getParameter("groupList");
		try{		
			HomeDto oHomeDto = new HomeDto();
			BeanUtils.copyProperties(oHomeDto, oHomeForm);
			oHomeDto.sethModality1(modality1);

			oHomeDto = homeService.getModalityTwoData(oHomeDto);
			
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
					
			logger.info("Enter into Quarter Controller");
		    model.addAttribute("home", oHomeForm);
		    page = "loadModalityTwoPage";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}
	
	

	
@RequestMapping(value = "/getDTFailureClassesAndWeather.jpage")
public String dtFailureClassesAndWeather(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		String returnPage = null;
		Connection conn = null;
		
		try {
			
			model.addAttribute("DTFCAWForm", oHomeForm);
			returnPage = "DTFailureClassesAndWeather";
		} catch (Exception e) {
			e.printStackTrace();
			returnPage = "ajaxerror";
			logger.error(e.getMessage());
		}
		return returnPage;
	}	
@RequestMapping(value = "/getFailureRateAndDowntime.jpage")
public String failureRateAndDowntime(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		String returnPage = null;
		Connection conn = null;
		
		try {
			
			model.addAttribute("FailureRateAndDowntimeForm", oHomeForm);
			returnPage = "FailureRateAndDowntime";
		} catch (Exception e) {
			e.printStackTrace();
			returnPage = "ajaxerror";
			logger.error(e.getMessage());
		}
		return returnPage;
	}	

@RequestMapping(value = "/getTurbineReliabilityDrillToPi.jpage", method = RequestMethod.POST)
public String getTurbineReliabilityDrillToPi(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
	String page = null;
	String modality1 = request.getParameter("groupList");
	try{		
		HomeDto oHomeDto = new HomeDto();
		BeanUtils.copyProperties(oHomeDto, oHomeForm);
		oHomeDto.sethModality1(modality1);

			oHomeDto = homeService.getTurbineReliabilityDrillToPi(oHomeDto);
			
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
					
			logger.info("Enter into Drill ot Pie Controller");
		    model.addAttribute("turbineForm", oHomeForm);
		    page = "turbineDrillToPie";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}
@RequestMapping(value = "/getWeiBull.jpage", method = RequestMethod.POST)
public String getgetWeiBull(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
	String page = null;
	String modality1 = request.getParameter("groupList");
	try{		
		HomeDto oHomeDto = new HomeDto();
		BeanUtils.copyProperties(oHomeDto, oHomeForm);
		oHomeDto.sethModality1(modality1);

			oHomeDto = homeService.getWeiBull(oHomeDto);
			
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
					
			logger.info("Enter into Drill ot Pie Controller");
		    model.addAttribute("turbineForm", oHomeForm);
		    page = "wieBull";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}
	@RequestMapping(value = "/getTurbineWiseList.jpage", method = RequestMethod.POST)
	public String getTurbineWiseList(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,HttpServletResponse response) {
		String page = null;
		String modality1 = request.getParameter("groupList");
		try{		
			HomeDto oHomeDto = new HomeDto();
			BeanUtils.copyProperties(oHomeDto, oHomeForm);
			oHomeDto.sethModality1(modality1);

			oHomeDto = homeService.getTurbineWiseList(oHomeDto);
			
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
					
			logger.info("Enter into Wise List");
		    model.addAttribute("turbineForm", oHomeForm);
		    page = "turbineWiseList";
			}
			catch (Exception e) {
				e.printStackTrace();// TODO: handle exception
				page = "error";
				logger.error(e.getMessage());
			}finally {
			}
			return page;
	}
	@RequestMapping(value = "/getTurbineChartR.jpage")
	public String turbineChartRed(@ModelAttribute("turbineChart") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
				HttpServletResponse response) {
			String returnPage = null;
			Connection conn = null;
			
			try {
				
				model.addAttribute("turbineChartR", oHomeForm);
				returnPage = "turboChartPageR";
			} catch (Exception e) {
				e.printStackTrace();
				returnPage = "ajaxerror";
				logger.error(e.getMessage());
			}
			return returnPage;
	}
	
	@RequestMapping(value = "/getTurbineChartB.jpage")
	public String turbineChartBlack(@ModelAttribute("turbineChart") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
				HttpServletResponse response) {
			String returnPage = null;
			Connection conn = null;
			
			try {
				
				model.addAttribute("turbineChartB", oHomeForm);
				returnPage = "turboChartPageB";
			} catch (Exception e) {
				e.printStackTrace();
				returnPage = "ajaxerror";
				logger.error(e.getMessage());
			}
			return returnPage;
	}
	
	@RequestMapping(value = "/getFilterPage.jpage")
	public String getFilterPage(ModelMap model, HttpServletRequest request,
				HttpServletResponse response) {
			String returnPage = null;
			Connection conn = null;
			
			try {
				
				
				returnPage = "filterPage";
			} catch (Exception e) {
				e.printStackTrace();
				returnPage = "ajaxerror";
				logger.error(e.getMessage());
			}
			return returnPage;
	}

	
	@RequestMapping(value = "/siteComparision.jpage")
	public String siteComparision(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		String returnPage;
		Connection conn = null;
		
		try {
			
			HomeDto oHomeDto = new HomeDto();
			BeanUtils.copyProperties(oHomeDto, oHomeForm);			
			oHomeDto = homeService.getSiteComparision(oHomeDto);
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
			logger.info("Enter into Wise List");
			model.addAttribute("siteComparision", oHomeForm);
			returnPage = "siteComparision";
		} catch (Exception e) {
			e.printStackTrace();
			returnPage = "ajaxerror";
			logger.error(e.getMessage());
		}
		return returnPage;
	}	

	
	
	@RequestMapping(value = "/getDecisionTree.jpage")
	public String decisionTree(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		String returnPage;
		Connection conn = null;
		
		try {
			
			model.addAttribute("decisionTree", oHomeForm);
			returnPage = "decisionTree";
		} catch (Exception e) {
			e.printStackTrace();
			returnPage = "ajaxerror";
			logger.error(e.getMessage());
		}
		return returnPage;
	}	
	
	

	
	
	@RequestMapping(value = "/criticalForecast.jpage")
	public String criticalForecast(@ModelAttribute("home") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
			HttpServletResponse response) {
		String returnPage;		
		
		try {
			HomeDto oHomeDto = new HomeDto();
			BeanUtils.copyProperties(oHomeDto, oHomeForm);			

			oHomeDto = homeService.getCriticalForecastList(oHomeDto);
			
			BeanUtils.copyProperties(oHomeForm, oHomeDto);
					
			logger.info("Enter into Wise List");
			
			
			model.addAttribute("criticalForecast", oHomeForm);			
			returnPage = "criticalForecast";
		} catch (Exception e) {
			e.printStackTrace();
			returnPage = "ajaxerror";
			logger.error(e.getMessage());
		}
		return returnPage;
	}	
	@RequestMapping(value = "/getEGTChart.jpage")
	public String egtChart(@ModelAttribute("turbineChart") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
				HttpServletResponse response) {
			String returnPage = null;
			Connection conn = null;
			HomeDto oHomeDto = new HomeDto();
			
			try {
				//oHomeDto = homeService.getEGTData(oHomeDto);
				model.addAttribute("turbineChart", oHomeForm);
				returnPage = "EGT";
			} catch (Exception e) {
				e.printStackTrace();
				returnPage = "ajaxerror";
				logger.error(e.getMessage());
			}
			return returnPage;
	}
	
	@RequestMapping(value = "/getEGTChartRed.jpage")
	public String egtChartRed(@ModelAttribute("turbineChart") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
				HttpServletResponse response) {
			String returnPage = null;
			Connection conn = null;
			HomeDto oHomeDto = new HomeDto();
			
			try {
				//oHomeDto = homeService.getEGTData(oHomeDto);
				model.addAttribute("turbineChart", oHomeForm);
				returnPage = "EGTRed";
			} catch (Exception e) {
				e.printStackTrace();
				returnPage = "ajaxerror";
				logger.error(e.getMessage());
			}
			return returnPage;
	}
	
	@RequestMapping(value = "/getEGTChartBlack.jpage")
	public String egtChartBlack(@ModelAttribute("turbineChart") HomeForm oHomeForm,ModelMap model, HttpServletRequest request,
				HttpServletResponse response) {
			String returnPage = null;
			Connection conn = null;
			HomeDto oHomeDto = new HomeDto();
			
			try {
				//oHomeDto = homeService.getEGTData(oHomeDto);
				model.addAttribute("turbineChart", oHomeForm);
				returnPage = "EGTBlack";
			} catch (Exception e) {
				e.printStackTrace();
				returnPage = "ajaxerror";
				logger.error(e.getMessage());
			}
			return returnPage;
	}}
