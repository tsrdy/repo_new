package com.gehc.wire.home.dao;

import java.sql.Connection;

import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.common.dto.UserSessionDto;
import com.gehc.wire.home.dto.LoginDto;

/**
 * @author 703092428
 * @FileName LoginDAO.java
 * @CreateDate Nov 26, 2012
 */
public interface LoginDAO {

	UserDto getUserDetails(Connection conn, LoginDto oLoginDto)throws Exception;

	boolean validateUser(Connection conn, LoginDto oLoginDto)throws Exception;

	void setUserSession(Connection conn, UserSessionDto oUserSessionDto)throws Exception;

	void updateUserSession(Connection conn, UserSessionDto oUserSessionDto)throws Exception;

	//String validateUser(User user);

}
