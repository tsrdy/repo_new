package com.gehc.wire.home.dao;

import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.service.PropertyService;


/**
 * @author 703092428
 * @FileName LoginQueries.java
 * @CreateDate Nov 26, 2012
 */
public interface LoginQueries {

		public static final String APP_SCHEMA = PropertyService.getProperty(MPRConstants.APP_PRPPERTIES_FILE,MPRConstants.APP_DB_SCHEMA);
		
		public static final String PROC_VALIDATE_USER   = "{call [IAO_600_User_Master](?,?)}";
		public static final String PROC_GET_USER_INFO   = "{call "+APP_SCHEMA+".[Chu_viwer_Proc_user_Details](?)}";
		public static final String PROC_VALIDATE_USERID = "{call [IAO_600_Fetch_User_SSO_Pwd](?)}";
		
}
