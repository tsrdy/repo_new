package com.gehc.wire.home.dao;

import java.sql.Connection;

import com.gehc.wire.home.dto.HomeDto;




/**
 * @author 703092428
 * @FileName HomeDAO.java
 * @CreateDate Nov 26, 2012
 */
public interface HomeDAO {

	
	HomeDto getNewUserRegisterData(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getSubRegionHome(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getCountryHome(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getStatesHome(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getModalityOne(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getModalityTwoData(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto addNewUser(Connection conn, HomeDto oHomeDto)throws Exception;

	HomeDto getLandingData(Connection conn, HomeDto oHomeDto)throws Exception;

	HomeDto getTurbDynaValues(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getTurbineReliabilityDrillToPi(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getWeiBull(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto failureByPartLife(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getTurbineWiseList(Connection conn, HomeDto oHomeDto)throws Exception;

	HomeDto getCriticalForecastList(Connection conn, HomeDto oHomeDto)throws Exception;

	HomeDto getSiteComparision(Connection conn, HomeDto oHomeDto)throws Exception;
	
	HomeDto getEGTData(Connection conn, HomeDto oHomeDto) throws Exception;
	
}
