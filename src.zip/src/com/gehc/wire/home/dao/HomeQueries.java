package com.gehc.wire.home.dao;

import com.gehc.wire.common.constants.BGConstants;
import com.gehc.wire.common.service.PropertyService;


/**
 * @author 703092428
 * @FileName LoginQueries.java
 * @CreateDate Nov 26, 2012
 */
public interface HomeQueries {

		public static final String APP_SCHEMA = PropertyService.getProperty(BGConstants.APP_PRPPERTIES_FILE,BGConstants.APP_DB_SCHEMA);
		public static final String  PROC_GET_SUB_REGION_HOME_DATA = "{ call gecisage.[MPR_205_Proc_Fetch_Sub_Region](?)}";
		public static final String  PROC_GET_SUB_COUNTRY_HOME_DATA = "{ call gecisage.[MPR_206_Proc_Fetch_Country](?,?)}";
		public static final String  PROC_GET_STATES_DATA_HOME = "{ call gecisage.[MPR_216_Proc_Fetch_State](?,?,?)}";
		public static final String  PROC_GET_MODALITY_HOME = "{ call gecisage.[MPR_207_Proc_Fetch_Group]()}";
		public static final String  PROC_GET_MODALITY2_HOME = "{ call gecisage.[MPR_208_Proc_Fetch_Modality](?,?)}";
		public static final String  PROC_ADD_NEW_USER_HOME = "{ call gecisage.[MPR_236_Proc_Insert_User](?,?,?,?,?,?,?)}";
		public static final String  PROC_ADD_LANDING_DATA = "{ call gecisage.[MPR_Proc_Summary_By_Modality](?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		
		//IAO WireFrames
		
		
		public static final String  PROC_IAO_WIREFRAME_TURBINE_MATRICES = "{ call IAO_600_Proc_View_Turbine_Operating_Matrices()}";
		String  PROC_IAO_WIREFRAME_TURBINE_DRILLTOPIE = "{ call IAO_600_Turbine_List()}";
		String  PROC_IAO_WIREFRAME_WIEBULL = "{ call  IAO_600_Raw_Weibul()}";
		String  PROC_IAO_WIREFRAME_FAILUREBYPARTLIFE = "{ call  IAO_600_Raw_Failure_Chart()}";
 
		String  PROC_IAO_WIREFRAME_TURBINE_WISE_SELECTION= "{ call IAO_600_Turbine_Wise_Selection_V1()}";
		String  PROC_IAO_WIREFRAME_CRITICAL_FORECAST= "{ call IAO_600_Raw_Critical_Spares()}";
		String  PROC_IAO_WIREFRAME_SITE_COMPARISION= "{ call IAO_600_Raw_Site_Comparisons()}";

		
}
