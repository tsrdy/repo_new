package com.gehc.wire.home.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.gehc.wire.common.dto.TableDto;
import com.gehc.wire.common.service.CommonService;
import com.gehc.wire.common.service.DBService;
import com.gehc.wire.home.dto.HomeDto;


public class HomeDAOImpl implements HomeDAO,HomeQueries {

	
	private static final Logger logger = Logger.getLogger(HomeDAOImpl.class);

	@Override
	public HomeDto getNewUserRegisterData(Connection conn, HomeDto oHomeDto)
			throws Exception {
		
		
		return oHomeDto;
	}

	@Override
	public HomeDto getSubRegionHome(Connection conn, HomeDto oHomeDto)
			throws Exception {
		// TODO Auto-generated method stub  
		TableDto oTableDto = null;
		ArrayList alData = new ArrayList();
		ArrayList alRevenue = new ArrayList();
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_GET_SUB_REGION_HOME_DATA);
		
		cstmt.setString(1, oHomeDto.gethRegion());
				
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					
					alData.add(oTableDto);
				}
				
			}
		oHomeDto.setAlSubRegion(alData);

		return oHomeDto;
	}

	@Override
	public HomeDto getCountryHome(Connection conn, HomeDto oHomeDto)
			throws Exception {
		TableDto oTableDto = null;
		ArrayList alData = new ArrayList();
		ArrayList alRevenue = new ArrayList();
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_GET_SUB_COUNTRY_HOME_DATA);
		
		cstmt.setString(1, oHomeDto.gethRegion());	
		cstmt.setString(2, oHomeDto.gethSubRegion());
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					alData.add(oTableDto);
				}
				
			}
		oHomeDto.setAlCountry(alData);

		return oHomeDto;
	}

	@Override
	public HomeDto getStatesHome(Connection conn, HomeDto oHomeDto)
			throws Exception {
		TableDto oTableDto = null;
		ArrayList alData = new ArrayList();
		ArrayList alRevenue = new ArrayList();
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_GET_STATES_DATA_HOME);
		
		cstmt.setString(1, oHomeDto.gethRegion());	
		cstmt.setString(2, oHomeDto.gethSubRegion());	
		cstmt.setString(3, oHomeDto.gethCountry());	
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					alData.add(oTableDto);
				}
				
			}
		oHomeDto.setAlState(alData);

		return oHomeDto;
	}

	@Override
	public HomeDto getModalityOne(Connection conn, HomeDto oHomeDto)
			throws Exception {
		TableDto oTableDto = null;
		ArrayList alData = new ArrayList();
		ArrayList alRevenue = new ArrayList();
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_GET_MODALITY_HOME);
		
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					alData.add(oTableDto);
				}
				
			}
		oHomeDto.setAlModality1(alData);

		return oHomeDto;
	}

	@Override
	public HomeDto getModalityTwoData(Connection conn, HomeDto oHomeDto)
			throws Exception {
		TableDto oTableDto = null;
		ArrayList alData = new ArrayList();
		ArrayList alRevenue = new ArrayList();
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_GET_MODALITY2_HOME);
		cstmt.setString(1, oHomeDto.gethModality1());
		cstmt.setString(2, oHomeDto.getSso());
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					alData.add(oTableDto);
				}
				
			}
		oHomeDto.setAlModality2(alData);

		return oHomeDto;
	}

	@Override
	public HomeDto addNewUser(Connection conn, HomeDto oHomeDto)
			throws Exception {

		String result = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_ADD_NEW_USER_HOME);
		
		cstmt.setString(1, oHomeDto.getUserSso());
		System.out.println("1"+oHomeDto.getUserSso());
		
		cstmt.setString(2, oHomeDto.getUserName());	
		System.out.println("2"+oHomeDto.getUserName());
		
		cstmt.setString(3, oHomeDto.getEmail());
		System.out.println("3"+oHomeDto.getEmail());
		
		cstmt.setString(4, oHomeDto.gethRole());	
		System.out.println("4"+oHomeDto.gethRole());
		
		cstmt.setString(5, oHomeDto.gethRegion());	
		System.out.println("5"+ oHomeDto.gethRegion());
		
		cstmt.setString(6, oHomeDto.gethModality1());
		System.out.println("6"+oHomeDto.gethModality1());
		
		cstmt.setString(7, oHomeDto.getUserAccessComments());
		System.out.println("7 "+oHomeDto.getUserAccessComments());
		
		/*cstmt.setString(6, oHomeDto.gethSubRegion());
		System.out.println("6"+oHomeDto.gethSubRegion());*/
		
		/*cstmt.setString(7, oHomeDto.gethCountry());	
		System.out.println("7"+ oHomeDto.gethCountry());*/
		
/*		cstmt.setString(8, oHomeDto.gethState());
		System.out.println("8"+oHomeDto.gethState());
		
		cstmt.setString(9, oHomeDto.gethModality1());
		System.out.println("9 "+oHomeDto.gethModality1());
		
		cstmt.setString(10, oHomeDto.gethModality2());
		System.out.println("10 "+oHomeDto.gethModality2());
		
		cstmt.setString(11, oHomeDto.getUserAccessComments());
		System.out.println("11 "+oHomeDto.getUserAccessComments());*/
		
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){				
				result=rs.getString(1);					
				}
				
			}
		

		return oHomeDto;
	}

	@Override
	public HomeDto getLandingData(Connection conn, HomeDto oHomeDto) throws Exception {
		TableDto oTableDto = null;
		ArrayList alData = new ArrayList();
		ArrayList alRevenue = new ArrayList();
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_ADD_LANDING_DATA);
		
		cstmt.setString(1, "2013");
		cstmt.setString(2, "Q2");
		cstmt.setString(3,null);
		cstmt.setString(4, null);
		cstmt.setString(5, null);
		cstmt.setString(6, null);
		cstmt.setString(7, null);
		cstmt.setString(8, null);
		cstmt.setString(9, null);
		cstmt.setString(10, null);
		cstmt.setString(11,null);
		cstmt.setString(12, null);
		cstmt.setString(13, null);
		cstmt.setString(14, null);
		
		rs = cstmt.executeQuery();
		
		
		alData = CommonService.getDataTable(rs);
		oHomeDto.setAlDataOne(alData);
		return oHomeDto;
	}

	@Override
	public HomeDto getTurbDynaValues(Connection conn, HomeDto oHomeDto)
			throws Exception {
		// TODO Auto-generated method stub  
		TableDto oTableDto = null;
		ArrayList dataSetOne = new ArrayList();
		ArrayList dataSetTwo = new ArrayList();
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					oTableDto.setColumn2(rs.getString(2));
					dataSetOne.add(oTableDto);
					dataSetTwo.add(oTableDto);
				}
				
			}
		oHomeDto.setAlSubRegion(dataSetOne);
		oHomeDto.setAlSubRegion(dataSetTwo);

		return oHomeDto;
	}
	@Override
	public HomeDto getTurbineReliabilityDrillToPi(Connection conn, HomeDto oHomeDto)
			throws Exception {
		// TODO Auto-generated method stub  
		TableDto oTableDto = null;
		List dataSetOne=new ArrayList();
	 
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_IAO_WIREFRAME_TURBINE_DRILLTOPIE);
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					oTableDto.setColumn2(rs.getString(2));
					oTableDto.setColumn3(rs.getString(3));
					oTableDto.setColumn4(rs.getString(4));
					oTableDto.setColumn5(rs.getString(5));
					oTableDto.setColumn6(rs.getString(6));
					oTableDto.setColumn7(rs.getString(7));
					oTableDto.setColumn8(rs.getString(8));
					oTableDto.setColumn9(rs.getString(9));
					oTableDto.setColumn10(rs.getString(10));
					oTableDto.setColumn11(rs.getString(11));
					 
					dataSetOne.add(oTableDto);
				}
				
			}
 
		oHomeDto.setAlTableData(dataSetOne);

		return oHomeDto;
	}
	
	@Override
	public HomeDto getWeiBull(Connection conn, HomeDto oHomeDto)
			throws Exception {
		// TODO Auto-generated method stub  
		TableDto oTableDto = null;
		List dataSetOne=new ArrayList();
	 
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_IAO_WIREFRAME_WIEBULL);
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					oTableDto.setColumn2(rs.getString(2));
					oTableDto.setColumn3(rs.getString(3));
					oTableDto.setColumn4(rs.getString(4));
					oTableDto.setColumn5(rs.getString(5));
					oTableDto.setColumn6(rs.getString(6));
					oTableDto.setColumn4(rs.getString(7));
					oTableDto.setColumn5(rs.getString(8));
					oTableDto.setColumn6(rs.getString(9));
					
					dataSetOne.add(oTableDto);
				}
				
			}
 
		oHomeDto.setAlTableData(dataSetOne);

		return oHomeDto;
	}
	@Override
	public HomeDto failureByPartLife(Connection conn, HomeDto oHomeDto)
			throws Exception {
		// TODO Auto-generated method stub  
		TableDto oTableDto = null;
		List dataSetOne=new ArrayList();
	 
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_IAO_WIREFRAME_FAILUREBYPARTLIFE);
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					oTableDto.setColumn2(rs.getString(2));
					oTableDto.setColumn3(rs.getString(3));
				 
					
					dataSetOne.add(oTableDto);
				}
				
			}
 
		oHomeDto.setAlTableData(dataSetOne);

		return oHomeDto;
	}
	
	
	@Override
	public HomeDto getTurbineWiseList(Connection conn, HomeDto oHomeDto)
			throws Exception {
		// TODO Auto-generated method stub  
		TableDto oTableDto = null;
		List dataSetOne=new ArrayList();
	 
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_IAO_WIREFRAME_TURBINE_WISE_SELECTION);
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					oTableDto.setColumn2(rs.getString(2));
					oTableDto.setColumn3(rs.getString(3));
					oTableDto.setColumn4(rs.getString(4));
					oTableDto.setColumn5(rs.getString(5));
					oTableDto.setColumn6(rs.getString(6));
					oTableDto.setColumn7(rs.getString(7));
					oTableDto.setColumn8(rs.getString(8));
					oTableDto.setColumn9(rs.getString(9));
					oTableDto.setColumn10(rs.getString(10));
					oTableDto.setColumn11(rs.getString(11));
					oTableDto.setColumn12(rs.getString(12));
					oTableDto.setColumn13(rs.getString(13));
					oTableDto.setColumn14(rs.getString(14));
					oTableDto.setColumn15(rs.getString(15));
					 
					dataSetOne.add(oTableDto);
				}
				
			}
 
		oHomeDto.setAlTableData(dataSetOne);

		return oHomeDto;
	}

	@Override
	public HomeDto getCriticalForecastList(Connection conn, HomeDto oHomeDto)
			throws Exception {
		TableDto oTableDto = null;
		List dataSetOne=new ArrayList();
	 
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		cstmt = conn.prepareCall(PROC_IAO_WIREFRAME_CRITICAL_FORECAST);
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString("Critical Spares"));
					oTableDto.setColumn2(rs.getString("Annual Failure Forecast"));
					oTableDto.setColumn3(rs.getString("Buy/No Buy Decision"));	
					oTableDto.setColumn4(rs.getString("Downtime Cost Impact ($)/Failure"));	
					oTableDto.setColumn5(rs.getString("Safety Stock"));	
					oTableDto.setColumn6(rs.getString("Current Inventory"));	
					oTableDto.setColumn7(rs.getString("Working Capital Impact"));	
					oTableDto.setColumn8(rs.getString("Annual Inventory Carrying Cost Savings"));	
					dataSetOne.add(oTableDto);
				}
				
			}
 
		oHomeDto.setAlTableData(dataSetOne);

		return oHomeDto;
	}

	@Override
	public HomeDto getSiteComparision(Connection conn, HomeDto oHomeDto) throws Exception {

		ArrayList<String> dataSetMonths = new ArrayList<String>();
		ArrayList<String> dataSetChw = new ArrayList<String>();
		ArrayList<String> dataSetKcw = new ArrayList<String>();
		ArrayList<String> dataSetNot = new ArrayList<String>();
		ArrayList<String> dataSetTop = new ArrayList<String>();
		ArrayList<String> dataSetChwTotal = new ArrayList<String>();
		ArrayList<String> dataSetKcwTotal = new ArrayList<String>();
		ArrayList<String> dataSetNotTotal = new ArrayList<String>();
		ArrayList<String> dataSetTopTotal = new ArrayList<String>();
		
		TableDto oTableDto = null;
		List siteComparisionDataSet=new ArrayList();

		CallableStatement cstmt = null;
		ResultSet rs = null;

		cstmt = conn.prepareCall(PROC_IAO_WIREFRAME_SITE_COMPARISION);

		rs = cstmt.executeQuery();
		if (rs != null) {
			while (rs.next()) {

				dataSetMonths.add(rs.getString("Months"));
				dataSetChw.add(rs.getString("CHW"));
				dataSetKcw.add(rs.getString("KCW"));
				dataSetNot.add(rs.getString("NOT"));
				dataSetTop.add(rs.getString("TOP"));
				dataSetChwTotal.add(rs.getString("CHW Total"));
				dataSetKcwTotal.add(rs.getString("KCW Total"));
				dataSetNotTotal.add(rs.getString("NOT Total"));
				dataSetTopTotal.add(rs.getString("TOP Total"));
				
				oTableDto=new TableDto();
				oTableDto.setColumn1(rs.getString("Months"));
				oTableDto.setColumn2(rs.getString("CHW"));
				oTableDto.setColumn3(rs.getString("KCW"));	
				oTableDto.setColumn4(rs.getString("NOT"));	
				oTableDto.setColumn5(rs.getString("TOP"));	
				oTableDto.setColumn6(rs.getString("CHW Total"));	
				oTableDto.setColumn7(rs.getString("KCW Total"));	
				oTableDto.setColumn8(rs.getString("NOT Total"));
				oTableDto.setColumn9(rs.getString("TOP Total"));
				siteComparisionDataSet.add(oTableDto);

			}

		}
		 oHomeDto.setAlTableData(siteComparisionDataSet);
		 oHomeDto.setDataSetMonths(dataSetMonths);
		 oHomeDto.setDataSetChw(dataSetChw);
		 oHomeDto.setDataSetKcw(dataSetKcw);
		 oHomeDto.setDataSetNot(dataSetNot);
		 oHomeDto.setDataSetTop(dataSetTop);
		 oHomeDto.setDataSetChwTotal(dataSetChwTotal);
		 oHomeDto.setDataSetKcwTotal(dataSetKcwTotal);
		 oHomeDto.setDataSetNotTotal(dataSetNotTotal);
		 oHomeDto.setDataSetTopTotal(dataSetTopTotal);

		new DBService().releaseResources(rs, cstmt);
		return oHomeDto;
	}
	
	@Override
	public HomeDto getEGTData(Connection conn, HomeDto oHomeDto)
			throws Exception {
		
		TableDto oTableDto = null;
		List<TableDto> dataSetOne=new ArrayList<TableDto>();
	    String PROC_IAO_WIREFRAME_EGT = "{ call IAO_600_Raw_EGT()}";
		
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
	
		cstmt = conn.prepareCall(PROC_IAO_WIREFRAME_EGT);
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oTableDto=new TableDto();
					oTableDto.setColumn1(rs.getString(1));
					oTableDto.setColumn2(rs.getString(2));
					oTableDto.setColumn3(rs.getString(3));			
					 
					dataSetOne.add(oTableDto);
				}
				
			}
 
		oHomeDto.setAlTableData(dataSetOne);

		return oHomeDto;
	
	}
}
