package com.gehc.wire.home.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import com.gehc.wire.common.dao.AjaxDaoImpl;
import com.gehc.wire.common.dao.AjaxQueries;
import com.gehc.wire.common.service.DBService;
import com.gehc.wire.home.dto.GraphDto;



/**
 * @author 703092428
 * @FileName HomeDAOImpl.java
 * @CreateDate Nov 26, 2012
 */
/*public class GraphDAOImpl implements GraphDAO,HomeQueries {
	private static final Logger logger = Logger.getLogger(AjaxDaoImpl.class);
 
	@Override
	public String getTurbDynaValues(Connection conn)
			throws Exception {
		 
		 	CallableStatement cstmt = null;
			ResultSet rs = null;
			TableDto oTableDto = null;
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
			System.out.println(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
			cstmt = conn.prepareCall(sbQuery.toString());
			 
			 
			rs = cstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					oTableDto=new TableDto();
						oTableDto.setColumn1(rs.getString(1));
						oTableDto.setColumn2(rs.getString(2));
						 
					}
					
				}
			new DBService().releaseResources(rs, cstmt);
			return "";
	}


	 

	 
	
}
*/

public class GraphDAOImpl implements GraphDAO,AjaxQueries {
	private static final Logger logger = Logger.getLogger(AjaxDaoImpl.class);
 
	@Override
	public GraphDto getTurbDynaValues(Connection conn,GraphDto oGraphDto)
			throws Exception {
		
		List objList = new LinkedList();
		List<GraphDto> graphValueList = new ArrayList<GraphDto>();
		ArrayList<String> dataSetOne = new ArrayList<String>();
		ArrayList<String> dataSetTwo = new ArrayList<String>();
		 
		 	CallableStatement cstmt = null;
			ResultSet rs = null;
			
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
			System.out.println(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
			cstmt = conn.prepareCall(sbQuery.toString());
			 
			 
			rs = cstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					dataSetOne.add(rs.getString("X"));
					dataSetTwo.add(rs.getString("Y"));
					
					}
					
				
			}
			oGraphDto.setDataSetOne(dataSetOne);
			oGraphDto.setDataSetTwo(dataSetTwo);
				
			
			new DBService().releaseResources(rs, cstmt);
			return oGraphDto;
	}

	@Override
	public GraphDto geDTFailureDynaValues(Connection conn, GraphDto oGraphDto)
			throws Exception {
		List objList = new LinkedList();
		List<GraphDto> graphValueList = new ArrayList<GraphDto>();
		ArrayList<String> dataSetOne = new ArrayList<String>();
		ArrayList<String> dataSetTwo = new ArrayList<String>();
		ArrayList<String> dataSetThree = new ArrayList<String>();
		 
		 	CallableStatement cstmt = null;
			ResultSet rs = null;
			
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
			System.out.println(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
			cstmt = conn.prepareCall(sbQuery.toString());
			 
			 
			rs = cstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					dataSetOne.add(rs.getString("X"));
					dataSetTwo.add(rs.getString("Y"));
					dataSetThree.add(rs.getString("Z"));
					}
					
				
			}
			oGraphDto.setDataSetOne(dataSetOne);
			oGraphDto.setDataSetTwo(dataSetTwo);
			oGraphDto.setDataSetThree(dataSetThree);
				
			
			new DBService().releaseResources(rs, cstmt);
			return oGraphDto;
	
	}

	@Override
	public GraphDto geFailureRateV1DynaValues(Connection conn,
			GraphDto oGraphDto) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GraphDto getAlarmDetectionValues(Connection conn, GraphDto oGraphDto, String query)
			throws Exception {
		
			
			ArrayList<String> dataSetOne = new ArrayList<String>();
			ArrayList<String> dataSetTwo = new ArrayList<String>();
			
			 	CallableStatement cstmt = null;
				ResultSet rs = null;
				
				StringBuffer sbQuery = new StringBuffer();
				sbQuery.append(query);
				System.out.println(query);
				cstmt = conn.prepareCall(sbQuery.toString());
				 
				 
				rs = cstmt.executeQuery();
				if(rs!=null){
					while(rs.next()){
						dataSetOne.add(rs.getString(1));
						dataSetTwo.add(rs.getString(2));
						
						}
						
					
				}
				oGraphDto.setDataSetOne(dataSetOne);
				oGraphDto.setDataSetTwo(dataSetTwo);
				
					
				
				new DBService().releaseResources(rs, cstmt);
				return oGraphDto;
		
		}

	@Override
	public GraphDto getEGTChartData(Connection conn, GraphDto oGraphDto,
			String query, String chartCase) throws Exception {
		
		ArrayList<String> dataSetOne = new ArrayList<String>();
		ArrayList<String> dataSetTwo = new ArrayList<String>();
		
		if(chartCase.equalsIgnoreCase("G")){
		     query = "{call IAO_600_Rawdata_Temp_1_Green()}";
		}
		else if(chartCase.equalsIgnoreCase("R")){
			query = "{call IAO_600_Rawdata_Temp_1_Red()}";
		}
		else if(chartCase.equalsIgnoreCase("B")){
			query = "{call IAO_600_Rawdata_Temp_1_Black()}";
		}
		
		
		
		 	CallableStatement cstmt = null;
			ResultSet rs = null;
			
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(query);
			System.out.println(query);
			cstmt = conn.prepareCall(sbQuery.toString());
			 
			rs = cstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					dataSetOne.add(rs.getString(2));   //1 - date 2 - temp a 3 - temp b
					dataSetTwo.add(rs.getString(3));
				}
			}
			oGraphDto.setDataSetOne(dataSetOne);
			oGraphDto.setDataSetTwo(dataSetTwo);
			
			getDataMap(conn, oGraphDto, chartCase);
			
			new DBService().releaseResources(rs, cstmt);
			return oGraphDto;
	
	}
	@Override
	public GraphDto getEGTChartDataTwo(Connection conn, GraphDto oGraphDto,
			String query, String chartCase) throws Exception {
		
		ArrayList<String> dataSetOne = new ArrayList<String>();
		ArrayList<String> dataSetTwo = new ArrayList<String>();
		
		if(chartCase.equalsIgnoreCase("G")){
		     query = "{call IAO_600_Speed_Green()}";
		}
		else if(chartCase.equalsIgnoreCase("R")){
			query = "{call IAO_600_Speed_Red()}";
		}
		else if(chartCase.equalsIgnoreCase("B")){
			query = "{call IAO_600_Speed_Black()}";
		}
		
		
		
		 	CallableStatement cstmt = null;
			ResultSet rs = null;
			
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(query);
			System.out.println(query);
			cstmt = conn.prepareCall(sbQuery.toString());
			 
			rs = cstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					dataSetOne.add(rs.getString(2));   //1 - date 2 - temp a 3 - temp b
					dataSetTwo.add(rs.getString(3));
				}
			}
			oGraphDto.setDataSetOne(dataSetOne);
			oGraphDto.setDataSetTwo(dataSetTwo);
			
			getDataMapTwo(conn, oGraphDto, chartCase);
			
			new DBService().releaseResources(rs, cstmt);
			return oGraphDto;
	
	}
	

	@Override
	public GraphDto getEGTChartData3(Connection conn, GraphDto oGraphDto,
			String query, String chartCase) throws Exception {

		ArrayList<String> dataSetOne = new ArrayList<String>();
		ArrayList<String> dataSetTwo = new ArrayList<String>();
		
		if(chartCase.equalsIgnoreCase("G")){
		     query = "{call IAO_600_Fuel_Green()}";
		}
		else if(chartCase.equalsIgnoreCase("R")){
			query = "{call IAO_600_Fuel_Red()}";
		}
		else if(chartCase.equalsIgnoreCase("B")){
			query = "{call IAO_600_Fuel_Black()}";
		}
		
		
		
		 	CallableStatement cstmt = null;
			ResultSet rs = null;
			
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(query);
			System.out.println(query);
			cstmt = conn.prepareCall(sbQuery.toString());
			 
			rs = cstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					dataSetOne.add(rs.getString(2));   //1 - date 2 - temp a 3 - temp b
					dataSetTwo.add(rs.getString(3));
				}
			}
			oGraphDto.setDataSetOne(dataSetOne);
			oGraphDto.setDataSetTwo(dataSetTwo);
			
			getDataMap3(conn, oGraphDto, chartCase);
			
			new DBService().releaseResources(rs, cstmt);
			return oGraphDto;
	
	}
	@Override
	public GraphDto getEGTChartDataFour(Connection conn, GraphDto oGraphDto,
			String query, String chartCase) throws Exception {
		
		ArrayList<String> dataSetOne = new ArrayList<String>();
		ArrayList<String> dataSetTwo = new ArrayList<String>();
		
		if(chartCase.equalsIgnoreCase("G")){
		     query = "{call IAO_600_Whether_Green()}";
		}
		else if(chartCase.equalsIgnoreCase("R")){
			query = "{call IAO_600_Whether_Red()}";
		}
		else if(chartCase.equalsIgnoreCase("B")){
			query = "{call IAO_600_Whether_Black()}";
		}
		
		
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		
		StringBuffer sbQuery = new StringBuffer();
		sbQuery.append(query);
		System.out.println(query);
		cstmt = conn.prepareCall(sbQuery.toString());
		 
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				dataSetOne.add(rs.getString(2));   //1 - date 2 - temp a 3 - temp b
				dataSetTwo.add(rs.getString(3));
			}
		}
		oGraphDto.setDataSetOne(dataSetOne);
		oGraphDto.setDataSetTwo(dataSetTwo);
		
		getDataMapFour(conn, oGraphDto, chartCase);
		
		new DBService().releaseResources(rs, cstmt);
		return oGraphDto;


	}
	private void getDataMapFour(Connection conn, GraphDto oGraphDto, String chartCase) throws Exception {
	    Map<String, String> dataOneMap = new HashMap<String, String>();
		
	 	CallableStatement cstmt = null;
		ResultSet rs = null;
		String query = null;
		if(chartCase.equalsIgnoreCase("G")){
		     query = "{call IAO_300_Rawdata_Whether_line_Green()}";
		}
		else if(chartCase.equalsIgnoreCase("R")){
			query = "{call IAO_300_Rawdata_Whether_line_Red()}";
		}
		else if(chartCase.equalsIgnoreCase("B")){
			query = "{call IAO_300_Rawdata_Whether_line_Black()}";
		}
		
		
		
		

		StringBuffer sbQuery = new StringBuffer();
		sbQuery.append(query);
		System.out.println(query);
		cstmt = conn.prepareCall(sbQuery.toString());
		 
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				
				String dateValue = formatDate(rs.getString(1));
				dataOneMap.put(dateValue, rs.getString(2));
			}
   	    }
		System.out.println(dataOneMap);
		Map<String, String> treeMap = new TreeMap<String, String>(dataOneMap);
		System.out.println(treeMap);
		oGraphDto.setDataOneMap(treeMap);
}
	private void getDataMap3(Connection conn, GraphDto oGraphDto,
			String chartCase)throws Exception {
	    Map<String, String> dataOneMap = new HashMap<String, String>();
		
	 	CallableStatement cstmt = null;
		ResultSet rs = null;
		String query = null;
		if(chartCase.equalsIgnoreCase("G")){
		     query = "{call IAO_300_Rawdata_Fuel_line_Green()}";
		}
		else if(chartCase.equalsIgnoreCase("R")){
			query = "{call IAO_300_Rawdata_Fuel_line_Red()}";
		}
		else if(chartCase.equalsIgnoreCase("B")){
			query = "{call IAO_300_Rawdata_Fuel_line_Black()}";
		}
	
		StringBuffer sbQuery = new StringBuffer();
		sbQuery.append(query);
		System.out.println(query);
		cstmt = conn.prepareCall(sbQuery.toString());
		 
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				
				String dateValue = formatDate(rs.getString(1));
				dataOneMap.put(dateValue, rs.getString(2));
			}
   	    }
		System.out.println(dataOneMap);
		Map<String, String> treeMap = new TreeMap<String, String>(dataOneMap);
		System.out.println(treeMap);
		oGraphDto.setDataOneMap(treeMap);
}
 

	private void getDataMapTwo(Connection conn, GraphDto oGraphDto, String chartCase) throws Exception {
	    Map<String, String> dataOneMap = new HashMap<String, String>();
	 	CallableStatement cstmt = null;
		ResultSet rs = null;
		String query = null;
		if(chartCase.equalsIgnoreCase("G")){
		     query = "{call IAO_300_Rawdata_Speed_line_Green()}";
		}
		else if(chartCase.equalsIgnoreCase("R")){
			query = "{call IAO_300_Rawdata_Speed_line_Red()}";
		}
		else if(chartCase.equalsIgnoreCase("B")){
			query = "{call IAO_300_Rawdata_Speed_line_Black()}";
		}
	
		StringBuffer sbQuery = new StringBuffer();
		sbQuery.append(query);
		System.out.println(query);
		cstmt = conn.prepareCall(sbQuery.toString());
		 
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				
				String dateValue = formatDate(rs.getString(1));
				dataOneMap.put(dateValue, rs.getString(2));
			}
   	    }
		System.out.println(dataOneMap);
		Map<String, String> treeMap = new TreeMap<String, String>(dataOneMap);
		System.out.println(treeMap);
		oGraphDto.setDataOneMap(treeMap);
}

	private void getDataMap(Connection conn, GraphDto oGraphDto, String chartCase) throws Exception {
		    Map<String, String> dataOneMap = new HashMap<String, String>();
			
		 	CallableStatement cstmt = null;
			ResultSet rs = null;
			String query = null;
			if(chartCase.equalsIgnoreCase("G")){
			     query = "{call IAO_300_Rawdata_Temp_1_line_Green()}";
			}
			else if(chartCase.equalsIgnoreCase("R")){
				query = "{call IAO_300_Rawdata_Temp_1_line_Red()}";
			}
			else if(chartCase.equalsIgnoreCase("B")){
				query = "{call IAO_300_Rawdata_Temp_1_line_Black()}";
			}
		
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(query);
			System.out.println(query);
			cstmt = conn.prepareCall(sbQuery.toString());
			 
			rs = cstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					
					String dateValue = formatDate(rs.getString(1));
					dataOneMap.put(dateValue, rs.getString(2));
				}
	   	    }
			System.out.println(dataOneMap);
			Map<String, String> treeMap = new TreeMap<String, String>(dataOneMap);
			System.out.println(treeMap);
			oGraphDto.setDataOneMap(treeMap);
	}

	private String formatDate(String string) throws Exception{
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		
		Date date = format.parse(string);
		long timeInMillis = date.getTime();
		
	    return String.valueOf(timeInMillis); 	
	}
	
}
	
		
