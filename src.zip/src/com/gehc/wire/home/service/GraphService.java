package com.gehc.wire.home.service;

import com.gehc.wire.home.dto.GraphDto;
import com.gehc.wire.home.dto.HomeDto;


/**
 * @author 703092428
 * @FileName HomeService.java
 * @CreateDate Nov 26, 2012
 */
public interface GraphService {
 
	GraphDto getTurboDynValues(GraphDto oGraphDto)throws Exception;

	GraphDto getDTFailureDynaValues(GraphDto oGraphDto)throws Exception;

	GraphDto getfailureRateV1DynaValues(GraphDto oGraphDto)throws Exception;

	GraphDto getfailureRateV2DynaValues(GraphDto oGraphDto)throws Exception;

	GraphDto getAlarmDetectionValues(GraphDto oGraphDto, String chartCase) throws Exception;

	GraphDto getEGTChartData(GraphDto oGraphDto, String chartCase) throws Exception;



	GraphDto getEGTChartDataFour(GraphDto oGraphDto, String chartCase)
			throws Exception;




	GraphDto getEGTChartData3(GraphDto oGraphDto, String chartCase)throws Exception;


	
	GraphDto getEGTChartDataTwo(GraphDto oGraphDto, String chartCase) throws Exception;

    
}
