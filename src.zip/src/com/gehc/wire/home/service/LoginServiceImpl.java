package com.gehc.wire.home.service;

import java.sql.Connection;

import org.springframework.beans.factory.annotation.Autowired;

import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.home.dao.LoginDAO;
import com.gehc.wire.home.dto.LoginDto;


/**
 * @author 703092428
 * @FileName LoginServiceImpl.java
 * @CreateDate Nov 26, 2012
 */

public class LoginServiceImpl  implements LoginService{
	@Autowired
	LoginDAO loginDAO;
	
	@Autowired
	public void setLoginDAO(LoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}

	//@Override
	public boolean isValidUser(Connection conn, LoginDto oLoginDto)
			throws Exception {
		
		boolean flag = false;
		flag = loginDAO.validateUser(conn, oLoginDto);
		return flag;
	}

	//@Override
	public UserDto getUserDetails(Connection conn, LoginDto oLoginDto)
			throws Exception {
		return loginDAO.getUserDetails(conn, oLoginDto);
	}
}
