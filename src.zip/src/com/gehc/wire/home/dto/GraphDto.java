package com.gehc.wire.home.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.gehc.wire.common.service.CommonService;


/**
 * 
 */
public class GraphDto {
	
	private String sso = null;
	
	
	private String x = null;
	private String y = null;
	private String z = null;
	
	private ArrayList dataSetOne= new ArrayList();
	private ArrayList dataSetTwo= new ArrayList();
	private ArrayList dataSetThree= new ArrayList();
	
	private Map<String, String> dataOneMap = new HashMap<String, String>();
	


	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}
	
	
	public ArrayList getDataSetOne() {
		return dataSetOne;
	}

	public void setDataSetOne(ArrayList dataSetOne) {
		this.dataSetOne = dataSetOne;
	}

	public ArrayList getDataSetTwo() {
		return dataSetTwo;
	}

	public void setDataSetTwo(ArrayList dataSetTwo) {
		this.dataSetTwo = dataSetTwo;
	}

	public ArrayList getDataSetThree() {
		return dataSetThree;
	}

	public void setDataSetThree(ArrayList dataSetThree) {
		this.dataSetThree = dataSetThree;
	}



	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	public String getZ() {
		return z;
	}
	public void setZ(String z) {
		this.z = z;
	}

	public Map<String, String> getDataOneMap() {
		return dataOneMap;
	}

	public void setDataOneMap(Map<String, String> dataOneMap) {
		this.dataOneMap = dataOneMap;
	}


	
	
	
}
