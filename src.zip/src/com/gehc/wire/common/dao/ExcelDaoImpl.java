package com.gehc.wire.common.dao;

import java.sql.Connection;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelDaoImpl implements ExcelDao {
	private static final Logger logger = Logger.getLogger(ExcelDaoImpl.class);
	

	
	public HSSFWorkbook writeTableData(Connection conn,
			HSSFWorkbook sampleWorkbook, HSSFSheet sampleDataSheet,HSSFPatriarch patriarch) throws Exception {

		
		
		
		
		return sampleWorkbook;
	}
}
