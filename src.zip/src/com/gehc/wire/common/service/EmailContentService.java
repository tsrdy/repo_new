package com.gehc.wire.common.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class EmailContentService {
	
	public static String getNewSDMCreationHeader(){
		StringBuffer sb =new StringBuffer();
		return sb.toString();
	}
	
	public static String getNewSDMCreationFooter(){
		StringBuffer sb =new StringBuffer();
		return sb.toString();
	}
	
	
	
	
}




