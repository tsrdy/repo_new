package com.gehc.wire.common.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.gehc.wire.common.constants.BGConstants;
import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.utilities.PropertyUtility;

public class ExcelService {
	
	public static final String APP_SCHEMA = PropertyService.getProperty(BGConstants.APP_PRPPERTIES_FILE,BGConstants.APP_DB_SCHEMA);
	static String sUploadPath = PropertyUtility.getProperty(MPRConstants.APP_PRPPERTIES_FILE, MPRConstants.APP_UPLOAD_PATH);
	
	/*public static CallableStatement getProductmanagementData(CallableStatement cstmt, QuarterActivityDto oQuarterActivityDto) throws Exception{
        
        ArrayList alXlsFieldsList = new ArrayList();
        
        MultipartFile file = oQuarterActivityDto.getFile();
        System.out.println(file);
        if(file == null){
                        System.out.println("did not enter the file");
        }
        else{
                        System.out.println("file is uploaded...");
        }
        InputStream myxls = file.getInputStream();
        
        HSSFWorkbook wb = new HSSFWorkbook(myxls);

        HSSFSheet xlSheet = wb.getSheetAt(0);
        HSSFSheet xlSheet1 = wb.getSheetAt(1);
        HSSFRow xlFirstRow = xlSheet.getRow(2);
        HSSFRow xlPresentRow = null;
        HSSFRow xlPresentRow1 = null;
        
        HSSFCell xlmodalityQ = null;
        HSSFCell xlregionQ = null;
        
        HSSFCell xlmarketSizeQ1 = null;
        HSSFCell xlmarketSizeVQ1 = null;
        HSSFCell xlgeOrderQ1 = null;
        HSSFCell xlgeOrderVQ1 = null;
        HSSFCell xlmarkerShareQ1 = null;
        HSSFCell xlmarkerShareVQ1 = null;
        
        HSSFCell xlmarketSizeQ2 = null;
        HSSFCell xlmarketSizeVQ2 = null;
        
        HSSFCell xlReportID = null;
        
        String status="SaveDraft";
                                       
                                       
        int iCountOfRows = xlSheet.getLastRowNum();
        int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();

        int iCount = 1;
        for (int i = 2; i < iCountOfRows; i++) {
        
                        xlPresentRow = xlSheet.getRow(i);
                        xlPresentRow1 = xlSheet1.getRow(i);
                        if (xlPresentRow != null) {
                                        
                        	xlmodalityQ = xlPresentRow.getCell(1);
                        	xlregionQ = xlPresentRow.getCell(2);
                        	
                        	
                        	xlmarketSizeQ1 = xlPresentRow.getCell(3);
                        	xlmarketSizeVQ1 = xlPresentRow.getCell(4);
                        	xlgeOrderQ1 = xlPresentRow.getCell(5);
                        	xlgeOrderVQ1 = xlPresentRow.getCell(6);
                        	xlmarkerShareQ1 = xlPresentRow.getCell(7);
                        	xlmarkerShareVQ1 = xlPresentRow.getCell(8);
                        	xlmarketSizeQ2 = xlPresentRow.getCell(9);
                        	xlmarketSizeVQ2 = xlPresentRow.getCell(10);
                        	
                        	xlReportID=xlPresentRow1.getCell(1);
                        	
                        	String id="1";
                        	
                        	
                        	String sTemp = "";
                            if (xlReportID == null)
                                            sTemp = null;
                            else if (xlReportID.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlReportID.getNumericCellValue();
                            else if (xlReportID.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlReportID.getStringCellValue();
                            else
                                            sTemp = null;
                            
                            if (xlReportID != null && xlReportID.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                cstmt.setInt(1, (int) xlReportID.getNumericCellValue());
                            else
                                cstmt.setString(1, sTemp);

                        	
                             sTemp = "";
                            if (xlmodalityQ == null)
                                            sTemp = null;
                            else if (xlmodalityQ.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmodalityQ.getNumericCellValue();
                            else if (xlmodalityQ.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmodalityQ.getStringCellValue();
                            else
                                            sTemp = null;

                                            cstmt.setString(2, sTemp);
                            
                            sTemp = "";
                            if (xlregionQ == null)
                                            sTemp = null;
                            else if (xlregionQ.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlregionQ.getNumericCellValue();
                            else if (xlregionQ.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlregionQ.getStringCellValue();
                            else
                                            sTemp = null;

                            
                                            cstmt.setString(3, sTemp);
                            
                            
                            
                            sTemp = "";
                            if (xlmarketSizeQ1 == null)
                                            sTemp = null;
                            else if (xlmarketSizeQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmarketSizeQ1.getNumericCellValue();
                            else if (xlmarketSizeQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmarketSizeQ1.getStringCellValue();
                            else
                                            sTemp = null;

                                            cstmt.setString(4, sTemp);
                                            cstmt.setString(5, null);

                        
                            
                            sTemp = "";
                            if (xlmarketSizeVQ1 == null)
                                            sTemp = null;
                            else if (xlmarketSizeVQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmarketSizeVQ1.getNumericCellValue();
                            else if (xlmarketSizeVQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmarketSizeVQ1.getStringCellValue();
                            else
                                            sTemp = null;
                           
                                            cstmt.setString(6, sTemp);
                                            cstmt.setString(7, null);
                                            cstmt.setString(8, null);
                                            cstmt.setString(9, null);
                        	
                        	
                            
                            sTemp = "";
                            if (xlgeOrderQ1 == null)
                                            sTemp = null;
                            else if (xlgeOrderQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlgeOrderQ1.getNumericCellValue();
                            else if (xlgeOrderQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlgeOrderQ1.getStringCellValue();
                            else
                                            sTemp = null;

                                            cstmt.setString(10, sTemp);
                                            cstmt.setString(11, null);
                            
                            
                            
                            sTemp = "";
                            if (xlgeOrderVQ1 == null)
                                            sTemp = null;
                            else if (xlgeOrderVQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlgeOrderVQ1.getNumericCellValue();
                            else if (xlgeOrderVQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlgeOrderVQ1.getStringCellValue();
                            else
                                            sTemp = null;
                           
                                            cstmt.setString(12, sTemp);
                                            cstmt.setString(13, null);
                                            cstmt.setString(14, null);
                                            cstmt.setString(15, null);
                            
                            
                            sTemp = "";
                            if (xlmarkerShareQ1 == null)
                                            sTemp = null;
                            else if (xlmarkerShareQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmarkerShareQ1.getNumericCellValue();
                            else if (xlmarkerShareQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmarkerShareQ1.getStringCellValue();
                            else
                                            sTemp = null;

                            
                                            cstmt.setString(16, sTemp);
                                            cstmt.setString(17, null);
                            
                            
                            sTemp = "";
                            if (xlmarkerShareVQ1 == null)
                                            sTemp = null;
                            else if (xlmarkerShareVQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmarkerShareVQ1.getNumericCellValue();
                            else if (xlmarkerShareVQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmarkerShareVQ1.getStringCellValue();
                            else
                                            sTemp = null;

                           
                                            cstmt.setString(18, sTemp);
                                            cstmt.setString(19, null);
                                            cstmt.setString(20, null);
                                            cstmt.setString(21, null);
                            
                            
                            
                            sTemp = "";
                            if (xlmarketSizeQ2 == null)
                                            sTemp = null;
                            else if (xlmarketSizeQ2.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmarketSizeQ2.getNumericCellValue();
                            else if (xlmarketSizeQ2.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmarketSizeQ2.getStringCellValue();
                            else
                                            sTemp = null;

                            
                                            cstmt.setString(22, sTemp);
                                            cstmt.setString(23, null);
                            
                            
                            sTemp = "";
                            if (xlmarketSizeVQ2 == null)
                                            sTemp = null;
                            else if (xlmarketSizeVQ2.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmarketSizeVQ2.getNumericCellValue();
                            else if (xlmarketSizeVQ2.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmarketSizeVQ2.getStringCellValue();
                            else
                                            sTemp = null;

                            
                                            cstmt.setString(24, sTemp);
                                            cstmt.setString(25, null);
                                            cstmt.setString(26, null);
                                            cstmt.setString(27, null);
                                            
                                            cstmt.setString(28, oQuarterActivityDto.getSso());
                                            cstmt.setString(29, status);
                                            
                        }
                        cstmt.addBatch();
        }
                        
return cstmt;
}
	
public static CallableStatement uploadMPRFXExcelData(CallableStatement cstmt, SettingsDto oSettingsDto) throws Exception{
        
        ArrayList alXlsFieldsList = new ArrayList();
        
        MultipartFile file = oSettingsDto.getFile();
        System.out.println(file);
        if(file == null){
                        System.out.println("did not enter the file");
        }
        else{
                        System.out.println("file is uploaded...");
        }
        InputStream myxls = file.getInputStream();
        
        HSSFWorkbook wb = new HSSFWorkbook(myxls);

        HSSFSheet xlSheet = wb.getSheetAt(0);
        //HSSFSheet xlSheet1 = wb.getSheetAt(1);
        HSSFRow xlFirstRow = xlSheet.getRow(1);
        HSSFRow xlPresentRow = null;
        HSSFRow xlPresentRow1 = null;
        
        HSSFCell xlmodalityQ = null;
        HSSFCell xlregionQ = null;
        
        HSSFCell xlmarketSizeQ1 = null;
        HSSFCell xlmarketSizeVQ1 = null;
        HSSFCell xlgeOrderQ1 = null;
        HSSFCell xlgeOrderVQ1 = null;
        HSSFCell xlmarkerShareQ1 = null;
        HSSFCell xlmarkerShareVQ1 = null;
        
        HSSFCell xlmarketSizeQ2 = null;
        HSSFCell xlmarketSizeVQ2 = null;
        
        HSSFCell xlReportID = null;
        
        String status="SaveDraft";
                                       
                                       
        int iCountOfRows = xlSheet.getLastRowNum();
        int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();

        int iCount = 1;
        for (int i = 1; i <=iCountOfRows; i++) {
        
                        xlPresentRow = xlSheet.getRow(i);
                        //xlPresentRow1 = xlSheet1.getRow(i);
                        if (xlPresentRow != null) {
                                        
                        	xlmodalityQ = xlPresentRow.getCell(0);
                        	xlregionQ = xlPresentRow.getCell(1);
                        	
                        	
                        	xlmarketSizeQ1 = xlPresentRow.getCell(2);
                        	xlmarketSizeVQ1 = xlPresentRow.getCell(3);
                        	xlgeOrderQ1 = xlPresentRow.getCell(4);
                        	
                        	                       	
                        	
                        	String id="1";
                        	
                        	
                        	cstmt.setInt(1, Integer.parseInt(oSettingsDto.getYear()));
                        	cstmt.setInt(2, Integer.parseInt(oSettingsDto.getQuarter()));
                        	cstmt.setString(3, null);
                        	
                        	
                        	
                        	String sTemp = "";
                            if (xlmodalityQ == null)
                                            sTemp = null;
                            else if (xlmodalityQ.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmodalityQ.getNumericCellValue();
                            else if (xlmodalityQ.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmodalityQ.getStringCellValue();
                            else
                                            sTemp = null;

                                            cstmt.setString(4, sTemp);
                            
                            sTemp = "";
                            if (xlregionQ == null)
                                            sTemp = null;
                            else if (xlregionQ.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlregionQ.getNumericCellValue();
                            else if (xlregionQ.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlregionQ.getStringCellValue();
                            else
                                            sTemp = null;

                            
                                            cstmt.setString(5, sTemp);
                            
                            
                            
                            sTemp = "";
                            if (xlmarketSizeQ1 == null)
                                            sTemp = null;
                            else if (xlmarketSizeQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmarketSizeQ1.getNumericCellValue();
                            else if (xlmarketSizeQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmarketSizeQ1.getStringCellValue();
                            else
                                            sTemp = null;

                                            cstmt.setFloat(6, Float.parseFloat(sTemp));
                                            

                        
                            
                            sTemp = "";
                            if (xlmarketSizeVQ1 == null)
                                            sTemp = null;
                            else if (xlmarketSizeVQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlmarketSizeVQ1.getNumericCellValue();
                            else if (xlmarketSizeVQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlmarketSizeVQ1.getStringCellValue();
                            else
                                            sTemp = null;
                           
                                            cstmt.setString(7, sTemp);
                                            
                        	
                        	
                            
                            sTemp = "";
                            if (xlgeOrderQ1 == null)
                                            sTemp = null;
                            else if (xlgeOrderQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + xlgeOrderQ1.getNumericCellValue();
                            else if (xlgeOrderQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + xlgeOrderQ1.getStringCellValue();
                            else
                                            sTemp = null;

                                            cstmt.setFloat(8, Float.parseFloat(sTemp));
                                            
                                            cstmt.setString(9, oSettingsDto.getSso());
                                            
                        }
                        cstmt.addBatch();
        }
                        
return cstmt;
}
	
public static CallableStatement uploadMPRFXExcelData(CallableStatement cstmt, SettingsDto oSettingsDto) throws Exception{
        
        ArrayList alXlsFieldsList = new ArrayList();
        
        MultipartFile file = oSettingsDto.getFile();
        System.out.println(file);
        if(file == null){
                        System.out.println("did not enter the file");
        }
        else{
                        System.out.println("file is uploaded...");
        }
        InputStream myxls = file.getInputStream();
        
        XSSFWorkbook wb = new XSSFWorkbook(myxls);

        XSSFSheet xlSheet = wb.getSheetAt(0);
        //HSSFSheet xlSheet1 = wb.getSheetAt(1);
        XSSFRow xlFirstRow = xlSheet.getRow(1);
        XSSFRow xlPresentRow = null;
        XSSFRow xlPresentRow1 = null;
        
       XSSFCell xlmodalityQ = null;
        XSSFCell xlregionQ = null;
        
        XSSFCell xlmarketSizeQ1 = null;
        XSSFCell xlmarketSizeVQ1 = null;
        XSSFCell xlgeOrderQ1 = null;
        XSSFCell xlgeOrderVQ1 = null;
        XSSFCell xlmarkerShareQ1 = null;
        XSSFCell xlmarkerShareVQ1 = null;
        
        XSSFCell xlmarketSizeQ2 = null;
        XSSFCell xlmarketSizeVQ2 = null;
        
        XSSFCell xlReportID = null;
        
        XSSFCell currencyQ1 = null;
        XSSFCell exchangeRQ1 = null;
        XSSFCell yearQ1 = null;
        XSSFCell quarterQ1 = null;
        
        
        String status="SaveDraft";
                                       
                                       
        int iCountOfRows = xlSheet.getLastRowNum();
        int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();

        int iCount = 1;
        for (int i = 1; i <=iCountOfRows; i++) {
        
                        xlPresentRow = xlSheet.getRow(i);
                        //xlPresentRow1 = xlSheet1.getRow(i);
                        if (xlPresentRow != null) {
                        	currencyQ1 = xlPresentRow.getCell(0);
                        	exchangeRQ1 = xlPresentRow.getCell(1);                        	
                        	yearQ1 = xlPresentRow.getCell(2);
                        	quarterQ1 = xlPresentRow.getCell(3);
                        	
                        	String sTemp = "";
                            if (currencyQ1 == null)
                                            sTemp = null;
                            else if (currencyQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + currencyQ1.getNumericCellValue();
                            else if (currencyQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + currencyQ1.getStringCellValue();
                            else
                                            sTemp = null;

                                            cstmt.setString(1, sTemp);
                            
                            sTemp = "";
                            if (exchangeRQ1 == null)
                                            sTemp = null;
                            else if (exchangeRQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + exchangeRQ1.getNumericCellValue();
                            else if (exchangeRQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + exchangeRQ1.getStringCellValue();
                            else
                                            sTemp = null;

                            
                                            cstmt.setString(2, sTemp);
                            
                            
                            
                            sTemp = "";
                            if (yearQ1 == null)
                                            sTemp = null;
                            else if (yearQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + yearQ1.getNumericCellValue();
                            else if (yearQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + yearQ1.getStringCellValue();
                            else
                                            sTemp = null;

                                            cstmt.setFloat(3, Float.parseFloat(sTemp));
                                            

                        
                            
                            sTemp = "";
                            if (quarterQ1 == null)
                                            sTemp = null;
                            else if (quarterQ1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
                                            sTemp = sTemp + quarterQ1.getNumericCellValue();
                            else if (quarterQ1.getCellType() == HSSFCell.CELL_TYPE_STRING)
                                            sTemp = sTemp + quarterQ1.getStringCellValue();
                            else
                                            sTemp = null;
                           
                                            cstmt.setString(4, sTemp);                                          
                                            
                        }
                        cstmt.addBatch();
        }
                        
return cstmt;
}
private static void createCell(HSSFWorkbook wb, HSSFRow row, short column, short align,Float value)
{
	HSSFCell cell = row.createCell(column);
	cell.setCellValue(value);
	cell.setCellType(cell.CELL_TYPE_NUMERIC);
	HSSFCellStyle cellStyle = wb.createCellStyle();
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
}
private static void createCell(HSSFWorkbook wb, HSSFRow row, short column, short align,String value)
{
	//Float f = Float.valueOf(value.trim()).floatValue();
	HSSFCell cell = row.createCell(column);
	cell.setCellValue(value);
	cell.setCellType(cell.CELL_TYPE_STRING);
	
	HSSFCellStyle cellStyle = wb.createCellStyle();
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
	cell.removeCellComment();
}
private static void createCell(HSSFWorkbook wb, HSSFRow row, short column, short align,Float value,String flag)
{
	HSSFCellStyle cellStyle = wb.createCellStyle();
	HSSFDataFormat df = wb.createDataFormat();

	if(flag.equalsIgnoreCase("CommaSeperated")){
		//createDataFormat();
		cellStyle.setDataFormat(df.getFormat("#,##0"));
	}
	else if(flag.equalsIgnoreCase("percentageAppend")){
		cellStyle.setDataFormat(df.getFormat("0%"));
	}
	HSSFCell cell = row.createCell(column);
	cell.setCellValue(value);
	//cell.setCellType(cell.CELL_TYPE_NUMERIC);
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
}
public static void createCell(HSSFWorkbook wb, HSSFRow row, short column, short align,String value, HSSFCellStyle cellStyle, short index, short solidForeground, short index2, short boldweightBold)
{
	//Float f = Float.valueOf(value.trim()).floatValue();
	
	HSSFCell cell = row.createCell(column);
	cell.setCellValue(value);
	cellStyle =  wb.createCellStyle(); 
	cellStyle.setFillForegroundColor(index);   
	cellStyle.setFillPattern(solidForeground);   
	HSSFFont my_font=wb.createFont();
	my_font.setColor(index2);
    my_font.setBoldweight(boldweightBold);
    cellStyle.setFont(my_font);
    
    cellStyle.setBorderBottom(cellStyle.BORDER_THIN);
    cellStyle.setBottomBorderColor(IndexedColors.WHITE.getIndex());
    cellStyle.setBorderLeft(cellStyle.BORDER_THIN);
    cellStyle.setLeftBorderColor(IndexedColors.WHITE.getIndex());
    cellStyle.setBorderRight(cellStyle.BORDER_THIN);
    cellStyle.setRightBorderColor(IndexedColors.WHITE.getIndex());
    cellStyle.setBorderTop(cellStyle.BORDER_THIN);
    cellStyle.setTopBorderColor(IndexedColors.WHITE.getIndex());
    cellStyle.setLocked(true);
	cell.setCellType(cell.CELL_TYPE_STRING);
	
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
	
	cell.removeCellComment();
}
public static void createCellI(HSSFWorkbook wb, HSSFRow row, short column, short align,double value, HSSFCellStyle cellStyle, short index, short solidForeground, short index2, short boldweightBold)
{
	//Float f = Float.valueOf(value.trim()).floatValue();
	
	HSSFCell cell = row.createCell(column);
	cell.setCellValue(value);
	cellStyle =  wb.createCellStyle(); 
	cellStyle.setFillForegroundColor(index);   
	cellStyle.setFillPattern(solidForeground);   
	HSSFFont my_font=wb.createFont();
	my_font.setColor(index2);
    my_font.setBoldweight(boldweightBold);
    cellStyle.setFont(my_font);
    
    cellStyle.setBorderBottom(cellStyle.BORDER_THIN);
    cellStyle.setBottomBorderColor(IndexedColors.WHITE.getIndex());
    cellStyle.setBorderLeft(cellStyle.BORDER_THIN);
    cellStyle.setLeftBorderColor(IndexedColors.WHITE.getIndex());
    cellStyle.setBorderRight(cellStyle.BORDER_THIN);
    cellStyle.setRightBorderColor(IndexedColors.WHITE.getIndex());
    cellStyle.setBorderTop(cellStyle.BORDER_THIN);
    cellStyle.setTopBorderColor(IndexedColors.WHITE.getIndex());
	cell.setCellType(cell.CELL_TYPE_NUMERIC);
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
	
	cell.removeCellComment();
}

public static CallableStatement uploadGEData(CallableStatement cstmt, DataDto oDataDto) throws Exception{
    
    ArrayList alXlsFieldsList = new ArrayList();
    
    List<MultipartFile> files = oDataDto.getFiles();
    
    MultipartFile file = files.get(0);
    System.out.println(file);
    if(file == null){
                    System.out.println("did not enter the file");
    }
    else{
                    System.out.println("file is uploaded...");
    }
    InputStream myxls = file.getInputStream();
    
    HSSFWorkbook wb = new HSSFWorkbook(myxls);

    HSSFSheet xlSheet = wb.getSheetAt(0);
    HSSFSheet xlSheet1 = wb.getSheetAt(1);
    HSSFRow xlFirstRow = xlSheet.getRow(0);
    HSSFRow xlPresentRow = null;
    HSSFRow xlPresentRow1 = null;
    
    HSSFCell xlYear = null;
    HSSFCell xlQtr = null;
    HSSFCell xlRegion = null;
    HSSFCell xlSubRegion = null;
    
    HSSFCell xlCountry = null;
    HSSFCell xlState = null;
    HSSFCell xlGroup = null;
    HSSFCell xlModality = null;
    HSSFCell xlSubModality = null;
    HSSFCell xlSegment = null;
    HSSFCell xlProduct = null;
    
    HSSFCell xlOrderD = null;
    HSSFCell xlSalesD = null;
    HSSFCell xlOrderH = null;
    HSSFCell xlSalesH = null;
    HSSFCell xlCurrencyH = null;
    
    String status="SaveDraft";
                                   
                                   
   int iCountOfRows = xlSheet.getLastRowNum();
    int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();

    int iCount = 1;
    for (int i = 1; i <= iCountOfRows; i++) {
    
                    xlPresentRow = xlSheet.getRow(i);
                    xlPresentRow1 = xlSheet1.getRow(i);
                    if (xlPresentRow != null) {
                                    
                    	//xlYear = xlPresentRow.getCell(2);
                    	xlQtr = xlPresentRow.getCell(1);
                    	xlRegion = xlPresentRow.getCell(3);
                    	System.out.println("xlRegion "+xlRegion);
                    	
                    	xlSubRegion = xlPresentRow.getCell(4);
                    	System.out.println("xlSubRegion "+xlSubRegion);
                    	
                    	xlCountry = xlPresentRow.getCell(5);
                    	System.out.println("xlCountry "+xlCountry);
                    	
                    	xlState  = xlPresentRow.getCell(6);
                    	System.out.println("xlState "+xlState);
                    	
                    	xlGroup = xlPresentRow.getCell(7);
                    	System.out.println("xlGroup "+xlGroup);
                    	
                    	xlModality = xlPresentRow.getCell(8);
                    	System.out.println("xlModality "+xlModality);
                    	
                    	xlSubModality = xlPresentRow.getCell(9);
                    	System.out.println("xlSubModality "+xlSubModality);
                    	
                    	xlSegment = xlPresentRow.getCell(10);
                    	System.out.println("xlSegment "+xlSegment);
                    	
                    	xlProduct = xlPresentRow.getCell(11);
                    	System.out.println("xlProduct "+xlProduct);
                    	// created By
                    	xlOrderD = xlPresentRow.getCell(12);
                    	System.out.println("xlOrderD "+xlOrderD);
                    	
                    	xlSalesD = xlPresentRow.getCell(13);
                    	System.out.println("xlSalesD "+xlSalesD);
                    	
                    	xlCurrencyH = xlPresentRow.getCell(2);
                    	System.out.println("xlCurrencyH "+xlCurrencyH);

                    	
                    	
                    	String id="1";
                    	
                    	
                	String sTemp = "";
                    sTemp = "";
                        
                        sTemp = xlRegion+"~"+xlSubRegion+"~"+xlCountry+"~"+xlState+"~"+xlGroup+"~"+xlModality+"~"+xlSubModality+"~"+xlSegment+"~"+xlProduct+"~"+xlCurrencyH;
                        
                        cstmt.setString(1, sTemp);
                        System.out.println("1"+sTemp);
                        
                        
                       
                        cstmt.setString(2, xlQtr.toString());
                        System.out.println("2"+xlQtr.toString());                

                    
                        cstmt.setString(3, "Both");
                        System.out.println("3"+"Both");
                        
                        
                        
                        sTemp = "";
                        if (xlOrderD == null)
                            sTemp = null;
                        else if (xlOrderD.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
                        	cstmt.setDouble(4, (double) xlOrderD.getNumericCellValue());
                        	System.out.println("4"+(double) xlOrderD.getNumericCellValue());
                        }
                        else{
                        	cstmt.setString(4,sTemp);
                        	System.out.println("4"+sTemp);
                        }
                        
                      
                                        
                      sTemp = "";
                      if (xlSalesD == null)
                               sTemp = null;
                       else if (xlSalesD.getCellType() == HSSFCell.CELL_TYPE_NUMERIC){
                              cstmt.setDouble(5, (double) xlSalesD.getNumericCellValue());
                              System.out.println("5"+(double) xlSalesD.getNumericCellValue());
                       }else{
                    	  cstmt.setString(5, sTemp);
                    	  System.out.println("5"+sTemp);
                       }
                     
                      
                      cstmt.setString(6, oDataDto.getSso());
                      System.out.println("6"+ oDataDto.getSso());    
                                                        
                                       
                    }
                    cstmt.addBatch();
    }
                    
return cstmt;
}

public static File getExcelFile(QuarterActivityDto oQuarterActivityDto) throws IOException 
{

	ResultSetMetaData rsmd = null;
	FileOutputStream oFileOutputStream = null;
	TableDto oTableDto = null;
	
	String sFileName = "PRCentral";
	 
	  
	sFileName = oQuarterActivityDto.getReportPage()+".xls";
	  
	File oFile = new File(sFileName);  
	oFileOutputStream = new FileOutputStream(oFile);
	
	HSSFWorkbook wb  = new HSSFWorkbook();
	HSSFSheet sheet = wb.createSheet("Sheet"+1);
	HSSFRow row  = null;
	HSSFCell cell = null;
	ArrayList<TableDto> alData = oQuarterActivityDto.getAlDataOne();
	if(alData!=null){
		int iColumnCount = 0;
		
		for(int i=0;i<alData.size();i++){
			 row     = sheet.createRow(i);
			oTableDto = alData.get(i);
			if(i==0)
				iColumnCount	= oTableDto.getColumnCount();
			for(int j=1;j<=iColumnCount;j++){
				 row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j)); 
			}
		}
	}
	wb.write(oFileOutputStream);
	return oFile;
}


private static void createCell(HSSFWorkbook wb, HSSFRow row, int column, short align,String value)
{
	//Float f = Float.valueOf(value.trim()).floatValue();
	HSSFCell cell = row.createCell(column-1);
	cell.setCellValue(value);
	cell.setCellType(cell.CELL_TYPE_STRING);
	
	HSSFCellStyle cellStyle = wb.createCellStyle();
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
	cell.removeCellComment();
}


private static void createCell(XSSFWorkbook wb, XSSFRow row, int column, short align,String value)
{
	//Float f = Float.valueOf(value.trim()).floatValue();
	XSSFCell cell = row.createCell(column-1);
	cell.setCellValue(value);
	cell.setCellType(cell.CELL_TYPE_STRING);
	
	XSSFCellStyle cellStyle = wb.createCellStyle();
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
	cell.removeCellComment();
}

private static void createCell(XSSFWorkbook wb, XSSFRow row, int column, short align,Double value)
{
	//Float f = Float.valueOf(value.trim()).floatValue();
	XSSFCell cell = row.createCell(column-1);
	cell.setCellValue(value);
	cell.setCellType(cell.CELL_TYPE_STRING);
	
	XSSFCellStyle cellStyle = wb.createCellStyle();
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
	cell.removeCellComment();
}

private static void createCell(HSSFWorkbook wb, HSSFRow row, int column, short align,Double value)
{
	//Float f = Float.valueOf(value.trim()).floatValue();
	HSSFCell cell = row.createCell(column-1);
	cell.setCellValue(value);
	cell.setCellType(cell.CELL_TYPE_NUMERIC);
	
	HSSFCellStyle cellStyle = wb.createCellStyle();
	cellStyle.setAlignment(align);
	cell.setCellStyle(cellStyle);
	cell.removeCellComment();
}


public static XSSFWorkbook getExcelDownloadOptionOneDataTemplate(ResultSet rs,String sFileName, String sheetName, int sheetNum, QuarterActivityDto oQuarterActivityDto) throws SQLException, IOException {
	
	ResultSetMetaData rsmd = null;
	FileOutputStream oFileOutputStream = null;

	sFileName = sFileName;

	File oFile = new File(sFileName);
	oFileOutputStream = new FileOutputStream(oFile);
	
	XSSFWorkbook wb  = new XSSFWorkbook();
	XSSFSheet sheet = wb.createSheet("Orders");
	XSSFRow row  = null;
	sheet.autoSizeColumn(0); 
	
	XSSFCellStyle styleHeader = wb.createCellStyle();
	
	styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
	styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	styleHeader.setBorderTop((short) 6); // double lines border
	styleHeader.setBorderBottom((short) 1); // single line border
	styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
	styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
	styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
	
    
    XSSFFont fontHeader = wb.createFont();
    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
    fontHeader.setFontHeightInPoints((short) 9);
    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
    fontHeader.setColor(HSSFColor.WHITE.index);
    styleHeader.setFont(fontHeader);
    
    DataValidationHelper dvHelper = sheet.getDataValidationHelper();
    DataValidationConstraint dvConstraint = dvHelper.createExplicitListConstraint(new String[] { "cell 1 edit","cell 2 edit"});
    CellRangeAddressList addressList = new CellRangeAddressList(0, 0, 0, 100);
    DataValidation validation = dvHelper.createValidation(dvConstraint, addressList);

   if (validation instanceof XSSFDataValidation) {
       validation.setSuppressDropDownArrow(false);
       validation.setShowErrorBox(true);
   } else {
       validation.setSuppressDropDownArrow(false);
   }
   
   XSSFCell cell = null;
   
   String downlaodType[] = oQuarterActivityDto.getDownloadType();
   ArrayList downLoadList = new ArrayList();
   for(int i=0;i<downlaodType.length;i++)
   {
	   downLoadList.add(downlaodType[i]);
   }
   
   
    if(downLoadList.size()==0 || downLoadList.contains("Orders"))
    {
    		row = sheet.createRow((short)0); 
    		
             cell = row.createCell(0);
			 cell.setCellValue("Region");
			 cell.setCellStyle(styleHeader);
			 row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			 sheet.setDefaultColumnWidth(20);
			 row.getCell(0).getSheet().addValidationData(validation);

		 
		 	row.createCell(1).setCellValue("Sub Region");
			row.getCell(1).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(1).getSheet().addValidationData(validation);
			
			row.createCell(2).setCellValue("Country");
			row.getCell(2).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(2).getSheet().addValidationData(validation);
			
			row.createCell(3).setCellValue("State");
			row.getCell(3).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(3).getSheet().addValidationData(validation);
			
			
			row.createCell(4).setCellValue("Year");
			row.getCell(4).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(4).getSheet().addValidationData(validation);
			
			
			row.createCell(5).setCellValue("Quarter");
			row.getCell(5).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(5).getSheet().addValidationData(validation);
			
			row.createCell(6).setCellValue("Date (MM/DD/YYYY)");
			row.getCell(6).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(6).getSheet().addValidationData(validation);
			
			row.createCell(7).setCellValue("Modality 1");
			row.getCell(7).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(7).getSheet().addValidationData(validation);
			
			row.createCell(8).setCellValue("Modality 2");
			row.getCell(8).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(8).getSheet().addValidationData(validation);
			
			row.createCell(9).setCellValue("Sub Modality");
			row.getCell(9).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(9).getSheet().addValidationData(validation);
			
			row.createCell(10).setCellValue("Segment");
			row.getCell(10).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(10).getSheet().addValidationData(validation);
			
			row.createCell(11).setCellValue("Currency");
			row.getCell(11).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(11).getSheet().addValidationData(validation);
			
			row.createCell(12).setCellValue("Rate");
			row.getCell(12).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(12).getSheet().addValidationData(validation);
			
			row.createCell(13).setCellValue("Orders (in applied Currency)");
			row.getCell(13).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(13).getSheet().addValidationData(validation);
			
			row.createCell(14).setCellValue("Orders in USD");
			row.getCell(14).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(14).getSheet().addValidationData(validation);
			
			
			row.createCell(15).setCellValue("Market (in applied Currency)");
			row.getCell(15).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(15).getSheet().addValidationData(validation);
			
			
			row.createCell(16).setCellValue("Market (in USD)");
			row.getCell(16).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(16).getSheet().addValidationData(validation);
			
			row.createCell(17).setCellValue("GE Units");
			row.getCell(17).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(17).getSheet().addValidationData(validation);
			
			row.createCell(18).setCellValue("Market Units");
			row.getCell(18).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(18).getSheet().addValidationData(validation);
			
    }
    
    if(downLoadList.contains("Sales")){
			
			 sheet = wb.createSheet("Sales");
			 row  = null;
			 sheet.autoSizeColumn(0); 
			
			 styleHeader = wb.createCellStyle();
			
			styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
			styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			styleHeader.setBorderTop((short) 6); // double lines border
			styleHeader.setBorderBottom((short) 1); // single line border
			styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
			styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
			styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
			
		    
		     fontHeader = wb.createFont();
		    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
		    fontHeader.setFontHeightInPoints((short) 9);
		    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		    fontHeader.setColor(HSSFColor.WHITE.index);
		    styleHeader.setFont(fontHeader);
			
		    		row = sheet.createRow((short)0); 
		    		
		             dvHelper = sheet.getDataValidationHelper();
		             dvConstraint = dvHelper.createExplicitListConstraint(new String[] { "cell 1 edit","cell 2 edit"});
		             addressList = new CellRangeAddressList(0, 0, 0, 100);
		             validation = dvHelper.createValidation(dvConstraint, addressList);

		           if (validation instanceof XSSFDataValidation) {
		               validation.setSuppressDropDownArrow(false);
		               validation.setShowErrorBox(true);
		           } else {
		               validation.setSuppressDropDownArrow(false);
		           }

		                
		              cell = row.createCell(0);
					 cell.setCellValue("Region");
					 cell.setCellStyle(styleHeader);
					 row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					 sheet.setDefaultColumnWidth(20);
					 row.getCell(0).getSheet().addValidationData(validation);

				 
				 	row.createCell(1).setCellValue("Sub Region");
					row.getCell(1).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(1).getSheet().addValidationData(validation);
					
					row.createCell(2).setCellValue("Country");
					row.getCell(2).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(2).getSheet().addValidationData(validation);
					
					row.createCell(3).setCellValue("State");
					row.getCell(3).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(3).getSheet().addValidationData(validation);
					
					
					row.createCell(4).setCellValue("Year");
					row.getCell(4).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(4).getSheet().addValidationData(validation);
					
					
					row.createCell(5).setCellValue("Quarter");
					row.getCell(5).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(5).getSheet().addValidationData(validation);
					
					row.createCell(6).setCellValue("Date (MM/DD/YYYY)");
					row.getCell(6).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(6).getSheet().addValidationData(validation);
					
					row.createCell(7).setCellValue("Modality 1");
					row.getCell(7).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(7).getSheet().addValidationData(validation);
					
					row.createCell(8).setCellValue("Modality 2");
					row.getCell(8).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(8).getSheet().addValidationData(validation);
					
					row.createCell(9).setCellValue("Sub Modality");
					row.getCell(9).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(9).getSheet().addValidationData(validation);
					
					row.createCell(10).setCellValue("Segment");
					row.getCell(10).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(10).getSheet().addValidationData(validation);
					
					row.createCell(11).setCellValue("Currency");
					row.getCell(11).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(11).getSheet().addValidationData(validation);
					
					row.createCell(12).setCellValue("Rate");
					row.getCell(12).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(12).getSheet().addValidationData(validation);
					
					row.createCell(13).setCellValue("Orders (in applied Currency)");
					row.getCell(13).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(13).getSheet().addValidationData(validation);
					
					row.createCell(14).setCellValue("Orders in USD");
					row.getCell(14).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(14).getSheet().addValidationData(validation);
					
					
					row.createCell(15).setCellValue("Market (in applied Currency)");
					row.getCell(15).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(15).getSheet().addValidationData(validation);
					
					
					row.createCell(16).setCellValue("Market (in USD)");
					row.getCell(16).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(16).getSheet().addValidationData(validation);
					
					row.createCell(17).setCellValue("GE Units");
					row.getCell(17).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(17).getSheet().addValidationData(validation);
					
					row.createCell(18).setCellValue("Market Units");
					row.getCell(18).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(18).getSheet().addValidationData(validation);
    }
   
    if(downLoadList.contains("Units"))
    {
    	sheet = wb.createSheet("Units");
		 row  = null;
		 sheet.autoSizeColumn(0); 
		
		 styleHeader = wb.createCellStyle();
		
		styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
		styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		styleHeader.setBorderTop((short) 6); // double lines border
		styleHeader.setBorderBottom((short) 1); // single line border
		styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
		styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
		styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
		
	    
	     fontHeader = wb.createFont();
	    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
	    fontHeader.setFontHeightInPoints((short) 9);
	    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	    fontHeader.setColor(HSSFColor.WHITE.index);
	    styleHeader.setFont(fontHeader);
		
	    		row = sheet.createRow((short)0); 
	    		
	             dvHelper = sheet.getDataValidationHelper();
	             dvConstraint = dvHelper.createExplicitListConstraint(new String[] { "cell 1 edit","cell 2 edit"});
	             addressList = new CellRangeAddressList(0, 0, 0, 100);
	             validation = dvHelper.createValidation(dvConstraint, addressList);

	           if (validation instanceof XSSFDataValidation) {
	               validation.setSuppressDropDownArrow(false);
	               validation.setShowErrorBox(true);
	           } else {
	               validation.setSuppressDropDownArrow(false);
	           }

	                
	              cell = row.createCell(0);
				 cell.setCellValue("Region");
				 cell.setCellStyle(styleHeader);
				 row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				 sheet.setDefaultColumnWidth(20);
				 row.getCell(0).getSheet().addValidationData(validation);

			 
			 	row.createCell(1).setCellValue("Sub Region");
				row.getCell(1).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(1).getSheet().addValidationData(validation);
				
				row.createCell(2).setCellValue("Country");
				row.getCell(2).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(2).getSheet().addValidationData(validation);
				
				row.createCell(3).setCellValue("State");
				row.getCell(3).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(3).getSheet().addValidationData(validation);
				
				
				row.createCell(4).setCellValue("Year");
				row.getCell(4).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(4).getSheet().addValidationData(validation);
				
				
				row.createCell(5).setCellValue("Quarter");
				row.getCell(5).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(5).getSheet().addValidationData(validation);
				
				row.createCell(6).setCellValue("Date (MM/DD/YYYY)");
				row.getCell(6).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(6).getSheet().addValidationData(validation);
				
				row.createCell(7).setCellValue("Modality 1");
				row.getCell(7).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(7).getSheet().addValidationData(validation);
				
				row.createCell(8).setCellValue("Modality 2");
				row.getCell(8).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(8).getSheet().addValidationData(validation);
				
				row.createCell(9).setCellValue("Sub Modality");
				row.getCell(9).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(9).getSheet().addValidationData(validation);
				
				row.createCell(10).setCellValue("Segment");
				row.getCell(10).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(10).getSheet().addValidationData(validation);
				
				row.createCell(11).setCellValue("Currency");
				row.getCell(11).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(11).getSheet().addValidationData(validation);
				
				row.createCell(12).setCellValue("Rate");
				row.getCell(12).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(12).getSheet().addValidationData(validation);
				
				row.createCell(13).setCellValue("Orders (in applied Currency)");
				row.getCell(13).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(13).getSheet().addValidationData(validation);
				
				row.createCell(14).setCellValue("Orders in USD");
				row.getCell(14).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(14).getSheet().addValidationData(validation);
				
				
				row.createCell(15).setCellValue("Market (in applied Currency)");
				row.getCell(15).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(15).getSheet().addValidationData(validation);
				
				
				row.createCell(16).setCellValue("Market (in USD)");
				row.getCell(16).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(16).getSheet().addValidationData(validation);
				
				row.createCell(17).setCellValue("GE Units");
				row.getCell(17).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(17).getSheet().addValidationData(validation);
				
				row.createCell(18).setCellValue("Market Units");
				row.getCell(18).setCellStyle(styleHeader);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
				row.getCell(18).getSheet().addValidationData(validation);
    }
    
    
    if(downLoadList.contains("CM"))
    {
    	 sheet = wb.createSheet("CM");
		 row  = null;
		 sheet.autoSizeColumn(0); 
		
		 styleHeader = wb.createCellStyle();
		
		styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
		styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		styleHeader.setBorderTop((short) 6); // double lines border
		styleHeader.setBorderBottom((short) 1); // single line border
		styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
		styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
		styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
		
	    
	     fontHeader = wb.createFont();
	    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
	    fontHeader.setFontHeightInPoints((short) 9);
	    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	    fontHeader.setColor(HSSFColor.WHITE.index);
	    styleHeader.setFont(fontHeader);
		
	    		row = sheet.createRow((short)0); 
	    		
	             dvHelper = sheet.getDataValidationHelper();
	             dvConstraint = dvHelper.createExplicitListConstraint(new String[] { "cell 1 edit","cell 2 edit"});
	             addressList = new CellRangeAddressList(0, 0, 0, 100);
	             validation = dvHelper.createValidation(dvConstraint, addressList);

	           if (validation instanceof XSSFDataValidation) {
	               validation.setSuppressDropDownArrow(false);
	               validation.setShowErrorBox(true);
	           } else {
	               validation.setSuppressDropDownArrow(false);
	           }

    		
             cell = row.createCell(0);
			 cell.setCellValue("Region");
			 cell.setCellStyle(styleHeader);
			 row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			 sheet.setDefaultColumnWidth(20);
			 row.getCell(0).getSheet().addValidationData(validation);

		 
		 	row.createCell(1).setCellValue("Sub Region");
			row.getCell(1).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(1).getSheet().addValidationData(validation);
			
			row.createCell(2).setCellValue("Country");
			row.getCell(2).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(2).getSheet().addValidationData(validation);
			
			row.createCell(3).setCellValue("State");
			row.getCell(3).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(3).getSheet().addValidationData(validation);
			
			
			row.createCell(4).setCellValue("Year");
			row.getCell(4).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(4).getSheet().addValidationData(validation);
			
			
			row.createCell(5).setCellValue("Quarter");
			row.getCell(5).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(5).getSheet().addValidationData(validation);
			
			row.createCell(6).setCellValue("Date (MM/DD/YYYY)");
			row.getCell(6).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(6).getSheet().addValidationData(validation);
			
			row.createCell(7).setCellValue("Modality 1");
			row.getCell(7).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(7).getSheet().addValidationData(validation);
			
			row.createCell(8).setCellValue("Modality 2");
			row.getCell(8).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(8).getSheet().addValidationData(validation);
			
			row.createCell(9).setCellValue("Sub Modality");
			row.getCell(9).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(9).getSheet().addValidationData(validation);
			
			row.createCell(10).setCellValue("Segment");
			row.getCell(10).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(10).getSheet().addValidationData(validation);
			
			row.createCell(11).setCellValue("Currency");
			row.getCell(11).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(11).getSheet().addValidationData(validation);
			
			row.createCell(12).setCellValue("Rate");
			row.getCell(12).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(12).getSheet().addValidationData(validation);
			
			row.createCell(13).setCellValue("Orders (in applied Currency)");
			row.getCell(13).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(13).getSheet().addValidationData(validation);
			
			row.createCell(14).setCellValue("Orders in USD");
			row.getCell(14).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(14).getSheet().addValidationData(validation);
			
			
			row.createCell(15).setCellValue("Market (in applied Currency)");
			row.getCell(15).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(15).getSheet().addValidationData(validation);
			
			
			row.createCell(16).setCellValue("Market (in USD)");
			row.getCell(16).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(16).getSheet().addValidationData(validation);
			
			row.createCell(17).setCellValue("GE Units");
			row.getCell(17).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(17).getSheet().addValidationData(validation);
			
			row.createCell(18).setCellValue("Market Units");
			row.getCell(18).setCellStyle(styleHeader);
			row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
			sheet.setDefaultColumnWidth(20);
			row.getCell(18).getSheet().addValidationData(validation);
			
    }
    
    
    sheet = wb.createSheet("Instructions");
	 row  = null;
	 sheet.autoSizeColumn(0); 
	
	 styleHeader = wb.createCellStyle();
	
	styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
	styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	styleHeader.setBorderTop((short) 6); // double lines border
	styleHeader.setBorderBottom((short) 1); // single line border
	styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
	styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
	styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
	
   
    fontHeader = wb.createFont();
   fontHeader.setFontName(HSSFFont.FONT_ARIAL);
   fontHeader.setFontHeightInPoints((short) 9);
   fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
   fontHeader.setColor(HSSFColor.WHITE.index);
   styleHeader.setFont(fontHeader);
	
   		row = sheet.createRow((short)0); 
   		
            dvHelper = sheet.getDataValidationHelper();
            dvConstraint = dvHelper.createExplicitListConstraint(new String[] { "cell 1 edit","cell 2 edit"});
            addressList = new CellRangeAddressList(0, 0, 0, 100);
            validation = dvHelper.createValidation(dvConstraint, addressList);

          if (validation instanceof XSSFDataValidation) {
              validation.setSuppressDropDownArrow(false);
              validation.setShowErrorBox(true);
          } else {
              validation.setSuppressDropDownArrow(false);
          }
	wb.write(oFileOutputStream);
	return wb;
}





public static QuarterActivityDto uploadOptionOneDataTemplate(CallableStatement cstmt,QuarterActivityDto oQuarterActivityDto) throws Exception {
	

    
	    List<MultipartFile> files = oQuarterActivityDto.getFiles();
	    MultipartFile file = files.get(0);
	    
	    MultipartFile file = oQuarterActivityDto.getOptionOneGEFile();
	    if(file == null){
	                    System.out.println("did not enter the file");
	    }
	    else{
	                    System.out.println("file is uploaded...");
	    }
	    InputStream myxls = file.getInputStream();
	    
	    XSSFWorkbook wb = new XSSFWorkbook(myxls);
	    int numberOfSheets = wb.getNumberOfSheets();
	    ArrayList<TableDto> alData = new ArrayList<TableDto>(); 
	    
	for(int l=0;l<(numberOfSheets-1);l++){
		
	    XSSFSheet xlSheet = wb.getSheetAt(l);
	    XSSFRow xlFirstRow = xlSheet.getRow(0);
	    XSSFRow xlPresentRow = null;
	    
	   int iCountOfRows = xlSheet.getPhysicalNumberOfRows();
	   int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();
	    
	     
	    TableDto oTableDto = null;
	  
	  
	    String status = "";
	    String validationMessage = "";
	    String values = "";
	    
	    boolean isValidData = true;
	    ResultSet rs = null;
	    
	    Iterator rows = xlSheet.rowIterator();
	    int k=0;
	    while (rows.hasNext()) {
	    	XSSFRow row = (XSSFRow) rows.next();
	    	k++;
	    	
	    }
	    
	    if(k==1 || k==0)
	    {
	    	oQuarterActivityDto.setIsValidData("empty"+xlSheet.getSheetName());
		}
	    else if(iCountOfColumns>19)
	    {
	    	oQuarterActivityDto.setIsValidData("more columns");
	    }
	    else if(iCountOfColumns<19)
	    {
	    	oQuarterActivityDto.setIsValidData("more columns");
	    }
		else
		{
	    for (int i = 1; i <= (iCountOfRows-1); i++) {
	    	 			
	    	 		   	xlPresentRow = xlSheet.getRow(i);
	    	 		   	oTableDto = new TableDto();

	    	 		   for(int m=0;m<(iCountOfColumns-1);m++)
	    	 		  {
	    	 			//  if(xlPresentRow.getCell(m)!=null && !xlPresentRow.getCell(m).toString().equalsIgnoreCase(""))
	    	 			  if((xlPresentRow.getCell(m)!=null && !xlPresentRow.getCell(m).toString().equalsIgnoreCase(""))|| m > 14)
				    		 {
	    	 				 
	    	 				 
	    	 				  
	    	 				  if(m==5  ||  m==12 || m==14)
	    	 				  {
	    	 					  
	    	 					 
	    	 				if(xlPresentRow.getCell(m)!=null && !xlPresentRow.getCell(m).toString().equalsIgnoreCase("CONF")){
	    	 			
	    	 					 Pattern pattern = Pattern.compile(".[^0-9]");
	    	 					 
	    	 					 String input = xlPresentRow.getCell(m).toString().replace(".0", "");
	    	 					 
	    	 					 if(!pattern.matcher(input).matches())
				    			 	{
				    				 oTableDto.setColumnValue((m+1), xlPresentRow.getCell(m).toString());
				    				 
				    		 		}
				    			 else
				    			 	{
				    				 status = "Failure";
					    			 validationMessage = xlFirstRow.getCell(m)+" Value should be numeric, alphanumeric and special charaters are not allowed.";
						    		 
					    			 oTableDto.setStatus(status);
					    			 oTableDto.setValidationMessage(validationMessage);
					    			 
					    			 isValidData = false;
					    			 oQuarterActivityDto.setIsValidData("false");
					    			 alData.add(oTableDto);
				    			 	}
	    	 					 }
	    	 				  }
	    	 				  else if(m==6)
	    	 				  {
	    	 					 String regexMMDDYYYY="^(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\\d\\d$";     
	    	 					 DateFormat dateFormat= new SimpleDateFormat("MM/dd/yyyy");
	    	 					try{
		    	 					Date date= xlPresentRow.getCell(m).getDateCellValue();
		    	 					String dateString= dateFormat.format(date);
		    	 					boolean isDate = Pattern.matches(regexMMDDYYYY, dateString); 
		    	 					System.out.println(isDate);
		    	 					oTableDto.setColumnValue((m+1), xlPresentRow.getCell(m).toString());
	    	 					}catch(Exception e)
	    	 					{
	    	 						status = "Failure";
					    			 validationMessage = xlFirstRow.getCell(m)+" Invalid Date Format";
						    		 
					    			 oTableDto.setStatus(status);
					    			 oTableDto.setValidationMessage(validationMessage);
					    			 
					    			 isValidData = false;
					    			 oQuarterActivityDto.setIsValidData("false");
					    			 alData.add(oTableDto);
	    	 					}
	    	 				  }else if(m==15||m==16||m==17||m==18){
	    	 					 oTableDto.setColumnValue((m+1), "0");  
	    	 				  }
	    	 				  else
	    	 				  {
				    				 if(m==0)
						    	    		values = xlPresentRow.getCell(m).toString();
						    	    	else
						    	    		values = values+"~"+xlPresentRow.getCell(m).toString();
				    				 
				    				 oTableDto.setColumnValue((m+1), xlPresentRow.getCell(m).toString());
				    				 
	    	 				  }
				    		 }
				    		 else
				    		 {
				    			 
				    			 status = "Failure";
				    			 validationMessage = xlFirstRow.getCell(m)+" cannot be blank";
				    			 
				    			 oTableDto.setStatus(status);
				    			 oTableDto.setValidationMessage(validationMessage);
				    			 
				    			 isValidData = false;
				    			 oQuarterActivityDto.setIsValidData("false");
				    			 alData.add(oTableDto);
				    		 }
	    	 			 
	    	 		  }
				   
	    	 		  
	    	 		   
				   if(isValidData)
				   {
					   oQuarterActivityDto.setIsValidData("true");
					   //	alData = new ArrayList<TableDto>();    
					   
				    	 cstmt.setString(1, oQuarterActivityDto.getYear());
				    	 System.out.println("1"+ oQuarterActivityDto.getYear());
				    	 
				    	 cstmt.setString(2, oQuarterActivityDto.getQtr());
				    	 System.out.println("2"+oQuarterActivityDto.getQtr());
				    	 
				    	 
				    	 if(xlPresentRow.getCell(2)!=null)
				    	 {
				    	 cstmt.setString(3, xlPresentRow.getCell(2).toString().replace(".0", ""));
				    	 System.out.println("3"+xlPresentRow.getCell(2).toString().replace(".0", ""));
				    	 }
				    	 else
				    	 {
				    	cstmt.setString(3, null);
					    System.out.println("3"+null);
				    	 }
				    	 
				    	 
				    	 if(xlPresentRow.getCell(3)!=null){
				    	 cstmt.setString(4, xlPresentRow.getCell(3).toString().replace(".0", ""));
				    	 System.out.println("4"+xlPresentRow.getCell(3).toString().replace(".0", ""));
				    	 }
				    	 else{
				    		 cstmt.setString(4, null);
							    System.out.println("4"+null);
				    	 }
				    	 
				    	 if(xlPresentRow.getCell(10)!=null){
				    	 cstmt.setString(5, xlPresentRow.getCell(10).toString().replace(".0", ""));
				    	 System.out.println("5"+xlPresentRow.getCell(10).toString().replace(".0", ""));
					    }
						 else{
							 cstmt.setString(5, null);
							    System.out.println("5"+null);
						 }
				    	 
				    	 
				    	 if(xlPresentRow.getCell(12)!=null){
				    	 cstmt.setString(6, xlPresentRow.getCell(12).toString().replace(".0", ""));
				    	 System.out.println("6"+xlPresentRow.getCell(12).toString().replace(".0", ""));
						}
						else{
							cstmt.setString(6, null);
						    System.out.println("6"+null);
						}
				    	 
				    	 if(xlPresentRow.getCell(13)!=null){
				    	 cstmt.setString(7, xlPresentRow.getCell(13).toString().replace(".0", ""));
				    	 System.out.println("7"+xlPresentRow.getCell(13).toString().replace(".0", ""));
						}
						else{
							cstmt.setString(7, null);
						    System.out.println("7"+null);
						}
				    	 
				    	 if(xlPresentRow.getCell(14)!=null){
				    	 cstmt.setString(8, xlPresentRow.getCell(14).toString().replace(".0", ""));
				    	 System.out.println("8"+xlPresentRow.getCell(14).toString().replace(".0", ""));
					     }
						 else{
							 cstmt.setString(8, null);
							    System.out.println("8"+null);
						 }
				    	 
				    	 if(xlPresentRow.getCell(17)!=null){
				    	 cstmt.setString(9, xlPresentRow.getCell(17).toString().replace(".0", ""));
				    	 System.out.println("9"+xlPresentRow.getCell(17).toString().replace(".0", ""));
					     }
						 else{
							 cstmt.setString(9, null);
							    System.out.println("9"+null);
						 }
				    	
				    	 cstmt.setString(10, "");
				    	 System.out.println("10"+"");
				    	
				    	 cstmt.setString(11, "");
				    	 System.out.println("11"+"");
				    	 
				    	 cstmt.setString(12, oQuarterActivityDto.getReportTypeQA());
				    	 System.out.println("12"+oQuarterActivityDto.getReportTypeQA());
				    	 
				    	 cstmt.setString(13,  oQuarterActivityDto.getSso());
				    	 System.out.println("13"+  oQuarterActivityDto.getSso());
				    	 
				    	 rs = cstmt.executeQuery();   
				    	 
				    	 if(rs!=null){
				    		 while(rs.next())
								{
				    			 status = rs.getString("Status");
				    			 validationMessage = rs.getString("Msg");
				    			 
				    			 oTableDto.setStatus(status);
				    			 oTableDto.setValidationMessage(validationMessage);
								}
				    	 }
				    	 alData.add(oTableDto);
	        }
	      }
		}
	    oQuarterActivityDto.setAlDataOne(alData);
	}	
	return oQuarterActivityDto;
	
	
    
    MultipartFile multipartFile = oQuarterActivityDto.getOptionOneGEFile();
    Date date = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyyh:mm:ssa");
	String formattedDate = sdf.format(date);
	
	String sFileName = multipartFile.getOriginalFilename();
	
	Date now = new Date();
	SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyyhmmss");
	String timestampString = formatter.format(now);

	int lastIndex = sFileName.lastIndexOf(".");
	sFileName =  sFileName.substring(0, lastIndex) + "_" + timestampString + "."
	+ sFileName.substring(lastIndex + 1, sFileName.length());

	
	 MultipartFile file = oQuarterActivityDto.getOptionOneGEFile();
	    if(file == null){
	                    System.out.println("did not enter the file");
	    }
	    else{
	                    System.out.println("file is uploaded...");
	    }
	    InputStream myxls = file.getInputStream();
	    
	    XSSFWorkbook wb = new XSSFWorkbook(myxls);
	    int numberOfSheets = wb.getNumberOfSheets();
	    ArrayList<TableDto> alData = new ArrayList<TableDto>(); 
	    
	for(int l=0;l<(numberOfSheets-1);l++){
		
	    XSSFSheet xlSheet = wb.getSheetAt(l);
	    XSSFRow xlFirstRow = xlSheet.getRow(0);
	    XSSFRow xlPresentRow = null;
	    
	   int iCountOfRows = xlSheet.getPhysicalNumberOfRows();
	   int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();
	    
	     
	    TableDto oTableDto = null;
	  
	  
	    String status = "";
	    String validationMessage = "";
	    String values = "";
	    
	    boolean isValidData = true;
	    ResultSet rs = null;
	    
	    Iterator rows = xlSheet.rowIterator();
	    int k=0;
	    while (rows.hasNext()) {
	    	XSSFRow row = (XSSFRow) rows.next();
	    	k++;
	    	
	    }
	    
	    if(k==1 || k==0)
	    {
	    	oQuarterActivityDto.setIsValidData("empty"+xlSheet.getSheetName());
		}
	    else if(iCountOfColumns>19)
	    {
	    	oQuarterActivityDto.setIsValidData("more columns");
	    }
	    else if(iCountOfColumns<19)
	    {
	    	oQuarterActivityDto.setIsValidData("more columns");
	    }
		else
		{
			 if(multipartFile.getOriginalFilename()!=""){
                 String fileNameToCreate = sUploadPath +"\\"+ sFileName;
                 try {
                       File file2 = new File(fileNameToCreate);
                       if(!file2.exists())
                       		{
                             multipartFile.getSize();
                             FileUtils.writeByteArrayToFile(file2, multipartFile.getBytes());
                       		}
                       } catch (Throwable e) {

                     }
           }
		}
	}
              
     return oQuarterActivityDto;
	}

public static XSSFWorkbook getExcelDownloadOptionOneTableTemplate(Connection conn,String sFileName, String sheetName, int sheetNum, QuarterActivityDto oQuarterActivityDto) throws Exception {
			FileOutputStream oFileOutputStream = null;
			File oFile = new File(sFileName);
			oFileOutputStream = new FileOutputStream(oFile);
			
			CallableStatement cstmt = null;
			ResultSet rs = null;
			ResultSetMetaData rsmd = null;
			CallableStatement cstmt1 = null;
			ResultSet rs1 = null;
			
			XSSFWorkbook wb  = new XSSFWorkbook();
			XSSFSheet sheet = null;
			XSSFRow row  = null;
			XSSFRow row1  = null;
			
			 String downlaodType[] = oQuarterActivityDto.getDownloadType();
			 ArrayList downLoadList = new ArrayList();
			 	for(int i=0;i<downlaodType.length;i++)
				{
				   downLoadList.add(downlaodType[i]);
				}
			 	
			 	if(downLoadList.size()==0)
			 		downLoadList.add("Orders");
			 	
			 	
			 CellStyle style = wb.createCellStyle();
		        style.setBorderBottom(CellStyle.BORDER_MEDIUM);
		        style.setBottomBorderColor(IndexedColors.BLUE.getIndex());
		        style.setBorderLeft(CellStyle.BORDER_MEDIUM);
		        style.setLeftBorderColor(IndexedColors.BLUE.getIndex());
		        style.setBorderRight(CellStyle.BORDER_MEDIUM);
		        style.setRightBorderColor(IndexedColors.BLUE.getIndex());
		        style.setBorderTop(CellStyle.BORDER_MEDIUM);
		        style.setTopBorderColor(IndexedColors.BLUE.getIndex());
		 

			
	           
for(int l=0;l<downLoadList.size();l++){
	
	
	oQuarterActivityDto.setQtrString(oQuarterActivityDto.getYear()+"-"+oQuarterActivityDto.getQtr());

	
	cstmt = conn.prepareCall("{ call "+APP_SCHEMA+".MPR_218_Proc_Download_GE_Table_Template(?,?,?,?,?,?,?,?,?,?,?,?,?)}");
	System.out.println("{ call "+APP_SCHEMA+".MPR_218_Proc_Download_GE_Table_Template(?,?,?,?,?,?,?,?,?)}");
	
	cstmt.setString(1, oQuarterActivityDto.getYear());
	System.out.println("1"+oQuarterActivityDto.getYear());
	
	if(oQuarterActivityDto.getQtr()==null)
	{	
		cstmt.setString(2,"68");
		System.out.println("2"+"68");
	}else
	{	
	cstmt.setString(2, oQuarterActivityDto.getQtr());
	System.out.println("2"+oQuarterActivityDto.getQtr());
	}
	
	cstmt.setString(3, oQuarterActivityDto.getServiceRegion());
	System.out.println("3"+oQuarterActivityDto.getServiceRegion());
	
	cstmt.setString(4, CommonService.getMultiList(oQuarterActivityDto.getSubRegion()));
	System.out.println("4"+CommonService.getMultiList(oQuarterActivityDto.getSubRegion()));
	
	cstmt.setString(5, CommonService.getMultiList(oQuarterActivityDto.getCountry()));
	System.out.println("5"+CommonService.getMultiList(oQuarterActivityDto.getCountry()));
	
	cstmt.setString(6, CommonService.getMultiList(oQuarterActivityDto.getState()));
	System.out.println("6"+CommonService.getMultiList(oQuarterActivityDto.getState()));
	
	cstmt.setString(7, CommonService.getMultiList(oQuarterActivityDto.getGroup()));
	System.out.println("7"+CommonService.getMultiList(oQuarterActivityDto.getGroup()));
	
	cstmt.setString(8, CommonService.getMultiList(oQuarterActivityDto.getModality()));
	System.out.println("8"+CommonService.getMultiList(oQuarterActivityDto.getModality()));
	
	cstmt.setString(9, CommonService.getMultiList(oQuarterActivityDto.getModality2()));
	System.out.println("9"+CommonService.getMultiList(oQuarterActivityDto.getModality2()));
	
	cstmt.setString(10, CommonService.getMultiList(oQuarterActivityDto.getSubModality()));
	System.out.println("10"+CommonService.getMultiList(oQuarterActivityDto.getSubModality()));
	
	cstmt.setString(11, oQuarterActivityDto.getForexExchange());
	System.out.println("11"+oQuarterActivityDto.getForexExchange());

	cstmt.setString(12, oQuarterActivityDto.getDownloadType()[0]);
	System.out.println("12"+oQuarterActivityDto.getDownloadType()[0]);
	
	cstmt.setString(12, oQuarterActivityDto.getTableTemplateReportTypeQA());
	System.out.println("12"+oQuarterActivityDto.getTableTemplateReportTypeQA());
	
	cstmt.setString(13, oQuarterActivityDto.getSso());
	System.out.println("13"+oQuarterActivityDto.getSso());
	
	rs = cstmt.executeQuery();
	
	
	 sheet = wb.createSheet(downLoadList.get(l).toString());
	 sheet.autoSizeColumn(0); 
	
	 DataValidationHelper dvHelper = sheet.getDataValidationHelper();
     DataValidationConstraint dvConstraint = dvHelper.createExplicitListConstraint(new String[] { "cell 1 edit","cell 2 edit"});
     CellRangeAddressList addressList = new CellRangeAddressList(0,1,0,100);
     DataValidation displayNameValidation = dvHelper.createValidation(dvConstraint, addressList);

    if (displayNameValidation instanceof XSSFDataValidation) {
 	   displayNameValidation.setSuppressDropDownArrow(false);
 	   displayNameValidation.setShowErrorBox(true);
    } else {
 	   displayNameValidation.setSuppressDropDownArrow(false);
    }
	 
	 
			if(rs!=null){
				rsmd = rs.getMetaData();
				
				if(!rsmd.getColumnName(1).toString().equalsIgnoreCase("No_Data"))
				{
					int iColumnCount = rsmd.getColumnCount();
					int iRowCount = 1;
					int iSheetNo = 1;
					
					String[] sColumnNames = new String[iColumnCount];
					String[] sValues = new String[iColumnCount];
					 row = sheet.createRow((short)0); 
					 
					 row.createCell(0).setCellValue("Country");
					 row.getCell(0).setCellStyle(style);
						for(int i=1;i<iColumnCount;i++){
							row.createCell(i).setCellValue(rsmd.getColumnName(i+1));
							row.getCell(i).setCellStyle(style);
							row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
							sheet.setDefaultColumnWidth(20);
							row.getCell(i).getSheet().addValidationData(displayNameValidation);
						}
						
						row = sheet.createRow((short)1); 
						row.createCell(0).setCellValue("");
						 row.getCell(0).setCellStyle(style);
						 
						for(int i=1;i<iColumnCount;i++){
							row.createCell(i).setCellValue(oQuarterActivityDto.getQtrString());
							row.getCell(i).setCellStyle(style);
							row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
							sheet.setDefaultColumnWidth(20);
							row.getCell(i).getSheet().addValidationData(displayNameValidation);
						}
					
					
					
					while(rs.next())
					{
						 CellStyle style2 = wb.createCellStyle();
						 	style2.setBorderBottom(CellStyle.BORDER_DOTTED);
					        style2.setBottomBorderColor(IndexedColors.BLACK.getIndex());
					        style2.setBorderLeft(CellStyle.BORDER_MEDIUM);
					        style2.setLeftBorderColor(IndexedColors.BLUE.getIndex());
					        style2.setBorderRight(CellStyle.BORDER_MEDIUM);
					        style2.setRightBorderColor(IndexedColors.BLUE.getIndex());
					        style2.setBorderTop(CellStyle.BORDER_DOTTED);
					        style2.setTopBorderColor(IndexedColors.BLACK.getIndex());
					 
						
						
						
						iRowCount++;
						row = sheet.createRow(iRowCount); 
						
						 sValues = new String[iColumnCount];
						for (int i=1;i<=iColumnCount;i++){
							if(i==1 || i==2)
							{
								addressList = new CellRangeAddressList(0,iRowCount,0,1);
								displayNameValidation = dvHelper.createValidation(dvConstraint, addressList);
								
								 if (displayNameValidation instanceof XSSFDataValidation) {
						        	   displayNameValidation.setSuppressDropDownArrow(false);
						        	   displayNameValidation.setShowErrorBox(true);
						           } else {
						        	   displayNameValidation.setSuppressDropDownArrow(false);
						           }
								 
								row.createCell(i-1).setCellValue(rs.getString(i));
								row.getCell(i-1).setCellStyle(style2);
								row.getCell(i-1).getSheet().addValidationData(displayNameValidation);
							}
							else
							{
								if(rs.getString(i)!=null && !rs.getString(i).equalsIgnoreCase(""))
								{
									createCell(wb,row,i, XSSFCellStyle.ALIGN_CENTER,  Double.parseDouble(rs.getString(i)));
									row.getCell(i-1).setCellStyle(style2);
								}
								else
								{
									createCell(wb,row,i, XSSFCellStyle.ALIGN_CENTER, "");
									row.getCell(i-1).setCellStyle(style2);
								}
							}
						}
					}
				 }
				
				else
				{
					row = sheet.createRow((short)0); 
					 row.createCell(0).setCellValue("No Data....");
				}
				
					
				}
			}


		sheet = wb.createSheet("Instructions");
		sheet.autoSizeColumn(0); 

			rsmd = null;
			wb.write(oFileOutputStream);
			return wb;
}

public static CallableStatement uploadOptionOneTableTemplate(CallableStatement cstmt, QuarterActivityDto oQuarterActivityDto) throws Exception {
		    
		    ArrayList alXlsFieldsList = new ArrayList();
		    List<MultipartFile> files = oQuarterActivityDto.getFiles();
		    MultipartFile file = files.get(0);
		    
		    MultipartFile file = oQuarterActivityDto.getOptionTwoGEFile();
		    System.out.println(file);
		    if(file == null){
		                    System.out.println("did not enter the file");
		    }
		    else{
		                    System.out.println("file is uploaded...");
		    }
		    InputStream myxls = file.getInputStream();
		    
		    XSSFWorkbook wb = new XSSFWorkbook(myxls);
		    int numberOfSheets = wb.getNumberOfSheets();
		    ArrayList<TableDto> alData = new ArrayList<TableDto>();     
		
for(int n=0;n<(numberOfSheets-1);n++){
			
		    XSSFSheet xlSheet = wb.getSheetAt(n);
		    XSSFRow xlFirstRow = xlSheet.getRow(0);
		    XSSFRow xlPresentRow = null;
		    String status="SaveDraft";
		                                   
		                                   
		    int iCountOfRows = xlSheet.getPhysicalNumberOfRows();
		    int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();
		    oQuarterActivityDto.setColumnCount(iCountOfColumns);
		    TableDto oTableDto = null;
		    String validationMessage = "";
		    boolean isValidData = true;
		    ResultSet rs = null;
		    Iterator rows = xlSheet.rowIterator();
		    int k=0;
		    
		    String modalityString = "";
		    String values = "";
		    String allValues = "";
		    String country = "";
		    String yearQtrString = "";
		    
		    for(int l=3;l<(iCountOfColumns);l++)
		    {
		    	if(l==3)
		    		modalityString = xlFirstRow.getCell(l).toString();
		    	else
		    		modalityString = modalityString+"~"+xlFirstRow.getCell(l).toString();
		    }
		    
		    
		    XSSFRow xlSecondRow = xlSheet.getRow(1);
		    
		    if(xlSecondRow!=null)
		    yearQtrString = xlSecondRow.getCell(1).toString();
		    
		    String modalityArray[] = modalityString.split("~");
			 oTableDto = new TableDto();
			 oTableDto.setColumn1("Country");
			 oTableDto.setColumn2("Currency");
			 oTableDto.setColumn3("Rate");
			 
			 for(int l=4;l<(modalityArray.length+4);l++)
			 {
				 oTableDto.setColumnValue(l,modalityArray[l-4]);
			 }

			 alData.add(oTableDto); 
			 
			 oTableDto = new TableDto();
			 oTableDto.setColumn1("");
			 oTableDto.setColumn2(yearQtrString);
			 oTableDto.setColumn3(yearQtrString);
			 for(int l=4;l<(modalityArray.length+4);l++)
			 {
				 oTableDto.setColumnValue(l,yearQtrString);
			 }
			 
			 alData.add(oTableDto); 
		    
		    
		    
		    
		  
		    int iCount = 1;
		    
		    while (rows.hasNext()) {
		    	XSSFRow row = (XSSFRow) rows.next();
		    	k++;
		    	
		    }
		    
		    if(k==1 || k==0)
		    {
		    	oQuarterActivityDto.setIsValidData("empty");
			}
			else
			{
		    for (int i = 2; i < iCountOfRows; i++) 
		    {
		    	
		      
  	 		   xlPresentRow = xlSheet.getRow(i);
  	 		   country = xlPresentRow.getCell(0).toString();
	  	 		 for(int m=3;m<(iCountOfColumns);m++)
	  	 		 {
	 			    if(m==3)
	 		    		allValues = xlPresentRow.getCell(m).toString();
	 		    	else
	 		    		allValues = allValues+"~"+xlPresentRow.getCell(m).toString();
	  	 		 }
	  	 		 
  	 			
  	 			
			    	 for(int m=3;m<(iCountOfColumns);m++)
			    	    {
			    		 
			    		 
			    		 
			    		 
			    		 
			    		 if(!xlPresentRow.getCell(m).toString().equalsIgnoreCase(""))
			    		 {
			    			 Pattern pattern = Pattern.compile(".[^0-9]");
    	 					 String input = xlPresentRow.getCell(m).toString().replace(".0", "");
    	 					 
    	 					 if(!pattern.matcher(input).matches())
			    			 	{
			    				 if(m==3)
					    	    		values = xlPresentRow.getCell(m).toString();
					    	    	else
					    	    		values = values+"~"+xlPresentRow.getCell(m).toString();
			    		 		}
			    			 else
			    			 	{
			    				 
			    				 String valueArray[] =  allValues.split("~");
			    				 oTableDto = new TableDto();
			    				 oTableDto.setColumn1(country);
			    				 oTableDto.setColumn2(xlPresentRow.getCell(1).toString());
			    				 oTableDto.setColumn3(xlPresentRow.getCell(2).toString());
			    				 for(int l=4;l<(valueArray.length+4);l++)
			    				 {
			    					 oTableDto.setColumnValue(l,valueArray[l-4]);
			    				 }
			    				 
			    				 status = "Failure";
				    			 validationMessage = "Value should be numeric.";
				    			 oTableDto.setStatus(status);
				    			 oTableDto.setValidationMessage(validationMessage);
			    				 
			    				 alData.add(oTableDto); 
			    				 
			    				 
			    				
				    			 
				    			 isValidData = false;
				    			 oQuarterActivityDto.setIsValidData("false");
					    		 }
			    		 }
			    		 else
			    		 {
			    				 if(m==3)
					    	    		values = xlPresentRow.getCell(m).toString();
					    	    	else
					    	    		values = values+"~"+xlPresentRow.getCell(m).toString();
			    		 }
			    		 
			    	   }
			    	 
			    	   
			    	 if(isValidData){	
			    		 
				    	 cstmt.setString(1, country);
				    	 System.out.println("1"+country);
				    	 
				    	 cstmt.setString(2, modalityString);
				    	 System.out.println("2"+modalityString);
				    	 
				    	 cstmt.setString(3, values);
				    	 System.out.println("3"+values);
				    	 
				    	 cstmt.setString(4, yearQtrString);
				    	 System.out.println("4"+yearQtrString);
	                    
				    	 cstmt.setString(5, oQuarterActivityDto.getForexExchange());
				    	 System.out.println("5"+oQuarterActivityDto.getForexExchange());
				    	 
				    	 cstmt.setString(6, oQuarterActivityDto.getSso());
				    	 System.out.println("6"+oQuarterActivityDto.getSso());
				    	 
				    	 cstmt.setString(7, oQuarterActivityDto.getTableTemplateReportTypeQA());
				    	 System.out.println("7"+oQuarterActivityDto.getTableTemplateReportTypeQA());
				    	 
				    	 cstmt.addBatch();  
				    	 oQuarterActivityDto.setIsValidData("true");
			    	 }
		    }
			}
}
		    oQuarterActivityDto.setAlDataOne(alData);
		    return cstmt;	
}
		
		
		

public static XSSFWorkbook getOptionOneMarketExcelFile(ResultSet rs,String sFileName, String sheetName, int sheetNum, QuarterActivityDto oQuarterActivityDto) throws Exception {
			
			ResultSetMetaData rsmd = null;
			FileOutputStream oFileOutputStream = null;


			File oFile = new File(sFileName);
			oFileOutputStream = new FileOutputStream(oFile);
			
			XSSFWorkbook wb  = new XSSFWorkbook();
			XSSFSheet sheet = wb.createSheet(sheetName);
			XSSFRow row  = null;
			sheet.autoSizeColumn(0); 
			
			XSSFCellStyle styleHeader = wb.createCellStyle();
			
			styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
			styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			styleHeader.setBorderTop((short) 6); // double lines border
			styleHeader.setBorderBottom((short) 1); // single line border
			styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
			styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
			styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
			
		    
		    XSSFFont fontHeader = wb.createFont();
		    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
		    fontHeader.setFontHeightInPoints((short) 9);
		    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		    fontHeader.setColor(HSSFColor.WHITE.index);
		    styleHeader.setFont(fontHeader);
			
		    DataValidationHelper dvHelper = sheet.getDataValidationHelper();
            DataValidationConstraint dvConstraint = dvHelper.createExplicitListConstraint(new String[] {"cell 1 edit","cell 2 edit"});
            CellRangeAddressList addressList = new CellRangeAddressList(0,1,0,100);
            DataValidation displayNameValidation = dvHelper.createValidation(dvConstraint, addressList);

           if (displayNameValidation instanceof XSSFDataValidation) {
        	   displayNameValidation.setSuppressDropDownArrow(false);
        	   displayNameValidation.setShowErrorBox(true);
           } else {
        	   displayNameValidation.setSuppressDropDownArrow(false);
           }
           
           
			if(rs!=null){
				rsmd = rs.getMetaData();
				
				if(!rsmd.getColumnName(1).toString().equalsIgnoreCase("No_Data"))
				{

				
				
				int iColumnCount = rsmd.getColumnCount();
				int iRowCount = 1;
				int iSheetNo = 1;
				
				String[] sColumnNames = new String[iColumnCount];
				String[] sValues = new String[iColumnCount];
				 
				row = sheet.createRow((short)0); 
				 for(int i=1;i<=iColumnCount;i++){
					 if(i!=14 && i!=15){
						row.createCell(i-1).setCellValue("");
						row.getCell(i-1).getSheet().addValidationData(displayNameValidation);
						row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
						sheet.setDefaultColumnWidth(20);
						
					 }else
					 {
						 if(i==14){
						 	row.createCell(i-1).setCellValue("GE Internal");
						 	row.getCell(i-1).setCellStyle(styleHeader);
						 	row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
							sheet.setDefaultColumnWidth(20); 
						 	row.getCell(i-1).getSheet().addValidationData(displayNameValidation);
						 }else{
							row.createCell(i-1).setCellValue("Market");
						 	row.getCell(i-1).setCellStyle(styleHeader);
						 	row.getCell(i-1).getSheet().addValidationData(displayNameValidation);
							row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
							sheet.setDefaultColumnWidth(20); 
						 }
					 }
					}
				 
				 
				 
				 row = sheet.createRow((short)1); 
					for(int i=1;i<=iColumnCount;i++){
						 if(i!=14 && i!=15){
								row.createCell(i-1).setCellValue(rsmd.getColumnName(i));
								row.getCell(i-1).setCellStyle(styleHeader);
								row.getCell(i-1).getSheet().addValidationData(displayNameValidation);
								row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
								sheet.setDefaultColumnWidth(20);
							 }else
							 {
								 	row.createCell(i-1).setCellValue("Orders ($) In Millions");
									row.getCell(i-1).setCellStyle(styleHeader);
									row.getCell(i-1).getSheet().addValidationData(displayNameValidation);
									row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
									sheet.setDefaultColumnWidth(20); 
									
							 }
							}
				
				while(rs.next())
				{
					iRowCount++;
					row = sheet.createRow(iRowCount); 
					
					sValues = new String[iColumnCount];
					for (int i=1;i<=iColumnCount;i++){
						if(i==13 || i==14 || i==15){
							
							DecimalFormat oneDigit = new DecimalFormat("#,##############0.0");
							double loadedValue = 0.0;
							
							if(rs.getString(i)!=null && !rs.getString(i).equalsIgnoreCase(""))
								loadedValue = Double.valueOf(oneDigit.format(Double.parseDouble(rs.getString(i))));
							
							row.createCell(i-1).setCellValue(loadedValue);
						}
						else{							
							if(i==iColumnCount)
							{
								addressList = new CellRangeAddressList(0,iRowCount,(iColumnCount-1),(iColumnCount-1));
								displayNameValidation = dvHelper.createValidation(dvConstraint, addressList);
								
								 if (displayNameValidation instanceof XSSFDataValidation) {
						        	   displayNameValidation.setSuppressDropDownArrow(false);
						        	   displayNameValidation.setShowErrorBox(true);
						           } else {
						        	   displayNameValidation.setSuppressDropDownArrow(false);
						           }
								 
								row.createCell(i-1).setCellValue(rs.getString(i));
								row.getCell(i-1).getSheet().addValidationData(displayNameValidation);
								
							}
							else
							{
								addressList = new CellRangeAddressList(0,iRowCount,0,11);
								displayNameValidation = dvHelper.createValidation(dvConstraint, addressList);
								
								 if (displayNameValidation instanceof XSSFDataValidation) {
						        	   displayNameValidation.setSuppressDropDownArrow(false);
						        	   displayNameValidation.setShowErrorBox(true);
						           } else {
						        	   displayNameValidation.setSuppressDropDownArrow(false);
						           }
								 
								row.createCell(i-1).setCellValue(rs.getString(i));
								row.getCell(i-1).getSheet().addValidationData(displayNameValidation);
							}
							
						}
					}
				}
					
				}
				else
				{
				row = sheet.createRow((short)0); 
				row.createCell(0).setCellValue("No Data....");
				}
			}
			
			 sheet = wb.createSheet("Instructions");
			 sheet.autoSizeColumn(0); 
			rsmd = null;
			
			wb.write(oFileOutputStream);
			return wb;
			
}

		public static CallableStatement uploadOptionOneMarketData(CallableStatement cstmt, QuarterActivityDto oQuarterActivityDto) throws Exception {
		    
		    ArrayList alXlsFieldsList = new ArrayList();
		    List<MultipartFile> files = oQuarterActivityDto.getFiles();
		    MultipartFile file = files.get(0);
		    
		    
		    MultipartFile file = oQuarterActivityDto.getOptionOneMarketFile();
		    System.out.println(file);
		    if(file == null){
		                    System.out.println("did not enter the file");
		    }
		    else{
		                    System.out.println("file is uploaded...");
		    }
		    InputStream myxls = file.getInputStream();
		    
		    XSSFWorkbook wb = new XSSFWorkbook(myxls);

		    XSSFSheet xlSheet = wb.getSheetAt(0);
		    XSSFRow xlFirstRow = xlSheet.getRow(0);
		    XSSFRow xlSecondRow = xlSheet.getRow(1);
		    XSSFRow xlPresentRow = null;
		    
		    String xlYear = null;
		    String xlQtr = null;
		    String xlRegion = null;
		    String xlSubRegion = null;
		    String xlCountry = null;
		    String xlState = null;
		    String xlGroup = null;
		    String xlModality = null;
		    String xlSubModality = null;
		    String xlSegment = null;
		    String xlProduct = null;
		    String xlGEOrderValue = null;
		    String xlMarketOrderValue = null;
		    String xlVersionValue=null;
		    String status="SaveDraft";
		    ArrayList<TableDto> alData = new ArrayList<TableDto>();      
		    TableDto oTableDto = null;
		    String validationMessage = "";
		    boolean isValidData = true;                                
		    Iterator rows = xlSheet.rowIterator();                               
		    int iCountOfRows = xlSheet.getPhysicalNumberOfRows();
		    int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();
		    oQuarterActivityDto.setColumnCount(iCountOfColumns);
		    int iCount = 1;
		    int k = 0; 
		    while (rows.hasNext()) {
		    	XSSFRow row = (XSSFRow) rows.next();
		    	k++;
		    	
		    }
		    
		    
		    if(iCountOfColumns==16)
		    {
		     oTableDto = new TableDto();
			 oTableDto.setColumn1("");
			 oTableDto.setColumn2("");
			 oTableDto.setColumn3("");
			 oTableDto.setColumn4("");
			 oTableDto.setColumn5("");
			 oTableDto.setColumn6("");
			 oTableDto.setColumn7("");
			 oTableDto.setColumn8("");
			 oTableDto.setColumn9("");
			 oTableDto.setColumn10("");
			 oTableDto.setColumn11("");
			 oTableDto.setColumn12("");
			 oTableDto.setColumn13("");
			 oTableDto.setColumn14("GE Internal");
			 oTableDto.setColumn15("Market");
			 oTableDto.setColumn16("");
			 alData.add(oTableDto); 
		    
			 oTableDto = new TableDto();
			 oTableDto.setColumn1(xlSecondRow.getCell(0).toString());
			 oTableDto.setColumn2(xlSecondRow.getCell(1).toString());
			 oTableDto.setColumn3(xlSecondRow.getCell(2).toString());
			 oTableDto.setColumn4(xlSecondRow.getCell(3).toString());
			 oTableDto.setColumn5(xlSecondRow.getCell(4).toString());
			 oTableDto.setColumn6(xlSecondRow.getCell(5).toString());
			 oTableDto.setColumn7(xlSecondRow.getCell(6).toString());
			 oTableDto.setColumn8(xlSecondRow.getCell(7).toString());
			 oTableDto.setColumn9(xlSecondRow.getCell(8).toString());
			 oTableDto.setColumn10(xlSecondRow.getCell(9).toString());
			 oTableDto.setColumn11(xlSecondRow.getCell(10).toString());
			 oTableDto.setColumn12(xlSecondRow.getCell(11).toString());
			 oTableDto.setColumn13(xlSecondRow.getCell(12).toString());
			 oTableDto.setColumn14(xlSecondRow.getCell(13).toString());
			 oTableDto.setColumn15(xlSecondRow.getCell(14).toString());
			 oTableDto.setColumn16(xlSecondRow.getCell(15).toString());
			 alData.add(oTableDto); 
		    
		    }
		    
		    
		    
		    
		    if(k==1 || k==0)
		    {
		    	oQuarterActivityDto.setIsValidData("empty");
			}
		    else if(iCountOfColumns>16)
		    {
		    	oQuarterActivityDto.setIsValidData("more columns");
		    }
		    else if(iCountOfColumns<16)
		    {
		    	oQuarterActivityDto.setIsValidData("less columns");
		    }
			else
			{
		    for (int i = 2; i <= iCountOfRows; i++) {
		    
		                    xlPresentRow = xlSheet.getRow(i);
		                    if (xlPresentRow != null) {
		                          
		                    	 xlYear = xlPresentRow.getCell(1).toString();
		            		     xlQtr = xlPresentRow.getCell(2).toString();
		            		     xlRegion = xlPresentRow.getCell(3).toString();
		            		     xlSubRegion = xlPresentRow.getCell(4).toString();
		            		     xlCountry = xlPresentRow.getCell(5).toString();
		            		     //xlState = xlPresentRow.getCell(6).toString();
		            		     xlGroup = xlPresentRow.getCell(7).toString();
		            		     xlModality = xlPresentRow.getCell(8).toString();
		            		     xlSubModality = xlPresentRow.getCell(9).toString();
		            		   //  xlMarketOrderValue= xlPresentRow.getCell(16).toString();
		            		     if(xlPresentRow.getCell(10)==null){
		            		    	 xlSegment="";	 
		            		     }else{
		            		    	 xlSegment = xlPresentRow.getCell(10).toString();
		            		     }
		            		     if(xlPresentRow.getCell(11)==null){
		            		    	 xlProduct="";	 
		            		     }else{
		            		     xlProduct = xlPresentRow.getCell(11).toString();
		            		     }	
		            		     xlVersionValue= xlPresentRow.getCell(15).toString(); 
		            		     
		            		    	  if(xlPresentRow.getCell(13)!=null && !xlPresentRow.getCell(13).toString().equalsIgnoreCase("") && xlPresentRow.getCell(14)!=null && !xlPresentRow.getCell(14).toString().equalsIgnoreCase(""))
				            		     {
				            		    	 if(xlPresentRow.getCell(13).getCellType() == HSSFCell.CELL_TYPE_NUMERIC && ( xlPresentRow.getCell(14).getCellType() == HSSFCell.CELL_TYPE_NUMERIC || xlPresentRow.getCell(14).toString().equalsIgnoreCase("CONF")))
								    		 {
				            		    		 xlGEOrderValue = xlPresentRow.getCell(13).toString();
						            		     xlMarketOrderValue = xlPresentRow.getCell(14).toString();
								    		 }
								    		 else
								    		 {
								    			 status = "Failure";
				 				    			 validationMessage = " Value should be numeric.";
				 				    			 oTableDto.setStatus(status);
				 				    			 oTableDto.setValidationMessage(validationMessage);
				 				    			 
					 				    		 oTableDto.setColumn1(xlPresentRow.getCell(0).toString());
					 				   			 oTableDto.setColumn2(xlPresentRow.getCell(1).toString());
					 				   			 oTableDto.setColumn3(xlPresentRow.getCell(2).toString());
					 				   			 if(xlPresentRow.getCell(3)!=null)
					 				   			 oTableDto.setColumn4(xlPresentRow.getCell(3).toString());
					 				   			 oTableDto.setColumn5(xlPresentRow.getCell(4).toString());
					 				   			 oTableDto.setColumn6(xlPresentRow.getCell(5).toString());
					 				   			 oTableDto.setColumn7(xlPresentRow.getCell(6).toString());
					 				   			 oTableDto.setColumn8(xlPresentRow.getCell(7).toString());
					 				   			 oTableDto.setColumn9(xlPresentRow.getCell(8).toString());
					 				   			 oTableDto.setColumn10(xlPresentRow.getCell(9).toString());
					 				   			 oTableDto.setColumn11(xlPresentRow.getCell(10).toString());
					 				   			 oTableDto.setColumn12(xlPresentRow.getCell(11).toString());
					 				   			 oTableDto.setColumn13(xlPresentRow.getCell(12).toString());
					 				   			 oTableDto.setColumn14(xlPresentRow.getCell(13).toString());
					 				   			 oTableDto.setColumn15(xlPresentRow.getCell(14).toString());
					 				   			 oTableDto.setColumn16(xlPresentRow.getCell(15).toString());
				 			    				 alData.add(oTableDto); 				 				    			 
				 				    			 isValidData = false;
				 				    			 oQuarterActivityDto.setIsValidData("false");
								    		 }
				            		     }
				            		     else
				            		     {
				            		    	 if(xlPresentRow.getCell(13)!=null)
				            		    	 xlGEOrderValue = xlPresentRow.getCell(13).toString();
				            		    	 if(xlPresentRow.getCell(14)!=null)
					            		     xlMarketOrderValue = xlPresentRow.getCell(14).toString();
				            		    	
				            		    	
				            		     }		 			    	   		             		   		             		    
		           if(isValidData)
		           {    
		                        cstmt.setInt(1, new Double(xlYear.toString()).intValue());
		                        System.out.println("1"+new Double(xlYear.toString()).intValue());		                       
		                        cstmt.setInt(2,  new Double(xlQtr.toString()).intValue());
		                        System.out.println("2"+new Double(xlQtr.toString()).intValue());                		                    
		                        cstmt.setString(3, xlCountry);
		                        System.out.println("3"+xlCountry);		                       
		                        cstmt.setString(4,xlState);
		                        System.out.println("4"+xlState);		                     
		                    	cstmt.setString(5, xlProduct);
		                    	System.out.println("5"+xlProduct);		                      
			                    cstmt.setString(6, oQuarterActivityDto.getForexExchange());
			                    System.out.println("6"+ oQuarterActivityDto.getForexExchange());			                    
			                    if(xlMarketOrderValue.equalsIgnoreCase("CONF")){			                    	
			                    	 cstmt.setString(7, null);
					                    System.out.println("7"+ "null");
			                    }else{
			                    cstmt.setDouble(7, Double.parseDouble(xlMarketOrderValue));
			                    System.out.println("7"+ Double.parseDouble(xlMarketOrderValue));
			                    }
			                    cstmt.setString(8, "0");
			                    System.out.println("8"+ "0");			                    
			                    cstmt.setString(9, "0");
			                    System.out.println("9"+ "0");			                    
			                    cstmt.setString(10, "");
			                    System.out.println("10"+ "");			                    
			                    cstmt.setString(11, "");
			                    System.out.println("11"+ "");			                    
			                    cstmt.setString(12, xlVersionValue);
			                   // System.out.println("12"+ oQuarterActivityDto.getVersion());
			                    System.out.println("12"+ xlVersionValue);
			                    cstmt.setString(13, oQuarterActivityDto.getSso());
			                    System.out.println("13"+ oQuarterActivityDto.getSso());			                    
			                    cstmt.addBatch();  			                    
			                    oQuarterActivityDto.setIsValidData("true");
		           				}
		             }
			}
		    oQuarterActivityDto.setAlDataOne(alData);
		}
		                    
		return cstmt;
}

		public static XSSFWorkbook getAssociationReportExcelFile(ResultSet rs,String sFileName, String sheetName, int sheetNum, QuarterActivityDto oQuarterActivityDto) throws Exception {
			
			ResultSetMetaData rsmd = null;
			FileOutputStream oFileOutputStream = null;

			File oFile = new File(sFileName);
			oFileOutputStream = new FileOutputStream(oFile);
			
			XSSFWorkbook wb  = new XSSFWorkbook();
			XSSFSheet sheet = wb.createSheet(sheetName);
			XSSFRow row  = null;
			sheet.autoSizeColumn(0); 
			
			XSSFCellStyle styleHeader = wb.createCellStyle();
			
			styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
			styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			styleHeader.setBorderTop((short) 6); // double lines border
			styleHeader.setBorderBottom((short) 1); // single line border
			styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
			styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
			styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
			
		    
		    XSSFFont fontHeader = wb.createFont();
		    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
		    fontHeader.setFontHeightInPoints((short) 9);
		    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		    fontHeader.setColor(HSSFColor.WHITE.index);
		    styleHeader.setFont(fontHeader);
			
		    DataValidationHelper dvHelper = sheet.getDataValidationHelper();
            DataValidationConstraint dvConstraint = dvHelper.createExplicitListConstraint(new String[] { "cell 1 edit","cell 2 edit"});
            CellRangeAddressList addressList = new CellRangeAddressList(0,1,0,100);
            DataValidation displayNameValidation = dvHelper.createValidation(dvConstraint, addressList);

           if (displayNameValidation instanceof XSSFDataValidation) {
        	   displayNameValidation.setSuppressDropDownArrow(false);
        	   displayNameValidation.setShowErrorBox(true);
           } else {
        	   displayNameValidation.setSuppressDropDownArrow(false);
           }
           
			
			if(rs!=null){
				rsmd = rs.getMetaData();
				int iColumnCount = rsmd.getColumnCount();
				int iRowCount = 0;
				int iSheetNo = 1;
				
				String[] sColumnNames = new String[iColumnCount];
				String[] sValues = new String[iColumnCount];
				 row = sheet.createRow((short)0); 
				 
					for(int i=1;i<=iColumnCount;i++){
						
						if(i<5)
						{
							row.createCell(i-1).setCellValue(rsmd.getColumnName(i));
							row.getCell(i-1).setCellStyle(styleHeader);
							row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
							sheet.setDefaultColumnWidth(20);
							
						}
						else if(i==5)
						{ 
							row.createCell(i-1).setCellValue(rsmd.getColumnName(i+1));
							row.getCell(i-1).setCellStyle(styleHeader);
							row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
							sheet.setDefaultColumnWidth(20);
						}
					}
					
					
				ArrayList 	alData = oQuarterActivityDto.getAlDataOne();
				
				for(int k=1;k<alData.size();k++)
				{
					TableDto oTableDto = (TableDto)alData.get(k);
					
					iRowCount++;
					row = sheet.createRow(iRowCount); 
					
					sValues = new String[iColumnCount];
					for (int i=1;i<=iColumnCount;i++){
						if(i<5)
						{
							createCell(wb,row,i, HSSFCellStyle.ALIGN_CENTER,  oTableDto.getColumnValue(i));
						}
						else if(i==5)
						{
							DecimalFormat oneDigit = new DecimalFormat("#,##############0.0");//format to 1 decimal place
							Double loadedValue = 0.0;
							
							if(oTableDto.getColumnValueAsNum(i+1)!=null && !oTableDto.getColumnValueAsNum(i+1).equalsIgnoreCase("-"))
								loadedValue = Double.valueOf(oneDigit.format(Double.parseDouble(oTableDto.getColumnValueAsNum(i+1))));
							
							
							createCell(wb,row,i, HSSFCellStyle.ALIGN_CENTER,  loadedValue);
						}
					}
				}
					
				}
			rsmd = null;
			
			wb.write(oFileOutputStream);
			return wb;
}
		
		

public static XSSFWorkbook getExcelDownloadCompetitiveTemplate(String sFileName, String sheetName, int sheetNum,CompetitiveDto oCompetitiveDto) throws IOException {
			
			ResultSetMetaData rsmd = null;
			FileOutputStream oFileOutputStream = null;

			sFileName = sFileName;

			File oFile = new File(sFileName);
			oFileOutputStream = new FileOutputStream(oFile);
			
			XSSFWorkbook wb  = new XSSFWorkbook();
			XSSFSheet sheet = wb.createSheet("Orders");
			XSSFRow row  = null;
			sheet.autoSizeColumn(0); 
			
			XSSFCellStyle styleHeader = wb.createCellStyle();
			
			styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
			styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			styleHeader.setBorderTop((short) 6); // double lines border
			styleHeader.setBorderBottom((short) 1); // single line border
			styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
			styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
			styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
			
		    
		    XSSFFont fontHeader = wb.createFont();
		    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
		    fontHeader.setFontHeightInPoints((short) 9);
		    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		    fontHeader.setColor(HSSFColor.WHITE.index);
		    styleHeader.setFont(fontHeader);
		    
		    DataValidationHelper dvHelper = sheet.getDataValidationHelper();
		    DataValidationConstraint dvConstraint = dvHelper.createExplicitListConstraint(new String[] { "cell 1 edit","cell 2 edit"});
		    CellRangeAddressList addressList = new CellRangeAddressList(0, 0, 0, 100);
		    DataValidation validation = dvHelper.createValidation(dvConstraint, addressList);

		   if (validation instanceof XSSFDataValidation) {
		       validation.setSuppressDropDownArrow(false);
		       validation.setShowErrorBox(true);
		   } else {
		       validation.setSuppressDropDownArrow(false);
		   }
		   
		   XSSFCell cell = null;
		   
		  
		    		row = sheet.createRow((short)0); 
		    		
		             cell = row.createCell(0);
					 cell.setCellValue("Regions");
					 cell.setCellStyle(styleHeader);
					 row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					 sheet.setDefaultColumnWidth(20);
					 row.getCell(0).getSheet().addValidationData(validation);

				 
				 	row.createCell(1).setCellValue("Business");
					row.getCell(1).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(1).getSheet().addValidationData(validation);
					
					row.createCell(2).setCellValue("Modality 1");
					row.getCell(2).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(2).getSheet().addValidationData(validation);
					
					row.createCell(3).setCellValue("Modality 2");
					row.getCell(3).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(3).getSheet().addValidationData(validation);
					
					
					row.createCell(4).setCellValue("Sub Modality");
					row.getCell(4).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(4).getSheet().addValidationData(validation);
					
					
					row.createCell(5).setCellValue("Year");
					row.getCell(5).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(5).getSheet().addValidationData(validation);
					
					row.createCell(6).setCellValue("Quarter");
					row.getCell(6).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(6).getSheet().addValidationData(validation);
					
					row.createCell(7).setCellValue("Competitor");
					row.getCell(7).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(7).getSheet().addValidationData(validation);
					
					row.createCell(8).setCellValue("Percentage (%)");
					row.getCell(8).setCellStyle(styleHeader);
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);
					row.getCell(8).getSheet().addValidationData(validation);
		   
			wb.write(oFileOutputStream);
			return wb;
}

public static CallableStatement uploadCompetitiveTemplate(CallableStatement cstmt, CompetitiveDto oCompetitiveDto) throws SQLException, IOException {
    
    ArrayList alXlsFieldsList = new ArrayList();
    
    MultipartFile file = oCompetitiveDto.getOptionOneGEFile();
    
    System.out.println(file);
    if(file == null){
                    System.out.println("did not enter the file");
    }
    else{
                    System.out.println("file is uploaded...");
    }
    InputStream myxls = file.getInputStream();
    
    XSSFWorkbook wb = new XSSFWorkbook(myxls);

    XSSFSheet xlSheet = wb.getSheetAt(0);
    XSSFRow xlFirstRow = xlSheet.getRow(0);
    XSSFRow xlPresentRow = null;
    XSSFRow xlPresentRow1 = null;
    
   
    XSSFCell xlRegion = null;
    XSSFCell xlSubRegion = null;
    XSSFCell xlGroup = null;
    XSSFCell xlModality = null;
    XSSFCell xlModality2 = null;
    XSSFCell xlSubModality = null;
    XSSFCell xlYear = null;
    XSSFCell xlQtr = null;
    XSSFCell xlCompetitor = null;
    XSSFCell xlValue = null;
    
    String status="SaveDraft";
                                   
                                   
   int iCountOfRows = xlSheet.getLastRowNum();
   int iCountOfColumns = xlFirstRow.getPhysicalNumberOfCells();
   int k =0;
   ArrayList<TableDto> alData = new ArrayList<TableDto>();      
   TableDto oTableDto = null;
   String validationMessage = "";
   boolean isValidData = true;                                
   Iterator rows = xlSheet.rowIterator();                               
   int iCount = 1;
   while (rows.hasNext()) {
   	XSSFRow row = (XSSFRow) rows.next();
   	k++;
   	
   }
   
    if(k==1 || k==0)
    {
    	oCompetitiveDto.setIsValidData("empty");
	}
    else if(iCountOfColumns>9)
    {
    	oCompetitiveDto.setIsValidData("more columns");
    }
    else if(iCountOfColumns<9)
    {
    	oCompetitiveDto.setIsValidData("more columns");
    }
	else
	{
    for (int i = 1; i <= iCountOfRows; i++) {
    
                    xlPresentRow = xlSheet.getRow(i);
                    if (xlPresentRow != null) {
                                    
                    	xlYear = xlPresentRow.getCell(5);
                    	xlQtr = xlPresentRow.getCell(6);
                    	xlRegion = xlPresentRow.getCell(0);
                    	xlGroup = xlPresentRow.getCell(1);
                    	xlModality = xlPresentRow.getCell(2);
                    	xlModality2= xlPresentRow.getCell(3);
                    	xlSubModality = xlPresentRow.getCell(4);
                    	xlCompetitor= xlPresentRow.getCell(7);
                    	xlValue= xlPresentRow.getCell(8);
                    	
                    	
                    	for(int m=1;m<=(iCountOfColumns);m++)
			    	    {
			    		 if(m==5 || m==6 || m==8)
			    		 {
			    			 Pattern pattern = Pattern.compile(".[^0-9]");
    	 					 String input = xlPresentRow.getCell(m).toString().replace(".0", "");
    	 					 
    	 					 if(!pattern.matcher(input).matches())
			    			 	{
			    				
			    		 		}
			    			 else
			    			 	{
			    				 status = "Failure";
				    			 validationMessage = "Value should be numeric.";
				    			 oTableDto.setStatus(status);
				    			 oTableDto.setValidationMessage(validationMessage);
			    				 
				    			 oTableDto.setColumn1( xlYear.toString().replace(".0", ""));
				    			 oTableDto.setColumn2(xlQtr.toString().replace(".0", ""));
				    			 oTableDto.setColumn3(xlRegion.toString());
				    			 oTableDto.setColumn4(xlSubRegion.toString());
				    			 oTableDto.setColumn5(xlGroup.toString());
				    			 oTableDto.setColumn6(xlModality.toString());
				    			 oTableDto.setColumn7(xlSubModality.toString());
				    			 oTableDto.setColumn8(xlCompetitor.toString());
				    			 oTableDto.setColumn9(xlValue.toString().replace(".0", ""));
				    			 
				    			 
				    			 
			    				 alData.add(oTableDto); 
				    			 isValidData = false;
				    			 oCompetitiveDto.setIsValidData("false");
					    		 }
			    		 }
			    	   }
			    	 
			    	   
			    	 if(isValidData){	
                    	
                        cstmt.setString(1, xlYear.toString().replace(".0", ""));
                        System.out.println("1"+xlYear.toString().replace(".0", ""));
                        
                        cstmt.setString(2, xlQtr.toString().replace(".0", ""));
                        System.out.println("2"+xlQtr.toString().replace(".0", ""));
                        
                        cstmt.setString(3, xlRegion.toString());
                        System.out.println("3"+xlRegion.toString());                
                    
                        cstmt.setString(4, xlGroup.toString());
                        System.out.println("4"+xlGroup.toString());
                        
                        cstmt.setString(5, xlModality.toString());
                        System.out.println("5"+xlModality.toString());
                       
                        cstmt.setString(6, xlModality2.toString());
                        System.out.println("6"+xlModality2.toString());                
                    
                        cstmt.setString(7, xlSubModality.toString());
                        System.out.println("7"+xlSubModality.toString());
                        
                        cstmt.setString(8, xlCompetitor.toString());
                        System.out.println("8"+xlCompetitor.toString());                
                    
                        cstmt.setString(9, xlValue.toString().replace(".0", ""));
                        System.out.println("9"+xlValue.toString().replace(".0", ""));
                                       
                    }
                    }
                    cstmt.addBatch();
                    oCompetitiveDto.setIsValidData("true");
    			}
    oCompetitiveDto.setAlDataOne(alData);
	}
    return cstmt;
}	



public static XSSFWorkbook getExcelExportComparision(String sFileName, String sheetName, int sheetNum, ReportDto oReportDto) throws SQLException, IOException {
	
	ResultSetMetaData rsmd = null;
	FileOutputStream oFileOutputStream = null;

	File oFile = new File(sFileName);
	oFileOutputStream = new FileOutputStream(oFile);
	
	XSSFWorkbook wb  = new XSSFWorkbook();
	XSSFSheet sheet = wb.createSheet(sheetName);
	XSSFRow row  = null;
	XSSFRow row1  = null;
	HSSFConditionalFormatting formati = null;
	sheet.autoSizeColumn(0); 
	TableDto oTableDto = null;
	XSSFCellStyle cellStyle = wb.createCellStyle();
	cellStyle.setFillForegroundColor(HSSFColor.AQUA.index);
	cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	
	
		XSSFCellStyle styleHeader = wb.createCellStyle();
		
		styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
		styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
		
	    
	    XSSFFont fontHeader = wb.createFont();
	    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
	    fontHeader.setFontHeightInPoints((short) 9);
	    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	    fontHeader.setColor(HSSFColor.WHITE.index);
	    styleHeader.setFont(fontHeader);
	
	row = sheet.createRow(0);
	row.createCell(0).setCellValue("Market");
	row.getCell(0).setCellStyle(styleHeader);
	CellRangeAddress addressList = new CellRangeAddress(0,0,0,3);
	sheet.addMergedRegion(addressList);
	
		int rowid=1;
        ArrayList<TableDto> alData = oReportDto.getAlDataOne();
        if(alData!=null){
            int iColumnCount = 0;
            
            iColumnCount      = (alData.get(0)).getColumnCount();
            for(int i=0;i<alData.size();i++)
            {
				  row = sheet.createRow(i+1);
                  oTableDto = alData.get(i);
                  if(i==0)
                  {
          		  for(int j=1;j<=iColumnCount;j++)
          		  	{ 
          			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
					row.getCell(j-1).setCellStyle(styleHeader);
          		  	}
                  }
                  else
                  {
                  for(int j=1;j<=iColumnCount;j++)
                  {
                   row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
                  }
                  
              }
                  rowid++;
          }
      }
        
        
        int nextLen=rowid;
        nextLen = nextLen+2;
        System.out.println("nextLen 1:"+nextLen);
        row = sheet.createRow(nextLen-1);
    	row.createCell(0).setCellValue("GE");
    	row.getCell(0).setCellStyle(styleHeader);
    	addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,3);
    	sheet.addMergedRegion(addressList);
    	
    	
        ArrayList<TableDto> alData2 = oReportDto.getAlDataTwo();
        if(alData2!=null){
            int iColumnCount = 0;
            iColumnCount      = (alData2.get(0)).getColumnCount();
            for(int i=0;i<alData2.size();i++)
            {
                  row     = sheet.createRow(nextLen+i);
                  oTableDto = alData2.get(i);
                  if(i==0)
                  {
          		  for(int j=1;j<=iColumnCount;j++)
          		  	{ 
          			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
					row.getCell(j-1).setCellStyle(styleHeader);
          		  	}
                  }
                  else
                  {
                  for(int j=1;j<=iColumnCount;j++)
                  {
                   row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
                  }
                  rowid++;
              }
          }
      }
		 
    nextLen=rowid+5;
    System.out.println("nextLen 2:"+nextLen);
    row = sheet.createRow(nextLen-1);
	row.createCell(0).setCellValue("GE Share % ");
	row.getCell(0).setCellStyle(styleHeader);
	addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,3);
	sheet.addMergedRegion(addressList);
	
	
    ArrayList<TableDto> alData3 = oReportDto.getAlDataThree();
    if(alData2!=null){
        int iColumnCount = 0;
        iColumnCount      = (alData3.get(0)).getColumnCount();
        for(int i=0;i<alData3.size();i++)
        {
              row     = sheet.createRow(nextLen+i);
              oTableDto = alData3.get(i);
              if(i==0)
              {
      		  for(int j=1;j<=iColumnCount;j++)
      		  	{ 
      			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
				row.getCell(j-1).setCellStyle(styleHeader);
      		  	}
              }
              else
              {
              for(int j=1;j<=iColumnCount;j++)
              {
               row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
              }
              rowid++;
          }
      }
  }
	 
nextLen=rowid+5;
nextLen=nextLen+3;
System.out.println("nextLen 3:"+nextLen);
row = sheet.createRow(nextLen-1);
row.createCell(0).setCellValue("GE V %");
row.getCell(0).setCellStyle(styleHeader);
addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,3);
sheet.addMergedRegion(addressList);


ArrayList<TableDto> alData4 = oReportDto.getAlDataFour();
if(alData2!=null){
    int iColumnCount = 0;
    iColumnCount      = (alData4.get(0)).getColumnCount();
    for(int i=0;i<alData3.size();i++)
    {
          row     = sheet.createRow(nextLen+i);
          oTableDto = alData4.get(i);
          if(i==0)
          {
  		  for(int j=1;j<=iColumnCount;j++)
  		  	{ 
  			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
			row.getCell(j-1).setCellStyle(styleHeader);
  		  	}
          }
          else
          {
          for(int j=1;j<=iColumnCount;j++)
          {
           row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
          }
          rowid++;
      }
  }
}
 
nextLen=rowid+5;
nextLen = nextLen+6;
System.out.println("nextLen 4:"+nextLen);
row = sheet.createRow(nextLen-1);
row.createCell(0).setCellValue("Market V%");
row.getCell(0).setCellStyle(styleHeader);
addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,3);
sheet.addMergedRegion(addressList);


ArrayList<TableDto> alData5 = oReportDto.getAlDataFive();
if(alData2!=null){
    int iColumnCount = 0;
    iColumnCount      = (alData5.get(0)).getColumnCount();
    for(int i=0;i<alData3.size();i++)
    {
          row     = sheet.createRow(nextLen+i);
          oTableDto = alData5.get(i);
          if(i==0)
          {
  		  for(int j=1;j<=iColumnCount;j++)
  		  	{ 
  			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
			row.getCell(j-1).setCellStyle(styleHeader);
  		  	}
          }
          else
          {
          for(int j=1;j<=iColumnCount;j++)
          {
           row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
          }
          rowid++;
      }
  }
}
 
nextLen=rowid+5;
nextLen = nextLen+9;
System.out.println("nextLen 5:"+nextLen);
row = sheet.createRow(nextLen-1);
row.createCell(0).setCellValue("GE Vpts");
row.getCell(0).setCellStyle(styleHeader);
addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,3);
sheet.addMergedRegion(addressList);


ArrayList<TableDto> alData6 = oReportDto.getAlDataSix();
if(alData2!=null){
    int iColumnCount = 0;
    iColumnCount      = (alData6.get(0)).getColumnCount();
    for(int i=0;i<alData3.size();i++)
    {
          row     = sheet.createRow(nextLen+i);
          oTableDto = alData6.get(i);
          if(i==0)
          {
  		  for(int j=1;j<=iColumnCount;j++)
  		  	{ 
  			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
			row.getCell(j-1).setCellStyle(styleHeader);
  		  	}
          }
          else
          {
          for(int j=1;j<=iColumnCount;j++)
          {
           row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
          }
          rowid++;
      }
  }
}
 
nextLen=rowid+5;
nextLen = nextLen+12;
System.out.println("nextLen 6:"+nextLen);
row = sheet.createRow(nextLen-1);
row.createCell(0).setCellValue("GE 4QtrAvg");
row.getCell(0).setCellStyle(styleHeader);
addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,3);
sheet.addMergedRegion(addressList);


ArrayList<TableDto> alData7 = oReportDto.getAlDataSeven();
if(alData2!=null){
    int iColumnCount = 0;
    iColumnCount      = (alData7.get(0)).getColumnCount();
    for(int i=0;i<alData3.size();i++)
    {
          row     = sheet.createRow(nextLen+i);
          oTableDto = alData7.get(i);
          if(i==0)
          {
  		  for(int j=1;j<=iColumnCount;j++)
  		  	{ 
  			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
			row.getCell(j-1).setCellStyle(styleHeader);
  		  	}
          }
          else
          {
          for(int j=1;j<=iColumnCount;j++)
          {
           row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
          }
          rowid++;
      }
  }
}
 
nextLen=rowid+5;
nextLen = nextLen+15;
System.out.println("nextLen 7:"+nextLen);
row = sheet.createRow(nextLen-1);
row.createCell(0).setCellValue("Market 4QTRAvg");
row.getCell(0).setCellStyle(styleHeader);
addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,3);
sheet.addMergedRegion(addressList);


ArrayList<TableDto> alData8 = oReportDto.getAlDataEight();
if(alData2!=null){
    int iColumnCount = 0;
    iColumnCount      = (alData8.get(0)).getColumnCount();
    for(int i=0;i<alData3.size();i++)
    {
          row     = sheet.createRow(nextLen+i);
          oTableDto = alData8.get(i);
          if(i==0)
          {
  		  for(int j=1;j<=iColumnCount;j++)
  		  	{ 
  			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
			row.getCell(j-1).setCellStyle(styleHeader);
  		  	}
          }
          else
          {
          for(int j=1;j<=iColumnCount;j++)
          {
           row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
          }
          rowid++;
      }
  }
}
 
nextLen=rowid+5;

	wb.write(oFileOutputStream);
	return wb;
}




public static XSSFWorkbook getRollingtoXls(ResultSet rs,String sFileName, String sheetName, int sheetNum, ReportDto oReportDto) throws SQLException, IOException {
	
	ResultSetMetaData rsmd = null;
	FileOutputStream oFileOutputStream = null;

	File oFile = new File(sFileName);
	oFileOutputStream = new FileOutputStream(oFile);
	
	XSSFWorkbook wb  = new XSSFWorkbook();
	XSSFSheet sheet = wb.createSheet(sheetName);
	XSSFRow row  = null;
	XSSFRow row1  = null;
	HSSFConditionalFormatting formati = null;
	sheet.autoSizeColumn(0); 
	TableDto oTableDto = null;
	XSSFCellStyle cellStyle = wb.createCellStyle();
	cellStyle.setFillForegroundColor(HSSFColor.AQUA.index);
	cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	
	
		XSSFCellStyle styleHeader = wb.createCellStyle();
		
		styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
		styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
		
	    
	    XSSFFont fontHeader = wb.createFont();
	    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
	    fontHeader.setFontHeightInPoints((short) 9);
	    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	    fontHeader.setColor(HSSFColor.WHITE.index);
	    styleHeader.setFont(fontHeader);
	
	row = sheet.createRow(0);
	row.createCell(0).setCellValue("4 QTR Avg MARKET ");
	row.getCell(0).setCellStyle(styleHeader);
	CellRangeAddress addressList = new CellRangeAddress(0,0,0,4);
	sheet.addMergedRegion(addressList);
	
		int rowid=1;
        ArrayList<TableDto> alData = oReportDto.getAlDataOne();
        if(alData!=null){
            int iColumnCount = 0;
            
            iColumnCount      = (alData.get(0)).getColumnCount();
            for(int i=0;i<alData.size();i++)
            {
				  row = sheet.createRow(i+1);
                  oTableDto = alData.get(i);
                  if(i==0)
                  {
          		  for(int j=1;j<=iColumnCount;j++)
          		  	{ 
          			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
					row.getCell(j-1).setCellStyle(styleHeader);
          		  	}
                  }
                  else
                  {
                  for(int j=1;j<=iColumnCount;j++)
                  {
                   row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
                  }
                  
              }
                  rowid++;
          }
      }
        
        
        int nextLen=rowid;
        nextLen=nextLen+2;
        row = sheet.createRow(nextLen-1);
    	row.createCell(0).setCellValue("4 QTR Avg GE");
    	row.getCell(0).setCellStyle(styleHeader);
    	addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,4);
    	sheet.addMergedRegion(addressList);
    	
    	
        ArrayList<TableDto> alData2 = oReportDto.getAlDataTwo();
        if(alData2!=null){
            int iColumnCount = 0;
            iColumnCount      = (alData2.get(0)).getColumnCount();
            for(int i=0;i<alData2.size();i++)
            {
                  row     = sheet.createRow(nextLen+i);
                  oTableDto = alData2.get(i);
                  if(i==0)
                  {
          		  for(int j=1;j<=iColumnCount;j++)
          		  	{ 
          			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
					row.getCell(j-1).setCellStyle(styleHeader);
          		  	}
                  }
                  else
                  {
                  for(int j=1;j<=iColumnCount;j++)
                  {
                   row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
                  }
                  rowid++;
              }
          }
      }
		 
    nextLen=rowid+5;
   // nextLen=nextLen+1;
    row = sheet.createRow(nextLen-1);
	row.createCell(0).setCellValue("4 QTR Avg GE Share % ");
	row.getCell(0).setCellStyle(styleHeader);
	addressList = new CellRangeAddress(nextLen-1,nextLen-1,0,4);
	sheet.addMergedRegion(addressList);
	
	
    ArrayList<TableDto> alData3 = oReportDto.getAlDataThree();
    if(alData2!=null){
        int iColumnCount = 0;
        iColumnCount      = (alData3.get(0)).getColumnCount();
        for(int i=0;i<alData3.size();i++)
        {
              row     = sheet.createRow(nextLen+i);
              oTableDto = alData3.get(i);
              if(i==0)
              {
      		  for(int j=1;j<=iColumnCount;j++)
      		  	{ 
      			row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
				row.getCell(j-1).setCellStyle(styleHeader);
      		  	}
              }
              else
              {
              for(int j=1;j<=iColumnCount;j++)
              {
               row.createCell(j-1).setCellValue(oTableDto.getColumnValue(j));
              }
              rowid++;
          }
      }
  }
	wb.write(oFileOutputStream);
	return wb;
}

public static XSSFWorkbook getExcelExportByRegion(ResultSet rs,String sFileName, String sheetName, int sheetNum, ViewsDto oViewsDto) throws SQLException, IOException {
	
	ResultSetMetaData rsmd = null;
	FileOutputStream oFileOutputStream = null;

	File oFile = new File(sFileName);
	oFileOutputStream = new FileOutputStream(oFile);
	
	XSSFWorkbook wb  = new XSSFWorkbook();
	XSSFSheet sheet = wb.createSheet(sheetName);
	XSSFRow row  = null;
	XSSFRow row1  = null;
	HSSFConditionalFormatting formati = null;
	sheet.autoSizeColumn(0); 

	 XSSFCellStyle whiteFG = wb.createCellStyle();
        whiteFG.setFillForegroundColor(HSSFColor.AQUA.index);
        whiteFG.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);


	
	
	if(rs!=null){
		rsmd = rs.getMetaData();
		int iColumnCount = rsmd.getColumnCount();
		int iRowCount = 0;
		int iSheetNo = 1;
		
		String[] sColumnNames = new String[iColumnCount];
		String[] sValues = new String[iColumnCount];
		 row = sheet.createRow((short)0); 
		 
		 row.createCell(0).setCellValue("Modality");
		 row.getCell(0).setCellStyle(whiteFG);
			for(int i=1;i<iColumnCount;i++){
				row.createCell(i).setCellValue(rsmd.getColumnName(i+1));
				row.getCell(i).setCellStyle(whiteFG);
				row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
				sheet.setDefaultColumnWidth(20);
			    
			}
			
		while(rs.next())
		{
			iRowCount++;
			row = sheet.createRow(iRowCount); 
			
			sValues = new String[iColumnCount];
			for (int i=1;i<=iColumnCount;i++){
				if(i==1)
				createCell(wb,row,i, HSSFCellStyle.ALIGN_LEFT, rs.getString(i));
				else{
					if(rs.getString(i)!=null && !rs.getString(i).equalsIgnoreCase(""))
						createCell(wb,row,i, HSSFCellStyle.ALIGN_CENTER, rs.getString(i));
					else
						createCell(wb,row,i, HSSFCellStyle.ALIGN_CENTER, "");
				}
			}
		}
			
		}
	rsmd = null;
	
	wb.write(oFileOutputStream);
	return wb;
}

public static void createCellBorder(XSSFWorkbook wb, XSSFRow row, short column, short align,String value, XSSFCellStyle cellStyle, short index, short solidForeground, short index2, short boldweightBold)
{
      //Float f = Float.valueOf(value.trim()).floatValue();
      
      XSSFCell cell = row.createCell(column);
      cell.setCellValue(value);
      cellStyle =  wb.createCellStyle(); 
      cellStyle.setFillForegroundColor(index);   
      cellStyle.setFillPattern(solidForeground);   
      XSSFFont my_font=wb.createFont();
      my_font.setColor(index2);
    my_font.setBoldweight(boldweightBold);
    cellStyle.setFont(my_font);
    cellStyle.setBorderLeft(cellStyle.BORDER_THIN);
    cellStyle.setLeftBorderColor(IndexedColors.WHITE.getIndex());
    cellStyle.setBorderRight(cellStyle.BORDER_THIN);
    cellStyle.setTopBorderColor(IndexedColors.WHITE.getIndex());
      cell.setCellType(cell.CELL_TYPE_STRING);
      cellStyle.setAlignment(align);
      cell.setCellStyle(cellStyle);
      
      cell.removeCellComment();
}*/

	          
	
	/*public static XSSFWorkbook getExcelDownloadChuvData(ResultSet rs,String sFileName, String sheetName, int sheetNum, CompetitiveDto oCompetitiveDto) throws Exception {
		
		ResultSetMetaData rsmd = null;
		FileOutputStream oFileOutputStream = null;

		File oFile = new File(sFileName);
		oFileOutputStream = new FileOutputStream(oFile);
		
		XSSFWorkbook wb  = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet(sheetName);
		XSSFRow row  = null;
		sheet.autoSizeColumn(0); 
		
		XSSFCellStyle styleHeader = wb.createCellStyle();
		
		styleHeader.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
		styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		styleHeader.setBorderTop((short) 6); // double lines border
		styleHeader.setBorderBottom((short) 1); // single line border
		styleHeader.setBorderLeft(CellStyle.BORDER_HAIR);
		styleHeader.setBorderRight(CellStyle.BORDER_THIN) ;
		styleHeader.setAlignment(CellStyle.ALIGN_CENTER);
		
	    
	    XSSFFont fontHeader = wb.createFont();
	    fontHeader.setFontName(HSSFFont.FONT_ARIAL);
	    fontHeader.setFontHeightInPoints((short) 9);
	    fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	    fontHeader.setColor(HSSFColor.WHITE.index);
	    styleHeader.setFont(fontHeader);
		
		if(rs!=null){
			rsmd = rs.getMetaData();
			int iColumnCount = rsmd.getColumnCount();
			 row = sheet.createRow((short)0); 
			 
				for(int i=1;i<=iColumnCount;i++){
						row.createCell(i-1).setCellValue(rsmd.getColumnName(i));
						row.getCell(i-1).setCellStyle(styleHeader);
						row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
						sheet.setDefaultColumnWidth(20);
						
				}
			int r=1;	
			while(rs.next()){
				row = sheet.createRow((short)r); 
				for (int i = 1; i <= iColumnCount; i++) {
					if(rs.getString(i)!=null){
						if(rs.getString(i).equalsIgnoreCase("")){
							row.createCell(i-1).setCellValue(rs.getString(i));
						}else{
							if(rs.getString(i).startsWith("w1")|| rs.getString(i).startsWith("w2")|| rs.getString(i).startsWith("w3")|| rs.getString(i).startsWith("w4")||rs.getString(i).startsWith("W1")|| rs.getString(i).startsWith("W2")|| rs.getString(i).startsWith("W3")|| rs.getString(i).startsWith("W4")){
								row.createCell(i-1).setCellValue("x");
							}else{
								row.createCell(i-1).setCellValue(rs.getString(i));
							}
							
						}
					}else{
						row.createCell(i-1).setCellValue(rs.getString(i));
					}
				
					
					row.setHeightInPoints((sheet.getDefaultRowHeightInPoints()));
					sheet.setDefaultColumnWidth(20);                  
				}
				 r++;
			}
			}
		rsmd = null;
		
		wb.write(oFileOutputStream);
		return wb;
}

	public static void createCell(HSSFWorkbook wb, HSSFRow row, short column, short align,String value, HSSFCellStyle cellStyle, short index, short solidForeground, short index2, short boldweightBold)
	{
		//Float f = Float.valueOf(value.trim()).floatValue();
		
		HSSFCell cell = row.createCell(column);
		cell.setCellValue(value);
		cellStyle =  wb.createCellStyle(); 
		cellStyle.setFillForegroundColor(index);   
		cellStyle.setFillPattern(solidForeground);   
		HSSFFont my_font=wb.createFont();
		my_font.setColor(index2);
	    my_font.setBoldweight(boldweightBold);
	    cellStyle.setFont(my_font);
	    
	    cellStyle.setBorderBottom(cellStyle.BORDER_THIN);
	    cellStyle.setBottomBorderColor(IndexedColors.WHITE.getIndex());
	    cellStyle.setBorderLeft(cellStyle.BORDER_THIN);
	    cellStyle.setLeftBorderColor(IndexedColors.WHITE.getIndex());
	    cellStyle.setBorderRight(cellStyle.BORDER_THIN);
	    cellStyle.setRightBorderColor(IndexedColors.WHITE.getIndex());
	    cellStyle.setBorderTop(cellStyle.BORDER_THIN);
	    cellStyle.setTopBorderColor(IndexedColors.WHITE.getIndex());
	    cellStyle.setLocked(true);
		cell.setCellType(cell.CELL_TYPE_STRING);
		
		cellStyle.setAlignment(align);
		cell.setCellStyle(cellStyle);
		
		cell.removeCellComment();
	}
	public static void createCellI(HSSFWorkbook wb, HSSFRow row, short column, short align,double value, HSSFCellStyle cellStyle, short index, short solidForeground, short index2, short boldweightBold)
	{
		//Float f = Float.valueOf(value.trim()).floatValue();
		
		HSSFCell cell = row.createCell(column);
		cell.setCellValue(value);
		cellStyle =  wb.createCellStyle(); 
		cellStyle.setFillForegroundColor(index);   
		cellStyle.setFillPattern(solidForeground);   
		HSSFFont my_font=wb.createFont();
		my_font.setColor(index2);
	    my_font.setBoldweight(boldweightBold);
	    cellStyle.setFont(my_font);
	    
	    cellStyle.setBorderBottom(cellStyle.BORDER_THIN);
	    cellStyle.setBottomBorderColor(IndexedColors.WHITE.getIndex());
	    cellStyle.setBorderLeft(cellStyle.BORDER_THIN);
	    cellStyle.setLeftBorderColor(IndexedColors.WHITE.getIndex());
	    cellStyle.setBorderRight(cellStyle.BORDER_THIN);
	    cellStyle.setRightBorderColor(IndexedColors.WHITE.getIndex());
	    cellStyle.setBorderTop(cellStyle.BORDER_THIN);
	    cellStyle.setTopBorderColor(IndexedColors.WHITE.getIndex());
		cell.setCellType(cell.CELL_TYPE_NUMERIC);
		cellStyle.setAlignment(align);
		cell.setCellStyle(cellStyle);
		
		cell.removeCellComment();
	}
	public static int countRow(ResultSet rs)throws SQLException, IOException{
	
	int iRowCount = 0;
	while(rs.next()){
		iRowCount++;
	}
	return iRowCount;
}*/
}
