package com.gehc.wire.common.service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.MissingResourceException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.gehc.wire.common.constants.BGConstants;


/**
 * @author 703092428
 * @FileName DBService.java
 * @CreateDate Nov 26, 2012
 */
public class DBService {
	
	
	/**
     * Context object to store the InitialContext class instance, 
     * which is used to lookup database
     */
    private static Context initCtx = null;
    
    /**
     * Object to store datasource instance that is used to establish 
     * database connection
     */
    public static javax.sql.DataSource ds;
    
    /**
     * String variable to store the database DSN name that is defined in 
     * the application/web server
     * This is used to establish connection with the database
     */
    public static String source = null;
    
    /**
     * String variable to store the database DSN name that is defined in 
     * the application/web server
     * This is used to establish connection with the database
     */
    public static String dsEnvironment = null;
    
    /**
     * String variable to store the connection object
     */
    public static Connection conn = null;
    
    /**
     * Constructor of DBUtility class
     */
    public DBService(){}
    
    
    /**
     * Static block to retrieve the datasource using which the database connection
     * object is retrieved.
     */
    static {
    	try{
    		 PropertyService.getProperty(BGConstants.APP_PRPPERTIES_FILE,BGConstants.APP_DB_SCHEMA);
    		
            // Retrieving the database dsn name provided in acmotor.properties file
            source =    PropertyService.getProperty(BGConstants.APP_PRPPERTIES_FILE,BGConstants.APP_DB_DNS); //"jdbc/MSSQL_SDM_JNDI";
         
            
            // Creating the initial naming context
            initCtx = new InitialContext();
            
            try {
				// Retreiving datasource from JNDI lookup 
				ds = (DataSource) initCtx.lookup("java:comp/env/" + source);
				
			} catch (Exception e) {
				System.out.println("data source...");
				e.printStackTrace();
			}
			System.out.println("DS"+ds);
        }catch(Exception e){
            
        }
    }
	
	public static int getRecordCount(ResultSet rs){
		return 0;
	}
	/**
     * Function to retrieve database connection object
     * @return Returns the connection object
     * @throws NamingException if datasource is not found
     * @throws SQLException if connection could not be established
     * @throws MissingResourceException if no object for the given key can be found
     * @throws NullPointerException if key is null
     */
    public Connection getDBConnection() throws NamingException, 
                                               SQLException, 
                                               MissingResourceException, 
                                               NullPointerException {
        // Get a datasource connection
        conn = ds.getConnection();
            
        return conn;
    }
    
    
    
    
    
    /**
     * This method is used to set connection's auto-commit property to false
     * @param conn Connection object to set auto commit to false
     * @throws SQLException if connection is not available
     */
    public void setAutoCommitFalse(Connection conn) throws SQLException {
        
        if (conn != null) 
            conn.setAutoCommit(false);      
    }
    
    /**
     * This method is used to set connection's auto-commit property to true
     * @param conn Connection object to set auto commit to true
     * @throws SQLException if connection is not available
     */
    public void setAutoCommitTrue(Connection conn) throws SQLException {
        
        if (conn != null) 
            conn.setAutoCommit(true);
    }
    
    /**
     * This method is used to commit a transaction
     * @param conn Connection object to commit the transaction
     * @throws SQLException if connection is not available
     */
    public void commit(Connection conn) throws SQLException {
        
        if (conn != null) 
            conn.commit();
        
    }
    
    /**
     * This method is used to rollback a transaction
     * @param conn Connection object to rollback the transaction
     * @throws SQLException if connection is not available
     */
    public void rollback(Connection conn) throws SQLException {
        
        if (conn != null) 
            conn.rollback();
        
    }
    
    /**
     * This method is used to close ResultSet, Statement & Connection and 
     * release them to the pool
     * @param rs ResultSet object to close
     * @param pStmt Statement object to close
     * @param conn Connection object to close
     * @throws SQLException if either Connection, Statement or ResultSet 
     * objects are not available
     */
    public void releaseResources(ResultSet rs, PreparedStatement pStmt, 
 Connection conn) throws SQLException {
        
        if (rs!=null)
            rs.close();
        
        if (pStmt!=null)
            pStmt.close();
        
        if (conn!=null)
            conn.close();
    }
    
    /**
     * This method is used to close ResultSet & Statement and release them to the pool
     * @param rs ResultSet object to close
     * @param pStmt PreparedStatement object to close
     * @throws SQLException if either Statement or ResultSet objects are not available
     */
    public void releaseResources(ResultSet rs, PreparedStatement pStmt) 
                                        throws SQLException {
        if (rs!=null)
            rs.close();
        
        if (pStmt!=null)
            pStmt.close();
    }
    
    /**
     * This method is used to close Statement & Connection and release them to the pool
     * @param pStmt Statement object to close
     * @param conn Connection object to close
     * @throws SQLException if either Connection or Statement objects are 
     * not available
     */
    public void releaseResources(PreparedStatement pStmt, Connection conn) 
                                    throws SQLException {
        if (pStmt!=null)
            pStmt.close();
        
        if (conn!=null)
            conn.close();
    }
    
    /**
     * This method is used to close ResultSet and release it to the pool
     * @param rs ResultSet object to close
     * @throws SQLException if either Connection, Statement or ResultSet 
     * objects are not available
     */
    public void releaseResources(ResultSet rs) throws SQLException {
        
        if (rs!=null)
            rs.close();
    }
    
    /**
     * This method is used to close Statement and release it to the pool
     * @param pStmt Statement object to close
     * @throws SQLException if either Connection, Statement or ResultSet 
     * objects are not available
     */
    public void releaseResources(PreparedStatement pStmt) throws SQLException {
        
        if (pStmt!=null)
            pStmt.close();
    }
    /**
     * This method is used to close Statement and release it to the pool
     * @param pStmt Statement object to close
     * @throws SQLException if either Connection, Statement or ResultSet 
     * objects are not available
     */
    public void releaseResources(Statement stmt) throws SQLException {
        
        if (stmt!=null)
        	stmt.close();
    }
    
    /**
     * This method is used to close Connection and release it to the pool
     * @param conn Connection object to close
     * @throws SQLException if either Connection, Statement or ResultSet 
     * objects are not available
     */
    public void releaseResources(Connection conn) throws SQLException {
        
        if (conn!=null)
            conn.close();
    }
    
    /**
     * This method is used to close Statement and release it to the pool
     * @param cStmt CallableStatement object to close
     * @throws SQLException if either Connection, Statement or ResultSet 
     * objects are not available
     */
    public void releaseResources(CallableStatement cStmt) throws SQLException {
        
        if (cStmt!=null)
        	cStmt.close();
    }
	public void releaseResources(ResultSet rs, PreparedStatement pstmt,
			CallableStatement cstmt) throws SQLException {
		if (rs!=null)
            rs.close();
        
        if (pstmt!=null)
        	pstmt.close();
        
        if (cstmt!=null)
        	cstmt.close();
	}
	
	public static int getNoOfRows(ResultSet rs) throws Exception{
		int noOfRows = 0;
		
		if(!rs.isBeforeFirst()){
			rs.beforeFirst();
		}
		if(rs!=null){
			while(rs.next()){
				noOfRows++;
			}
		}
		rs.beforeFirst();
		return noOfRows;
	}
	
	
	 
}
