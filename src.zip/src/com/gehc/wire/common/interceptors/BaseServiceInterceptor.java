package com.gehc.wire.common.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.common.dto.UserSessionDto;


/**
 * @author 703092428
 * @FileName BaseServiceInterceptor.java
 * @CreateDate Nov 26, 2012
 */
public class BaseServiceInterceptor extends HandlerInterceptorAdapter {

	static Logger logger = Logger.getLogger(LoggerInterceptor.class);

	static{
		BasicConfigurator.configure();
	}
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		logger.info("Before handling the request");
		isValidUser(request);
		return super.preHandle(request, response, handler);
	}
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		logger.info("After handling the request");
		super.postHandle(request, response, handler, modelAndView);
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		logger.info("After rendering the view");
		super.afterCompletion(request, response, handler, ex);
	}

	public  UserSessionDto setUserInfo(HttpServletRequest request,UserDto oUserDto) throws Exception{

		request.getSession().setAttribute(MPRConstants.APP_LOGINUSER_INFO, oUserDto);
		UserSessionDto oUserSessionDto = new UserSessionDto();
		oUserSessionDto.setSso(oUserDto.getSSO());
		oUserSessionDto.setHost(request.getRemoteHost());
		oUserSessionDto.setServerHost(request.getServerName());
		oUserSessionDto.setSessionid(request.getSession().getId());
		return oUserSessionDto;
	}


	public  UserDto getUserInfo(HttpServletRequest request) throws Exception{
		UserDto oUserDto = null;

		logger.error("Third::"+request.getSession().getId());
		oUserDto = (UserDto)request.getSession().getAttribute(MPRConstants.APP_LOGINUSER_INFO);

		return oUserDto;
	}

	public  boolean isValidUser(HttpServletRequest request)throws Exception{
		boolean isValidUser = true;
		UserDto oLoginUserDto = (UserDto)request.getSession().getAttribute("loginUserInfo");
		if(oLoginUserDto==null || oLoginUserDto.getSSO()==null || oLoginUserDto.getSSO().equalsIgnoreCase("")){
			
			isValidUser = false;
		}
		return isValidUser;
	}
}
