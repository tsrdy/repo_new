package com.gehc.wire.common.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gehc.wire.common.dto.TableDto;



public class Data {

	private static Map<String, List<TableDto>> data = new HashMap<String, List<TableDto>>();

	  static{
	    populateBS217RHData();
	  }

/*	  public List<TableDto> getData(String postcode,DataDto oDataDto){
	    return data.get(postcode.toUpperCase());
	  }
*/
	private static void populateBS217RHData() {

		List<TableDto> dataList = new ArrayList<TableDto>();
		
		
		/*for(int i=0;i<alData.size();i++)
		{
			TableDto oTableDto = (TableDto)alData.get(i);
			dataList.add(new TableDto(oTableDto.getColumn1(),oTableDto.getColumn2(),oTableDto.getColumn3(),oTableDto.getColumn4(),oTableDto.getColumn5(),oTableDto.getColumn6(),oTableDto.getColumn7(),oTableDto.getColumn8(),oTableDto.getColumn9(),oTableDto.getColumn10(),
									  oTableDto.getColumn11(),oTableDto.getColumn12(),oTableDto.getColumn13(),oTableDto.getColumn14(),oTableDto.getColumn15(),oTableDto.getColumn16(),oTableDto.getColumn17(),oTableDto.getColumn18(),oTableDto.getColumn19(),oTableDto.getColumn20(),
									  oTableDto.getColumn21(),oTableDto.getColumn22(),oTableDto.getColumn23(),oTableDto.getColumn24(),oTableDto.getColumn25(),oTableDto.getColumn26()
									));
		}*/
		data.put("BS21 7RH", dataList);
	
	}
}
