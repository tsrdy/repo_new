package main.java.parts_price_info;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class PartsService {

	private static final Logger LOG = LoggerFactory
			.getLogger(PartsService.class);

	Session session = null;

	public PartsService() {
		File f = new File("E:\\SpringBootV\\src\\hibernate.cfg.xml");

		Configuration configuration = new Configuration().configure(f);

		SessionFactory factory = configuration.buildSessionFactory();
		session = factory.openSession();
		File file = null;
		try {
			file = convertCSVtoJson();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONParser parser = new JSONParser();
		System.out.println("parser::" + parser);
		JSONArray jsonArray = null;
		try {
			jsonArray = (JSONArray) parser.parse(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("jsonArray::" + jsonArray);

		for (Object o : jsonArray) {
			JSONObject partsJson = (JSONObject) o;
			double dnet = 0.0;
			Date date = new Date();
			Date processedOn = new Date();

			String itemNo = null;

			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

			if ((String) partsJson.get("ItemNo") != null
					&& !"".equals((String) partsJson.get("ItemNo"))) {
				itemNo = (String) partsJson.get("ItemNo");
			}

			if (partsJson.get("Dnet") != null
					&& !"".equals(partsJson.get("Dnet"))) {
				dnet = Double.valueOf((String) partsJson.get("Dnet"));
			}

			try {
				if (partsJson.get("Date") != null
						&& !"".equals(partsJson.get("Date"))) {
					date = dateFormat.parse((String) partsJson.get("Date"));
				}
				if (partsJson.get("ProcessedOn") != null
						&& !"".equals(partsJson.get("ProcessedOn"))) {
					processedOn = dateFormat.parse((String) partsJson
							.get("ProcessedOn"));
				}

			} catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			PartsInfo partsInfo = new PartsInfo(itemNo, dnet, date, processedOn);

			Transaction tx = session.beginTransaction();
			session.save(partsInfo);
			tx.commit();

		}

	}

	@RequestMapping("/parts")
	public String getService() {
		return "Welcome to Micro Services";
	}

	@RequestMapping(value = "/getPartsList", method = RequestMethod.GET, produces = {
			"application/json", "application/xml" }, headers = "Accept=application/json,application/xml")
	public @ResponseBody PartsList getAllBooks() {

		Query query = session.createQuery("FROM  PartsInfo");

		List<PartsInfo> list = query.list();
		/* id = list.size(); */
		ArrayList<PartsInfo> alist = new ArrayList<PartsInfo>();
		for (PartsInfo array : list) {
			PartsInfo b = new PartsInfo();

			b.setItemNo(array.getItemNo());
			b.setDnet(array.getDnet());
			b.setDate(array.getDate());
			b.setProcessedOn(array.getProcessedOn());
			alist.add(b);

		}

		PartsList elist = new PartsList(alist);
		return elist;
	}

	@RequestMapping(value = "/getParts/{itemNo}", method = RequestMethod.GET, produces = {
			"application/json", "application/xml" }, headers = "Accept=application/xml, application/json")
	public @ResponseBody PartsInfo findParts(
			@PathVariable(value = "itemNo") String itemNo) {

		Query query = session.createQuery("FROM PartsInfo");

		List<PartsInfo> list = query.list();
		PartsInfo b = new PartsInfo();
		for (PartsInfo array : list) {
			if (array.getItemNo().equals(itemNo)) {

				b.setItemNo(array.getItemNo());
				b.setDnet(array.getDnet());
				b.setDate(array.getDate());
				b.setProcessedOn(array.getProcessedOn());

			}
		}

		return b;
	}

	/*@RequestMapping(value = "/addBook", method = RequestMethod.POST, consumes = {
			"application/json", "application/xml" }, produces = { "text/plain" })
	public @ResponseBody String addBook(@RequestBody PartsInfo b) {

		PartsInfo book = new PartsInfo(b.getId(), b.getName(), b.getAuthor(),
				b.getPrice());

		Transaction tx = session.beginTransaction();
		session.save(book);
		tx.commit();

		System.out.println("Book with Id " + (id) + " successfully  added");

		return "Book with Id " + (id + 1) + " successfully  added";

	}*/

	public static String readFile(String filename) {
		String result = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				line = br.readLine();
			}
			result = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static File convertCSVtoJson() throws Exception {
		File input = new File("parts_price_info.csv");
		File output = new File("parts_price_info.json");

		List<Map<?, ?>> data = readObjectsFromCsv(input);
		writeAsJson(data, output);
		return output;
	}

	public static List<Map<?, ?>> readObjectsFromCsv(File file)
			throws IOException {
		CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
		CsvMapper csvMapper = new CsvMapper();
		MappingIterator<Map<?, ?>> mappingIterator = csvMapper
				.reader(Map.class).with(bootstrap).readValues(file);

		return mappingIterator.readAll();
	}

	public static void writeAsJson(List<Map<?, ?>> data, File file)
			throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(file, data);
	}

}
