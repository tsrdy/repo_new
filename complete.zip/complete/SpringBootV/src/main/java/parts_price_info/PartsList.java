package main.java.parts_price_info;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)

@XmlRootElement(name = "PartsList")
public class PartsList {
	private List<PartsInfo> partsList;

	public List<PartsInfo> getPartsList() {
		return partsList;
	}

	public void setPartsList(List<PartsInfo> partsList) {
		this.partsList = partsList;
	}

	public PartsList(List<PartsInfo> partsList) {
		super();
		this.partsList = partsList;
	}

	public PartsList() {
		super();
		// TODO Auto-generated constructor stub
	}
}
