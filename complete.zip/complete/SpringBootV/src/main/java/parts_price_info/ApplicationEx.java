package main.java.parts_price_info;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class ApplicationEx {

  public static void main(String[] args) {
   
    SpringApplication.run(ApplicationEx.class, args);
  }
}