
package main.java.parts_price_info;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Parts")
@Entity
@Table(name="Parts_price_info")
public class PartsInfo {

    @XmlElement(required = true)
    @Id
    @Column(name="ItemNo")
    protected String itemNo;
    
    @XmlElement(required = true)
    @Column(name="Dnet")
    protected double dnet;
    
    @XmlElement(required = true)
    @Column(name="Date")
    protected Date date;
    
    @XmlElement(required = true)
    @Column(name="ProcessedOn")
    protected Date processedOn;

	public String getItemNo() {
		return itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public double getDnet() {
		return dnet;
	}

	public void setDnet(double dnet) {
		this.dnet = dnet;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getProcessedOn() {
		return processedOn;
	}

	public void setProcessedOn(Date processedOn) {
		this.processedOn = processedOn;
	}

	public PartsInfo(String itemNo, double dnet, Date date, Date processedOn) {
		super();
		this.itemNo = itemNo;
		this.dnet = dnet;
		this.date = date;
		this.processedOn = processedOn;
	}

	public PartsInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}

