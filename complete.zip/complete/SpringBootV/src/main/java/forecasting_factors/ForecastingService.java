package main.java.forecasting_factors;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class ForecastingService {

	private static final Logger LOG = LoggerFactory
			.getLogger(ForecastingService.class);

	Session session = null;

	public ForecastingService() {
		File f = new File("E:\\SpringBootV\\src\\hibernate.cfg.xml");

		Configuration configuration = new Configuration().configure(f);

		SessionFactory factory = configuration.buildSessionFactory();
		session = factory.openSession();
		File file = null;
		try {
			file = convertCSVtoJson();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONParser parser = new JSONParser();
		System.out.println("parser::" + parser);
		JSONArray jsonArray = null;
		try {
			jsonArray = (JSONArray) parser.parse(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("jsonArray::" + jsonArray);
		int count=0;
		for (Object o : jsonArray) {
			JSONObject forecastJson = (JSONObject) o;
			
			int id=0;
						String engGrp=null;
			int refYear=0;
			int year=0;
			float operable=0.0f;
			float utilization=0.0f;
			float uptime=0.0f;
			count=count+1;
			id=count;
			

			
			if ((String) forecastJson.get("EngGrp") != null
					&& !"".equals((String) forecastJson.get("EngGrp"))) {
				engGrp = (String) forecastJson.get("EngGrp");
			}
			if (forecastJson.get("RefYear") != null
					&& !"".equals(forecastJson.get("RefYear"))) {
				refYear = Integer.valueOf((String) forecastJson.get("RefYear"));
			}
			if (forecastJson.get("Year") != null
					&& !"".equals(forecastJson.get("Year"))) {
				year = Integer.valueOf((String) forecastJson.get("Year"));
			}
			if (forecastJson.get("Operable") != null
					&& !"".equals(forecastJson.get("Operable"))) {
				operable = Float.valueOf((String) forecastJson.get("Operable"));
			}
			if (forecastJson.get("Utilization") != null
					&& !"".equals(forecastJson.get("Utilization"))) {
				utilization = Float.valueOf((String) forecastJson.get("Utilization"));
			}
			if (forecastJson.get("Uptime") != null
					&& !"".equals(forecastJson.get("Uptime"))) {
				uptime = Float.valueOf((String) forecastJson.get("Uptime"));
			}

			

			ForecastingFactors forecastingFactors= new ForecastingFactors( id,  engGrp,  refYear,  year, operable,  utilization,  uptime);

			Transaction tx = session.beginTransaction();
			session.save(forecastingFactors);
			tx.commit();

		}

	}

	@RequestMapping("/forecasting")
	public String getService() {
		return "Welcome to Micro Services";
	}

	@RequestMapping(value = "/getForecastingFactorsList", method = RequestMethod.GET, produces = {
			"application/json", "application/xml" }, headers = "Accept=application/json,application/xml")
	public @ResponseBody ForecastingFactorsList getForecastingFactorsList() {

		Query query = session.createQuery("FROM  ForecastingFactors");

		List<ForecastingFactors> list = query.list();
		
		ArrayList<ForecastingFactors> alist = new ArrayList<ForecastingFactors>();
		for (ForecastingFactors array : list) {
			ForecastingFactors b = new ForecastingFactors();
			b.setId(array.getId());
			b.setEngGrp(array.getEngGrp());
			b.setRefYear(array.getRefYear());
			b.setYear(array.getYear());
			b.setOperable(array.getOperable());
			b.setUtilization(array.getUtilization());
			b.setUptime(array.getUptime());
			alist.add(b);

		}
	

		ForecastingFactorsList elist = new ForecastingFactorsList(alist);
		return elist;
	}

	@RequestMapping(value = "/getForecasting/{enggrp}", method = RequestMethod.GET, produces = {
			"application/json", "application/xml" }, headers = "Accept=application/xml, application/json")
	public @ResponseBody ForecastingFactorsList findParts(
			@PathVariable(value = "enggrp") String enggrp) {

		Query query = session.createQuery("FROM ForecastingFactors");

		List<ForecastingFactors> list = query.list();
		ArrayList forecastList=new ArrayList();
		ForecastingFactors b = new ForecastingFactors();
		for (ForecastingFactors array : list) {
			if (array.getEngGrp().equals(enggrp)) {
				b.setId(array.getId());
				b.setEngGrp(array.getEngGrp());
				b.setRefYear(array.getRefYear());
				b.setYear(array.getYear());
				b.setOperable(array.getOperable());
				b.setUtilization(array.getUtilization());
				b.setUptime(array.getUptime());
				forecastList.add(b);
			}
		}
		ForecastingFactorsList forecastingFactorsList=new ForecastingFactorsList(forecastList);
		return forecastingFactorsList;
	}

	/*@RequestMapping(value = "/addBook", method = RequestMethod.POST, consumes = {
			"application/json", "application/xml" }, produces = { "text/plain" })
	public @ResponseBody String addBook(@RequestBody PartsInfo b) {

		PartsInfo book = new PartsInfo(b.getId(), b.getName(), b.getAuthor(),
				b.getPrice());

		Transaction tx = session.beginTransaction();
		session.save(book);
		tx.commit();

		System.out.println("Book with Id " + (id) + " successfully  added");

		return "Book with Id " + (id + 1) + " successfully  added";

	}*/

	public static String readFile(String filename) {
		String result = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				line = br.readLine();
			}
			result = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static File convertCSVtoJson() throws Exception {
		File input = new File("forecasting_factors.csv");
		File output = new File("forecasting_factors.json");

		List<Map<?, ?>> data = readObjectsFromCsv(input);
		writeAsJson(data, output);
		return output;
	}

	public static List<Map<?, ?>> readObjectsFromCsv(File file)
			throws IOException {
		CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
		CsvMapper csvMapper = new CsvMapper();
		MappingIterator<Map<?, ?>> mappingIterator = csvMapper
				.reader(Map.class).with(bootstrap).readValues(file);

		return mappingIterator.readAll();
	}

	public static void writeAsJson(List<Map<?, ?>> data, File file)
			throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(file, data);
	}

}
