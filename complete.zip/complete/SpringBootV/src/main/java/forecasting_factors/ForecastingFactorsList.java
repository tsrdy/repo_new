package main.java.forecasting_factors;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)

@XmlRootElement(name = "PartsList")
public class ForecastingFactorsList {
	private List<ForecastingFactors> ForecastingList;

	public List<ForecastingFactors> getForecastingList() {
		return ForecastingList;
	}
	public void setForecastingList(List<ForecastingFactors> forecastingList) {
		ForecastingList = forecastingList;
	}

	public ForecastingFactorsList() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ForecastingFactorsList(List<ForecastingFactors> forecastingList) {
		super();
		ForecastingList = forecastingList;
	}
}
