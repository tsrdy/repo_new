
package main.java.forecasting_factors;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Parts")
@Entity
@Table(name="Forecasting_factors")
public class ForecastingFactors {
	
	@Id
	@Column(name="id")
	protected int id;

	@XmlElement(required = true)
    @Column(name="EngGrp")
    protected String engGrp;
    
    @XmlElement(required = true)
    @Column(name="RefYear")
    protected int refYear;
    
    @XmlElement(required = true)
    @Column(name="Year")
    protected int year ;
    
    @XmlElement(required = true)
    @Column(name="Operable")
    protected float operable ;
    
    @XmlElement(required = true)
    @Column(name="Utilization")
    protected float utilization;
   
    @XmlElement(required = true)
    @Column(name="Uptime")
    protected float uptime ;
    
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
    
	public String getEngGrp() {
		return engGrp;
	}



	public void setEngGrp(String engGrp) {
		this.engGrp = engGrp;
	}



	public int getRefYear() {
		return refYear;
	}



	public void setRefYear(int refYear) {
		this.refYear = refYear;
	}



	public int getYear() {
		return year;
	}



	public void setYear(int year) {
		this.year = year;
	}



	public float getOperable() {
		return operable;
	}



	public void setOperable(float operable) {
		this.operable = operable;
	}



	public float getUtilization() {
		return utilization;
	}



	public void setUtilization(float utilization) {
		this.utilization = utilization;
	}



	public float getUptime() {
		return uptime;
	}



	public void setUptime(float uptime) {
		this.uptime = uptime;
	}


	public ForecastingFactors(int id, String engGrp, int refYear, int year,
			float operable, float utilization, float uptime) {
		super();
		this.id = id;
		this.engGrp = engGrp;
		this.refYear = refYear;
		this.year = year;
		this.operable = operable;
		this.utilization = utilization;
		this.uptime = uptime;
	}

	public ForecastingFactors() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}

