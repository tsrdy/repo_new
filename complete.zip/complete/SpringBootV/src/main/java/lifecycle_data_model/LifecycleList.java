package main.java.lifecycle_data_model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)

@XmlRootElement(name = "LifecycleList")
public class LifecycleList {
	private List<Lifecycle> lifecycle;

	public List<Lifecycle> getLifecycle() {
		return lifecycle;
	}

	public void setLifecycle(List<Lifecycle> lifecycle) {
		this.lifecycle = lifecycle;
	}

	public LifecycleList(List<Lifecycle> lifecycle) {
		super();
		this.lifecycle = lifecycle;
	}

	public LifecycleList() {
		super();
		// TODO Auto-generated constructor stub
	}
}
