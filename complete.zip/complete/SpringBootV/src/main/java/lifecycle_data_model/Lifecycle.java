package main.java.lifecycle_data_model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Lifecycle")
@Entity
@Table(name = "Lifecycle_data_model")
public class Lifecycle {
	@Id
	@Column(name="id")
	protected int id;
	@XmlElement(required = true)
	@Column(name = "tLCModelDetail_Model")
	protected String tLCModelDetail_Model;

	@XmlElement(required = true)
	@Column(name = "Hours")
	protected int hours;

	@XmlElement(required = true)
	@Column(name = "Item")
	protected String item;

	@XmlElement(required = true)
	@Column(name = "Description")
	protected String description;

	@XmlElement(required = true)
	@Column(name = "Qty")
	protected int qty;

	@XmlElement(required = true)
	@Column(name = "TtlAmt")
	protected double ttlAmt;

	@XmlElement(required = true)
	@Column(name = "Field0")
	protected String field0;

	@XmlElement(required = true)
	@Column(name = "Services")
	protected String services;

	@XmlElement(required = true)
	@Column(name = "Service_Cost")
	protected String service_Cost;
	public String gettLCModelDetail_Model() {
		return tLCModelDetail_Model;
	}

	public void settLCModelDetail_Model(String tLCModelDetail_Model) {
		this.tLCModelDetail_Model = tLCModelDetail_Model;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public double getTtlAmt() {
		return ttlAmt;
	}

	public void setTtlAmt(double ttlAmt) {
		this.ttlAmt = ttlAmt;
	}

	public String getField0() {
		return field0;
	}

	public void setField0(String field0) {
		this.field0 = field0;
	}

	public String getServices() {
		return services;
	}

	public void setServices(String services) {
		this.services = services;
	}

	public String getService_Cost() {
		return service_Cost;
	}

	public void setService_Cost(String service_Cost) {
		service_Cost = service_Cost;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public Lifecycle(int id, String tLCModelDetail_Model, int hours,
			String item, String description, int qty, double ttlAmt,
			String field0, String services, String service_Cost) {
		super();
		this.id = id;
		this.tLCModelDetail_Model = tLCModelDetail_Model;
		this.hours = hours;
		this.item = item;
		this.description = description;
		this.qty = qty;
		this.ttlAmt = ttlAmt;
		this.field0 = field0;
		this.services = services;
		this.service_Cost = service_Cost;
	}

	public Lifecycle() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
