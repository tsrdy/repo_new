package main.java.book;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;



@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class BookService {

	private static final Logger LOG = LoggerFactory.getLogger(BookService.class);

	Session session=null;
	private int id=0;
	public BookService() {
		File f = new File("E:\\SpringBootV\\src\\hibernate.cfg.xml");
		
		Configuration configuration=new Configuration().configure(f);
		
		SessionFactory factory=configuration.buildSessionFactory();
		 session=factory.openSession();    
		 File file=null;
			try {
				file = convertCSVtoJson();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			JSONParser parser = new JSONParser();
			System.out.println("parser::"+parser);
			JSONArray jsonArray=null;
			try {
				jsonArray = (JSONArray)parser.parse(new FileReader(file));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("jsonArray::"+jsonArray);

			for (Object o : jsonArray) {
				JSONObject bookJson = (JSONObject) o;
				float price=0;
				int id=0 ;
				String name= (String) bookJson.get("name");
				String author = null; 
				if((String) bookJson.get("author")!=null&&!"".equals((String) bookJson.get("author"))){
					author= (String) bookJson.get("author");
				}
				String  priceString = (String) bookJson.get("price");
				if(priceString!=null&&!"".equals(priceString)){
					price=Float.valueOf(priceString);
				}
				if((String) bookJson.get("id")!=null&&!"".equals((String) bookJson.get("id"))){
					id= Integer.valueOf((String) bookJson.get("id"));
				}

				Book book=new Book(id,name,author,price);

				Transaction tx=session.beginTransaction();
				session.save(book);		
				tx.commit();		

				System.out.println("Book with Id " + (id) + " successfully  added");


			}
			

		
	   }
	@RequestMapping("/book")
	public String getService() {
		return "Welcome to Micro Services";
	}


	@RequestMapping(value="/getBookList", method = RequestMethod.GET,produces={"application/json", "application/xml"}, headers="Accept=application/json,application/xml")
	public @ResponseBody BookList getAllBooks() {

		Query query = session.createQuery("FROM  Book");

		List<Book> list=query.list();
		id=list.size();
		ArrayList<Book> alist = new ArrayList<Book>();
		for(Book array:list){
			Book b=new Book();

			b.setId(array.getId());
			b.setName(array.getName());
			b.setAuthor(array.getAuthor());
			b.setPrice(array.getPrice());

			alist.add(b);

		}

		BookList elist=new BookList(alist);
		return elist;
	}

	@RequestMapping(value="/getBook/{id}", method = RequestMethod.GET,produces={"application/json", "application/xml"}, headers="Accept=application/xml, application/json")

	public @ResponseBody Book findBook(@PathVariable(value="id") int empId) {



		Query query = session.createQuery("FROM  Book");

		List<Book> list=query.list();
		Book b=new Book();
		for(Book array:list){
			if(array.getId()==empId)
			{


				b.setId(array.getId());
				b.setName(array.getName());
				b.setAuthor(array.getAuthor());
				b.setPrice(array.getPrice());

			}
		}

		return b;
	}

	@RequestMapping(value="/addBook", method = RequestMethod.POST,consumes={"application/json", "application/xml"}, produces={"text/plain"})
	public @ResponseBody String addBook(@RequestBody Book b) {

		
			Book book=new Book(b.getId(),b.getName(),b.getAuthor(),b.getPrice());

			Transaction tx=session.beginTransaction();
			session.save(book);		
			tx.commit();		

			System.out.println("Book with Id " + (id) + " successfully  added");
		
		return "Book with Id " + (id+1) + " successfully  added";

	}
	public static String readFile(String filename) {
		String result = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(filename));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				line = br.readLine();
			}
			result = sb.toString();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public static File convertCSVtoJson() throws Exception {
		File input = new File("data.csv");
		File output = new File("data.json");

		List<Map<?, ?>> data = readObjectsFromCsv(input);
		writeAsJson(data, output);
		return output;
	}

	public static List<Map<?, ?>> readObjectsFromCsv(File file) throws IOException {
		CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
		CsvMapper csvMapper = new CsvMapper();
		MappingIterator<Map<?, ?>> mappingIterator = csvMapper.reader(Map.class).with(bootstrap).readValues(file);

		return mappingIterator.readAll();
	}

	public static void writeAsJson(List<Map<?, ?>> data, File file) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(file, data);
	}



}
