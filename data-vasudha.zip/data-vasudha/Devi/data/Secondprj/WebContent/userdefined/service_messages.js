var servicemodule = angular.module("ServiceMessages",[]); 
servicemodule.service("ServiceOperations",function(){
	this.SuccessMsg = function()
	{
		return "You are Login Suceesfully";
	}
	this.FailureMsg = function()
	{
		return "Invalid User Name Password";
	}
	this.sum = function(a,b)
	{
		return a+b;
	}
});