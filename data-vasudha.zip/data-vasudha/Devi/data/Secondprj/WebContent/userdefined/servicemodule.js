var servicemodule = angular.module("ServiceMethod",[]); 
servicemodule.service("Operations",function(){
	this.getData = function()
	{
		var data = [];
		data.push({"id":"123","name":"Pradeep","designation":"Developer"});
		data.push({"id":"124","name":"Praveen","designation":"Hr"});
		data.push({"id":"125","name":"Pramod","designation":"Tester"});
		return data;
	};
});