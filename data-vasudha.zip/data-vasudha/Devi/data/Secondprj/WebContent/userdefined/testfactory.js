angular.module("fact",[]).
factory("PizzaFactory",function(){
	var pizza = {};
	pizza.getType = function(type)
	{
		if(type == 'V')
			{
				return "Veg";
			}
		else
			{
				return "Non-Veg";
			}
	}
	pizza.getPrice = function(type)
	{
		if(type == 'V')
			{
				return 500;
			}
		else
			{
				return 700;
			}
	}
	return pizza;
});