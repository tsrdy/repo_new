angular.module("ServiceModule",[]).
service("AjaxService", function($http) {
    
    this.getCustomerData=function(){
        var promise= $http.get("cust.json");
        return promise;
    };
    this.getCustomerListData=function(){
        var promise= $http.get("customerlist.json");
        return promise;
    };

    
  /*  this.postCustomerData=function(data){
    	console.log(data)
        var promise=$http.post("postEx.jsp",{},{"params":data});
    	console.log(data)
        return promise;
    };*/
    
    this.postCustomerData=function(data){
        var promise=$http.post("postEx.jsp","id="+data.id+"&name="+data.name,
                {"headers":{"Content-Type":"application/x-www-form-urlencoded"}});
        return promise;
    };
    
});

