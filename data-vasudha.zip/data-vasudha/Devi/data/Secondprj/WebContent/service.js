angular.module("ServiceModule",[]).
service("AjaxService", function($http) {
    
    this.getCustomerData=function(){
        var promise= $http.get("cust.json");
        return promise;
    };
    this.getCustomerListData=function(){
        var promise= $http.get("customerlist.json");
        return promise;
    };

    
});
