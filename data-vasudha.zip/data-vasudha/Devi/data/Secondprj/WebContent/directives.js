angular.module("directiveModule2",[])
.directive("secondDirective", function(){
    var content={
            template:"<h2 id='h'>This is a test directive with {{city}} and {{state}}</h2>",
            scope:{
                "city":"=",
                "state":"="
            },
            "link":function(scope,element,attrs)
            {
                element.bind("mouseenter",function(){
                	console.log("hello")
                	$(this).css("color","#FF0000");
                	$(this).find("h2").css("background-color","yellow");
                });
                element.bind("mouseleave",function(){
                	$(this).css("color","#000000");
                	$(this).find("h2").css("background-color","aqua");
                });
            }
    };
    return content;
});