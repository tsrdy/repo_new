var module=angular.module("ServiceModule",[]);
module.service("myService",function(){
	
	this.getData=function()
	{
		employees=[
                   {"id":101,"name":"Arvind","designation":"Developer"},
                   {"id":102,"name":"Deva","designation":"Team Lead"},
                   {"id":103,"name":"Raghav","designation":"Architect"}
                   ];
		return employees;
	}
	
});
