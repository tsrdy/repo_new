/**
 * Created by 400221791 on 2/24/2016.
 */
var app=angula.module("myApp",[]);

app.directive('innerHtmlBind', function() {
    return {
        restrict: 'A',
        scope: {
            inner_html: '=innerHtml'
        },
        link: function(scope, element, attrs) {
            scope.inner_html = element.html();
        }
    }
});
app.contoller("ModalDemoCtrl",function($scope)
{

})