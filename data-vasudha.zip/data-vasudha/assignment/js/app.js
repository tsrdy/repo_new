var app=angular.module("EcomApp",[]);
app.controller("EcomCtrl",function($scope,$http)
{
    /*$scope.showModal = false;
    $scope.toggleModal = function(){
        $scope.showModal = !$scope.showModal;
    };*/

    $scope.showModal = false;
    $scope.buttonClicked = "";
    $scope.toggleModal = function(p_id){
        console.log(p_id)
        $scope.edit_p_id = p_id;
        $scope.showModal = !$scope.showModal;
    };
    $http.get("../assignment/assets/cart.json").success(function(data)
    {
        $scope.data=data;
        console.log(data);
    }).error(function(error)
    {
        console.log("JSON file is Not loaded");
    })

    $scope.addCart=function()
    {

    }

});

app.filter('capitalize', function() {
    return function(input) {
        return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    }
});

app.directive('modal', function () {
    return {
        template: '<div class="modal fade">' +
        '<div class="modal-dialog">' +
        '<div class="modal-content">' +
        '<div class="modal-header">' +
        '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
        '<h4 class="modal-title">{{ edit_p_id }} clicked!!</h4>' +
        '</div>' +
        '<div class="modal-body" ng-transclude></div>' +
        '</div>' +
        '</div>' +
        '</div>',
        restrict: 'E',
        transclude: true,
        replace:true,
        scope:true,
        link: function postLink(scope, element, attrs) {
            scope.$watch(attrs.visible, function(value){
                if(value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });

            $(element).on('shown.bs.modal', function(){
                scope.$apply(function(){
                    scope.$parent[attrs.visible] = true;
                });
            });

            $(element).on('hidden.bs.modal', function(){
                scope.$apply(function(){
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
});



