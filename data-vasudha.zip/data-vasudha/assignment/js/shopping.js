var app=angular.module("EcomApp",[]);
app.controller("EcomCtrl",function($scope,$http)
{
    /*$scope.showModal = false;
     $scope.toggleModal = function(){
     $scope.showModal = !$scope.showModal;
     };*/

    $scope.showModal = false;
    $scope.buttonClicked = "";
    $scope.toggleModal = function(event){
        console.log(event.target.id)
        $scope.edit_p_id = event.target.id;
        $scope.loadEditData($scope.edit_p_id);
        $scope.showModal = !$scope.showModal;
    };
    $scope.loadEditData=function(pid)
    {
        $scope.productsInCart=$scope.data.productsInCart;
        for(i=0;i<$scope.productsInCart.length;i++)
        {
            console.log($scope.productsInCart[i].p_id)
            if($scope.productsInCart[i].p_id==pid)
            {
                $scope.colors=$scope.productsInCart[i].p_available_options.colors;
                $scope.size=$scope.productsInCart[i].p_available_options.sizes;
                $scope.qty=1;
            }
        }
        console.log($scope.colors)
    }
    $http.get("../assignment/assets/cart.json").success(function(data)
    {
        $scope.data=data;
        console.log(data);
    }).error(function(error)
    {
        console.log("JSON file is Not loaded");
    })

    $scope.addCart=function()
    {

    }
    $scope.save=function()
    {
        $scope.productsInCart=$scope.data.productsInCart;
        for(i=0;i<$scope.productsInCart.length;i++)
        {

            if($scope.productsInCart[i].p_id==$scope.edit_p_id)
            {

                $scope.data.productsInCart[i].p_selected_color.name=$scope.ecolor;
                console.log($scope.ecolor);
                console.log($scope.data.productsInCart[i].p_selected_color.name);
                $scope.data.productsInCart[i].p_selected_size.code=$scope.esize;
                $scope.data.productsInCart[i].p_quantity=$scope.eqty;
                console.log("qty"+$scope.eqty);
            }
        }
        /*$scope.$apply();*/
        $scope.showModal = false;

    }
    $scope.changeColor=function(ecolor)
    {
        $scope.ecolor=ecolor;
    }
    $scope.changeSize=function(esize)
    {
        $scope.esize=esize;
    }
    $scope.changeQty=function(qty)
    {
        $scope.eqty=qty;
        $scope.qty=qty;
    }

});

app.filter('capitalize', function() {
    return function(input) {
        return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
    }
});

app.directive('modal', function () {
    return {
        template: '<div class="modal fade">' +
        '<div class="modal-dialog">' +
        '<div class="modal-content">' +
        '<div class="modal-header">' +
        '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>' +
        '<h4 class="modal-title"> Edit the Size , Color and Qty!!</h4>' +
        '</div>' +
        '<div class="modal-body" ng-transclude></div>' +
        '</div>' +
        '</div>' +
        '</div>',
        restrict: 'E',
        transclude: true,
        replace:true,
        scope:true,
        link: function postLink(scope, element, attrs) {
            scope.$watch(attrs.visible, function(value){
                if(value == true)
                    $(element).modal('show');
                else
                    $(element).modal('hide');
            });

            $(element).on('shown.bs.modal', function(){
                scope.$apply(function(){
                    scope.$parent[attrs.visible] = true;
                });
            });

            $(element).on('hidden.bs.modal', function(){
                scope.$apply(function(){
                    scope.$parent[attrs.visible] = false;
                });
            });
        }
    };
});



