import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


public class AngularJsServlet extends HttpServlet {
        private static final long serialVersionUID = 1L;

        public AngularJsServlet() {
                super();
        }

        protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
                EmpData personData = new EmpData();
                
                personData.setId(request.getParameter("id"));
                personData.setEname(request.getParameter("ename"));;
                personData.setSalary(request.getParameter("salary"));
              
                GsonBuilder gsonBuilder = new GsonBuilder();
                Gson gson = gsonBuilder.create();
              
               /* List<EmpData> empList = new LinkedList<EmpData>();
               
                empList.add(personData);
                
                String json =gson.toJson(empList);*/
                
                String json =gson.toJson(personData);
                
                
                System.out.println(json);
             // try-with-resources statement based on post comment below :)
        		/*try (FileWriter file = new FileWriter("D:/Users/400221791/workspace/DemoJSON/WebContent/JSONUpdate/json/emps.json")) {
        			file.write(json);
        			System.out.println("Successfully Copied JSON Object to File...");
        		}*/
                
                RandomAccessFile randomAccessFile = new RandomAccessFile("D:/Users/400221791/workspace/DemoJSON/WebContent/JSONUpdate/json/emps.json", "rw");
                long pos = randomAccessFile.length();
                while (randomAccessFile.length() > 0) {
                    pos--;
                    randomAccessFile.seek(pos);
                    if (randomAccessFile.readByte() == ']') {
                        randomAccessFile.seek(pos);
                        break;
                    }
                }
                randomAccessFile.writeBytes("," + json + "]");
                randomAccessFile.close();
                

                response.setContentType("application/json");
                response.getWriter().write(json);
        }
}