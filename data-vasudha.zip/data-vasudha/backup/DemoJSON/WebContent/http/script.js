var app=angular.module("myApp",[]);
app.controller("ctrl1",function($scope,$http){
               
                $http({
                                url:"data.json",
                                type:"GET",
                                }).success(function(result)
                                {
                                                $scope.data=result;
                                                
                                                console.log($scope.data)
                                                
                                })
                
});
