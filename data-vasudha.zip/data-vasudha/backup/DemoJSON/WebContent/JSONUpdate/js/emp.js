var app=angular.module("myApp",[])
app.controller("myCtrl",function($scope,$http)
{
	
	$http({
		url:"../JSONUpdate/json/emps.json",
		method:"POST"
	}).success(function(data){
		$scope.emps=data
	})
	
	$scope.add=function()
	{
		
		$http({
			url:"http://localhost:8080/DemoJSON/javaAngularJS",
			method:"POST",
			data: $.param({id:$scope.id,ename:$scope.ename,salary:$scope.salary}),
			headers: {
			      'Content-Type': 'application/x-www-form-urlencoded'
			    }
		}).success(function(data){
			$scope.emps=data
		}).error(function(data){
			console.log(data)
		})
	}
})
