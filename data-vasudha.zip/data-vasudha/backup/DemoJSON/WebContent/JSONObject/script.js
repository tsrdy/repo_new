var app=angular.module("myApp",['ngStorage']);

app.controller("ctrl1",function($scope,$localStorage){
	
          $scope.jsonObj=$localStorage.jsonObj||[];   
          
      $scope.add=function()
      {
    	  var addObj={name:$scope.ename,id:$scope.eid}
    	  $scope.jsonObj.push(addObj);    	  
    	  $localStorage.jsonObj=$scope.jsonObj;
    	  
      }
      $scope.deleteData=function()
      {
    	  console.log($scope.jsonObj.length)
    	  for(var i=0;i<$scope.jsonObj.length;i++)
    		  {
    		  console.log($scope.jsonObj[i])
    		  if($scope.jsonObj[i].name===$scope.ename && $scope.jsonObj[i].id===$scope.eid)
    			  {
    			  console.log(i);
    			  $scope.jsonObj.splice(i,1);
    			  i--;
    			  console.log($scope.jsonObj)
    			  $localStorage.jsonObj=$scope.jsonObj;
    			  }
    		  }
      }
                
});
