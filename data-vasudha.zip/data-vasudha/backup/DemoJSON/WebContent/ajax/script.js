var app=angular.module("myApp",[]);
app.controller("ctrl1",function($scope){

                $.ajax({
                                url:"data.json",
                                type:"GET",
                                success: function(result)
                                {
                                                $scope.data=result;
                                                console.log($scope.data)
                                                
                                               
                                }
                });
               
                $.apply();
                console.log("scope "+$scope.data)
                
});
