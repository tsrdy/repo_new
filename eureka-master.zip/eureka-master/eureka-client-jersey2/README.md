This is work in progress. DiscoveryClient has hard dependency on Jersey 1.x, and it must be removed first
before Jersey 2.x transport can be injected.