package srvcpoc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.srvcnow.Servnowv2Application;
import com.srvcnow.dao.IncidentCommentDaoImpl;
import com.srvcnow.dto.Comment;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = Servnowv2Application.class)
public class CommentTest {
	private final Log logger = LogFactory.getLog(CommentTest.class);
	@Autowired
	IncidentCommentDaoImpl commentDao;

	private MockMvc mvc;	
	
	@Test
	public void getDummy() throws Exception {		
		assertTrue(true);
		logger.info("getDummy");
		
	}

	//@Test
	public void getTestComments() throws Exception {
		List<Comment> temp = commentDao.findAll();
		assertNotNull(temp);
		assertTrue(!temp.isEmpty());
		logger.info("temp"+temp.size());
		
	}

	//@Test
	public void getTestCommentByIncident() throws Exception {
		List<Comment> temp = commentDao.getCommentByIncident("INC1498929");
		logger.info("temp"+temp.size());

	}
	//@Test
    public void getCommentUrl() throws Exception {
		logger.info("getCommentUrl");
        mvc.perform(get("/getComments/1")
        		.header("ConsumerApp", "Junit-Test")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
                //.andExpect(jsonPath("$", ));
    }

	//@Test
	public void createComment() {
		Comment objComment = new Comment("Testing","Vikash", "502582959", new Date(), "INC1498929");
		int count = commentDao.addComments(objComment);
		System.out.println("count:" + count);
		List<Comment> temp = commentDao.getCommentByIncident(objComment.getIncidentId().toString());
		assertNotNull(objComment);

		}

}
