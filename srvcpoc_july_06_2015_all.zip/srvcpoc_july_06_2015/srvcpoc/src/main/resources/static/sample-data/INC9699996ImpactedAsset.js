[
    {
        "assetId": 1,
        "assetName": "potentialAsset--1"
    },
    {
        "assetId": 2,
        "assetName": "potentialAsset--2"
    },
    {
        "assetId": 3,
        "assetName": "potentialAsset--3"
    },
    {
        "assetId": 4,
        "assetName": "potentialAsset--4"
    },
    {
        "assetId": 5,
        "assetName": "potentialAsset--5"
    },
    {
        "assetId": 6,
        "assetName": "potentialAsset--6"
    },
    {
        "assetId": 7,
        "assetName": "potentialAsset--7"
    },
    {
        "assetId": 8,
        "assetName": "potentialAsset--8"
    },
    {
        "assetId": 9,
        "assetName": "potentialAsset--9"
    },
    {
        "assetId": 10,
        "assetName": "potentialAsset--10"
    },
    {
        "assetId": 11,
        "assetName": "potentialAsset--11"
    },
    {
        "assetId": 12,
        "assetName": "potentialAsset--12"
    },
    {
        "assetId": 13,
        "assetName": "potentialAsset--13"
    },
    {
        "assetId": 14,
        "assetName": "potentialAsset--14"
    },
    {
        "assetId": 15,
        "assetName": "potentialAsset--15"
    }
]