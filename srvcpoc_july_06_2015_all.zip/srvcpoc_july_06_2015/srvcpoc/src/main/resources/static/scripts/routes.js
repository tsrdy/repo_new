/**
 * Router Config This is the router definition that defines all application
 * routes.
 */
define([ 'angular', 'angular-ui-router' ], function(angular) {
	'use strict';
	return angular.module('app.routes', [ 'ui.router' ]).config(
			[
					'$stateProvider',
					'$urlRouterProvider',
					'$locationProvider',
					function($stateProvider, $urlRouterProvider,
							$locationProvider) {

						// Turn on or off HTML5 mode which uses the # hash
						$locationProvider.html5Mode(true).hashPrefix('!');

						/**<%!  %>
						 * Router paths This is where the name of the route is
						 * matched to the controller and view template.
						 */
						$stateProvider.state('dashboards', {
							// parent: 'secure',
							url : '/dashboards',
							templateUrl : 'views/dashboards.html',
							controller : 'DashboardsCtrl'
						}).state('dataSet1', {
							url : '/blankpage/:No/:shtDesc/:CI/:priority',
							templateUrl : 'views/blank-page.html',
							controller : 'SampleCtrl'
						})

						.state('incidentdatapage1', {
							url : '/incidentdatapage?incidentNo',
							templateUrl: 'views/incidentdata.html',
							controller: 'IncidentPageCtrl'
							 
						}).state('contacts', {
							//url : 'pk/:incidentNo_',
							templateUrl : 'views/incidentdata.html',
							controller : function($scope,$stateParams) {
								$scope.title = 'My Contacts';
								console.log($stateParams.incidentNo_)
								
							}
						}).state('blanksubpage', {
							url : '/blanksubpage',
							templateUrl : 'views/blank-sub-page.html'
						});
						$urlRouterProvider.otherwise(function($injector) {
							var $state = $injector.get('$state');
							//document.querySelector('px-app-nav').markSelected('dashboards');
							console.log("inside other wise of URL");
							//$state.go('contacts', {"incidentNo_" : window.myObj.myGlobal});
						});

					} ]);
});
