define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('DashboardsCtrl', ['$scope', '$log', 'PredixAssetService', 'PredixViewService','$http', function ($scope, $log, PredixAssetService, PredixViewService,$http) {

        
           
          $http.get('sample-data/'+'TableData.json').then(function success(response){
            
          $scope.incidentId=response.data[0].Number;
          $scope.records=response.data;
          //$scope.pno=response.data[0].Number;
        })



     
        
    }]);
});
