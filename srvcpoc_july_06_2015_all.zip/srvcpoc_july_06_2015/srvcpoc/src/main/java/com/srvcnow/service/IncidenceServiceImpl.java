package com.srvcnow.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.srvcnow.dao.IncidenceDataDao;
import com.srvcnow.util.SystemGoUtil;

@Component
public class IncidenceServiceImpl implements IncidenceService {

	@Autowired
	IncidenceDataDao incidenceDataDao;

	@Override
	public String getIncidenceData(String incidentId) {
		RestTemplate restTemplate = SystemGoUtil.createRestTemplate();
//		String incidentJsonData = restTemplate.getForObject(
//				"https://gedev.service-now.com/incident.do?JSONv2&sysparm_query=numberSTARTSWITH" + incidentId,
//				String.class);
		String incidentJsonData = restTemplate.getForObject(
				"https://gesandbox1.service-now.com/incident.do?JSONv2&sysparm_query=numberSTARTSWITH" + incidentId,
				String.class);
		return incidentJsonData;
	}

	@Override
	/**
	 * FETCH 'INCIDENT NUMBER'
	 */
	public String getIncidenceNumber(String incidencData, String incidenceNo) {
		String incidenceNumber = getIncNumber(incidencData, incidenceNo);
		return incidenceNumber;
	}

	/**
	 * If No data in DB then Pull 'INCIDENT NUMBER' from API (Json Data)
	 * 
	 * @param incidencData
	 * @param incidenceNo
	 * @return
	 */
	private String getIncNumber(String incidencData, String incidenceNo) {
		String incidenceNumber = "";
		Map<String, String> incidenceInfo = new HashMap<String, String>();
		if (incidencData.equals("DB")) {
			incidenceInfo = incidenceDataDao.retriveDBData(incidenceNo);
			incidenceNumber = incidenceInfo.get("number").toString();
		} else {
			incidenceInfo = SystemGoUtil.getParsedData(incidencData, "number");
			incidenceNumber = incidenceInfo.get("number").toString();
		}

		return incidenceNumber;
	}

	// -----*****************NEED TO IDENTIFY CI tags FROM API

	@Override
	/**
	 * FETCH INCIDENT 'CONFIGURATION ITEMS' from API
	 */
	public String getIncidenceCi(String incidencData, String incidenceNo) {
		String incidenceCi = getIncCi(incidencData, incidenceNo);
		return incidenceCi;
	}

	/**
	 * If No data in DB then Pull INCIDENT 'CONFIGURATION ITEMS' from API (Json
	 * Data)
	 * 
	 * @param incidencData
	 * @param incidenceNo
	 * @return
	 */
	private String getIncCi(String incidencData, String incidenceNo) {
		String incidenceCi = "";
		Map<String, String> incidenceInfo = new HashMap<String, String>();
		if (incidencData.equals("DB")) {
			incidenceInfo = incidenceDataDao.retriveDBData(incidenceNo);
			incidenceCi = incidenceInfo.get("short_description").toString();
		} else {
			incidenceInfo = SystemGoUtil.getParsedData(incidencData, "short_description");
			incidenceCi = incidenceInfo.get("short_description").toString();
		}

		return incidenceCi;
	}

	@Override
	/**
	 * FETCH SHORT DESCRIPTION
	 */
	public String getIncidenceDescription(String incidencData, String incidenceNo) {
		String incidenceDesc = getIncDescription(incidencData, incidenceNo);
		return incidenceDesc;
	}

	/**
	 * If No data in DB then Pull INCIDENT 'DESCRIPTION' from API (Json Data)
	 * 
	 * @param incidencData
	 * @param incidenceNo
	 * @return
	 */
	private String getIncDescription(String incidencData, String incidenceNo) {
		String incidenceDesc = "";
		Map<String, String> incidenceInfo = new HashMap<String, String>();
		if (incidencData.equals("DB")) {
			incidenceInfo = incidenceDataDao.retriveDBData(incidenceNo);
			incidenceDesc = incidenceInfo.get("short_description").toString();
		} else {
			incidenceInfo = SystemGoUtil.getParsedData(incidencData, "short_description");
			incidenceDesc = incidenceInfo.get("short_description").toString();
		}

		return incidenceDesc;
	}

	@Override
	/**
	 * FETCH POTENTIALLY IMPACTED UI ASSET LISTS
	 */
	public List<String> getPotentialImpactedCiAsets(String incidencData, String incidenceNo) {
		List<String> potentiallyImpactedAssetList = getIncAsset(incidencData, incidenceNo);
		return potentiallyImpactedAssetList;
	}

	/**
	 * If No data in DB then Pull IMPACTED 'ASSETS' from API (Json Data)
	 * 
	 * @param incidencData
	 * @param incidenceNo
	 * @return
	 */
	private List<String> getIncAsset(String incidencData, String incidenceNo) {
		List<String> incAssetList = new ArrayList<String>();
		Map<String, String> incidenceInfo = new HashMap<String, String>();
		String imactedAppInfo = null;

		if (incidencData.equals("DB")) {
			incAssetList = incidenceDataDao.retrivePotentialAssetListDB(incidenceNo);
		} else {
			incidenceInfo = SystemGoUtil.getParsedData(incidencData, "u_impacted_ci_list");
			imactedAppInfo = incidenceInfo.get("u_impacted_ci_list").toString();
			if (imactedAppInfo != null) {
				String[] ciList = SystemGoUtil.parseString(imactedAppInfo);
				incAssetList.addAll(SystemGoUtil.getAssetListValData(ciList));
			}
		}

		return incAssetList;
	}

	@Override
	/**
	 * FETCH POTENTIALLY IMPACTED UI APPLICATION LIST based on Asset List from
	 * DB
	 */
	public List<String> getPotentialImpactedCiApps(String incData, String incId, List<String> ciAssetsList) {
		List<String> potentiallyImpactedAppList = getIncApp(incData, incId, ciAssetsList);
		return potentiallyImpactedAppList;
	}

	/**
	 * If No data in DB then Pull IMPACTED 'APPLICATION' from POSTGRES TABLE
	 * else from Saved
	 * 
	 * @param incidencData
	 * @param incidenceNo
	 * @return
	 */
	private List<String> getIncApp(String incidencData, String incId, List<String> ciAssetsList) {
		List<String> incAppList = new ArrayList<String>();
		if (incidencData.equals("DB")) {
			incAppList = incidenceDataDao.retrivePotentialAppListDB(incId);
		} else {
			incAppList = incidenceDataDao.retriveAppList(incId, ciAssetsList);
//			incAppList =  new ArrayList<String>();
		}

		return incAppList;
	}

	@Override
	/**
	 * CHEK DATA FROM DB
	 */
	public Boolean checkDbData(String incidenceNo) {
		return incidenceDataDao.checkDataFromDb(incidenceNo);
	}

	/**
	 * @return the incidenceDataDao
	 */
	public IncidenceDataDao getIncidenceDataDao() {
		return incidenceDataDao;
	}

	/**
	 * @param incidenceDataDao
	 *            the incidenceDataDao to set
	 */
	public void setIncidenceDataDao(IncidenceDataDao incidenceDataDao) {
		this.incidenceDataDao = incidenceDataDao;
	}

}
