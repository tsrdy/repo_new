package com.srvcnow.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.srvcnow.dao.IncidentCommentDaoImpl;
import com.srvcnow.dto.CI;
import com.srvcnow.dto.Comment;
import com.srvcnow.dto.Incident;
import com.srvcnow.service.IncidenceService;

@RestController
public class IncidentController {
	private final Log logger = LogFactory.getLog(IncidentController.class);

	@Autowired
	IncidentCommentDaoImpl commentDao;

	@Autowired
	IncidenceService incidenceSrvc;
	String incData = "";
	String incId = "";
	List<String> potentiallyImpactAssets = new ArrayList<String>();

	@RequestMapping(value = "/getincident/{incidentId}")
	public @ResponseBody Incident getincident(@PathVariable("incidentId") String incidentId) {

		this.setIncData(getIncidenceData(incidentId));
		Incident inc = new Incident();
		inc.setIncidentId(incidenceSrvc.getIncidenceNumber(incData, incidentId));
		inc.setDescription(incidenceSrvc.getIncidenceDescription(incData, incidentId));
		inc.setCi(incidenceSrvc.getIncidenceCi(incData, incidentId));
		return inc;
	}

	@RequestMapping(value = "/getPotentiallyImpactAssets/{incidentId}")
	public @ResponseBody List getPotentiallyImpactAssets(@PathVariable("incidentId") String incidentId) {
		this.setIncData(getIncidenceData(incidentId));
		if(this.potentiallyImpactAssets.size()>0){
			this.potentiallyImpactAssets.clear();
		}
		this.potentiallyImpactAssets = incidenceSrvc.getPotentialImpactedCiAsets(incData, incidentId);

		List<CI> al = new ArrayList<CI>();
		for (String listVal : potentiallyImpactAssets) {
			CI inc = new CI();
			inc.setCiname(listVal);
			al.add(inc);
		}
		return al;
	}

	@RequestMapping(value = "/getPotentiallyImpactApps/{incidentId}")
	public @ResponseBody List getPotentiallyImpactApps(@PathVariable("incidentId") String incidentId) {

		List<String> impactAppList = new ArrayList<String>();
		List<CI> al = new ArrayList<CI>();

		impactAppList = incidenceSrvc.getPotentialImpactedCiApps(incData,incidentId,this.potentiallyImpactAssets);

		for (String listVal : impactAppList) {
			CI inc = new CI();
			inc.setCiname(listVal);
			al.add(inc);
		}

		return al;
	}

	@RequestMapping(value = "/getComments/{incidentId}")
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody List getComments(@PathVariable("incidentId") String incidentId) {
		logger.info("Inside ");

		/*
		 * List al = new ArrayList(); Comment c1 = new Comment(); c1.setComment(
		 * "0 New comments"); c1.setId(Integer.parseInt("1"));
		 * c1.setLoggedDate(new Date()); al.add(c1);
		 * 
		 * c1 = new Comment(); c1.setComment(
		 * "1 This stages them for the first commit 1. ");
		 * c1.setId(Integer.parseInt("1")); c1.setLoggedDate(new Date());
		 * al.add(c1);
		 * 
		 * c1 = new Comment(); c1.setComment(
		 * "2 New Commit the files that you've staged in your local repository ."
		 * ); c1.setId(Integer.parseInt("1")); c1.setLoggedDate(new Date());
		 * al.add(c1);
		 * 
		 * c1 = new Comment(); c1.setComment(
		 * "3 New At the top of your GitHub repository's Quick Setup page, cli"
		 * ); c1.setId(Integer.parseInt("1")); c1.setLoggedDate(new Date());
		 * al.add(c1);
		 * 
		 * c1 = new Comment(); c1.setComment(
		 * "4 New Push the changes in your local repository to GitHub.");
		 * c1.setId(Integer.parseInt("1")); c1.setLoggedDate(new Date());
		 * al.add(c1);
		 */

		return commentDao.getCommentByIncident(incidentId);
	}

	@RequestMapping(value = "/addincident", method = RequestMethod.POST)
	public @ResponseBody int addIncident(@RequestBody Comment comment) {
		int count = 0;
		count = commentDao.addComments(comment);
		return count;
	}

	/**
	 * 
	 * @param incidentId
	 * @return
	 */
	private String getIncidenceData(String incidentId) {
		String incidenceData = null;
		boolean checkDbData = false;

		checkDbData = incidenceSrvc.checkDbData(incidentId);
		if (!checkDbData) {
			incidenceData = incidenceSrvc.getIncidenceData(incidentId);
			this.setIncData(incidenceData);
		}else{
			incidenceData = "DB";
			this.setIncData(incidenceData);
		}
		
		return incidenceData;
	}

	/**
	 * @return the incidenceSrvc
	 */
	public IncidenceService getIncidenceSrvc() {
		return incidenceSrvc;
	}

	/**
	 * @param incidenceSrvc
	 *            the incidenceSrvc to set
	 */
	public void setIncidenceSrvc(IncidenceService incidenceSrvc) {
		this.incidenceSrvc = incidenceSrvc;
	}

	/**
	 * @return the incData
	 */
	public String getIncData() {
		return incData;
	}

	/**
	 * @param incData
	 *            the incData to set
	 */
	public void setIncData(String incData) {
		this.incData = incData;
	}

	/**
	 * @return the potentiallyImpactAssets
	 */
	public List<String> getPotentiallyImpactAssets() {
		return potentiallyImpactAssets;
	}

	/**
	 * @param potentiallyImpactAssets
	 *            the potentiallyImpactAssets to set
	 */
	public void setPotentiallyImpactAssets(List<String> potentiallyImpactAssets) {
		this.potentiallyImpactAssets = potentiallyImpactAssets;
	}

}
