package com.srvcnow.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:query.properties")
public final class QueryUtil {

	public static String checkDbData;

	public static String appListQuery;

	public static String incIdCiDescQuery;

	public static String incAssetListQuery;

	public static String incAppListQuery;

	public static String incConfAssetQuery;

	public static String incConfAppsQuery;

	@Autowired
	public QueryUtil(@Value("${spring.checkDbData}") String checkDbData,
			@Value("${spring.appListQuery}") String appListQuery,
			@Value("${spring.incIdCiDescQuery}") String incIdCiDescQuery,
			@Value("${spring.incAssetListQuery}") String incAssetListQuery,
			@Value("${spring.incAppListQuery}") String incAppListQuery,
			@Value("${spring.incConfAssetQuery}") String incConfAssetQuery,
			@Value("${spring.incConfAppsQuery}") String incConfAppsQuery) {
		QueryUtil.checkDbData = checkDbData;
		System.out.println("================== " + checkDbData + "================== ");
		QueryUtil.appListQuery = appListQuery;
		System.out.println("================== " + appListQuery + "================== ");
		QueryUtil.incIdCiDescQuery = incIdCiDescQuery;
		System.out.println("================== " + incIdCiDescQuery + "================== ");
		QueryUtil.incAssetListQuery = incAssetListQuery;
		System.out.println("================== " + incAssetListQuery + "================== ");
		QueryUtil.incAppListQuery = incAppListQuery;
		System.out.println("================== " + incAppListQuery + "================== ");
		QueryUtil.incConfAssetQuery = incConfAssetQuery;
		System.out.println("================== " + incConfAssetQuery + "================== ");
		QueryUtil.incConfAppsQuery = incConfAppsQuery;
		System.out.println("================== " + incConfAppsQuery + "================== ");
	}
}
