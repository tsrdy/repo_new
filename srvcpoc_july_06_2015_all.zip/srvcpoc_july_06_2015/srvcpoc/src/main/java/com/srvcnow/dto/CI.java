package com.srvcnow.dto;

public class CI {
	public Integer id;
	public String ciname;
	public String ciassetid;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCiname() {
		return ciname;
	}

	public void setCiname(String ciname) {
		this.ciname = ciname;
	}

	public String getCiassetid() {
		return ciassetid;
	}

	public void setCiassetid(String ciassetid) {
		this.ciassetid = ciassetid;
	}

}
