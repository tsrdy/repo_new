package com.srvcnow.service;

import java.util.List;

public interface IncidenceService {
	
	String getIncidenceData(String incidentId);
	
	String getIncidenceNumber(String incidencData,String incidenceNo);

	String getIncidenceCi(String incidencData,String incidenceNo);

	String getIncidenceDescription(String incidenceNo, String incidentId);

	List<String> getPotentialImpactedCiAsets(String incidencData, String incidenceNo);

	List<String> getPotentialImpactedCiApps(String incData, String incId, List<String> ciAssets);
	
	Boolean checkDbData(String incidenceNo);


}
