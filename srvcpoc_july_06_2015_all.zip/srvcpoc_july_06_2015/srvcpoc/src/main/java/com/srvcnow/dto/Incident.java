package com.srvcnow.dto;

public class Incident {

	public Integer id;
	public String priority;
	public String incidentId;
	public String description;
	public String ci;
	public String incident_id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCi() {
		return ci;
	}

	public void setCi(String ci) {
		this.ci = ci;
	}

	public String getIncidentId() {
		return incidentId;
	}

	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}

	/**
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * @param priority
	 *            the priority to set
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * @return the incident_id
	 */
	public String getIncident_id() {
		return incident_id;
	}

	/**
	 * @param incident_id the incident_id to set
	 */
	public void setIncident_id(String incident_id) {
		this.incident_id = incident_id;
	}
	

}
