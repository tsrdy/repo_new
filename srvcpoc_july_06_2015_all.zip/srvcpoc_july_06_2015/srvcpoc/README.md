# srvcpoc

## servicenow POC

Link
http://localhost:8080/incidentdatapage?incidentNo=IJC001

### Table
-Incident
	incident_no	- pk
	incident_state // json state object
	incident ci
	incident_shortdesc
	incident_priority
	
-Confirmed Assets Impacted 
-Confirmed Applications Impacted
-Potentially Impacted Assets
-Potentially Impacted Applications
-Comments 
	id - PK
	comments
	date
	loggedby

	
## Reference 
spring-projects/spring-data-examples
https://github.com/spring-projects/spring-data-examples/tree/master/jpa

## MVM
---------------------
1.Download ojdbc7.jar
2.mvn install:install-file -Dfile=C:/Users/502428495/Downloads/ojdbc7.jar} -DgroupId=com.oracle -DartifactId=ojdbc7 -Dversion=12.1.0.1 -Dpackaging=jar

3. Add following in pom.xml

<dependency>
            <groupId>com.oracle</groupId>
            <artifactId>ojdbc7</artifactId>
            <version>12.1.0.1</version>
        </dependency>
        
## How to have configure 2 datasources
check this link http://stackoverflow.com/questions/30362546/how-to-use-2-or-more-databases-with-spring
