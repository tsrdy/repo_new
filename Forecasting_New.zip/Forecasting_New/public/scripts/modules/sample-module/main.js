define(['./sample-module',
	'./sample-directive', 
	'./sample-filter', 
	'./sample-service',

	'./dashboard-controller',
	'./sample-controller',
	'./forecast-controller',

	'./predix-asset-service', 
	'./predix-user-service', 
	'./predix-view-service'], function() {

});
