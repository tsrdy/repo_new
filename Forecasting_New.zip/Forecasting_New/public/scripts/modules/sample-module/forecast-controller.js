define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

// Controller definition
controllers.controller('forecastCtrl', ['$scope', '$http','$log','$q', function ($scope, $http, $log, $q) {
      
    $scope.partNo;
    $scope.drpDwnSel;
    $scope.headerData;
    $scope.tableData;
    $scope.toggleExpansion = false;
   // $scope.labelFlag=false;

    //$scope.selOptions=["Simple Avg", "Moving Avg", "WMA 12 Month", "Single Exp.", "Double Exp.", "Triple Exp.", "Linear Reg", "Croston"];
    $scope.selOptions=[ {"name":"Simple Avg", "val":"simple Average"},
                        {"name":"Moving Avg", "val":"moving Avg 5 Months"},
                        {"name":"WMA 12 Month", "val":"wma 12 Months"},
                        {"name":"Single Exp", "val":"Single Exponential"},
                        {"name":"Double Exp", "val":"Double Exp"},
                        {"name":"Triple Exp", "val":"Triple Exp"},
                        {"name":"Linear Reg", "val":"Linear Reg"}];
                        
    $scope.bestMethod= {"THQL2130": "Single Exp",
                        "THQB32030": "Moving Avg",
                        "TEY320": "WMA 12 Month",
                        "SELA36AT0100": "Double Exp"};

    $scope.highlightBestMethod= function (){
          angular.forEach($scope.bestMethod, function(value,key){
              if($scope.partNo==key){
                $scope.hbmFlag=$scope.bestMethod[key];
              }
            })
     
         
          $('#highlightBox tr:nth-child(1)').each(function(){
              $(this).find('td').each(function(){
                  var checkValue=($(this).html());
                 // console.log(checkValue);
                  if(checkValue==$scope.hbmFlag){

                     $(this).css("background-color","#4D529A")
                    }
                  else{
                     $(this).css("background-color","#7CB5EC")
                    }
              })
          });
    }

    $scope.getData= function(sel) {
      var elem=document.getElementById('optionId');
      document.getElementById("optionId")[0].removeAttribute("selected", "selected");
      $scope.drpDwnSel=elem[parseInt(elem.value)+1].innerHTML;
      
      var url1="https://geisforecast-service1.run.aws-usw02-pr.ice.predix.io/getMaterialList/"+$scope.partNo;
      $http.get(url1).success(function(response){
      
      $scope.headerData=response[0];
      // debugger
      })

      var url2="https://geisforecast-service.run.aws-usw02-pr.ice.predix.io/getMaterialForecastList/"+$scope.partNo+"/"+sel;
      $http.get(url2).success(function(response){
      
      $scope.tableData=response;
      $scope.changechart0($scope.tableData);
      $scope.changechart1($scope.tableData);

      //console.log(JSON.stringify($scope.tableData))
       })
    };


    $scope.clearDrpDwn= function() {
      //$scope.labelFlag=false;
      //debugger
      $scope.drpDwnSel="";
      $scope.changechart0([]);
      $scope.changechart1([]);
      document.getElementById("optionId")[0].setAttribute("selected", "selected");
    }

    $scope.toggleExpandMin= function() {
      if($scope.toggleExpansion==false){
        $scope.toggleExpansion=true;
        $('#faToggle').removeClass('fa-plus-square');
        $('#faToggle').removeClass('green');
        $('#faToggle').addClass('fa-minus-square');
        $('#faToggle').addClass('red');
      }
      else {
        $scope.toggleExpansion=false;
        $('#faToggle').removeClass('fa-minus-square');
        $('#faToggle').removeClass('red');
        $('#faToggle').addClass('fa-plus-square');
        $('#faToggle').addClass('green');
      }
     // console.log($scope.toggleExpansion);

    }
    
    $scope.reloadPage = function(){window.location.reload()};


/*For Chart on left side*/  
    $scope.changechart0 = function(dataSet){
      //debugger
      var categories=[];
      var geIsApe=[];
      var genpactApe=[];
      var demand=[];
      var total=0;
      var total2=0;
      var avg=[];
      var avg2=[];
      var actualData=[];

      angular.forEach(dataSet, function(value, key){

        categories.push(value.timePeriod);

        /*Split percent and convert to number*/
        var gEISAPEtemp=value.gEISAPE.split("%");
        geIsApe.push(parseInt(gEISAPEtemp[0]));

        /*Split percent and convert to number*/
        var genpactAPEtemp=value.genpactAPE.split("%");
        genpactApe.push(parseInt(genpactAPEtemp[0]));
/*--Check Actual Data length--*/
        /*Split percent and convert to number*/
        var genpactFCSTtemp=value.genpactFCST.split("%");
        if(parseInt(genpactFCSTtemp[0])!==0){
          actualData.push(parseInt(genpactFCSTtemp[0]));
        }

        total=total+parseInt(gEISAPEtemp[0]); //ge Ape
        //debugger
        total2=total2+parseInt(genpactAPEtemp[0]); //genpact Ape

        demand.push(parseInt(value.demand));

      })

      console.log(actualData.length);
      //console.log(total+"  "+total2)
      for(var i=0; i<geIsApe.length;i++){
        avg.push(Math.round(total/geIsApe.length));
      }
      for(var i=0; i<genpactApe.length;i++){
        avg2.push(Math.round(total2/actualData.length));
      }

      $scope.geIsMapeAvg=avg[0];
      $scope.genpactMapeAvg=avg2[0];

      console.log(JSON.stringify(avg))
      console.log(JSON.stringify(avg2))

     // debugger
      var chartData0={
          chart: {
            type:  'column',
            renderTo: 'container'
          },
          
          title: {
              text: ''
          },
          subtitle: {
              text: ''
          },
          xAxis: {
              categories: categories
          },
          yAxis: [{
              min: 0,
              max:100,
              title: {
                  text: ''
              },
              labels: {
                    formatter: function () {
                        return  this.axis.defaultLabelFormatter.call(this)+''+'%';
                    }            
                }
              },{
                
                  title: {
                      text: ''
                  },
                  opposite: true
              }],
          series: [{
            yAxis:0,
            type:'column',
            color: '#7cb5ec',
             name: ' GE IS APE',
              data: geIsApe

          }, {
            yAxis:0,
            type:'column',
            color: 'black',
             name: 'Genpact APE',
              data: genpactApe

          },
            {
                yAxis:0,
                type: 'line',
                marker: {
                    enabled:false
                },
                color:'#7cb5ec',
                name: 'GE IS MAPE',
                data: avg,
                dashStyle: 'dash'
            },
            {
                yAxis:0,
                type: 'line',
                marker: {
                    enabled:false
                },
                color:'black',
                name: 'GENPACT MAPE',
                data: avg2,
                dashStyle: 'dash'
            }],
            legend: {
                itemStyle: {
                   fontSize:'9px',
                   font: '9pt Trebuchet MS, Verdana, sans-serif',
                   color: '#A0A0A0'
                },
                itemHoverStyle: {
                   color: '#444'
                },
                itemHiddenStyle: {
                   color: '#444'
                }

            },
            credits: {
                enabled: false
            },
            exporting: {
              enabled: false
            },
            annotationsOptions: {
              enabledButtons: false
            }
      };

      var chart0=new Highcharts.Chart(chartData0);
    }
    $scope.changechart0();
 
/*For Chart on right Side*/    
    $scope.changechart1 = function(dataSet){
      var categories=[];
      var geIsFcst=[];
      var genpactFcst=[];
      var demand=[];
      angular.forEach(dataSet, function(value, key){
        categories.push(value.timePeriod);

        /*Split percent and convert to number*/
        var gEISFCSTtemp=value.gEISFCST.split("%");
        geIsFcst.push(parseInt(gEISFCSTtemp[0]));

        /*Split percent and convert to number*/
        var genpactFCSTtemp=value.genpactFCST.split("%");
        genpactFcst.push(parseInt(genpactFCSTtemp[0]));

        demand.push(parseInt(value.demand));

      })

     // debugger
      var chartData1={
          chart: {
            type:  'column',
            renderTo: 'container1'
          },
          
          title: {
              text: ''
          },
          subtitle: {
              text: ''
          },
          xAxis: {
              categories: categories
          },
          yAxis: [{
              /*min: 0,
              max:45000,*/
              title: {
                  text: ''
              },
              /*labels: {
                    formatter: function () {
                        return  this.axis.defaultLabelFormatter.call(this)+''+'k';
                    }            
                }*/
              },
                /*{
                  min: 0,
                  max:45000,
                  title: {
                      text: ''
                  },
                  /*labels: {
                    formatter: function () {
                        return  this.axis.defaultLabelFormatter.call(this)+''+'k';
                        }            
                  },
                  opposite: true
                  }*/
              ],
          series: [{
           /* yAxis:0,*/
            type:'column',
            color: '#7cb5ec',
             name: ' GE IS FCST',
              data: geIsFcst

          }, {
            /*yAxis:0,*/
            type:'column',
            color: 'black',
             name: 'Genpact FCST',
              data: genpactFcst

          },{
               /* yAxis:1,*/
                type: 'line',
                color:'#006eb9',
                name: 'Demand',
                data: demand

            }],
            legend: {
                itemStyle: {
                   fontSize:'9px',
                   font: '9pt Trebuchet MS, Verdana, sans-serif',
                   color: '#A0A0A0'
                },
                itemHoverStyle: {
                   color: '#444'
                },
                itemHiddenStyle: {
                   color: '#444'
                }

            },
            credits: {
                enabled: false
            },
            exporting: {
              enabled: false
            },
            annotationsOptions: {
              enabledButtons: false
            }
      };

      var chart1=new Highcharts.Chart(chartData1);
    }
    $scope.changechart1();


    }]);
});
  



  

  
    
 



