
insert into T_ACCOUNT (NUMBER, NAME) values ('123456789', 'sanjeev');
insert into T_ACCOUNT (NUMBER, NAME) values ('123456001', 'hemalatha');
insert into T_ACCOUNT (NUMBER, NAME) values ('123456002', 'vijaya lakshmi');
insert into T_ACCOUNT (NUMBER, NAME) values ('123456003', 'uma');
insert into T_ACCOUNT (NUMBER, NAME) values ('123456004', 'shashikala');
insert into T_ACCOUNT (NUMBER, NAME) values ('123456005', 'yashaswi reddy');
insert into T_ACCOUNT (NUMBER, NAME) values ('123456006', 'Sunny');
insert into T_ACCOUNT (NUMBER, NAME) values ('123456007', 'Ramu');
insert into T_ACCOUNT (NUMBER, NAME) values ('123456008', 'Pradeep');