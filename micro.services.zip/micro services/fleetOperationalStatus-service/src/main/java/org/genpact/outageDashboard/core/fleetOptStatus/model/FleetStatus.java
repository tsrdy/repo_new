package org.genpact.outageDashboard.core.fleetOptStatus.model;

/**
 * Created by Rajesh on 2-Sep-15
 */

public class FleetStatus {

	private String technology;
	private String equipmentCode;
	private int inServiceCount;
	private int installCount;
	private int releaseCount;
	private int totalCount;
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getEquipmentCode() {
		return equipmentCode;
	}
	public void setEquipmentCode(String equipmentCode) {
		this.equipmentCode = equipmentCode;
	}
	public int getInServiceCount() {
		return inServiceCount;
	}
	public void setInServiceCount(int inServiceCount) {
		this.inServiceCount = inServiceCount;
	}
	public int getInstallCount() {
		return installCount;
	}
	public void setInstallCount(int installCount) {
		this.installCount = installCount;
	}
	public int getReleaseCount() {
		return releaseCount;
	}
	public void setReleaseCount(int releaseCount) {
		this.releaseCount = releaseCount;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	
	
	public FleetStatus(String technology, String equipmentCode, int inServiceCount, int installCount, int releaseCount,
			int totalCount) {
		super();
		this.technology = technology;
		this.equipmentCode = equipmentCode;
		this.inServiceCount = inServiceCount;
		this.installCount = installCount;
		this.releaseCount = releaseCount;
		this.totalCount = totalCount;
	}
	public FleetStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	

	
	
	
}
