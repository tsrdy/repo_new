package org.genpact.outageDashboard.core.fleetOptStatus.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;



public class FleeetStatusDAOImpl {
	
	
public List<FleetStatus> fetchFleetStatusData(JdbcTemplate jdbcTemplate,String eventId){
		
		String sql = "select N_EVENT_ID,C_GIB_SERIAL_NUMBER,C_SOURCE_EVENT_TYPE,C_SOURCE_EVENT_ID,C_SOURCE_EVENT_STATUS from ts_app_005_event_master where C_SOURCE_EVENT_STATUS='OTR Program Creation'";
		/*StringBuffer sql = new StringBuffer("select N_EVENT_ID,C_GIB_SERIAL_NUMBER,C_SOURCE_EVENT_TYPE,C_SOURCE_EVENT_ID,C_SOURCE_EVENT_STATUS from ts_app_005_event_master");
		sql.append("where C_SOURCE_EVENT_STATUS=");
		sql.append("'OTR Program Creation'");*/
		
		
		
		List<FleetStatus> fleetStatusList = jdbcTemplate.query(sql.toString(),new RowMapper<FleetStatus>(){
			//@Override
			 public FleetStatus mapRow(ResultSet resultSet, int line) throws SQLException{
			  
				 FleetStatus event = new FleetStatus();
				
				
				return event;
			  //return userExtractor.extractData(resultSet);
			 }
		});
		
		return fleetStatusList;
		
		/*List<Event> events = new ArrayList<Event>();
		
		List<Map<String,Object>> rows = jdbcTemplate.queryForList(sql.toString());
		for (Map<String,Object> row : rows) {
			Event event = new Event();
			BigDecimal bigId = (BigDecimal)row.get("N_EVENT_ID");
			Integer eventInt = bigId.intValue();
			
			event.setEventId(eventInt);
			event.setC_GIB_SERIAL_NUMBER((String)row.get("C_GIB_SERIAL_NUMBER"));
			event.setC_SOURCE_EVENT_TYPE((String)row.get("C_SOURCE_EVENT_TYPE"));
			event.setC_SOURCE_EVENT_ID((String)row.get("C_SOURCE_EVENT_ID"));
			event.setC_SOURCE_EVENT_STATUS((String)row.get("C_SOURCE_EVENT_STATUS"));
			events.add(event);
		}
		
		
		return events;*/
	}

}
