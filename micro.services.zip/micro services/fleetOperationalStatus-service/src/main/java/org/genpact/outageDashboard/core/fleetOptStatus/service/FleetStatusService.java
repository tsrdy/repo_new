package org.genpact.outageDashboard.core.fleetOptStatus.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.outageDashboard.core.fleetOptStatus.model.FleetStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 3-Sep-15
 */

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController

public class FleetStatusService {

	private static final Logger LOG = LoggerFactory.getLogger(FleetStatusService.class);

	
	/**
     * 
     * @param ssoID,timePeriod
     * @return
     */
    
    @RequestMapping("/fleetStatus/{ssoID}")
    public List<FleetStatus> getFleetStatus(@PathVariable int ssoID){
    	
    	/*ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("context.xml");
    	//DataSource dataSource = (DataSource)ctx.getBean("dataSource");
    	
    	JdbcTemplate jdbcTemplate = (JdbcTemplate)ctx.getBean("jdbcTemplate");*/
		
    	List<FleetStatus> objList = new ArrayList<FleetStatus>();
    	
    	objList.add(new FleetStatus("Aero Gas Turbine", "LM25C", 8, 0, 2, 10));
    	
    	objList.add(new FleetStatus("Aero Gas Turbine",	"LM25C+",2,	0,	0,	2));
    	objList.add(new FleetStatus("Aero Gas Turbine",	"LM6M",	4,	0,	1,	5));
    	objList.add(new FleetStatus("Aero Gas Turbine",	"PGT25+G4",	28,	18,	0,	46));
    	objList.add(new FleetStatus("Axial Compressor",	"AN",	8,	0,	0,	8));
    	objList.add(new FleetStatus("Centrifugal Compressor",	"2BCL",	21,	18,	0,	39));
    	objList.add(new FleetStatus("Centrifugal Compressor",	"2MCL",	2,	0,	0,	2));
    	objList.add(new FleetStatus("Centrifugal Compressor",	"3BCL",	1,1,	0,	2));
    	objList.add(new FleetStatus("Centrifugal Compressor",	"3MCL",	20,	7,	0,	27));
    	objList.add(new FleetStatus("Centrifugal Compressor",	"BCL",	9,	5,	0,	14));
    	objList.add(new FleetStatus("Centrifugal Compressor",	"DMCL",	0,	4,	0,	4));
    	objList.add(new FleetStatus("Centrifugal Compressor",	"MCL",	19,	19,	0,	38));
    	objList.add(new FleetStatus("Generator	BDAX", "9",	0,	5,	0,	5));
    	objList.add(new FleetStatus("HD Gas Turbine",	"32J",	5,	0,	0,	5));
    	objList.add(new FleetStatus("HD Gas Turbine",	"51P",	8,	0,	0,	8));
    	objList.add(new FleetStatus("HD Gas Turbine",	"51PA",	8,	0,	0,	8));
    	objList.add(new FleetStatus("HD Gas Turbine",	"52C",	5,	0,	0,	5));
    	objList.add(new FleetStatus("HD Gas Turbine",	"52C+",	12,	0,	0,	12));

    	
    	return objList;
    	
    	
    	
    }

}
