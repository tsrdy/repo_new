package org.genpact.outageDashboard.core.OFView.model;

/**
 * Created by Rajesh on 2-Sep-15
 */

public class OutageForecastSummary {

	private int siteCount;
	private int eventCount;
	
	public OutageForecastSummary(){
		
		
	}
	
	public OutageForecastSummary(int siteCount, int eventCount) {
		this.siteCount = siteCount;
		this.eventCount = eventCount;
	}
	
	

	public int getSiteCount() {
		return siteCount;
	}

	public void setSiteCount(int siteCount) {
		this.siteCount = siteCount;
	}

	public int getEventCount() {
		return eventCount;
	}

	public void setEventCount(int eventCount) {
		this.eventCount = eventCount;
	}
	
	
	
	
}
