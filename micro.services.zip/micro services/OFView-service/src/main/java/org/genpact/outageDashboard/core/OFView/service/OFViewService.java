package org.genpact.outageDashboard.core.OFView.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.outageDashboard.core.OFView.model.OutageForecastSummary;
import org.genpact.outageDashboard.core.OFView.model.OutageForecastSummaryDaoImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 2-Sep-15
 */

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController

public class OFViewService {

	private static final Logger LOG = LoggerFactory.getLogger(OFViewService.class);

	/**
	 * 
	 * @param ssoID,timePeriod
	 * @return
	 */

	@RequestMapping("/ofView/{ssoID}/{timePeriod}")
	public OutageForecastSummary getOFSummary(@PathVariable int ssoID, @PathVariable String timePeriod) {

		 /*ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("context.xml");
			DataSource dataSource = (DataSource)ctx.getBean("dataSource");
			
			JdbcTemplate jdbcTemplate = (JdbcTemplate)ctx.getBean("jdbcTemplate");
			
		OutageForecastSummary objOutageForecastSummary = new OutageForecastSummary();
		
		OutageForecastSummaryDaoImpl outageForecastSummaryDaoImpl = new OutageForecastSummaryDaoImpl();

		if (timePeriod.equals("1")) {
		
			objOutageForecastSummary = outageForecastSummaryDaoImpl.fetchOutageForeCastData(jdbcTemplate,timePeriod);

		} else if (timePeriod.equals("2")) {
			objOutageForecastSummary = outageForecastSummaryDaoImpl.fetchOutageForeCastData(jdbcTemplate,timePeriod);
		} else if (timePeriod.equals("3")) {
			objOutageForecastSummary = outageForecastSummaryDaoImpl.fetchOutageForeCastData(jdbcTemplate,timePeriod);

		}

		return objOutageForecastSummary;*/
		
		OutageForecastSummary objOutageForecastSummary = new OutageForecastSummary();

		if (timePeriod.equals("1")) {
			objOutageForecastSummary.setSiteCount(67);
			objOutageForecastSummary.setEventCount(78);

		} else if (timePeriod.equals("2")) {
			objOutageForecastSummary.setSiteCount(23);
			objOutageForecastSummary.setEventCount(67);

		} else if (timePeriod.equals("3")) {
			objOutageForecastSummary.setSiteCount(37);
			objOutageForecastSummary.setEventCount(89);

		}

		return objOutageForecastSummary;

	}

}
