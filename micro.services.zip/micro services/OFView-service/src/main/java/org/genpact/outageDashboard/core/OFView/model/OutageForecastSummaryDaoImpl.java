package org.genpact.outageDashboard.core.OFView.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

public class OutageForecastSummaryDaoImpl {

	public OutageForecastSummary fetchOutageForeCastData(JdbcTemplate jdbcTemplate,String timePeriod){
		
		
		OutageForecastSummary outageForecastSummaryObj=null;
		
		StringBuffer sql1 = new StringBuffer("select count(n_site_otg_id) OUTAGES_COUNT from ts_cfg_032_user_sn ts_cfg_032,ts_app_005_event_master ta05,ts_app_038_oe_otg_events ts_app_038");
		sql1.append(" ");
		sql1.append("where ts_cfg_032.c_sso = 'ibas_read' and ts_cfg_032.c_gib_serial_number  = ta05.c_gib_serial_number and ta05.n_event_id = ts_app_038.n_event_id");
		sql1.append(" ");
		sql1.append("and ta05.d_event_date between trunc(sysdate) and add_months(trunc(sysdate, 'MM'), 6)");
		sql1.append(" ");
		sql1.append("UNION ALL");
		sql1.append(" ");
		sql1.append("select count(n_event_id) from ts_cfg_032_user_sn ts_cfg_032,ts_app_005_event_master ta05");
		sql1.append(" ");
		sql1.append("where ts_cfg_032.c_sso = 'ibas_read'and ts_cfg_032.c_gib_serial_number  = ta05.c_gib_serial_number and ta05.d_event_date between trunc(sysdate) and");
		sql1.append(" ");
		sql1.append("add_months(trunc(sysdate, 'MM'), 6)");
		
		
		StringBuffer sql2 = new StringBuffer("select count(n_site_otg_id) OUTAGES_COUNT from ts_cfg_032_user_sn ts_cfg_032,ts_app_005_event_master     ta05,ts_app_038_oe_otg_events ts_app_038");
		sql2.append(" ");
		sql2.append("where ts_cfg_032.c_sso = 'ibas_read' and ts_cfg_032.c_gib_serial_number  = ta05.c_gib_serial_number and ta05.n_event_id = ts_app_038.n_event_id");
		sql2.append(" ");
		sql2.append("and ta05.d_event_date between add_months(add_months(trunc(sysdate, 'MM'), 6),0) and add_months(add_months(trunc(sysdate, 'MM'), 6),6) ");
		sql2.append(" ");
		sql2.append("UNION ALL");
		sql2.append(" ");
		sql2.append("select count(n_event_id) from ts_cfg_032_user_sn ts_cfg_032,ts_app_005_event_master     ta05");
		sql2.append(" ");
		sql2.append("where ts_cfg_032.c_sso = 'ibas_read' and ts_cfg_032.c_gib_serial_number  = ta05.c_gib_serial_number and ta05.d_event_date between ");
		sql2.append(" ");
		sql2.append("add_months(add_months(trunc(sysdate, 'MM'), 6),0) and add_months(add_months(trunc(sysdate, 'MM'), 6),6)");
		
		
		StringBuffer sql3 = new StringBuffer("select count(n_site_otg_id) OUTAGES_COUNT from ts_cfg_032_user_sn ts_cfg_032,ts_app_005_event_master ta05,ts_app_038_oe_otg_events ts_app_038");
		sql3.append(" ");
		sql3.append("where ts_cfg_032.c_sso = 'ibas_read' and ts_cfg_032.c_gib_serial_number  = ta05.c_gib_serial_number and ta05.n_event_id = ts_app_038.n_event_id");
		sql3.append(" ");
		sql3.append("and ta05.d_event_date between add_months(add_months(trunc(sysdate, 'MM'), 6),0) and add_months(add_months(trunc(sysdate, 'MM'), 6),6) ");
		sql3.append(" ");
		sql3.append("UNION ALL");
		sql3.append(" ");
		sql3.append("select count(n_event_id) from ts_cfg_032_user_sn ts_cfg_032,ts_app_005_event_master     ta05");
		sql3.append(" ");
		sql3.append("where ts_cfg_032.c_sso = 'ibas_read' and ts_cfg_032.c_gib_serial_number  = ta05.c_gib_serial_number");
		sql3.append(" ");
		sql3.append("and ta05.d_event_date > add_months(trunc(sysdate, 'MM'), 12)");
		
		
		
		if(timePeriod.equals("1")){
			outageForecastSummaryObj = new OutageForecastSummary();
			List<Map<String,Object>> dataList = jdbcTemplate.queryForList(sql1.toString());
			
			for(int i=0;i<dataList.size();i++){
				Map row = dataList.get(i);
				if(i==0){
					BigDecimal bigId = (BigDecimal)row.get("OUTAGES_COUNT");
					Integer siteInt = bigId.intValue();
					
					//event.setEventId(eventInt);
					outageForecastSummaryObj.setSiteCount(siteInt);
			}else{
				BigDecimal bigId = (BigDecimal)row.get("OUTAGES_COUNT");
				Integer eventInt = bigId.intValue();
				
				outageForecastSummaryObj.setEventCount(eventInt);
			}
				
			
		}	
		}else if(timePeriod.equals("2")){
			outageForecastSummaryObj = new OutageForecastSummary();
			List<Map<String,Object>> dataList = jdbcTemplate.queryForList(sql2.toString());
			
			for(int i=0;i<dataList.size();i++){
				Map row = dataList.get(i);
				if(i==0){
					BigDecimal bigId = (BigDecimal)row.get("OUTAGES_COUNT");
					Integer siteInt = bigId.intValue();
					
					//event.setEventId(eventInt);
					outageForecastSummaryObj.setSiteCount(siteInt);
			}else{
				BigDecimal bigId = (BigDecimal)row.get("OUTAGES_COUNT");
				Integer eventInt = bigId.intValue();
				
				outageForecastSummaryObj.setEventCount(eventInt);
			}
				
			
		}
			
		}else if(timePeriod.equals("3")){
			
			outageForecastSummaryObj = new OutageForecastSummary();
			List<Map<String,Object>> dataList = jdbcTemplate.queryForList(sql3.toString());
			
			for(int i=0;i<dataList.size();i++){
				Map row = dataList.get(i);
				if(i==0){
					BigDecimal bigId = (BigDecimal)row.get("OUTAGES_COUNT");
					Integer siteInt = bigId.intValue();
					
					//event.setEventId(eventInt);
					outageForecastSummaryObj.setSiteCount(siteInt);
			}else{
				BigDecimal bigId = (BigDecimal)row.get("OUTAGES_COUNT");
				Integer eventInt = bigId.intValue();
				
				outageForecastSummaryObj.setEventCount(eventInt);
			}
				
			
		}
			
		}
		return outageForecastSummaryObj;
		
		
	}
}
