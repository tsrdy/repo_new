package com.genpact.microservice.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.microservice.service.model.EnginesDetailBean;


@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class EnginesDataService {

	
	 @RequestMapping("/")
	    public String  getRefreshedData(){
		 
		 long numbervalue = (long)(Math.round(Math.random() * 99));
		 String data ="Hello new Number"+numbervalue;
		 return data;
	 }
	
	 
	 @RequestMapping("/enginesDetail/{ssoId}")
public List<EnginesDetailBean> fetchAvailableEngines(@PathVariable int ssoId){
		 
		 List<EnginesDetailBean> listObject = new ArrayList<EnginesDetailBean>();
		 
		 EnginesDetailBean bean1 = new EnginesDetailBean("ANKARA_812402",795687);
		 listObject.add(bean1);
		 
		 EnginesDetailBean bean2 = new EnginesDetailBean("KATZA_812418",795688);
		 listObject.add(bean2);
		 
		 EnginesDetailBean bean3 = new EnginesDetailBean("BANGPA_821124",795695);
		 listObject.add(bean3);
		 
		 EnginesDetailBean bean4 = new EnginesDetailBean("MINERA_820598",795710);
		 listObject.add(bean4);
		 
		 EnginesDetailBean bean5 = new EnginesDetailBean("BRITISH_808499",795734);
		 listObject.add(bean5);
		 
		 EnginesDetailBean bean6 = new EnginesDetailBean("MCKEE_821164",795739);
		 listObject.add(bean6);
		 
		 EnginesDetailBean bean7 = new EnginesDetailBean("LANSING_821330",795743);
		 listObject.add(bean7);
		 
		 EnginesDetailBean bean8 = new EnginesDetailBean("LANXESS_820221",795745);
		 listObject.add(bean8);
		 
		 EnginesDetailBean bean9 = new EnginesDetailBean("ALTO_820089",795758);
		 listObject.add(bean9);
		 
		 EnginesDetailBean bean10 = new EnginesDetailBean("NESHER_820172",795806);
		 listObject.add(bean10);
		 
		 EnginesDetailBean bean11 = new EnginesDetailBean("TEKIRDAG_820408",796014);
		 listObject.add(bean11);
		 
		 return listObject;
		 
	 }
}
