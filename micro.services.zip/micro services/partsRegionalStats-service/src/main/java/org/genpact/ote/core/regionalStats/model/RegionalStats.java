package org.genpact.ote.core.regionalStats.model;

public class RegionalStats {

	private double entitlement;;
	private double  wedMarketShare;
	private String  wedMarketSharePercent;
	private String  oermMarketSharePercent;
	private String  willFitterMarketSharePercent;
	private String  remanMarketSharePercent;
	
	public double getEntitlement() {
		return entitlement;
	}
	public void setEntitlement(double entitlement) {
		this.entitlement = entitlement;
	}
	public double getWedMarketShare() {
		return wedMarketShare;
	}
	public void setWedMarketShare(double wedMarketShare) {
		this.wedMarketShare = wedMarketShare;
	}
	public String getWedMarketSharePercent() {
		return wedMarketSharePercent;
	}
	public void setWedMarketSharePercent(String wedMarketSharePercent) {
		this.wedMarketSharePercent = wedMarketSharePercent;
	}
	public String getOermMarketSharePercent() {
		return oermMarketSharePercent;
	}
	public void setOermMarketSharePercent(String oermMarketSharePercent) {
		this.oermMarketSharePercent = oermMarketSharePercent;
	}
	public String getWillFitterMarketSharePercent() {
		return willFitterMarketSharePercent;
	}
	public void setWillFitterMarketSharePercent(String willFitterMarketSharePercent) {
		this.willFitterMarketSharePercent = willFitterMarketSharePercent;
	}
	public String getRemanMarketSharePercent() {
		return remanMarketSharePercent;
	}
	public void setRemanMarketSharePercent(String remanMarketSharePercent) {
		this.remanMarketSharePercent = remanMarketSharePercent;
	}
	
	public RegionalStats(double entitlement, double wedMarketShare, String wedMarketSharePercent,
			String oermMarketSharePercent, String willFitterMarketSharePercent, String remanMarketSharePercent) {
		super();
		this.entitlement = entitlement;
		this.wedMarketShare = wedMarketShare;
		this.wedMarketSharePercent = wedMarketSharePercent;
		this.oermMarketSharePercent = oermMarketSharePercent;
		this.willFitterMarketSharePercent = willFitterMarketSharePercent;
		this.remanMarketSharePercent = remanMarketSharePercent;
	}

	
	
	
}
