package org.genpact.ote.core.regionalStats.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.ote.core.regionalStats.model.RegionalStats;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 22-Sep-15
 */

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class RegionalStatsService {
	
	private static final Logger LOG = LoggerFactory.getLogger(RegionalStatsService.class);

	 @RequestMapping("/regionalStats/")    
	    public RegionalStats  getRegionalStats(){
		 
		 RegionalStats objRegionalStats = new RegionalStats(6.25, 3.37, "54%", "4%", "24%", "18%");
		 
		return objRegionalStats;
	 }
	

}
