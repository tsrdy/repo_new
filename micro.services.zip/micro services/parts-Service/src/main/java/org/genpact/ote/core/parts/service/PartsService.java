package org.genpact.ote.core.parts.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.ote.core.parts.model.PartsModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 18-Sep-15wedx
 */

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class PartsService {
	
	
private static final Logger LOG = LoggerFactory.getLogger(PartsModel.class);

    
    @RequestMapping("/top20Parts/")    
    public List<PartsModel>  getTop20Parts(){
		 
    	
		 		List<PartsModel> listObject = new ArrayList<PartsModel>();

    			PartsModel  objPartsModel1 =new PartsModel("168290B","bushing/bearing","550%","239%","536%");
    			PartsModel  objPartsModel2 =new PartsModel("G-918-320","bushing/bearing","175%","20%","0%");
    			PartsModel  objPartsModel3 =new PartsModel("A205210","bushing/bearing","169%","169%","332%");
    			PartsModel  objPartsModel4 =new PartsModel("168922P","seal ring","160%","635%","1209%");
    			PartsModel  objPartsModel5 =new PartsModel("208434F","bushing/bearing","121%","36%","656%");
    			PartsModel  objPartsModel6 =new PartsModel("A211820","rockers/lifters","111%","58%","98%");
    			PartsModel  objPartsModel7 =new PartsModel("493026","seal ring","89%","80%","74%");
    			PartsModel  objPartsModel8 =new PartsModel("161339","bushing/bearing","84%","36%","202%");
    			PartsModel  objPartsModel9 =new PartsModel("208434G","bushing/bearing","75%","24%","394%");
    			PartsModel  objPartsModel10 =new PartsModel("211887A","thermostat","68%","6%","480%");
    			PartsModel  objPartsModel11 =new PartsModel("78391","bushing/bearing","49%","81%","171%");
    			PartsModel  objPartsModel12 =new PartsModel("69694G","electronic/control","47%","13%","0%");
    			PartsModel  objPartsModel13 =new PartsModel("G-918-344","bushing/bearing","45%","65%","75%");
    			PartsModel  objPartsModel14 =new PartsModel("296178","seal ring","42%","41%","62%");
    			PartsModel  objPartsModel15 =new PartsModel("69919D","sparkplug","36%","48%","40%");
    			PartsModel  objPartsModel16 =new PartsModel("145029A","bushing/bearing","35%","25%","27%");
    			PartsModel  objPartsModel17 =new PartsModel("304889B","damper","34%","0%","0%");
    			PartsModel  objPartsModel18 =new PartsModel("168922M","seal ring","32%","101%","126%");
    			PartsModel  objPartsModel19 =new PartsModel("305169","bushing/bearing","28%","0%","25%");
    			PartsModel  objPartsModel20 =new PartsModel("305169B","bushing/bearing","28%","0%","26%");
    			PartsModel  objPartsModel21 =new PartsModel("208349","air filter","27%","0%","26%");
    			PartsModel  objPartsModel22 =new PartsModel("153063E","gears/spindles","26%","21%","9%");
    			PartsModel  objPartsModel23 =new PartsModel("489605","oil filter","22%","24%","0%");
    			PartsModel  objPartsModel24 =new PartsModel("A209617","belts/hoses","21%","15%","25%");
    			PartsModel  objPartsModel25 =new PartsModel("169180L","air filter","21%","11%","0%");
    			
    			listObject.add(objPartsModel1);
    			listObject.add(objPartsModel2);
    			listObject.add(objPartsModel3);
    			listObject.add(objPartsModel4);
    			listObject.add(objPartsModel5);
    			listObject.add(objPartsModel6);
    			listObject.add(objPartsModel7);
    			listObject.add(objPartsModel8);
    			listObject.add(objPartsModel9);
    			listObject.add(objPartsModel10);
    			listObject.add(objPartsModel11);
    			listObject.add(objPartsModel12);
    			listObject.add(objPartsModel13);
    			listObject.add(objPartsModel14);
    			listObject.add(objPartsModel15);
    			listObject.add(objPartsModel16);
    			listObject.add(objPartsModel17);
    			listObject.add(objPartsModel18);
    			listObject.add(objPartsModel19);
    			listObject.add(objPartsModel20);
    			listObject.add(objPartsModel21);
    			listObject.add(objPartsModel22);
    			listObject.add(objPartsModel23);
    			listObject.add(objPartsModel24);
    			listObject.add(objPartsModel25);

    			return listObject;

	 }
    
    @RequestMapping("/bottom20Parts/")    
    public List<PartsModel>  bottom20Parts(){
    	
    	
    	List<PartsModel> bottom20PartsList = new ArrayList<PartsModel>();
    	
    	PartsModel  objPartsModel1=new PartsModel("G-960-298","water pump","0%","0%","78%");
    	PartsModel  objPartsModel2=new PartsModel("496909","thermostat","0%","0%","0%");
    	PartsModel  objPartsModel3=new PartsModel("496904","thermostat","0%","0%","0%");
    	PartsModel  objPartsModel4=new PartsModel("489459","thermostat","0%","133%","68%");
    	PartsModel  objPartsModel5=new PartsModel("295827D","seal ring","0%","0%","0%");
    	PartsModel  objPartsModel6=new PartsModel("290230A","seal ring","0%","41%","46%");
    	PartsModel  objPartsModel7=new PartsModel("290221B","seal ring","0%","0%","0%");
    	PartsModel  objPartsModel8=new PartsModel("C296140D","reg valve other","0%","0%","0%");
    	PartsModel  objPartsModel9=new PartsModel("C296078G","reg valve other","0%","632%","255%");
    	PartsModel  objPartsModel10=new PartsModel("C296078E","reg valve other","0%","82%","20%");
    	PartsModel  objPartsModel11=new PartsModel("A296140E","reg valve other","0%","0%","104%");
    	PartsModel  objPartsModel12=new PartsModel("A296078G","reg valve other","0%","966%","185%");
    	PartsModel  objPartsModel13=new PartsModel("A296078F","reg valve other","0%","0%","0%");
    	PartsModel  objPartsModel14=new PartsModel("A296078E","reg valve other","0%","26%","79%");
    	PartsModel  objPartsModel15=new PartsModel("G-980-170","oil pump","0%","0%","0%");
    	PartsModel  objPartsModel16=new PartsModel("G-980-165","oil pump","0%","0%","0%");
    	PartsModel  objPartsModel17=new PartsModel("G-980-159","oil pump","0%","0%","32%");
    	PartsModel  objPartsModel18=new PartsModel("G-980-157","oil pump","0%","0%","0%");
    	PartsModel  objPartsModel19=new PartsModel("G-979-295","gasket","0%","0%","0%");
    	PartsModel  objPartsModel20=new PartsModel("G-979-284","gasket","0%","0%","0%");
    	PartsModel  objPartsModel21=new PartsModel("G-979-278","gasket","0%","15%","0%");
    	PartsModel  objPartsModel22=new PartsModel("G-900-1061","gasket","0%","0%","0%");
    	PartsModel  objPartsModel23=new PartsModel("G-900-1052","gasket","0%","40%","0%");
    	PartsModel  objPartsModel24=new PartsModel("G-900-1039","gasket","0%","39%","29%");
    	PartsModel  objPartsModel25=new PartsModel("287000","gasket","0%","113%","0%");
    	PartsModel  objPartsModel26=new PartsModel("E740400","electronic/control","0%","96%","0%");
    	
		bottom20PartsList.add(objPartsModel1);
		bottom20PartsList.add(objPartsModel2);
		bottom20PartsList.add(objPartsModel3);
		bottom20PartsList.add(objPartsModel4);
		bottom20PartsList.add(objPartsModel5);
		bottom20PartsList.add(objPartsModel6);
		bottom20PartsList.add(objPartsModel7);
		bottom20PartsList.add(objPartsModel8);
		bottom20PartsList.add(objPartsModel9);
		bottom20PartsList.add(objPartsModel10);
		bottom20PartsList.add(objPartsModel11);
		bottom20PartsList.add(objPartsModel12);
		bottom20PartsList.add(objPartsModel13);
		bottom20PartsList.add(objPartsModel14);
		bottom20PartsList.add(objPartsModel15);
		bottom20PartsList.add(objPartsModel16);
		bottom20PartsList.add(objPartsModel17);
		bottom20PartsList.add(objPartsModel18);
		bottom20PartsList.add(objPartsModel19);
		bottom20PartsList.add(objPartsModel20);
		bottom20PartsList.add(objPartsModel21);
		bottom20PartsList.add(objPartsModel22);
		bottom20PartsList.add(objPartsModel23);
		bottom20PartsList.add(objPartsModel24);
		bottom20PartsList.add(objPartsModel25);

		return bottom20PartsList;


    	
    }
    }
    


