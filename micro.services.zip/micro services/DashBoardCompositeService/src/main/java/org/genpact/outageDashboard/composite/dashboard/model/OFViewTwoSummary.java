package org.genpact.outageDashboard.composite.dashboard.model;

public class OFViewTwoSummary {

}
