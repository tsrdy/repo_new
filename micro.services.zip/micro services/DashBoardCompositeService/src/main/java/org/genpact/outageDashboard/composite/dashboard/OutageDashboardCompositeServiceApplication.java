package org.genpact.outageDashboard.composite.dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class OutageDashboardCompositeServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OutageDashboardCompositeServiceApplication.class, args);
    }
}
