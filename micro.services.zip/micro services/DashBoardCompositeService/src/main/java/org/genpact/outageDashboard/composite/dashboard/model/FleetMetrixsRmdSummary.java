package org.genpact.outageDashboard.composite.dashboard.model;

public class FleetMetrixsRmdSummary {

	private String type;
	private int wholeFleet;
	private int yourFleet;
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getWholeFleet() {
		return wholeFleet;
	}
	public void setWholeFleet(int wholeFleet) {
		this.wholeFleet = wholeFleet;
	}
	public int getYourFleet() {
		return yourFleet;
	}
	public void setYourFleet(int yourFleet) {
		this.yourFleet = yourFleet;
	}
	public FleetMetrixsRmdSummary(String type, int wholeFleet, int yourFleet) {
		super();
		this.type = type;
		this.wholeFleet = wholeFleet;
		this.yourFleet = yourFleet;
	}
	
	
}
