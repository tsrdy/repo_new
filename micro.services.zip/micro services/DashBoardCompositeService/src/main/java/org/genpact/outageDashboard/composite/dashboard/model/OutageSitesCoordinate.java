package org.genpact.outageDashboard.composite.dashboard.model;

public class OutageSitesCoordinate {

	private String siteDuns;
	private double siteLatitude;
	private double siteLongtitude;
	private String siteIcon;
	private int siteStatus;
	private String siteName;
	private String siteCustomer;
	private String siteCity;
	private String siteCountry;
	private String statusDesc;
	private String siteMap;
	public String getSiteDuns() {
		return siteDuns;
	}
	public void setSiteDuns(String siteDuns) {
		this.siteDuns = siteDuns;
	}
	public double getSiteLatitude() {
		return siteLatitude;
	}
	public void setSiteLatitude(double siteLatitude) {
		this.siteLatitude = siteLatitude;
	}
	public double getSiteLongtitude() {
		return siteLongtitude;
	}
	public void setSiteLongtitude(double siteLongtitude) {
		this.siteLongtitude = siteLongtitude;
	}
	public String getSiteIcon() {
		return siteIcon;
	}
	public void setSiteIcon(String siteIcon) {
		this.siteIcon = siteIcon;
	}
	public int getSiteStatus() {
		return siteStatus;
	}
	public void setSiteStatus(int siteStatus) {
		this.siteStatus = siteStatus;
	}
	public String getSiteName() {
		return siteName;
	}
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}
	public String getSiteCustomer() {
		return siteCustomer;
	}
	public void setSiteCustomer(String siteCustomer) {
		this.siteCustomer = siteCustomer;
	}
	public String getSiteCity() {
		return siteCity;
	}
	public void setSiteCity(String siteCity) {
		this.siteCity = siteCity;
	}
	public String getSiteCountry() {
		return siteCountry;
	}
	public void setSiteCountry(String siteCountry) {
		this.siteCountry = siteCountry;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getSiteMap() {
		return siteMap;
	}
	public void setSiteMap(String siteMap) {
		this.siteMap = siteMap;
	}
	
	
	
	
}
