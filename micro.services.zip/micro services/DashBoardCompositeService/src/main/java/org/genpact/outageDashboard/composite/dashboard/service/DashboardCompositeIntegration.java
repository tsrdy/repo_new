package org.genpact.outageDashboard.composite.dashboard.service;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.genpact.outageDashboard.composite.dashboard.model.EnginesDetailBean;
import org.genpact.outageDashboard.composite.dashboard.model.FleetMetrixsRmdSummary;
import org.genpact.outageDashboard.composite.dashboard.model.FleetOperationalStatus;
import org.genpact.outageDashboard.composite.dashboard.model.OFViewOneSummary;
import org.genpact.outageDashboard.composite.dashboard.model.OutageSitesCoordinate;
import org.genpact.outageDashboard.composite.dashboard.model.OutageTimingStatus;
import org.genpact.outageDashboard.composite.dashboard.model.OutageTypeSummary;
import org.genpact.outageDashboard.util.ServiceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

/**
 * Created by Rajesh on 3-Sep-15
 */
@Component
@ComponentScan("org.genpact.outageDashboard.util")
public class DashboardCompositeIntegration {

	private static final Logger LOG = LoggerFactory.getLogger(DashboardCompositeIntegration.class);

	@Autowired
	private LoadBalancerClient loadBalancer;

	@Autowired(required = true)
	ServiceUtils util;

	private RestTemplate restTemplate = new RestTemplate();

	private ObjectReader oFViewOneReader = null;

	public ResponseEntity<OFViewOneSummary> getOFView(String ssoId, String timePeriod) {

		OFViewOneSummary objOFView;

		URI uri = util.getServiceUrl("OUTAGE-FORECAST-SUMMARY-SERVICE");

		String url = uri.toString() + "/ofView/" + ssoId + "/" + timePeriod;

		LOG.info("Get Outage Dashboard from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("GetOFViewOneSummary http-status: {}", resultStr.getStatusCode());
		LOG.info("GetOFViewOneSummary body: {}", resultStr.getBody());

		objOFView = response2OFViewOne(resultStr);

		return util.createOkResponse(objOFView);

	}

	public ResponseEntity<List<FleetOperationalStatus>> getFleetOperationalStatus(String ssoId) {

		List<FleetOperationalStatus> list;

		URI uri = util.getServiceUrl("FLEET-OPERATION-STATUS-SUMMARY-SERVICE");

		String url = uri.toString() + "/fleetStatus/" + ssoId;

		LOG.info("Get Fleet Operational Status from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("Get Fleet Operational Status Summary http-status: {}", resultStr.getStatusCode());
		LOG.info("Get Fleet Operational Status  body: {}", resultStr.getBody());

		list = response2FleetOptStatus(resultStr);

		return util.createOkResponse(list);

	}

	public ResponseEntity<List<OutageTypeSummary>> getOutageType(String ssoId) {

		List<OutageTypeSummary> outageTypeList;
		URI uri = util.getServiceUrl("OUTAGE-TYPE-SERVICE");

		String url = uri.toString() + "/outageType/" + ssoId;

		LOG.info("Get Outage Type from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("Get Fleet Operational Status Summary http-status: {}", resultStr.getStatusCode());
		LOG.info("Get Fleet Operational Status  body: {}", resultStr.getBody());

		outageTypeList = response2OutageType(resultStr);

		return util.createOkResponse(outageTypeList);

	}

	public ResponseEntity<List<OutageSitesCoordinate>> getMapCordinates(String ssoId) {
	
		
		List<OutageSitesCoordinate> objCordinatesList;
		
		URI uri = util.getServiceUrl("MAP-SERVICE");
		String url = uri.toString() + "/oFSitesLoc/" + ssoId;
		
		
		LOG.info("Get Map Coordinates from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("Get  Map Coordinates http-status: {}", resultStr.getStatusCode());
		LOG.info("Get Map Coordinates  body: {}", resultStr.getBody());
	
		objCordinatesList= response2MapList(resultStr);
		
		return util.createOkResponse(objCordinatesList);
		
	}
	
	
	public ResponseEntity<List<OutageTimingStatus>> getTimingStatus(String ssoId) {
		
		List<OutageTimingStatus> objTimingList;
		
		URI uri = util.getServiceUrl("OUTAGE-TIMING-SERVICE");
		String url = uri.toString() + "/outageTimingStatus/" + ssoId;

		LOG.info("Get Outage Timing Status from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("Get  Timing Status http-status: {}", resultStr.getStatusCode());
		LOG.info("Get Timing Status  body: {}", resultStr.getBody());
		
		objTimingList=response2TimingStatusList(resultStr);
				
		return util.createOkResponse(objTimingList);

		
	}
	
	
	public OFViewOneSummary response2OFViewOne(ResponseEntity<String> response) {

		try {
			return getOFViewOneReader().readValue(response.getBody());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private ObjectReader getOFViewOneReader() {

		if (oFViewOneReader != null)
			return oFViewOneReader;

		ObjectMapper mapper = new ObjectMapper();
		return oFViewOneReader = mapper.reader(OFViewOneSummary.class);
	}

	public List<FleetOperationalStatus> response2FleetOptStatus(ResponseEntity<String> response) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			List list = mapper.readValue(response.getBody(), new TypeReference<List<FleetOperationalStatus>>() {
			});
			List<FleetOperationalStatus> fleetOperationalStatus = list;
			return fleetOperationalStatus;

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}

	public List<OutageTypeSummary> response2OutageType(ResponseEntity<String> response) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			List list = mapper.readValue(response.getBody(), new TypeReference<List<OutageTypeSummary>>() {
			});
			List<OutageTypeSummary> outageTypeList = list;
			return outageTypeList;

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}
	
	public List<OutageSitesCoordinate> response2MapList(ResponseEntity<String> response) {
		
		ObjectMapper mapper = new ObjectMapper();
		try {
			List list = mapper.readValue(response.getBody(), new TypeReference<List<OutageSitesCoordinate>>() {
			});
			List<OutageSitesCoordinate> mapList = list;
			return mapList;

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}
	
	
public List<OutageTimingStatus> response2TimingStatusList(ResponseEntity<String> response) {
		
		ObjectMapper mapper = new ObjectMapper();
		try {
			List list = mapper.readValue(response.getBody(), new TypeReference<List<OutageTimingStatus>>() {
			});
			List<OutageTimingStatus> timingList = list;
			return timingList;

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}
	
public List<FleetMetrixsRmdSummary> response2FleetRMDList(ResponseEntity<String> response) {
	
	/*ObjectMapper mapper = new ObjectMapper();
	try {
		List list = mapper.readValue(response.getBody(), new TypeReference<List<OutageTimingStatus>>() {
		});
		List<OutageTimingStatus> timingList = list;
		return timingList;

	} catch (JsonParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (JsonMappingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return null;
*/
	
	List<FleetMetrixsRmdSummary> fleetMetrixsRmdSummaryList = new ArrayList<FleetMetrixsRmdSummary>();
	FleetMetrixsRmdSummary fleetMetrixsRmdSummary1  = new FleetMetrixsRmdSummary("Units",953,200);
	FleetMetrixsRmdSummary fleetMetrixsRmdSummary2  = new FleetMetrixsRmdSummary("Drivers",337,120);
	FleetMetrixsRmdSummary fleetMetrixsRmdSummary3  = new FleetMetrixsRmdSummary("Sites",300,110);
	FleetMetrixsRmdSummary fleetMetrixsRmdSummary4  = new FleetMetrixsRmdSummary("Pre-COD",250,120);
	FleetMetrixsRmdSummary fleetMetrixsRmdSummary5  = new FleetMetrixsRmdSummary("Trips",1200,400);
	
	fleetMetrixsRmdSummaryList.add(fleetMetrixsRmdSummary1);
	fleetMetrixsRmdSummaryList.add(fleetMetrixsRmdSummary2);
	fleetMetrixsRmdSummaryList.add(fleetMetrixsRmdSummary3);
	fleetMetrixsRmdSummaryList.add(fleetMetrixsRmdSummary4);
	fleetMetrixsRmdSummaryList.add(fleetMetrixsRmdSummary5);
	
	return fleetMetrixsRmdSummaryList;
	
}

public List<FleetMetrixsRmdSummary> getfleetMetrixRMDData(String ssoId) {
	
	List<FleetMetrixsRmdSummary> rmdDataList;
	
	URI uri = util.getServiceUrl("OUTAGE-TIMING-SERVICE");
	String url = uri.toString() + "/outageTimingStatus/" + ssoId;

	LOG.info("Get Outage Timing Status from URL: {}", url);

	ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

	LOG.info("Get  Timing Status http-status: {}", resultStr.getStatusCode());
	LOG.info("Get Timing Status  body: {}", resultStr.getBody());
	
	rmdDataList=response2FleetRMDList(resultStr);
			
	//return util.createOkResponse(rmdDataList);
	
	return rmdDataList;

	
}

public List<EnginesDetailBean> getEnginesDetail(String ssoId){
	
	List<EnginesDetailBean> enginesDetailBeanList;
	
	/*URI uri = util.getServiceUrl("ENGINE-DATA-SERVICE");
	String url = uri.toString() + "/enginesDetail/" + ssoId;

	LOG.info("Get Outage Timing Status from URL: {}", url);

	ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

	LOG.info("Get  Timing Status http-status: {}", resultStr.getStatusCode());
	LOG.info("Get Timing Status  body: {}", resultStr.getBody());
	
	enginesDetailBeanList=response2EngineDetailsList(resultStr);*/
			
	//return util.createOkResponse(rmdDataList);
	
	enginesDetailBeanList = response2EngineDetailsList();
	
	return enginesDetailBeanList;
	
}


public List<EnginesDetailBean> response2EngineDetailsList() {

	/*ObjectMapper mapper = new ObjectMapper();
	try {
		List list = mapper.readValue(response.getBody(), new TypeReference<List<EnginesDetailBean>>() {
		});
		List<EnginesDetailBean> enginesDetailList = list;
		return enginesDetailList;

	} catch (JsonParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (JsonMappingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return null;*/
	
	List<EnginesDetailBean> listObject = new ArrayList<EnginesDetailBean>();
	 
	 EnginesDetailBean bean1 = new EnginesDetailBean("ANKARA_812402",795687);
	 listObject.add(bean1);
	 
	 EnginesDetailBean bean2 = new EnginesDetailBean("KATZA_812418",795688);
	 listObject.add(bean2);
	 
	 EnginesDetailBean bean3 = new EnginesDetailBean("BANGPA_821124",795695);
	 listObject.add(bean3);
	 
	 EnginesDetailBean bean4 = new EnginesDetailBean("MINERA_820598",795710);
	 listObject.add(bean4);
	 
	 EnginesDetailBean bean5 = new EnginesDetailBean("BRITISH_808499",795734);
	 listObject.add(bean5);
	 
	 EnginesDetailBean bean6 = new EnginesDetailBean("MCKEE_821164",795739);
	 listObject.add(bean6);
	 
	 EnginesDetailBean bean7 = new EnginesDetailBean("LANSING_821330",795743);
	 listObject.add(bean7);
	 
	 EnginesDetailBean bean8 = new EnginesDetailBean("LANXESS_820221",795745);
	 listObject.add(bean8);
	 
	 EnginesDetailBean bean9 = new EnginesDetailBean("ALTO_820089",795758);
	 listObject.add(bean9);
	 
	 EnginesDetailBean bean10 = new EnginesDetailBean("NESHER_820172",795806);
	 listObject.add(bean10);
	 
	 EnginesDetailBean bean11 = new EnginesDetailBean("TEKIRDAG_820408",796014);
	 listObject.add(bean11);
	 
	 return listObject;
}

}
