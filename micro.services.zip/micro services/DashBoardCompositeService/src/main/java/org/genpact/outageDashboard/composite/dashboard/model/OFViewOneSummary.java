package org.genpact.outageDashboard.composite.dashboard.model;

public class OFViewOneSummary {


	private int siteCount;
	private int eventCount;
	
	
	public int getSiteCount() {
		return siteCount;
	}
	public void setSiteCount(int siteCount) {
		this.siteCount = siteCount;
	}
	public int getEventCount() {
		return eventCount;
	}
	public void setEventCount(int eventCount) {
		this.eventCount = eventCount;
	}
	
	
}
