package org.genpact.outageDashboard.composite.dashboard.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.outageDashboard.composite.dashboard.model.DashboardDataAggregated;
import org.genpact.outageDashboard.composite.dashboard.model.EnginesDetailBean;
import org.genpact.outageDashboard.composite.dashboard.model.FleetMetrixsRmdSummary;
import org.genpact.outageDashboard.composite.dashboard.model.FleetOperationalStatus;
import org.genpact.outageDashboard.composite.dashboard.model.OFViewOneSummary;
import org.genpact.outageDashboard.composite.dashboard.model.OutageSitesCoordinate;
import org.genpact.outageDashboard.composite.dashboard.model.OutageTimingStatus;
import org.genpact.outageDashboard.composite.dashboard.model.OutageTypeSummary;
import org.genpact.outageDashboard.util.ServiceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




/**
 * Created by Rajesh on 9-Sep-15
 */

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class DashboardCompositeService {
	
    private static final Logger LOG = LoggerFactory.getLogger(DashboardCompositeService.class);

    
    @Autowired
    DashboardCompositeIntegration integration;
    
    @Autowired
    ServiceUtils util;
    
    /*@RequestMapping("/")
    public String getOutageDashboard() {
        return "{\"timestamp\":\"" + new Date() + "\",\"content\":\"Hello\"}";
    }*/
    
    private List<FleetOperationalStatus> fleetOperationalStatusList;
    
    
    @RequestMapping("/")
    public ResponseEntity<DashboardDataAggregated> getOFOneView() {
		
    	String ssoId="501211111";
    	 // 1. Get OF First View
       // ResponseEntity<OFViewOneSummary> oFViewOneResult = integration.getOFView(ssoId,"1");
        ResponseEntity<OFViewOneSummary>  oFViewOneResult = integration.getOFView(ssoId,"1");
        
    	OFViewOneSummary objOFViewOne=oFViewOneResult.getBody();

        
        if (!oFViewOneResult.getStatusCode().is2xxSuccessful()) {
            // We can't proceed, return whatever fault we got from the getProduct call
            return util.createResponse(null, oFViewOneResult.getStatusCode());
        }
    	

        // 2. Get OF Second View
        ResponseEntity<OFViewOneSummary> oFViewTwoResult = integration.getOFView(ssoId,"2");
        	
        	OFViewOneSummary objOFViewTwo=oFViewTwoResult.getBody();
        
        if (!oFViewTwoResult.getStatusCode().is2xxSuccessful()) {
            // We can't proceed, return whatever fault we got from the getProduct call
            return util.createResponse(null, oFViewTwoResult.getStatusCode());
        }
        
       
        // 3. Get OF Third View
        ResponseEntity<OFViewOneSummary> oFViewThreeResult = integration.getOFView(ssoId,"3");

    	OFViewOneSummary objOFViewThree=oFViewThreeResult.getBody();

        
        if (!oFViewThreeResult.getStatusCode().is2xxSuccessful()) {
            // We can't proceed, return whatever fault we got from the getProduct call
            return util.createResponse(null, oFViewThreeResult.getStatusCode());
        }
        
     // 4. Get Fleet Operational Status View
        ResponseEntity<List<FleetOperationalStatus>> objFleetList= integration.getFleetOperationalStatus(ssoId);
        
        List<FleetOperationalStatus> obj=objFleetList.getBody();
        	
        LOG.info("size of Fleet Status="+obj.size());
        
        
        // 5. Get Outage Type View
        
        ResponseEntity<List<OutageTypeSummary>> objOutageTypeList= integration.getOutageType(ssoId);
        List<OutageTypeSummary> objOutageType= objOutageTypeList.getBody();
        
        LOG.info("size of Outage Type="+objOutageType.size());


        // 6. Get Map Coordinates
        
        ResponseEntity<List<OutageSitesCoordinate>> objCoordinatesList= integration.getMapCordinates(ssoId);
        List<OutageSitesCoordinate> mapCoordinatesList= objCoordinatesList.getBody();
        
        LOG.info("size of Map List="+mapCoordinatesList.size());

        
        // 7. Get Timing Status
        
        ResponseEntity<List<OutageTimingStatus>> objTimingStatusList= integration.getTimingStatus(ssoId);
        List<OutageTimingStatus> objTimingStatus= objTimingStatusList.getBody();
        
        LOG.info("size of Timing List="+objTimingStatus.size());
	
        //8. Get RMD data
        
        //ResponseEntity<List<OutageTimingStatus>> objTimingStatusList= integration.getTimingStatus(ssoId);
        List<FleetMetrixsRmdSummary> fleetMetrixsRmdSummaryList= integration.getfleetMetrixRMDData(ssoId);
        
        LOG.info("size of rmd List="+fleetMetrixsRmdSummaryList.size());
        
        //9. Get Engine Details
        
        List<EnginesDetailBean> enginesDetailBeanList = integration.getEnginesDetail(ssoId);
        
        return util.createOkResponse(new DashboardDataAggregated(ssoId, objOFViewOne, objOFViewTwo, objOFViewThree, obj, mapCoordinatesList, objTimingStatus, objOutageType,fleetMetrixsRmdSummaryList,enginesDetailBeanList));
        
    }
    
    @RequestMapping("/outageDashboard/{ssoId}")
    public ResponseEntity<DashboardDataAggregated> getOFOneView1(@PathVariable String ssoId) {
		
    	// ResponseEntity<OFViewOneSummary> oFViewOneResult = integration.getOFView(ssoId,"1");
        ResponseEntity<OFViewOneSummary>  oFViewOneResult = integration.getOFView(ssoId,"1");
        
    	OFViewOneSummary objOFViewOne=oFViewOneResult.getBody();

        
        if (!oFViewOneResult.getStatusCode().is2xxSuccessful()) {
            // We can't proceed, return whatever fault we got from the getProduct call
            return util.createResponse(null, oFViewOneResult.getStatusCode());
        }
    	

        // 2. Get OF Second View
        ResponseEntity<OFViewOneSummary> oFViewTwoResult = integration.getOFView(ssoId,"2");
        	
        	OFViewOneSummary objOFViewTwo=oFViewTwoResult.getBody();
        
        if (!oFViewTwoResult.getStatusCode().is2xxSuccessful()) {
            // We can't proceed, return whatever fault we got from the getProduct call
            return util.createResponse(null, oFViewTwoResult.getStatusCode());
        }
        
       
        // 3. Get OF Third View
        ResponseEntity<OFViewOneSummary> oFViewThreeResult = integration.getOFView(ssoId,"3");

    	OFViewOneSummary objOFViewThree=oFViewThreeResult.getBody();

        
        if (!oFViewThreeResult.getStatusCode().is2xxSuccessful()) {
            // We can't proceed, return whatever fault we got from the getProduct call
            return util.createResponse(null, oFViewThreeResult.getStatusCode());
        }
        
     // 4. Get Fleet Operational Status View
        ResponseEntity<List<FleetOperationalStatus>> objFleetList= integration.getFleetOperationalStatus(ssoId);
        
        List<FleetOperationalStatus> obj=objFleetList.getBody();
        	
        LOG.info("size of Fleet Status="+obj.size());
        
        
        // 5. Get Outage Type View
        
        ResponseEntity<List<OutageTypeSummary>> objOutageTypeList= integration.getOutageType(ssoId);
        List<OutageTypeSummary> objOutageType= objOutageTypeList.getBody();
        
        LOG.info("size of Outage Type="+objOutageType.size());


        // 6. Get Map Coordinates
        
        ResponseEntity<List<OutageSitesCoordinate>> objCoordinatesList= integration.getMapCordinates(ssoId);
        List<OutageSitesCoordinate> mapCoordinatesList= objCoordinatesList.getBody();
        
        LOG.info("size of Map List="+mapCoordinatesList.size());

        
        // 7. Get Timing Status
        
        ResponseEntity<List<OutageTimingStatus>> objTimingStatusList= integration.getTimingStatus(ssoId);
        List<OutageTimingStatus> objTimingStatus= objTimingStatusList.getBody();
        
        LOG.info("size of Timing List="+objTimingStatus.size());
	
        //8. Get RMD data
        
        //ResponseEntity<List<OutageTimingStatus>> objTimingStatusList= integration.getTimingStatus(ssoId);
        List<FleetMetrixsRmdSummary> fleetMetrixsRmdSummaryList= integration.getfleetMetrixRMDData(ssoId);
        
        LOG.info("size of rmd List="+fleetMetrixsRmdSummaryList.size());
        
        //9. Get Engine Details
        
        List<EnginesDetailBean> enginesDetailBeanList = integration.getEnginesDetail(ssoId);
        
        return util.createOkResponse(new DashboardDataAggregated(ssoId, objOFViewOne, objOFViewTwo, objOFViewThree, obj, mapCoordinatesList, objTimingStatus, objOutageType,fleetMetrixsRmdSummaryList,enginesDetailBeanList));
    
    }
}
