package org.genpact.outageDashboard.composite.dashboard.model;

public class OutageTypeSummary {

	private String maintenanceLevel;
	private String year;
	private String month;
	private int count;
	public String getMaintenanceLevel() {
		return maintenanceLevel;
	}
	public void setMaintenanceLevel(String maintenanceLevel) {
		this.maintenanceLevel = maintenanceLevel;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
	
}
