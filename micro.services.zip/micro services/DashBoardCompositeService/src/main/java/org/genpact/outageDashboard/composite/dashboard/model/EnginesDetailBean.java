package org.genpact.outageDashboard.composite.dashboard.model;

public class EnginesDetailBean {

	private String engineName;
	private int engineModelNumber;
	public String getEngineName() {
		return engineName;
	}
	public void setEngineName(String engineName) {
		this.engineName = engineName;
	}
	public int getEngineModelNumber() {
		return engineModelNumber;
	}
	public void setEngineModelNumber(int engineModelNumber) {
		this.engineModelNumber = engineModelNumber;
	}
	public EnginesDetailBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EnginesDetailBean(String engineName, int engineModelNumber) {
		super();
		this.engineName = engineName;
		this.engineModelNumber = engineModelNumber;
	}
	
	
}
