package org.genpact.outageDashboard.composite.dashboard.model;

public class FleetOperationalStatus {

	private String technology;
	private String equipmentCode;
	private int inServiceCount;
	private int installCount;
	private int releaseCount;
	private int totalCount;
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getEquipmentCode() {
		return equipmentCode;
	}
	public void setEquipmentCode(String equipmentCode) {
		this.equipmentCode = equipmentCode;
	}
	public int getInServiceCount() {
		return inServiceCount;
	}
	public void setInServiceCount(int inServiceCount) {
		this.inServiceCount = inServiceCount;
	}
	public int getInstallCount() {
		return installCount;
	}
	public void setInstallCount(int installCount) {
		this.installCount = installCount;
	}
	public int getReleaseCount() {
		return releaseCount;
	}
	public void setReleaseCount(int releaseCount) {
		this.releaseCount = releaseCount;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	
	
	
	
}
