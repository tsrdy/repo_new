package org.genpact.outageDashboard.composite.dashboard.model;

import java.util.List;

import org.springframework.http.ResponseEntity;

public class DashboardDataAggregated {

	private String ssoId;

	private OFViewOneSummary viewOneSummary,viewTwoSummary,viewThreeSummary;
	/*private OFViewTwoSummary viewTwoSummary;
	private OFViewThreeSummary viewThreeSummary;*/
	private List<FleetOperationalStatus> fleetStatusSummary;
	private List<OutageSitesCoordinate> outageSitesCoordinates;
	private List<OutageTimingStatus> outageTimingStatus;
	private List<OutageTypeSummary> outageTypeSummary;
	private List<FleetMetrixsRmdSummary> fleetMetrixsRmdSummary;
	private List<EnginesDetailBean> enginesDetailBeanList;

	public String getSsoId() {
		return ssoId;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	
	
	
	public OFViewOneSummary getViewOneSummary() {
		return viewOneSummary;
	}

	public void setViewOneSummary(OFViewOneSummary viewOneSummary) {
		this.viewOneSummary = viewOneSummary;
	}

	public OFViewOneSummary getViewTwoSummary() {
		return viewTwoSummary;
	}

	public void setViewTwoSummary(OFViewOneSummary viewTwoSummary) {
		this.viewTwoSummary = viewTwoSummary;
	}

	public OFViewOneSummary getViewThreeSummary() {
		return viewThreeSummary;
	}

	public void setViewThreeSummary(OFViewOneSummary viewThreeSummary) {
		this.viewThreeSummary = viewThreeSummary;
	}

	public List<FleetOperationalStatus> getFleetStatusSummary() {
		return fleetStatusSummary;
	}

	public void setFleetStatusSummary(List<FleetOperationalStatus> fleetStatusSummary) {
		this.fleetStatusSummary = fleetStatusSummary;
	}

	public List<OutageSitesCoordinate> getOutageSitesCoordinates() {
		return outageSitesCoordinates;
	}

	public void setOutageSitesCoordinates(List<OutageSitesCoordinate> outageSitesCoordinates) {
		this.outageSitesCoordinates = outageSitesCoordinates;
	}

	public List<OutageTimingStatus> getOutageTimingStatus() {
		return outageTimingStatus;
	}

	public void setOutageTimingStatus(List<OutageTimingStatus> outageTimingStatus) {
		this.outageTimingStatus = outageTimingStatus;
	}

	public List<OutageTypeSummary> getOutageTypeSummary() {
		return outageTypeSummary;
	}

	public void setOutageTypeSummary(List<OutageTypeSummary> outageTypeSummary) {
		this.outageTypeSummary = outageTypeSummary;
	}

	
	public List<FleetMetrixsRmdSummary> getFleetMetrixsRmdSummary() {
		return fleetMetrixsRmdSummary;
	}

	public void setFleetMetrixsRmdSummary(
			List<FleetMetrixsRmdSummary> fleetMetrixsRmdSummary) {
		this.fleetMetrixsRmdSummary = fleetMetrixsRmdSummary;
	}

	
	public List<EnginesDetailBean> getEnginesDetailBeanList() {
		return enginesDetailBeanList;
	}

	public void setEnginesDetailBeanList(
			List<EnginesDetailBean> enginesDetailBeanList) {
		this.enginesDetailBeanList = enginesDetailBeanList;
	}

	public DashboardDataAggregated(String ssoId, OFViewOneSummary viewOneSummary, OFViewOneSummary viewTwoSummary,
			OFViewOneSummary viewThreeSummary, List<FleetOperationalStatus> fleetStatusSummary,
			List<OutageSitesCoordinate> outageSitesCoordinates, List<OutageTimingStatus> outageTimingStatus,
			List<OutageTypeSummary> outageTypeSummary,List<FleetMetrixsRmdSummary> fleetMetrixsRmdSummary,List<EnginesDetailBean> enginesDetailBeanList) {
		super();
		this.ssoId = ssoId;
		this.viewOneSummary = viewOneSummary;
		this.viewTwoSummary = viewTwoSummary;
		this.viewThreeSummary = viewThreeSummary;
		this.fleetStatusSummary = fleetStatusSummary;
		this.outageSitesCoordinates = outageSitesCoordinates;
		this.outageTimingStatus = outageTimingStatus;
		this.outageTypeSummary = outageTypeSummary;
		this.fleetMetrixsRmdSummary = fleetMetrixsRmdSummary;
		this.enginesDetailBeanList = enginesDetailBeanList;
		
	}
	
	/*public DashboardDataAggregated(String ssoId, OFViewOneSummary viewOneSummary, OFViewOneSummary viewTwoSummary,
			OFViewOneSummary viewThreeSummary, List<FleetOperationalStatus> fleetStatusSummary,
			List<OutageSitesCoordinate> outageSitesCoordinates, List<OutageTimingStatus> outageTimingStatus,
			List<OutageTypeSummary> outageTypeSummary,List<FleetMetrixsRmdSummary> fleetMetrixsRmdSummary) {
		super();
		this.ssoId = ssoId;
		this.viewOneSummary = viewOneSummary;
		this.viewTwoSummary = viewTwoSummary;
		this.viewThreeSummary = viewThreeSummary;
		this.fleetStatusSummary = fleetStatusSummary;
		this.outageSitesCoordinates = outageSitesCoordinates;
		this.outageTimingStatus = outageTimingStatus;
		this.outageTypeSummary = outageTypeSummary;
		this.fleetMetrixsRmdSummary = fleetMetrixsRmdSummary;
		
	}*/


	
	

	

	
	
}
