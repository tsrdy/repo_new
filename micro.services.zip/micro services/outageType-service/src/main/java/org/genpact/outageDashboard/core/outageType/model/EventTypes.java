package org.genpact.outageDashboard.core.outageType.model;

public class EventTypes {
	
	private String maintenanceLevel;
	private String year;
	private String month;
	private int count;
	
	
	public String getMaintenanceLevel() {
		return maintenanceLevel;
	}
	public void setMaintenanceLevel(String maintenanceLevel) {
		this.maintenanceLevel = maintenanceLevel;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
	public EventTypes(String maintenanceLevel, String year, String month, int count) {
		this.maintenanceLevel = maintenanceLevel;
		this.year = year;
		this.month = month;
		this.count = count;
	}

	
	
	
}
