package org.genpact.outageDashboard.core.outageType.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.outageDashboard.core.outageType.model.EventTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 2-Sep-15
 *
 */


@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class OutageTypeService {
	
	
    private static final Logger LOG = LoggerFactory.getLogger(OutageTypeService.class);

	
	
	/**
     * 
     * @param ssoID
     * @return
     */
    
    
    @RequestMapping("/outageType/{ssoID}")	
	public List<EventTypes> getOutageTypeSummary(@PathVariable int ssoID){
    	
    	List<EventTypes> objList = new ArrayList<EventTypes>();
		
    	objList.add(new EventTypes("CI", "2017", "01", 2));
    	objList.add(new EventTypes("CI",	"2017",	"01",	2));
    	objList.add(new EventTypes("CI",	"2017",	"02",	1));
    	objList.add(new EventTypes("CI",	"2017",	"04",	2));
    	objList.add(new EventTypes("CI",	"2017",	"06",	1));
    	objList.add(new EventTypes("CI",	"2017",	"07",	1));
    	objList.add(new EventTypes("CI",	"2017",	"08",	2));
    	objList.add(new EventTypes("HGPI",	"2017",	"05",	4));
    	objList.add(new EventTypes("HGPI",	"2017",	"06",	1));
    	objList.add(new EventTypes("HSI",	"2017",	"02",	6));
    	objList.add(new EventTypes("HSI",	"2017",	"03",	1));
    	objList.add(new EventTypes("HSI",	"2017",	"04",	1));
    	objList.add(new EventTypes("HSI",	"2017",	"08",	10));
    	objList.add(new EventTypes("LEV1",	"2017",	"02",	1));
    	objList.add(new EventTypes("LEV1",	"2017",	"03",	1));
    	objList.add(new EventTypes("LEV1",	"2017",	"04",	4));
    	objList.add(new EventTypes("LEV1",	"2017",	"05",	3));
    	objList.add(new EventTypes("LTI",	"2017",	"06",	1));
    	objList.add(new EventTypes("LTI",	"2017",	"07",	2));
    	objList.add(new EventTypes("MI",	"2017",	"03",	2));
    	objList.add(new EventTypes("MI",	"2017",	"04",	4));
    	objList.add(new EventTypes("CI",	"2015",	"12",	1));
    	objList.add(new EventTypes("FO",	"2015",	"09",	4));
    	objList.add(new EventTypes("HSI",	"2015",	"09",	3));
    	objList.add(new EventTypes("HSI",	"2015",	"12",	3));

    	return objList;
		
	}

}
