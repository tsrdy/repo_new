package org.genpact.outageDashboard.core.sitesMap.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.outageDashboard.core.sitesMap.model.SitesMapLocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 2-Sep-15
 *
 */


@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController

public class OutageSitesLocationService {
	
    private static final Logger LOG = LoggerFactory.getLogger(OutageSitesLocationService.class);

	
	
	/**
     * 
     * @param ssoID
     * @return
     */
    
    @RequestMapping("/oFSitesLoc/{ssoID}")	
	public List<SitesMapLocation> getOutageSitesLocation(@PathVariable int ssoID){
		
  	    	List<SitesMapLocation> objMapList = new ArrayList<SitesMapLocation>();

  	    objMapList.add( new SitesMapLocation("644001802", -6.8027028, 12.6145536, "equip_green.gif", 2, "LUANDA", "CABINDA GULF OIL COMPANY LIMITED", "LUANDA", "ANGOLA", "In Service", "6.8S  12.61E"));
  	    objMapList.add( new SitesMapLocation("365952063",-12.348056,13.545556,"equip_green.gif",2,"BIOPIO STATION","EMPRESA NACIONAL DE ELECTRICIDADE (ENE)","LUANDA", "ANGOLA", "In Service","12.35S  13.55E"));
		objMapList.add( new SitesMapLocation("552705576",-7.4556345,12.6383965,"equip_green.gif",2,"Kizomba A & B","EXXON MOBIL","LUANDA", "ANGOLA","In Service","7.46S  12.64E"));
		objMapList.add(new SitesMapLocation("954568379",-7.478955,12.7856605,"equip_green.gif",2,"ANGOLA/SOYO","OPCO SOCIEDADE OPERACIONAL ANGOLA LNG, SA","LUANDA","ANGOLA","In Service","7.48S  12.79E"));
  	    	
  	     
    			
    	return objMapList;
    	
    	
    	
		
	}
    
    /**
     * 
     * @param ssoID,timePeriod
     * @return
     */
    
    @RequestMapping("/")
    public String getMap(){
		
    	
    	return "Hello";
    	
    	
    }
    

}
