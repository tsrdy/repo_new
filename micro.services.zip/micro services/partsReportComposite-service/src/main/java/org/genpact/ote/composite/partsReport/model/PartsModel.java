package org.genpact.ote.composite.partsReport.model;

public class PartsModel {

	private String partsNumber;
	private String partsDesc;
	private String share11Percent;
	private String share10Percent;
	private String share09Percent;

	public String getPartsNumber() {
		return partsNumber;
	}

	public void setPartsNumber(String partsNumber) {
		this.partsNumber = partsNumber;
	}

	public String getPartsDesc() {
		return partsDesc;
	}

	public void setPartsDesc(String partsDesc) {
		this.partsDesc = partsDesc;
	}

	public String getShare11Percent() {
		return share11Percent;
	}

	public void setShare11Percent(String share11Percent) {
		this.share11Percent = share11Percent;
	}

	public String getShare10Percent() {
		return share10Percent;
	}

	public void setShare10Percent(String share10Percent) {
		this.share10Percent = share10Percent;
	}

	public String getShare09Percent() {
		return share09Percent;
	}

	public void setShare09Percent(String share09Percent) {
		this.share09Percent = share09Percent;
	}

	

	
	
}
