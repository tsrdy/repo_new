package org.genpact.ote.composite.partsReport.model;

public class MarketShare {
	
	/*private String year;
	private String orgName;
	private String marketShare;
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getMarketShare() {
		return marketShare;
	}
	public void setMarketShare(String marketShare) {
		this.marketShare = marketShare;
	}*/
	
	private int year1Share;
	private int year2Share;
	private int year3Share;
	private String orgName;
	
	
	
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public int getYear1Share() {
		return year1Share;
	}
	public void setYear1Share(int year1Share) {
		this.year1Share = year1Share;
	}
	public int getYear2Share() {
		return year2Share;
	}
	public void setYear2Share(int year2Share) {
		this.year2Share = year2Share;
	}
	public int getYear3Share() {
		return year3Share;
	}
	public void setYear3Share(int year3Share) {
		this.year3Share = year3Share;
	}
	
	
	
	
	
	
	

}
