package org.genpact.ote.composite.partsReport.service;

import java.io.IOException;
import java.net.URI;
import java.util.List;

import org.genpact.ote.composite.partsReport.model.MarketShare;
import org.genpact.ote.composite.partsReport.model.PartsModel;
import org.genpact.ote.composite.partsReport.model.RegionalStats;
import org.genpact.ote.composite.partsReport.util.ServiceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

@Component
@ComponentScan("org.genpact.ote.composite.partsReport.util")
public class PartsReportCompositeIntegration {

	@Autowired
	private LoadBalancerClient loadBalancer;

	@Autowired
	ServiceUtils util;

	private RestTemplate restTemplate = new RestTemplate();

	private ObjectReader regionalStatsReader = null;
	
	
	private static final Logger LOG = LoggerFactory.getLogger(PartsReportCompositeIntegration.class);

	public ResponseEntity<List<PartsModel>> getTop20Parts() {

		List<PartsModel> objPartsModelList;

		URI uri = util.getServiceUrl("PARTS-SERVICE");

		String url = uri.toString() + "/top20Parts/";

		LOG.info("Get Top 20 Parts from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("GetOFViewOneSummary http-status: {}", resultStr.getStatusCode());
		LOG.info("GetOFViewOneSummary body: {}", resultStr.getBody());

		objPartsModelList = response2Parts(resultStr);

		return util.createOkResponse(objPartsModelList);

	}
	
	public ResponseEntity<List<PartsModel>> getBottom20Parts() {

		List<PartsModel> objPartsModelList;

		URI uri = util.getServiceUrl("PARTS-SERVICE");

		String url = uri.toString() + "/bottom20Parts/";

		LOG.info("Get Top 20 Parts from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("GetOFViewOneSummary http-status: {}", resultStr.getStatusCode());
		LOG.info("GetOFViewOneSummary body: {}", resultStr.getBody());

		objPartsModelList = response2Parts(resultStr);

		return util.createOkResponse(objPartsModelList);

	}
	
	
	public ResponseEntity<List<MarketShare>> getMarketShare() {

		List<MarketShare> objMarketShareList;

		URI uri = util.getServiceUrl("MARKET-SHARE-SERVICE");

		String url = uri.toString() + "/getMarketShare/";

		LOG.info("Get Top 20 Parts from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("GetOFViewOneSummary http-status: {}", resultStr.getStatusCode());
		LOG.info("GetOFViewOneSummary body: {}", resultStr.getBody());

		objMarketShareList = response2MarketShare(resultStr);

		return util.createOkResponse(objMarketShareList);

	}
	
	
	public ResponseEntity<RegionalStats>  getRegionalStats() {

		RegionalStats objRegionalStats;

		URI uri = util.getServiceUrl("REGIONAL-STATS-SERVICE");

		String url = uri.toString() + "/regionalStats/";

		LOG.info("Get Regional Stats from URL: {}", url);

		ResponseEntity<String> resultStr = restTemplate.getForEntity(url, String.class);

		LOG.info("GetOFViewOneSummary http-status: {}", resultStr.getStatusCode());
		LOG.info("GetOFViewOneSummary body: {}", resultStr.getBody());

		objRegionalStats = respons2RegionalStats(resultStr);

		return util.createOkResponse(objRegionalStats);

	}
	
	
	
	public RegionalStats respons2RegionalStats(ResponseEntity<String> response) {

		try {
			return getRegionalStatsReader().readValue(response.getBody());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private ObjectReader getRegionalStatsReader() {

		if (regionalStatsReader != null)
			return regionalStatsReader;

		ObjectMapper mapper = new ObjectMapper();
		return regionalStatsReader = mapper.reader(RegionalStats.class);
	}

	

	public List<PartsModel> response2Parts(ResponseEntity<String> response) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			LOG.info("Before Processing"+response.getBody());

			List list = mapper.readValue(response.getBody(), new TypeReference<List<PartsModel>>() {
			});
			
			LOG.info("After Processing");

			List<PartsModel> partsList = list;
			return partsList;

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}

	
	public List<MarketShare> response2MarketShare(ResponseEntity<String> response) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			LOG.info("Before Processing"+response.getBody());

			List list = mapper.readValue(response.getBody(), new TypeReference<List<MarketShare>>() {
			});
			
			LOG.info("After Processing");

			List<MarketShare> marketShareList = list;
			
			return marketShareList;

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}
	

}
