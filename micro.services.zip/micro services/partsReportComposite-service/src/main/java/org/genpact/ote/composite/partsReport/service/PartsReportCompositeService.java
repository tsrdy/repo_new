package org.genpact.ote.composite.partsReport.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.ote.composite.partsReport.model.MarketShare;
import org.genpact.ote.composite.partsReport.model.PartsModel;
import org.genpact.ote.composite.partsReport.model.PartsReportAggregatedData;
import org.genpact.ote.composite.partsReport.model.RegionalStats;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 22-Sep-15
 */

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController

public class PartsReportCompositeService {

    private static final Logger LOG = LoggerFactory.getLogger(PartsReportCompositeService.class);

    @Autowired
    PartsReportCompositeIntegration integration;
    
    @Autowired
    org.genpact.ote.composite.partsReport.util.ServiceUtils util;
    
      
    @RequestMapping("/partsReport/")
    public ResponseEntity<PartsReportAggregatedData> getPartsReport() {
    	LOG.info("Entered");
    	
    	// 1. Get Top 20 Parts
    	ResponseEntity<List<PartsModel>> objTopPartsList= integration.getTop20Parts();
    	
    	 List<PartsModel> objTop20Parts= objTopPartsList.getBody();
     	
    	 LOG.info("size of Top 20  Parts="+objTop20Parts.size());	
    	 
    	 
    	// 2. Get Bottom 20 Parts
     	ResponseEntity<List<PartsModel>> objBottomPartsList= integration.getBottom20Parts();
     	
     	 List<PartsModel> objBottom20Parts= objBottomPartsList.getBody();
      	
     	 LOG.info("size of Bottom 20  Parts="+objBottom20Parts.size());	

    	
     	// 3. Get Market Share
      	ResponseEntity<List<MarketShare>> objMarketShareList= integration.getMarketShare();
      	
      	 List<MarketShare> objMarketShare= objMarketShareList.getBody();
       	
      	 LOG.info("size of MarketShare List="+objMarketShare.size());	
     	 
      	 
      // 3. Get Regional Stats
       	ResponseEntity<RegionalStats> objRegionalStatsList= integration.getRegionalStats();
       	
       	RegionalStats objRegionalStats= objRegionalStatsList.getBody();
    	
		return util.createOkResponse(new PartsReportAggregatedData(objTop20Parts, objBottom20Parts, objRegionalStats, objMarketShare));
	
    }
	
}
