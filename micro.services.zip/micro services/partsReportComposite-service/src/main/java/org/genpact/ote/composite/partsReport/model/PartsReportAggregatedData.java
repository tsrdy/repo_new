package org.genpact.ote.composite.partsReport.model;

import java.util.List;

public class PartsReportAggregatedData {

	private List<PartsModel> objtop20PartsList;
	private List<PartsModel> objbottom20PartsList;
	private RegionalStats objRegionalStats;
	private List<MarketShare> objMarketShareList;
	
	
	public List<PartsModel> getObjtop20PartsList() {
		return objtop20PartsList;
	}
	public void setObjtop20PartsList(List<PartsModel> objtop20PartsList) {
		this.objtop20PartsList = objtop20PartsList;
	}
	public List<PartsModel> getObjbottom20PartsList() {
		return objbottom20PartsList;
	}
	public void setObjbottom20PartsList(List<PartsModel> objbottom20PartsList) {
		this.objbottom20PartsList = objbottom20PartsList;
	}
	public RegionalStats getObjRegionalStats() {
		return objRegionalStats;
	}
	public void setObjRegionalStats(RegionalStats objRegionalStats) {
		this.objRegionalStats = objRegionalStats;
	}
	public List<MarketShare> getObjMarketShareList() {
		return objMarketShareList;
	}
	public void setObjMarketShareList(List<MarketShare> objMarketShareList) {
		this.objMarketShareList = objMarketShareList;
	}
	
	
	public PartsReportAggregatedData(List<PartsModel> objtop20PartsList, List<PartsModel> objbottom20PartsList,
			RegionalStats objRegionalStats, List<MarketShare> objMarketShareList) {
		super();
		this.objtop20PartsList = objtop20PartsList;
		this.objbottom20PartsList = objbottom20PartsList;
		this.objRegionalStats = objRegionalStats;
		this.objMarketShareList = objMarketShareList;
	}
	
	
}
