package org.genpact.ote.core.search.model;

import java.util.List;

public class SearchOptionsCompositeData {

	private List<EngineDetails> engineDetailsList;
	
	private List<DistributorDetails> distributorDetailsList;
	
	private List<PartCategories> partCategoriesList;
	
	private List<RegionDetails> regionDetailsList;
	
	private List<Integer> yearsList;

	public List<EngineDetails> getEngineDetailsList() {
		return engineDetailsList;
	}

	public void setEngineDetailsList(List<EngineDetails> engineDetailsList) {
		this.engineDetailsList = engineDetailsList;
	}

	public List<DistributorDetails> getDistributorDetailsList() {
		return distributorDetailsList;
	}

	public void setDistributorDetailsList(
			List<DistributorDetails> distributorDetailsList) {
		this.distributorDetailsList = distributorDetailsList;
	}

	public List<PartCategories> getPartCategoriesList() {
		return partCategoriesList;
	}

	public void setPartCategoriesList(List<PartCategories> partCategoriesList) {
		this.partCategoriesList = partCategoriesList;
	}

	public List<RegionDetails> getRegionDetailsList() {
		return regionDetailsList;
	}

	public void setRegionDetailsList(List<RegionDetails> regionDetailsList) {
		this.regionDetailsList = regionDetailsList;
	}

	public List<Integer> getYearsList() {
		return yearsList;
	}

	public void setYearsList(List<Integer> yearsList) {
		this.yearsList = yearsList;
	}

	public SearchOptionsCompositeData(List<EngineDetails> engineDetailsList,
			List<DistributorDetails> distributorDetailsList,
			List<PartCategories> partCategoriesList,
			List<RegionDetails> regionDetailsList, List<Integer> yearsList) {
		super();
		this.engineDetailsList = engineDetailsList;
		this.distributorDetailsList = distributorDetailsList;
		this.partCategoriesList = partCategoriesList;
		this.regionDetailsList = regionDetailsList;
		this.yearsList = yearsList;
	}

	public SearchOptionsCompositeData() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
