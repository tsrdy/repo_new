package org.genpact.ote.core.search.model;

public class DistributorDetails {

	private String distributorName;

	public String getDistributorName() {
		return distributorName;
	}

	public void setDistributorName(String distributorName) {
		this.distributorName = distributorName;
	}

	public DistributorDetails(String distributorName) {
		super();
		this.distributorName = distributorName;
	}

	public DistributorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
