package org.genpact.ote.core.search.model;

public class RegionDetails {

	private String regionName;

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public RegionDetails(String regionName) {
		super();
		this.regionName = regionName;
	}

	public RegionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
