package org.genpact.ote.core.search.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.ote.core.search.model.DistributorDetails;
import org.genpact.ote.core.search.model.EngineDetails;
import org.genpact.ote.core.search.model.PartCategories;
import org.genpact.ote.core.search.model.RegionDetails;
import org.genpact.ote.core.search.model.SearchOptionsCompositeData;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class SearchOptionsDataService {

	
	@RequestMapping("/getSearchOptions/")
	public SearchOptionsCompositeData getSearchOptionsData(){
		
		List<DistributorDetails> distributorDetailsList = new ArrayList<DistributorDetails>();
			
		DistributorDetails distributorDetails1 = new DistributorDetails("All");
		DistributorDetails distributorDetails2 = new DistributorDetails("distributor1");
		DistributorDetails distributorDetails3 = new DistributorDetails("distributor2");
		DistributorDetails distributorDetails4 = new DistributorDetails("distributor3");
		distributorDetailsList.add(distributorDetails1);
		distributorDetailsList.add(distributorDetails2);
		distributorDetailsList.add(distributorDetails3);
		distributorDetailsList.add(distributorDetails4);
		
		List<EngineDetails> engineDetailsList = new ArrayList<EngineDetails>();
		
		EngineDetails engineDetails1 = new EngineDetails("All");
		EngineDetails engineDetails2 = new EngineDetails("engineType1");
		EngineDetails engineDetails3 = new EngineDetails("engineType2");
		EngineDetails engineDetails4 = new EngineDetails("engineType3");
		engineDetailsList.add(engineDetails1);
		engineDetailsList.add(engineDetails2);
		engineDetailsList.add(engineDetails3);
		engineDetailsList.add(engineDetails4);
		
		List<PartCategories> partCategoriesList = new ArrayList<PartCategories>();
		
		PartCategories partCategories1 = new PartCategories("All");
		PartCategories partCategories2 = new PartCategories("category1");
		PartCategories partCategories3 = new PartCategories("category2");
		PartCategories partCategories4 = new PartCategories("category3");
		partCategoriesList.add(partCategories1);
		partCategoriesList.add(partCategories2);
		partCategoriesList.add(partCategories3);
		partCategoriesList.add(partCategories4);
		
		List<RegionDetails> regionDetailsList = new ArrayList<RegionDetails>();
		
		RegionDetails regionDetails1 = new RegionDetails("All");
		RegionDetails regionDetails2 = new RegionDetails("Latin America");
		RegionDetails regionDetails3 = new RegionDetails("Europe");
		RegionDetails regionDetails4 = new RegionDetails("Asia");
		RegionDetails regionDetails5 = new RegionDetails("USA");
		regionDetailsList.add(regionDetails1);
		regionDetailsList.add(regionDetails2);
		regionDetailsList.add(regionDetails3);
		regionDetailsList.add(regionDetails4);
		regionDetailsList.add(regionDetails5);
		
		List<Integer> yearsList = new ArrayList<Integer>();
		yearsList.add(2015);
		yearsList.add(2014);
		yearsList.add(2013);
		yearsList.add(2012);
		yearsList.add(2011);
		yearsList.add(2010);
		yearsList.add(2009);
		yearsList.add(2008);
		yearsList.add(2007);
		yearsList.add(2006);
		yearsList.add(2005);
		
		
		SearchOptionsCompositeData searchOptionsCompositeData = new SearchOptionsCompositeData(engineDetailsList,distributorDetailsList,
																partCategoriesList,regionDetailsList,yearsList);
		
		return searchOptionsCompositeData;
		
		
		
	}
}
