package org.genpact.ote.core.search.model;

public class EngineDetails {

	private String engineFamilyType;

	public String getEngineFamilyType() {
		return engineFamilyType;
	}

	public void setEngineFamilyType(String engineFamilyType) {
		this.engineFamilyType = engineFamilyType;
	}

	public EngineDetails(String engineFamilyType) {
		super();
		this.engineFamilyType = engineFamilyType;
	}

	public EngineDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
