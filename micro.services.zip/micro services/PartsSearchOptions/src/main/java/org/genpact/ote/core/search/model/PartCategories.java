package org.genpact.ote.core.search.model;

public class PartCategories {

	private String categoryName;

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public PartCategories(String categoryName) {
		super();
		this.categoryName = categoryName;
	}

	public PartCategories() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
