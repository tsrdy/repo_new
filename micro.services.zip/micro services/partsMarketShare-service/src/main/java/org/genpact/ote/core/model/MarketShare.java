package org.genpact.ote.core.model;

public class MarketShare {
	
	private int year1Share;
	private int year2Share;
	private int year3Share;
	private String orgName;
	
	
	
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
	
	public int getYear1Share() {
		return year1Share;
	}
	public void setYear1Share(int year1Share) {
		this.year1Share = year1Share;
	}
	public int getYear2Share() {
		return year2Share;
	}
	public void setYear2Share(int year2Share) {
		this.year2Share = year2Share;
	}
	public int getYear3Share() {
		return year3Share;
	}
	public void setYear3Share(int year3Share) {
		this.year3Share = year3Share;
	}
	public MarketShare(int year1Share, int year2Share, int year3Share,
			String orgName) {
		super();
		this.year1Share = year1Share;
		this.year2Share = year2Share;
		this.year3Share = year3Share;
		this.orgName = orgName;
	}
	
	
	
	
	

}
