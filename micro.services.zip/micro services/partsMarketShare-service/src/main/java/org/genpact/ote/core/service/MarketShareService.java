package org.genpact.ote.core.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.ote.core.model.MarketShare;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 22-Sep-15wedx
 */

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class MarketShareService {

	
private static final Logger LOG = LoggerFactory.getLogger(MarketShareService.class);

    
    @RequestMapping("/getMarketShare/")    
    public List<MarketShare>  getMarketShares(){
		 
    	ArrayList<MarketShare> objMarketShareList = new ArrayList<>();
    	
    	/*MarketShare obj1 = new MarketShare("2011", "Waukesha", "54%");
    	MarketShare obj2 = new MarketShare("2010", "Waukesha", "66%");
    	MarketShare obj3 = new MarketShare("2009", "Waukesha", "67%");
    	
    	MarketShare obj4 = new MarketShare("2011", "OEM", "4%");
    	MarketShare obj5 = new MarketShare("2010", "OEM", "8%");
    	MarketShare obj6 = new MarketShare("2009", "OEM", "2%");
    	
    	
    	MarketShare obj7 = new MarketShare("2011", "WillFitter", "24%");
    	MarketShare obj8 = new MarketShare("2010", "WillFitter", "15");
    	MarketShare obj9 = new MarketShare("2009", "WillFitter", "21%");
    	
    	MarketShare obj10 = new MarketShare("2011", "Reman", "18%");
    	MarketShare obj11 = new MarketShare("2010", "Reman", "10");
    	MarketShare obj12 = new MarketShare("2009", "Reman", "10%");*/
    	
    	MarketShare obj1 = new MarketShare(54,66,67,"Waukesha");
    	MarketShare obj2 = new MarketShare(4,8,2,"OEM");
    	MarketShare obj3 = new MarketShare(24,15,21,"WillFitter");
    	MarketShare obj4 = new MarketShare(18,10,10,"Reman");
    	
    	objMarketShareList.add(obj1);
    	objMarketShareList.add(obj2);
    	objMarketShareList.add(obj3);
    	objMarketShareList.add(obj4);
    	
    	
		return objMarketShareList;
    	
    }
}
