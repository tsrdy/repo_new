/*angular.module('myApp.controllers',[])

angular.module('myApp.controllers').controller('homeCtrl',

		function($rootScope, $scope, $http, $location) {
	
				console.log("entering home controller::"+$rootScope.authenticated);
				$scope.validLogin = false;
				$scope.validLogin = $rootScope.authenticated;
				
			$http.get('resource/').success(function(data) {
				$scope.greeting = data;
			})
	
});*/

var homeCtrl = ['$scope',
                '$rootScope',
                '$location',
                '$routeParams',
                '$http',
                '$route',
                '$resource',
                '$timeout',
                '$q',
                '$window',
                '$interval',
                function($scope,
               		 $rootScope,
               		 $location,
               		 $routeParams,
               		 $http,
               		 $route,
               		 $resource,
               		$timeout,
               		$q,
               		$window,
               		$interval){
	
	console.log("entering home controller::"+$rootScope.authenticated);
	console.log("home controller user logged in:"+$rootScope.loginSSO)
	//$scope.validLogin = false;
	
	$scope.authenticated = $rootScope.authenticated;
	var loginSSO = '501211111'; //$rootScope.loginSSO;
	
	var self =this;
	self.param = $routeParams.param;
	console.log("homeCtrl controller called and params is::"+self.param);
	/*$rootScope.loginSSoID = self.param;*/
	//$scope.loading = true;
	var OFViewServiceData=[];
	
		
	$http.get('outageDashboard/'+loginSSO).success(function(data) {
		console.log("calling composite service under home controller");
		$scope.compositeData = data;
		console.log("response from composite service::"+angular.toJson($scope.compositeData));
		
		$scope.viewOneSummary = $scope.compositeData.viewOneSummary;
		$scope.viewTwoSummary = $scope.compositeData.viewTwoSummary;
		$scope.viewThreeSummary = $scope.compositeData.viewThreeSummary;
		$scope.mapDataResponse = $scope.compositeData.outageSitesCoordinates;
		$scope.fleetStatusSummaryData = $scope.compositeData.fleetStatusSummary;
		$scope.outageTypeSummaryData = $scope.compositeData.outageTypeSummary;
		$scope.outageTimingStatusData = $scope.compositeData.outageTimingStatus;
		$scope.fleetMetrixsRmdSummaryData = $scope.compositeData.fleetMetrixsRmdSummary;
		/*$scope.engineDetailsData = $scope.compositeData.enginesDetailBeanList;*/
		/*$scope.ServiceData.ofViewServiceData = angular.toJson(OFViewServiceData);
		
		console.log("ofViewServiceSummay data is::"+$scope.ServiceData.ofViewServiceData);*/
		$scope.loadPeriodStatusData($scope.viewOneSummary,$scope.viewTwoSummary,$scope.viewThreeSummary)
		$scope.init_map($scope.mapDataResponse);
		$scope.loadFleetStatusGraphData($scope.fleetStatusSummaryData);
		$scope.loadoutageTypeSummaryGraph($scope.outageTypeSummaryData);
		$scope.init_pieChart($scope.outageTimingStatusData);
		$scope.loadRMDGraphData($scope.fleetMetrixsRmdSummaryData);
		
		/*$scope.changedEnginedNumber = $scope.engineDetailsData[0].engineModelNumber;
		console.log("changedEnginedNumber on initial call is::"+$scope.engineDetailsData[0].engineModelNumber);*/
		//$scope.loading = false;
		//$scope.ofViewServiceDataloadSec1($scope.OFViewServiceData);
	})
	
	
	$scope.OutageEventsData = [{"eventid":8080,"eventDate":"29-SEP-15","maintenanceType":"Major Inspection","eventStatus":"Confirmed"},
	                           {"eventid":2620887,"eventDate":"17-SEP-15","maintenanceType":"Forced Unplanned","eventStatus":"Confirmed"},
	                           {"eventid":2620887,"eventDate":"17-SEP-15","maintenanceType":"Boroscopic Inspection","eventStatus":"Confirmed"},
	                           {"eventid":2571543,"eventDate":"16-SEP-15","maintenanceType":"Major Inspection","eventStatus":"Confirmed"},
	                           {"eventid":2571543,"eventDate":"12-SEP-15","maintenanceType":"combustion Inspection","eventStatus":"Confirmed"}]
	
	$scope.loadPeriodStatusData = function(data1,data2,data3){
		
		$scope.periodStatusData=[];
		$scope.periodStatusData.push({timePeriod:"3 months",data:data1});
		$scope.periodStatusData.push({timePeriod:"6 months",data:data2});
		$scope.periodStatusData.push({timePeriod:"12 months",data:data3});
		console.log("period status array data"+angular.toJson($scope.periodStatusData));
		$scope.selectedPeriodObject = $scope.periodStatusData[0];
		$scope.siteDetails = $scope.selectedPeriodObject.data;
	}
	
	$scope.displaySiteDetails = function(data){
		
		console.log("calling displaySiteDetails function::"+angular.toJson(data.data));
		$scope.siteDetails = data.data;
	}
	
	$scope.loadFleetStatusGraphData = function(data){
		
		 	
		 	//$timeout(function(){$scope.loading = false}, 3000);
		 	$scope.inserviceArray =[];
			$scope.installArray=[];
			$scope.releaseArray=[];
			$scope.equipmentCodeArray=[];
			
			
		 $scope.loadingfleetStatusSummaryGraphsData = function(data){
				
				
				if(angular.isArray(data)){
					
					for(counter in data){
						
						$scope.inserviceArray.push(data[counter].inServiceCount);
						$scope.installArray.push(data[counter].installCount);
						$scope.releaseArray.push(data[counter].releaseCount);
						$scope.equipmentCodeArray.push(data[counter].equipmentCode);
						
						
					}
				}
			}
		 
		
		 
		 $scope.loadingfleetStatusSummaryGraphsData(data);
		 
		 $scope.fleetStatusSummaryChartData = {
		 		 title: {
		 			text: 'Fleet Status'
			        },
			        options: {
			            chart: {
			                type: 'column'
			            }
			        },
			        series: [ {
					    name: 'InService',
					    data: $scope.inserviceArray
					  }, {
					    name: 'Install',
					    data: $scope.installArray
					  },{
						  name: 'Release',
						    data: $scope.releaseArray
						  }],
					  xAxis: {
						    title: {
						      text: 'Engine Type'
						    },
						    categories: $scope.equipmentCodeArray
						  },
					yAxis: {
							title: {
							      text: 'Inservice/Install/Release'
							    }
							
							},
			        loading: false
			    }
		/*$timeout(function(){$scope.loading = false}, 3000);*/
		 
		 // use below if not using highcharts
		/*$scope.outagesData = {
				title: { text: 'Fleet Status' },
				subtitle: { text: '' },
				series: [{
				    name: 'InService',
				    data: $scope.inserviceArray
				  }, {
				    name: 'Install',
				    data: $scope.installArray
				  },{
					  name: 'Release',
					    data: $scope.releaseArray
					  }],
				  xAxis: {
					    title: {
					      text: 'Engine Type'
					    },
					    categories: $scope.equipmentCodeArray
					  },
				yAxis: {
						title: {
						      text: 'Inservice/Install/Release'
						    }
						
						}
		}
		
		
		$window.seriesData = $scope.outagesData;*/
		
		
		
	}
	
	
	$scope.loadoutageTypeSummaryGraph = function(data){
		
		console.log("entering loadoutageTypeSummaryGraph method")
		/*$scope.listOfOutageTypes = ["BI","CI","COM","HGPI","HSI","LEV1","LEV2","LTI","MR","MI","MIN",
		                            "UNK","INS","INSP","CAP","TOOL","AUX1","MED","OP","AUX2","AUX3",
		                            "CAP2","CAP3","1CYL","2CYL","FO","CO","SU","MA"];*/
		
		$scope.maintenanceLevelTempArray =[];
		$scope.yearTempArray=[];
		$scope.monthTempArray=[];
		$scope.countTempArray=[];
		
		
		$scope.maintenanceLevelArray =[];
		$scope.yearArray=[];
		$scope.monthArray=[];
		$scope.countArray=[];
		
		$scope.tempSameMaintenanceLevelArray=[];
		
		$scope.SummaryData = function(data){
			
			 if(angular.isArray(data)){
					
					for(counter in data){
						
						$scope.maintenanceLevelTempArray.push(data[counter].maintenanceLevel);
						$scope.yearTempArray.push(data[counter].year);
						$scope.monthTempArray.push(data[counter].month);
						$scope.countTempArray.push(data[counter].count);
						
					}
					
			 }
			 
			 $scope.maintenanceLevelArray = $scope.uniqueArray($scope.maintenanceLevelTempArray);
			 $scope.yearArray=$scope.uniqueArray($scope.yearTempArray);
			 console.log("unique maintenance levels::"+ $scope.maintenanceLevelArray);
			 
			 $scope.finalForamattedArray =[];
			$scope.countYear2015 =0;
			$scope.countYear2016 =0;
			$scope.countYear2017 =0;
			 
			 for(counter in data){
				 
				 if(data[counter].maintenanceLevel ==="CI"){
					 
					 if(data[counter].year === "2015"){
						 
						 $scope.countYear2015 = $scope.countYear2015+data[counter].count;
					 }else if(data[counter].year === "2016"){
						 $scope.countYear2016 = $scope.countYear2016+data[counter].count;
					 }else if(data[counter].year === "2017"){
						 $scope.countYear2017 = $scope.countYear2017+data[counter].count;
					 }
				 }
				 
				 //console.log("reached end of array counter:"+counter);
				 
				 if(counter == data.length-1){
					 
					 var outageObjectelementData1={};
					
					 outageObjectelementData1.outageType="CI"
						 outageObjectelementData1.count2015=$scope.countYear2015;
							 outageObjectelementData1.count2016=$scope.countYear2016;
								 outageObjectelementData1.count2017=$scope.countYear2017;
								 $scope.finalForamattedArray.push(outageObjectelementData1);
					 	$scope.countYear2015 =0;
						$scope.countYear2016 =0;
						$scope.countYear2017 =0;
						
				 }
				 
			 }
			 
			 for(counter in data){
				 
				 if(data[counter].maintenanceLevel ==="HGPI"){
					 
					 if(data[counter].year === "2015"){
						 
						 $scope.countYear2015 = $scope.countYear2015+data[counter].count;
					 }else if(data[counter].year === "2016"){
						 $scope.countYear2016 = $scope.countYear2016+data[counter].count;
					 }else if(data[counter].year === "2017"){
						 $scope.countYear2017 = $scope.countYear2017+data[counter].count;
					 }
				 }
				 
				 //console.log("reached end of array counter:"+counter);
				 
				 if(counter == data.length-1){
					
					 var outageObjectelementData1={};	
					 outageObjectelementData1.outageType="HGPI"
						 outageObjectelementData1.count2015=$scope.countYear2015;
							 outageObjectelementData1.count2016=$scope.countYear2016;
								 outageObjectelementData1.count2017=$scope.countYear2017;
								 $scope.finalForamattedArray.push(outageObjectelementData1);
					 	$scope.countYear2015 =0;
						$scope.countYear2016 =0;
						$scope.countYear2017 =0;
						
				 }
				 
			 }
			 
			 for(counter in data){
						 
						 if(data[counter].maintenanceLevel ==="HSI"){
							 
							 if(data[counter].year === "2015"){
								 
								 $scope.countYear2015 = $scope.countYear2015+data[counter].count;
							 }else if(data[counter].year === "2016"){
								 $scope.countYear2016 = $scope.countYear2016+data[counter].count;
							 }else if(data[counter].year === "2017"){
								 $scope.countYear2017 = $scope.countYear2017+data[counter].count;
							 }
						 }
						 
						 //console.log("reached end of array counter:"+counter);
						 
						 if(counter == data.length-1){
							
							 var outageObjectelementData1={};	
							 outageObjectelementData1.outageType="HSI"
								 outageObjectelementData1.count2015=$scope.countYear2015;
									 outageObjectelementData1.count2016=$scope.countYear2016;
										 outageObjectelementData1.count2017=$scope.countYear2017;
										 $scope.finalForamattedArray.push(outageObjectelementData1);
							 	$scope.countYear2015 =0;
								$scope.countYear2016 =0;
								$scope.countYear2017 =0;
							 
						 }
						 
					 }
			for(counter in data){
				 
				 if(data[counter].maintenanceLevel ==="LEV1"){
					 
					 if(data[counter].year === "2015"){
						 
						 $scope.countYear2015 = $scope.countYear2015+data[counter].count;
					 }else if(data[counter].year === "2016"){
						 $scope.countYear2016 = $scope.countYear2016+data[counter].count;
					 }else if(data[counter].year === "2017"){
						 $scope.countYear2017 = $scope.countYear2017+data[counter].count;
					 }
				 }
				 
				 //console.log("reached end of array counter:"+counter);
				 
				 if(counter == data.length-1){
					 var outageObjectelementData1={};	
					 outageObjectelementData1.outageType="LEV1"
						 outageObjectelementData1.count2015=$scope.countYear2015;
							 outageObjectelementData1.count2016=$scope.countYear2016;
								 outageObjectelementData1.count2017=$scope.countYear2017;
								 $scope.finalForamattedArray.push(outageObjectelementData1);
					 	$scope.countYear2015 =0;
						$scope.countYear2016 =0;
						$scope.countYear2017 =0;
				 }
				 
			}
			for(counter in data){
				 
				 if(data[counter].maintenanceLevel ==="LEV2"){
					 
					 if(data[counter].year === "2015"){
						 
						 $scope.countYear2015 = $scope.countYear2015+data[counter].count;
					 }else if(data[counter].year === "2016"){
						 $scope.countYear2016 = $scope.countYear2016+data[counter].count;
					 }else if(data[counter].year === "2017"){
						 $scope.countYear2017 = $scope.countYear2017+data[counter].count;
					 }
				 }
				 
				 //console.log("reached end of array counter:"+counter);
				 
				 if(counter == data.length-1){
					 var outageObjectelementData1={};	
					 outageObjectelementData1.outageType="LEV2"
						 outageObjectelementData1.count2015=$scope.countYear2015;
							 outageObjectelementData1.count2016=$scope.countYear2016;
								 outageObjectelementData1.count2017=$scope.countYear2017;
								 $scope.finalForamattedArray.push(outageObjectelementData1);
					 	$scope.countYear2015 =0;
						$scope.countYear2016 =0;
						$scope.countYear2017 =0;
				 }
				 
			}
			
			for(counter in data){
				 
				 if(data[counter].maintenanceLevel ==="LTI"){
					 
					 if(data[counter].year === "2015"){
						 
						 $scope.countYear2015 = $scope.countYear2015+data[counter].count;
					 }else if(data[counter].year === "2016"){
						 $scope.countYear2016 = $scope.countYear2016+data[counter].count;
					 }else if(data[counter].year === "2017"){
						 $scope.countYear2017 = $scope.countYear2017+data[counter].count;
					 }
				 }
				 
				 //console.log("reached end of array counter:"+counter);
				 
				 if(counter == data.length-1){
					 var outageObjectelementData1={};	
					 outageObjectelementData1.outageType="LTI"
						 outageObjectelementData1.count2015=$scope.countYear2015;
							 outageObjectelementData1.count2016=$scope.countYear2016;
								 outageObjectelementData1.count2017=$scope.countYear2017;
								 $scope.finalForamattedArray.push(outageObjectelementData1);
					 	$scope.countYear2015 =0;
						$scope.countYear2016 =0;
						$scope.countYear2017 =0;
				 }
				 
			}
			for(counter in data){
				 
				 if(data[counter].maintenanceLevel ==="MI"){
					 
					 if(data[counter].year === "2015"){
						 
						 $scope.countYear2015 = $scope.countYear2015+data[counter].count;
					 }else if(data[counter].year === "2016"){
						 $scope.countYear2016 = $scope.countYear2016+data[counter].count;
					 }else if(data[counter].year === "2017"){
						 $scope.countYear2017 = $scope.countYear2017+data[counter].count;
					 }
				 }
				 
				 //console.log("reached end of array counter:"+counter);
				 
				 if(counter == data.length-1){
					 var outageObjectelementData1={};	
					 outageObjectelementData1.outageType="MI"
						 outageObjectelementData1.count2015=$scope.countYear2015;
							 outageObjectelementData1.count2016=$scope.countYear2016;
								 outageObjectelementData1.count2017=$scope.countYear2017;
								 $scope.finalForamattedArray.push(outageObjectelementData1);
					 	$scope.countYear2015 =0;
						$scope.countYear2016 =0;
						$scope.countYear2017 =0;
				 }
				 
			}
			for(counter in data){
				 
				 if(data[counter].maintenanceLevel ==="FO"){
					 
					 if(data[counter].year === "2015"){
						 
						 $scope.countYear2015 = $scope.countYear2015+data[counter].count;
					 }else if(data[counter].year === "2016"){
						 $scope.countYear2016 = $scope.countYear2016+data[counter].count;
					 }else if(data[counter].year === "2017"){
						 $scope.countYear2017 = $scope.countYear2017+data[counter].count;
					 }
				 }
				 
				 //console.log("reached end of array counter:"+counter);
				 
				 if(counter == data.length-1){
					 var outageObjectelementData1={};	
					 outageObjectelementData1.outageType="FO"
						 outageObjectelementData1.count2015=$scope.countYear2015;
							 outageObjectelementData1.count2016=$scope.countYear2016;
								 outageObjectelementData1.count2017=$scope.countYear2017;
								 $scope.finalForamattedArray.push(outageObjectelementData1);
					 	$scope.countYear2015 =0;
						$scope.countYear2016 =0;
						$scope.countYear2017 =0;
				 }
				 
			}
				
			 console.log("record of formatted type for CI::"+angular.toJson($scope.finalForamattedArray));
			 
			 	/*$scope.maintenanceLevelArray =$scope.uniqueArray($scope.maintenanceLevelTempArray);
				$scope.yearArray=$scope.uniqueArray($scope.yearTempArray);
				$scope.monthArray=$scope.uniqueArray($scope.monthTempArray);
				$scope.countArray=$scope.uniqueArray($scope.countTempArray);*/
			
		 }
		
		$scope.SummaryData(data);
		
		$scope.inmaintenanceLevelArray =[];
		$scope.in2015Array=[];
		$scope.in2016Array=[];
		$scope.in2017Array=[];
		
		
		$scope.summaryFinalData = function(data1){
			
			console.log("inside summaryDummyData formatted object"+angular.toJson(data1));
			
				if(angular.isArray(data1)){
					
					for(counter in data1){
						
						$scope.inmaintenanceLevelArray.push(data1[counter].outageType);
						$scope.in2015Array.push(data1[counter].count2015);
						$scope.in2016Array.push(data1[counter].count2016);
						$scope.in2017Array.push(data1[counter].count2017);
					
					}
				}
				
				console.log("inside summaryDummyData maintenancelevel array"+angular.toJson($scope.inmaintenanceLevelArray));
			}
		
		$scope.summaryFinalData($scope.finalForamattedArray);
		
		$scope.outageTypeSummaryChartData = {
		 		 title: {
		 			text: 'OUTAGE TYPES'
			        },
			        options: {
			            chart: {
			                type: 'column'
			            }
			        },
			        series: [ {
					    name: '2015',
					    data: $scope.in2015Array
					  }, {
					    name: '2016',
					    data: $scope.in2016Array
					  },{
						  name: '2017',
						    data: $scope.in2017Array
						  }],
					  xAxis: {
						    title: {
						      text: 'Outage Type'
						    },
						    categories: $scope.inmaintenanceLevelArray
						  },
					yAxis: {
							title: {
							      text: 'count'
							    }
							
							},
			        loading: false
			    }
		
		// use below if highchart directive is not used.
		/*$scope.outagesSummayData = {
				title: { text: 'OUTAGE TYPES' },
				subtitle: { text: '' },
				series: [{
				    name: '2015',
				    data: $scope.in2015Array
				  }, {
				    name: '2016',
				    data: $scope.in2016Array
				  },{
					  name: '2017',
					    data: $scope.in2017Array
					  }],
				  xAxis: {
					    title: {
					      text: 'Outage Type'
					    },
					    categories: $scope.inmaintenanceLevelArray
					  },
				yAxis: {
						title: {
						      text: 'count'
						    }
						
						}
		}
		
		
		$window.outageTypeSummaryData = $scope.outagesSummayData;*/
		$timeout(function(){$scope.loading = false}, 3000);
		
		
	}
	
	
	$scope.init_map = function(data){
		
		console.log("entering init_map to load map data");
		/*$scope.loading = true;*/
		
		    var map;
		    var bounds = new google.maps.LatLngBounds();
		    var mapOptions = {
		        mapTypeId: 'roadmap'
		    };
		    
		    var iconBase = 'https://maps.google.com/mapfiles/kml/shapes/';
		    // Display a map on the page
		    //var var_map = new google.maps.Map(document.getElementById("map-container"), var_mapoptions);
		    map = new google.maps.Map(document.getElementById("map-container"), mapOptions);
		    map.setTilt(45);
		        
		    // Multiple Markers
		    /*var markers = [
		        ['London Eye, London', 51.503454,-0.119562],
		        ['Palace of Westminster, London', 51.499633,-0.124755]
		    ];*/
		      
		   var markers = [
		                  [data[0].siteCity, data[0].siteLongtitude,data[0].siteLatitude],
		  		        	[data[1].siteCity, data[1].siteLongtitude,data[1].siteLatitude],
		  		        	[data[2].siteCity, data[2].siteLongtitude,data[2].siteLatitude],
		  		        	[data[3].siteCity, data[3].siteLongtitude,data[3].siteLatitude],
		                  ]
		    // Info Window Content
		    var infoWindowContent = [
		        ['<div class="info_content">' +
		        '<h3> <font color="red">City:</font>' +data[0].siteCity+'</h3>'+
		        '<p> <font color="red">Customer:</font>'+data[0].siteCustomer+'&nbsp;&nbsp;&nbsp'+data[0].siteName +'</p>' + '</div>'],
		        ['<div class="info_content">' +
			        '<h3> <font color="red">City:</font>' +data[1].siteCity+'</h3>'+
			        '<p> <font color="red">Customer:</font>'+data[1].siteCustomer+'&nbsp;&nbsp;&nbsp'+data[1].siteName +'</p>' + '</div>'],
			        ['<div class="info_content">' +
				        '<h3> <font color="red">City:</font>' +data[2].siteCity+'</h3>'+
				        '<p> <font color="red">Customer:</font>'+data[2].siteCustomer+'&nbsp;&nbsp;&nbsp'+data[2].siteName +'</p>' + '</div>'],
				        ['<div class="info_content">' +
					        '<h3> <font color="red">City:</font>' +data[3].siteCity+'</h3>'+
					        '<p> <font color="red">Customer:</font>'+data[3].siteCustomer+'&nbsp;&nbsp;&nbsp'+data[3].siteName +'</p>' + '</div>']
		    ];
		        
		    // Display multiple markers on a map
		    var infoWindow = new google.maps.InfoWindow(), marker, i;
		    
		    // Loop through our array of markers & place each one on the map  
		    for( i = 0; i < markers.length; i++ ) {
		        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
		        bounds.extend(position);
		        marker = new google.maps.Marker({
		            position: position,
		            icon: iconBase + 'library_maps.png',
		            map: map,
		            title: markers[i][0]
		        });
		        
		        // Allow each marker to have an info window    
		        google.maps.event.addListener(marker, 'click', (function(marker, i) {
		            return function() {
		                infoWindow.setContent(infoWindowContent[i][0]);
		                infoWindow.open(map, marker);
		            }
		        })(marker, i));

		        // Automatically center the map fitting all markers on the screen
		        map.fitBounds(bounds);
		    }

		    // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
		    var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
		        //this.setZoom(14);
		        //this.setZoomIn(14);
		        google.maps.event.removeListener(boundsListener);
		    });
		
		    /*$scope.loading = false;*/
		
	}
	
	$scope.init_pieChart = function(data){
		
		//$scope.dummyPieData = [["On Time",3],["Overdue",14],["Completed",80]]
		$scope.ontimeValue=3;
		console.log("pie chard response data::"+data);
		/*$scope.loading = true;
		$timeout(function(){$scope.loading = false}, 2000);*/
		/*$scope.timingStatusChartData = {
				  series: [{
				      //data: [['On Time', 10], ['OverDue', 40], ['Completed', 135]]
					  data: [[data[0].status,data[0].count],[data[1].status,data[1].count],[data[2].status,data[2].count]]
				  }]
				};*/
	
		/*$scope.timingStatusChartData = [{
			  data: [[data[0].status,data[0].count],[data[1].status,data[1].count],[data[2].status,data[2].count]]
		  }]*/
		/*$scope.myData = [
		                 { value : 50, color : "#F7464A" },
		                 { value : 90, color : "#E2EAE9" },
		                 { value : 75, color : "#D4CCC5" },
		                 { value : 30, color : "#949FB1"}
		               ];*/
		$scope.myData =[
						{ label: data[0].status,value : data[0].count,color : "#F7464A" },
						{ label: data[1].status,value : data[1].count,color : "#FF9900"},
						{ label: data[2].status,value : data[2].count,color : "#4863A0"},
		                ]
		//$window.pieChartData1 = $scope.timingStatusChartData;
		//$window.onTime='3';
		
	}
	
	
	$scope.uniqueArray = function(origArr) {
	    var newArr = [],
	        origLen = origArr.length,
	        found, x, y;

	    for (x = 0; x < origLen; x++) {
	        found = undefined;
	        for (y = 0; y < newArr.length; y++) {
	            if (origArr[x] === newArr[y]) {
	                found = true;
	                break;
	            }
	        }
	        if (!found) {
	            newArr.push(origArr[x]);
	        }
	    }
	    return newArr;
	}

	$scope.loadRMDGraphData = function(data){
		
		console.log("inside loadRMDGraphData ::");
		$scope.dummyjsonResponse = [{"type":"Units","WholeFleet":953,"YourFleet":74},
		                         {"type":"Drivers","WholeFleet":337,"YourFleet":37},
		                         {"type":"Sites","WholeFleet":92,"YourFleet":11},
		                         {"type":"Pre-COD","WholeFleet":33,"YourFleet":28},
		                         {"type":"Trips","WholeFleet":1300,"YourFleet":33}
		                         ];
		
		
		/*$scope.loading1 = true;*/
	 	//$timeout(function(){$scope.loading = false}, 3000);
	 	$scope.inTypeArray =[];
		$scope.wholeFleetArray=[];
		$scope.yourFleetArray=[];
		
		
		
	 $scope.loadingRMDSummaryGraphsData = function(data){
		 console.log("inside loadingRMDSummaryGraphsData ::"+angular.toJson(data));
			
			if(angular.isArray(data)){
				
				for(counter in data){
					console.log("inside rmd data for loop::"+angular.toJson(data[counter]));
					$scope.inTypeArray.push(data[counter].type);
					$scope.wholeFleetArray.push(data[counter].wholeFleet);
					$scope.yourFleetArray.push(data[counter].yourFleet);
					
					
					
				}
			}
		}
	 
	
	 
	 $scope.loadingRMDSummaryGraphsData(data);
	 	console.log("each array inTypeArray::"+angular.toJson($scope.inTypeArray))
	 	console.log("each array wholeFleetArray::"+angular.toJson($scope.wholeFleetArray))
	 	console.log("each array yourFleetArray::"+angular.toJson($scope.yourFleetArray))
	 	
		/*
		$scope.rmdData = {
                title : {
                       text : 'Fleet Metrics SnapShot'
                },
                subtitle : {
                       text : 'Source: RMD, IBAS'
                },
                series : [
                              {
                                    name : 'Whole Fleet',
                                    data : $scope.wholeFleetArray
                              },
                              {
                                    name : 'Your Fleet',
                                    data : $scope.yourFleetArray
                              } ],
                xAxis : {
                       title : {
                              text : 'Key Values'
                       },
                       categories : $scope.inTypeArray
                },
                yAxis : {
                       title : {
                              text : 'Metrics'
                       }
                },
                legend : {
                       y : 40
                }
         };*/

	 	$scope.rmdChartData = {
	 		 title: {
	 			text : 'Fleet Metrics SnapShot'
		        },
		        options: {
		            chart: {
		                type: 'column'
		            }
		        },
		        series: [ {
                    name : 'Whole Fleet',
                    data : $scope.wholeFleetArray
		        	},
		        	{
                    name : 'Your Fleet',
                    data : $scope.yourFleetArray
		        	}],
		        xAxis : {
	                       title : {
	                              text : 'Key Values'
	                       },
	                       categories : $scope.inTypeArray
	                },
	            yAxis : {
	                       title : {
	                              text : 'Metrics'
	                       }
	                },
		        loading: false
		    }
	 	
	 	// use below if not using hightcharts directive.
		/*$window.rmdSummaryData = $scope.rmdData;*/
	 	
	 	//$scope.loading = false;
	}
	
	//var chart;
	
	

}]