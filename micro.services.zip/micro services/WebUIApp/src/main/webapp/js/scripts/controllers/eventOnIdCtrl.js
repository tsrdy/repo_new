/*angular.module('myApp.controllers',[])

angular.module('myApp.controllers').controller('eventOnIdCtrl',function($scope, $http,$routeParams) {
	
	var self =this;
	self.param = $routeParams.param;
	console.log("eventOnId controller called::"+self.param);
	
	$http.get('event/'+self.param).success(function(data) {
		$scope.eventListData = data;
		console.log("value from respone for event::"+angular.toJson($scope.eventListData));
	})
		
		
});
*/
var eventOnIdCtrl = ['$scope',
                     '$rootScope',
                     '$location',
                     '$routeParams',
                     '$http',
                     '$route',
                     '$routeParams',
                     function($scope,
                    		 $rootScope,
                    		 $location,
                    		 $routeParams,
                    		 $http,
                    		 $route,
                    		 $routeParams){
	
				var self =this;
				self.param = $routeParams.param;
				console.log("eventOnId controller called::"+self.param);
				
				$http.get('event/'+self.param).success(function(data) {
					$scope.eventListData = data;
					console.log("value from respone for event::"+angular.toJson($scope.eventListData));
				})
	
}]