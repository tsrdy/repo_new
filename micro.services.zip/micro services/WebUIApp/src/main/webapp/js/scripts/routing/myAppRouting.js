myApp.config(['$routeProvider','$httpProvider',function($routeProvider,$httpProvider){

	console.log("entered router config file");
	
	$routeProvider.when('/', {
		templateUrl : 'views/login.html',
		controller : 'loginCtrl'
	}).when('/outageDashboard', {
		templateUrl : 'views/dashboard.html',
		controller : 'homeCtrl'
	}).when('/monitoring', {
		templateUrl : 'views/monitor-engines.html',
		controller : 'monitorCtrl'
	}).when('/reports', {
		templateUrl : 'views/reports.html',
		controller : 'reportsCtrl'
	}).when('/maps', {
		templateUrl : 'views/maps.html',
		controller : 'mapCtrl'
	}).otherwise('/');

	$httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

}])