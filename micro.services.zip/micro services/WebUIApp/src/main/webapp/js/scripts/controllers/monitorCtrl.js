var monitorCtrl = ['$scope',
                '$rootScope',
                '$location',
                '$routeParams',
                '$http',
                '$route',
                '$resource',
                '$timeout',
                '$q',
                '$window',
                '$interval',
                function($scope,
               		 $rootScope,
               		 $location,
               		 $routeParams,
               		 $http,
               		 $route,
               		 $resource,
               		$timeout,
               		$q,
               		$window,
               		$interval){
	
	console.log("monitor controller user logged in:"+$rootScope.loginSSO)
	var loginSSO = '501211111'; //$rootScope.loginSSO;
	
	$scope.loading = true;
	$http.get('enginesDetail/'+loginSSO).success(function(data) {
		
		$scope.engineDetailsData = data;
		console.log("response from enginedetails service"+angular.toJson($scope.engineDetailsData));
		
		$scope.changedEnginedNumber = $scope.engineDetailsData[0].engineModelNumber;
		$scope.loading = false;
	});
	
	
	$scope.refreshFunction = function(){
		
		$scope.tempDetails;
		var chart;
		
		$scope.graphPlots=[];
		$scope.pressurePlots=[];
		$scope.xSeriesValues=[];
		$scope.P48SELPlots=[];
		$scope.temperatureLowThreshold =4
        $scope.pressureLowThreshold =80;
		$scope.PS3SELThreshold= 20;
		chart = new Highcharts.Chart({
            chart: {
            	renderTo: 'spinecontainer',
                type: 'spline',
                animation: Highcharts.svg, // don't animate in old IE
                marginRight: 15,
                events: {
                    load: function () {
                    	
                        // set up the updating of the chart each second
                    	
                       var series = this.series[0];
                       var series2 = this.series[1];
                       var series3 = this.series[2];
                       var x,y,z,w,shift,shift1,timeInSeconds;
                      
                       
                       
                       var i=0;
                       setInterval(function () {
                    	   
                            $http.get('dataRefresh/'+$scope.changedEnginedNumber).success(function(point) {
   							console.log("after refreshing data is ::"+angular.toJson(point));
   							$scope.tempDetails = point;
   						});
                            		shift = series.data.length > 20; // shift if the series is  longer than 20
                            		shift1 = series2.data.length > 20;
                            		series.zones[0].value = $scope.temperatureLowThreshold;
                                    series2.zones[0].value = $scope.pressureLowThreshold;
                                    series3.zones[0].value = $scope.PS3SELThreshold;
                            		console.log("value of threshold temper::"+series.zones[0].value);
                            		x = (new Date()).getTime();
                            		timeInSeconds = Highcharts.dateFormat('%H:%M:%S', x);
                            		
		                            if($scope.tempDetails.powerOutputMWSEL != undefined){
			   		                   y=$scope.tempDetails.powerOutputMWSEL;
			   		                console.log("y value from datafresh after time function"+y);
		                            }
			   		                
			   		             if($scope.tempDetails.combustorExhaustT48SEL != undefined){
			   		                	z = $scope.tempDetails.combustorExhaustT48SEL;
			   		                	console.log("z value from datafresh after time function"+z);
			   		             }
			   		               
			   		          if($scope.tempDetails.hpcDischargePressurePS3SEL != undefined){
		   		                	w = $scope.tempDetails.hpcDischargePressurePS3SEL;
		   		                	console.log("z value from datafresh after time function"+z);
		   		             }
	   		                // add the point
	   		                 series.addPoint([x,y], true, shift);
	   		                 series2.addPoint([x,z], true, shift);
	   		                 series3.addPoint([x,w], true, shift);
	   		                 if(i<20){
	   		                	 
	   		                 $scope.xSeriesValues[i] = timeInSeconds;
	   		                 $scope.graphPlots[i] = y;
	   		                 $scope.pressurePlots[i] =z;
	   		                 $scope.P48SELPlots[i] = w;
	   		                 
	   		                 }else{
	   		                	 
	   		                	 // for Xseries time 
	   		                	$scope.xSeriesValues[0] = $scope.xSeriesValues[1];
	   		                	$scope.xSeriesValues[1] = $scope.xSeriesValues[2];
	   		                	$scope.xSeriesValues[2] = $scope.xSeriesValues[3];
	   		                	$scope.xSeriesValues[3] = $scope.xSeriesValues[4];
	   		                	$scope.xSeriesValues[4] = $scope.xSeriesValues[5];
	   		                	$scope.xSeriesValues[5] = $scope.xSeriesValues[6];
	   		                	$scope.xSeriesValues[6] = $scope.xSeriesValues[7];
	   		                	$scope.xSeriesValues[7] = $scope.xSeriesValues[8];
	   		                	$scope.xSeriesValues[8] = $scope.xSeriesValues[9];
	   		                	$scope.xSeriesValues[9] = $scope.xSeriesValues[10];
	   		                	$scope.xSeriesValues[10] = $scope.xSeriesValues[11];
	   		                	$scope.xSeriesValues[11] = $scope.xSeriesValues[12];
	   		                	$scope.xSeriesValues[12] = $scope.xSeriesValues[13];
	   		                	$scope.xSeriesValues[13] = $scope.xSeriesValues[14];
	   		                	$scope.xSeriesValues[14] = $scope.xSeriesValues[15];
	   		                	$scope.xSeriesValues[15] =$scope.xSeriesValues[16];
	   		                	$scope.xSeriesValues[16] =$scope.xSeriesValues[17];
	   		                	$scope.xSeriesValues[17] =$scope.xSeriesValues[18];
	   		                	$scope.xSeriesValues[18] =$scope.xSeriesValues[19];
	   		                	$scope.xSeriesValues[19] =timeInSeconds;
	   		                	 
	   		                	 // for temperature
	   		                	$scope.graphPlots[0] = $scope.graphPlots[1];
	   		                	$scope.graphPlots[1] = $scope.graphPlots[2];
	   		                	$scope.graphPlots[2] = $scope.graphPlots[3];
	   		                	$scope.graphPlots[3] = $scope.graphPlots[4];
	   		                	$scope.graphPlots[4] = $scope.graphPlots[5];
	   		                	$scope.graphPlots[5] = $scope.graphPlots[6];
	   		                	$scope.graphPlots[6] = $scope.graphPlots[7];
	   		                	$scope.graphPlots[7] = $scope.graphPlots[8];
	   		                	$scope.graphPlots[8] = $scope.graphPlots[9];
	   		                	$scope.graphPlots[9] = $scope.graphPlots[10];
	   		                	$scope.graphPlots[10] = $scope.graphPlots[11];
	   		                	$scope.graphPlots[11] = $scope.graphPlots[12];
	   		                	$scope.graphPlots[12] = $scope.graphPlots[13];
	   		                	$scope.graphPlots[13] = $scope.graphPlots[14];
	   		                	$scope.graphPlots[14] = $scope.graphPlots[15];
	   		                	$scope.graphPlots[15] =$scope.graphPlots[16];
	   		                	$scope.graphPlots[16] =$scope.graphPlots[17];
	   		                	$scope.graphPlots[17] =$scope.graphPlots[18];
	   		                	$scope.graphPlots[18] =$scope.graphPlots[19];
	   		                	$scope.graphPlots[19] =y;
	   		                	
	   		                	// for pressure
	   		                	
	   		                	$scope.pressurePlots[0] = $scope.pressurePlots[1];
	   		                	$scope.pressurePlots[1] = $scope.pressurePlots[2];
	   		                	$scope.pressurePlots[2] = $scope.pressurePlots[3];
	   		                	$scope.pressurePlots[3] = $scope.pressurePlots[4];
	   		                	$scope.pressurePlots[4] = $scope.pressurePlots[5];
	   		                	$scope.pressurePlots[5] = $scope.pressurePlots[6];
	   		                	$scope.pressurePlots[6] = $scope.pressurePlots[7];
	   		                	$scope.pressurePlots[7] = $scope.pressurePlots[8];
	   		                	$scope.pressurePlots[8] = $scope.pressurePlots[9];
	   		                	$scope.pressurePlots[9] = $scope.pressurePlots[10];
	   		                	$scope.pressurePlots[10] = $scope.pressurePlots[11];
	   		                	$scope.pressurePlots[11] = $scope.pressurePlots[12];
	   		                	$scope.pressurePlots[12] = $scope.pressurePlots[13];
	   		                	$scope.pressurePlots[13] = $scope.pressurePlots[14];
	   		                	$scope.pressurePlots[14] = $scope.pressurePlots[15];
	   		                	$scope.pressurePlots[15] =$scope.pressurePlots[16];
	   		                	$scope.pressurePlots[16] =$scope.pressurePlots[17];
	   		                	$scope.pressurePlots[17] =$scope.pressurePlots[18];
	   		                	$scope.pressurePlots[18] =$scope.pressurePlots[19];
	   		                	$scope.pressurePlots[19] =z;
	   		                	
	   		                	// for  P48SEL
	   		                	$scope.P48SELPlots[0] = $scope.P48SELPlots[1];
	   		                	$scope.P48SELPlots[1] = $scope.P48SELPlots[2];
	   		                	$scope.P48SELPlots[2] = $scope.P48SELPlots[3];
	   		                	$scope.P48SELPlots[3] = $scope.P48SELPlots[4];
	   		                	$scope.P48SELPlots[4] = $scope.P48SELPlots[5];
	   		                	$scope.P48SELPlots[5] = $scope.P48SELPlots[6];
	   		                	$scope.P48SELPlots[6] = $scope.P48SELPlots[7];
	   		                	$scope.P48SELPlots[7] = $scope.P48SELPlots[8];
	   		                	$scope.P48SELPlots[8] = $scope.P48SELPlots[9];
	   		                	$scope.P48SELPlots[9] = $scope.P48SELPlots[10];
	   		                	$scope.P48SELPlots[10] = $scope.P48SELPlots[11];
	   		                	$scope.P48SELPlots[11] = $scope.P48SELPlots[12];
	   		                	$scope.P48SELPlots[12] = $scope.P48SELPlots[13];
	   		                	$scope.P48SELPlots[13] = $scope.P48SELPlots[14];
	   		                	$scope.P48SELPlots[14] = $scope.P48SELPlots[15];
	   		                	$scope.P48SELPlots[15] =$scope.P48SELPlots[16];
	   		                	$scope.P48SELPlots[16] =$scope.P48SELPlots[17];
	   		                	$scope.P48SELPlots[17] =$scope.P48SELPlots[18];
	   		                	$scope.P48SELPlots[18] =$scope.P48SELPlots[19];
	   		                	$scope.P48SELPlots[19] = w;
	   		                 }
	   		                 i++;
	   		              
                        }, 1000);
                    }
                }
            },
            title: {
                text: 'Engine Data'
            },
            xAxis: {
                type: 'datetime',
                tickPixelInterval: 150
            },
            yAxis: {
                title: {
                    text: 'Value'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.series.name + '</b><br/>' +
                        Highcharts.dateFormat('%Y-%m-%d %H:%M:%S', this.x) + '<br/>' +this.y;
                       //Highcharts.numberFormat(this.y);
                }
            	
            },
            legend: {
                enabled: false
            },
            exporting: {
                enabled: false
            },
            series: [
	                 {
		                name: 'MWSEL',
		                data:[],
		                zones: [{
			                color: 'red'
			            }, {
			                value: 6,
			                color: '#0080FF'
			            },{
			                color: '#33CC33'
			            }]
		                     },
	                 {
		                name: 'T48SEL',
		                data:[],
		                zones: [{
			                color: 'red'
			            }, {
			                value: 6,
			                color: '#0080FF'
			            },{
			                color: '#33CC33'
			            }]
	                  },
	                  {
			                name: 'P48SEL',
			                data:[],
			                zones: [{
				                color: 'red'
				            }, {
				                value: 6,
				                color: '#0080FF'
				            },{
				                color: '#33CC33'
				            }]
		                  }
            ]
        });
		
	}
	
	$scope.changeEngineNumber = function(engineNumber){
		
		$scope.changedEnginedNumber = engineNumber;
		
		console.log("inside changeEngineNumber value is::"+$scope.changedEnginedNumber);
	}
	
	$scope.hideTempThreshold = true;
	$scope.hidePressureThreshold = true;
	$scope.hideP48SELThreshold = true;
	$scope.changeTempThreshold = function(data,type){
		
		if(angular.equals(type,"TEMP")){
			$scope.temperatureLowThreshold = data;
			$scope.hideTempThreshold = false;
		}else if(angular.equals(type,"PRESSURE")){
			$scope.pressureLowThreshold  = data;
			 $scope.hidePressureThreshold = false;
		}else if(angular.equals(type,"P48SEL")){
			$scope.PS3SELThreshold  = data;
			 $scope.hideP48SELThreshold = false;
		}
	}
	
	$scope.saveThreshold = function(){
		
		$scope.hideTempThreshold = true;
		$scope.hidePressureThreshold = true;
		 $scope.hideP48SELThreshold = true;
	}
	
}];