var mapCtrl = ['$scope',
                '$rootScope',
                '$location',
                '$routeParams',
                '$http',
                '$route',
                function($scope,
               		 $rootScope,
               		 $location,
               		 $routeParams,
               		 $http,
               		 $route){
	
	console.log("entering map controller::"+$rootScope.authenticated);
	$scope.validLogin = false;
	$scope.validLogin = $rootScope.authenticated;
	
	$scope.init_map = function(){
		
		var var_location = new google.maps.LatLng(45.430817,12.331516);
		 
        var var_mapoptions = {
          center: var_location,
          zoom: 14
        };
 
		var var_marker = new google.maps.Marker({
			position: var_location,
			map: var_map,
			title:"Venice"});
 
        var var_map = new google.maps.Map(document.getElementById("map-container"),
            var_mapoptions);
 
		var_marker.setMap(var_map);	
 	
	}
}]