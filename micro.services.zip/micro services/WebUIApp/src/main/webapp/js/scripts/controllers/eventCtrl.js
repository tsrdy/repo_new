/*angular.module('myApp.controllers',[])

angular.module('myApp.controllers').controller('eventCtrl',function($rootScope, $scope, $http, $location) {

		console.log("entering event controller::"+$rootScope.authenticated);
		$scope.validLogin = false;
		$scope.validLogin = $rootScope.authenticated;
		
		console.log("event controller called::");
		
		
		$http.get('event/').success(function(data) {
			$scope.greeting = data;
		})
	
});*/

var eventCtrl = ['$scope',
                 '$rootScope',
                 '$location',
                 '$routeParams',
                 '$http',
                 '$route',
                 function($scope,
                		 $rootScope,
                		 $location,
                		 $routeParams,
                		 $http,
                		 $route){
	
	console.log("entering event controller::"+$rootScope.authenticated);
	$scope.authenticated = false;
	$scope.authenticated = $rootScope.authenticated;
	
	console.log("event controller called::");
	
	
	/*$http.get('event/').success(function(data) {
		$scope.greeting = data;
	})*/
	
}]
