/*angular.module('myApp.controllers', []);

angular.module('myApp.controllers').controller('loginCtrl',[ '$rootScope', '$scope', '$http', '$location', '$route' ,function($rootScope, $scope, $http, $location, $route) {

	$scope.loginUserName = '';
    $scope.sso1 = "501211111";
    $scope.sso2 = "501212222";
    $scope.sso3 = "501213333";
    $scope.invalidLogin = false;
    $scope.authenticated = false;
   
    
    $scope.validateLogin = function(){
    	
      
       if(angular.equals($scope.loginUserName, $scope.sso1) || angular.equals($scope.loginUserName, $scope.sso2) || angular.equals($scope.loginUserName, $scope.sso3)){
              $scope.invalidLogin = false;
              if(angular.equals($scope.loginUserName, $scope.sso1)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $location.path("/event");
            	  //$window.location.href = "/home.html"
              }else if(angular.equals($scope.loginUserName, $scope.sso2)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $location.path("/home");
              }else if(angular.equals($scope.loginUserName, $scope.sso3)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $location.path("/home");
              }
              //window.location.replace("../multipage/home.html");
              // $window.location.href= "../multipage/home.html?userLoggedIn="+username;
             
       }
       else{
              $scope.invalidLogin = true;
       }
    };
}])*/

var loginCtrl = ['$scope',
                 '$rootScope',
                 '$location',
                 '$routeParams',
                 '$http',
                 '$route',
                 function($scope,
                		 $rootScope,
                		 $location,
                		 $routeParams,
                		 $http,
                		 $route){
	
	
	$scope.loginUserName = '';
    $scope.sso1 = "501211111";
    $scope.sso2 = "501212222";
    $scope.sso3 = "501213333";
    $scope.invalidLogin = false;
    $scope.authenticated = false;
   
    
    $scope.validateLogin = function(){
    	
      
       if(angular.equals($scope.loginUserName, $scope.sso1) || angular.equals($scope.loginUserName, $scope.sso2) || angular.equals($scope.loginUserName, $scope.sso3)){
              $scope.invalidLogin = false;
              if(angular.equals($scope.loginUserName, $scope.sso1)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $rootScope.loginSSO = $scope.loginUserName;
            	  //$location.path("/outageDashboard/"+$scope.loginUserName);
            	  $location.path("/outageDashboard");
            	  //$window.location.href = "/home.html"
              }else if(angular.equals($scope.loginUserName, $scope.sso2)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $location.path("/home");
              }else if(angular.equals($scope.loginUserName, $scope.sso3)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $location.path("/home");
              }
              //window.location.replace("../multipage/home.html");
              // $window.location.href= "../multipage/home.html?userLoggedIn="+username;
             
       }
       else{
              $scope.invalidLogin = true;
              $scope.authenticated = false;
       }
    };
    
	
}]