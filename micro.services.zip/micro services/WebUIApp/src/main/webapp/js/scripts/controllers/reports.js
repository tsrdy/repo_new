var reportsCtrl = ['$scope',
                '$rootScope',
                '$location',
                '$routeParams',
                '$http',
                '$route',
                '$resource',
                '$timeout',
                '$q',
                '$window',
                '$interval',
                function($scope,
               		 $rootScope,
               		 $location,
               		 $routeParams,
               		 $http,
               		 $route,
               		 $resource,
               		$timeout,
               		$q,
               		$window,
               		$interval){
	
	console.log("reports controller user logged in:"+$rootScope.loginSSO)
	
	
	$http.get('getSearchOptions/').success(function(data) {
		console.log("calling PARTS-SEARCH-OPTIONS under reports controller");
		console.log("PARTS-SEARCH-OPTIONS response::"+angular.toJson(data));
		$scope.searchOptionsData = data;
		
		$scope.engineFamiliyDetailsList = $scope.searchOptionsData.engineDetailsList;
		$scope.yearsList = $scope.searchOptionsData.yearsList;
		$scope.partsCategoriesList = $scope.searchOptionsData.partCategoriesList;
		$scope.regionDetailsList = $scope.searchOptionsData.regionDetailsList;
		$scope.distributorDetailsList = $scope.searchOptionsData.distributorDetailsList;
		
		$scope.regionSelected = $scope.regionDetailsList[0].regionName;
		$scope.distributorSelected = $scope.distributorDetailsList[0].distributorName;
		$scope.partCategorySelected = $scope.partsCategoriesList[0].categoryName;
		$scope.engineFamilySelected = $scope.engineFamiliyDetailsList[0].engineFamilyType;
		$scope.yearSelected = $scope.yearsList[0];
	});
	
	
	$scope.setUpdated = function(data,type){
		
		if(angular.equals(type,"REGION")){
			
			$scope.regionSelected = data;
			console.log("regionselected is::"+$scope.regionSelected);
		}else if(angular.equals(type,"DISTRIBUTOR")){
			
			$scope.distributorSelected = data;
			console.log("distributorSelected is::"+$scope.distributorSelected);
		}else if(angular.equals(type,"PARTCATEGORY")){
			
			$scope.partCategorySelected = data;
			console.log("partCategorySelected is::"+$scope.partCategorySelected);
		}else if(angular.equals(type,"YEARS")){
			
			$scope.yearSelected = data;
			console.log("yearSelected is::"+$scope.yearSelected);
		}else if(angular.equals(type,"ENGINECATEGORY")){
			
			$scope.engineFamilySelected = data;
			console.log("engineFamilySelected is::"+$scope.engineFamilySelected);
		}
	}
	
	
	$scope.displayData = false;
	$scope.objRegionalStatsData;
	$scope.objMarketShareData;
	$scope.objtop20PartsData;
	$scope.objbottom20PartsData;
	$scope.generateReport = function(){
		$scope.displayData = false;
		$http.get('partsReport/').success(function(data) {
			
			$scope.compositePartsResponse = data;
			console.log("composite response from PARTS-COMPOSITE-SERVICE::"+angular.toJson($scope.compositePartsResponse));
			
			$scope.objRegionalStatsData = $scope.compositePartsResponse.objRegionalStats;
			$scope.objMarketShareData = $scope.compositePartsResponse.objMarketShareList;
			$scope.objtop20PartsData = $scope.compositePartsResponse.objtop20PartsList;
			$scope.objbottom20PartsData = $scope.compositePartsResponse.objbottom20PartsList;
			
			$scope.generateMarketShareGraph($scope.objMarketShareData)
			$scope.displayData = true;
		});
	}
	
	$scope.generateMarketShareGraph = function(data){
		
		$scope.organizations=[];
		$scope.yearOne=[];
		$scope.yearTwo=[];
		$scope.yearThree=[];
		
		if(angular.isArray(data)){
			
			for(var counter in data){
				
				$scope.organizations.push(data[counter].orgName);
				$scope.yearOne.push(data[counter].year1Share);
				$scope.yearTwo.push(data[counter].year2Share);
				$scope.yearThree.push(data[counter].year3Share);
				
			}
		}
		
		console.log("organizations data is::"+$scope.organizations);
		/*$scope.marketShareChartData = {
		 		 title: {
		 			text: 'MarketShare'
			        },
			        options: {
			            chart: {
			            	renderTo: 'marketShareContainer',
			                type: 'column'
			            },
			            plotOptions: {
				            column: {
				                stacking: 'percent'
				            }
				        }
			        },
			        series: [ {
					    name: '2009',
					    data: $scope.yearOne
					  }, {
					    name: '2010',
					    data: $scope.yearTwo
					  },{
						  name: '2011',
						    data: $scope.yearThree
						  }],
					  xAxis: {
						    title: {
						      text: 'hello'
						    },
						    categories: $scope.organizations
						  },
					yAxis: {
								min: 0,
					            title: {
					                text: 'Total Percentile'
					            }
							},
			        loading: false
			    }
		*/
		
		chart = new Highcharts.Chart({
			chart: {
				renderTo :'marketShareContainer',
	            type: 'column',
	        },
	        title: {
	            text: 'Stacked column chart'
	        },
	        xAxis: {
	            categories: $scope.organizations
	        },
	        yAxis: {
	            min: 0,
	            title: {
	                text: 'Total Percentile'
	            }
	        },
	        tooltip: {
	            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
	            shared: true
	        },
	        plotOptions: {
	            column: {
	                stacking: 'percent'
	            }
	        },
	        series: [{
	            name: '2009',
	            data: $scope.yearOne
	        }, {
	            name: '2010',
	            data: $scope.yearTwo
	        }, {
	            name: '2011',
	            data: $scope.yearThree
	        }]
		});
	}
}];