/*angular.module('myApp', [ 'ngRoute' ]).config(function($routeProvider, $httpProvider) {

	$routeProvider.when('/', {
		templateUrl : 'home.html',
		controller : 'home'
	}).when('/login', {
		templateUrl : 'login.html',
		controller : 'navigation'
	}).when('/event', {
		templateUrl : 'event.html',
		controller : 'event'
	}).when('/event/:param', {
		templateUrl : 'EventList.html',
		controller : 'eventOnId'
	}).otherwise('/');

	$routeProvider.when('/home', {
		templateUrl : 'home.html',
		controller : 'home'
	}).when('/', {
		templateUrl : 'login.html',
		controller : 'navigation'
	}).when('/event', {
		templateUrl : 'event.html',
		controller : 'event'
	}).when('/event/:param', {
		templateUrl : 'EventList.html',
		controller : 'eventOnId'
	}).otherwise('/');
	$httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

}).controller('navigation',

function($rootScope, $scope, $http, $location, $route,$window) {

	$scope.tab = function(route) {
		return $route.current && route === $route.current.controller;
	};

	var authenticate = function(credentials, callback) {

		var headers = credentials ? {
			authorization : "Basic "
					+ btoa(credentials.username + ":"
							+ credentials.password)
		} : {};

		$http.get('user', {
			headers : headers
		}).success(function(data) {
			if (data.name) {
				$rootScope.authenticated = true;
			} else {
				$rootScope.authenticated = false;
			}
			callback && callback();
		}).error(function() {
			$rootScope.authenticated = false;
			callback && callback();
		});

	}

	authenticate();

	$scope.credentials = {};
	$scope.login = function() {
		authenticate($scope.credentials, function() {
			if ($rootScope.authenticated) {
				console.log("Login succeeded")
				$location.path("/event");
				$scope.error = false;
				$rootScope.authenticated = true;
			} else {
				console.log("Login failed")
				$location.path("/login");
				$scope.error = true;
				$rootScope.authenticated = false;
			}
		})
	};

	$scope.logout = function() {
		$http.post('logout', {}).success(function() {
			$rootScope.authenticated = false;
			$location.path("/");
		}).error(function(data) {
			console.log("Logout failed")
			$rootScope.authenticated = false;
		});
	}
	
	
    $scope.loginUserName = '';
    $scope.sso1 = "501211111";
    $scope.sso2 = "501212222";
    $scope.sso3 = "501213333";
    $scope.invalidLogin = false;
    $scope.authenticated = false;
   
    
    $scope.validateLogin = function(){
    	
      
       if(angular.equals($scope.loginUserName, $scope.sso1) || angular.equals($scope.loginUserName, $scope.sso2) || angular.equals($scope.loginUserName, $scope.sso3)){
              $scope.invalidLogin = false;
              if(angular.equals($scope.loginUserName, $scope.sso1)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $location.path("/event");
            	  //$window.location.href = "/home.html"
              }else if(angular.equals($scope.loginUserName, $scope.sso2)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $location.path("/home");
              }else if(angular.equals($scope.loginUserName, $scope.sso3)){
            	  $scope.authenticated = true;
            	  $rootScope.authenticated = $scope.authenticated;
            	  $location.path("/home");
              }
              //window.location.replace("../multipage/home.html");
              // $window.location.href= "../multipage/home.html?userLoggedIn="+username;
             
       }
       else{
              $scope.invalidLogin = true;
       }
    };
      
   
  

}).controller('home', function($scope, $http,$rootScope) {
	
	console.log("entering home controller::"+$rootScope.authenticated);
	$scope.validLogin = false;
	$scope.validLogin = $rootScope.authenticated;
	$http.get('resource/').success(function(data) {
		$scope.greeting = data;
	})
}).controller('event', function($scope, $http,$rootScope) {
	
	console.log("entering event controller::"+$rootScope.authenticated);
	$scope.validLogin = false;
	$scope.validLogin = $rootScope.authenticated;
	
	console.log("event controller called::");
	
	
	$http.get('event/').success(function(data) {
		$scope.greeting = data;
	})
	
	
}).controller('eventOnId', function($scope, $http,$routeParams) {
	
	var self =this;
	self.param = $routeParams.param;
	console.log("eventOnId controller called::"+self.param);
	$http.get('event/'+self.param).success(function(data) {
		$scope.eventListData = data;
		console.log("value from respone for event::"+angular.toJson($scope.eventListData));
	})
});*/

'use strict';

// Declare app level module which depends on views, and components
var myApp= angular.module('myApp', ['ngRoute','ngResource','app.directives','highcharts-ng','tc.chartjs'])

.run(function() {
   //...

})
.config(function() {
  //...
});