define(['./basicModel.js'], function (BasicModel) {
    var model1 = new BasicModel('Dashboard', '50%');
    return model1;
});
