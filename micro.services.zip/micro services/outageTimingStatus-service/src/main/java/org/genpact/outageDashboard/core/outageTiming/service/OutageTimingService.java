package org.genpact.outageDashboard.core.outageTiming.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.genpact.outageDashboard.core.outageTiming.model.OutageTimingStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Rajesh on 2-Sep-15
 *
 */


@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class OutageTimingService {
	
    private static final Logger LOG = LoggerFactory.getLogger(OutageTimingService.class);

    
    /**
     * 
     * @param ssoID
     * @return
     */
    
    
    @RequestMapping("/outageTimingStatus/{ssoID}")	
	public List<OutageTimingStatus> getOutageTypeSummary(@PathVariable int ssoID){
		
    	List<OutageTimingStatus> timingList = new ArrayList<OutageTimingStatus>();
    	
    	timingList.add(new OutageTimingStatus("On Time", 3));
    	timingList.add(new OutageTimingStatus("Overdue", 14));
    	timingList.add(new OutageTimingStatus("Completed",80));
    	
    	return timingList;
    	
		
	}

}
