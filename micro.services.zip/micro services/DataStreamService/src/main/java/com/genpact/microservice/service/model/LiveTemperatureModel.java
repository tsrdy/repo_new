package com.genpact.microservice.service.model;

public class LiveTemperatureModel {

	private String timePeriod;
	private int temperature;
	private int temperature1;
	
	public String getTimePeriod() {
		return timePeriod;
	}
	public void setTimePeriod(String timePeriod) {
		this.timePeriod = timePeriod;
	}
	public int getTemperature() {
		return temperature;
	}
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}
	
	
	public int getTemperature1() {
		return temperature1;
	}
	public void setTemperature1(int temperature1) {
		this.temperature1 = temperature1;
	}
	public LiveTemperatureModel(String timePeriod, int temperature,int temperature1) {
		super();
		this.timePeriod = timePeriod;
		this.temperature = temperature;
		this.temperature1 = temperature1;
	}
	
	
}
