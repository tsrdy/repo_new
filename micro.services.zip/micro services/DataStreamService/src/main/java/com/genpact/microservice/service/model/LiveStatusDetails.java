package com.genpact.microservice.service.model;

public class LiveStatusDetails {

	/*//private int hours;
	private int minutes;
	//private int seconds;
	private int temperature;
	private double pressure;*/
	
	private double powerOutputMWSEL;
	private double combustorExhaustT48SEL;
	private double hpcDischargePressurePS3SEL;
	
	
	
	
	public double getPowerOutputMWSEL() {
		return powerOutputMWSEL;
	}
	public void setPowerOutputMWSEL(double powerOutputMWSEL) {
		this.powerOutputMWSEL = powerOutputMWSEL;
	}
	public double getCombustorExhaustT48SEL() {
		return combustorExhaustT48SEL;
	}
	public void setCombustorExhaustT48SEL(double combustorExhaustT48SEL) {
		this.combustorExhaustT48SEL = combustorExhaustT48SEL;
	}
	public double getHpcDischargePressurePS3SEL() {
		return hpcDischargePressurePS3SEL;
	}
	public void setHpcDischargePressurePS3SEL(double hpcDischargePressurePS3SEL) {
		this.hpcDischargePressurePS3SEL = hpcDischargePressurePS3SEL;
	}
	
	/*public int getMinutes() {
		return minutes;
	}
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}
	
	public int getTemperature() {
		return temperature;
	}
	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}
	public double getPressure() {
		return pressure;
	}
	public void setPressure(double pressure) {
		this.pressure = pressure;
	}
	*/
	public LiveStatusDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	/*public LiveStatusDetails(int minutes, int temperature, double pressure) {
		super();
		this.minutes = minutes;
		this.temperature = temperature;
		this.pressure = pressure;
	}*/
	
	public LiveStatusDetails(double powerOutputMWSEL,
			double combustorExhaustT48SEL, double hpcDischargePressurePS3SEL) {
		super();
		this.powerOutputMWSEL = powerOutputMWSEL;
		this.combustorExhaustT48SEL = combustorExhaustT48SEL;
		this.hpcDischargePressurePS3SEL = hpcDischargePressurePS3SEL;
	}
	
	
	
	
}
