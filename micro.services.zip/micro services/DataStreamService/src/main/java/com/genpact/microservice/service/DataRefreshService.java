package com.genpact.microservice.service;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.genpact.microservice.service.DAO.TemperatureDAOImpl;
import com.genpact.microservice.service.model.LiveStatusDetails;

@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class DataRefreshService {

	public static int counter =0;
	 @RequestMapping("/")
	    public String  getRefreshedData(){
		 
		 long numbervalue = (long)(Math.round(Math.random() * 99));
		 String data ="Hello new Number"+numbervalue;
		 return data;
	 }
	 
	 /*@RequestMapping("/dataRefresh/{ssoId}")
	    public RandomDataModel  getRefreshedData(@PathVariable String ssoId){
		 counter++;
		
		 RandomDataModel randomDataModel = new RandomDataModel();
		 Long numbervalue = Math.round(Math.random() * 99);
		 int number = numbervalue.intValue();
		 randomDataModel.setRandomNumber(number);
		 return randomDataModel;
	 }*/
	 
	 /*@RequestMapping("/dataRefresh/{ssoId}")
	    public LiveStatusDetails  getRefreshedData(@PathVariable String ssoId){
		 
		 
		 TemperatureDAOImpl temperatureDAOImpl = new TemperatureDAOImpl();
		 LiveStatusDetails tempObject = temperatureDAOImpl.getTimeAndTemperature(counter);
		 counter++;
		 return tempObject;
		 
	 }*/
	 
	 	@RequestMapping("/dataRefresh/{engineNumber}")
	    public LiveStatusDetails  getRefreshedData(@PathVariable String engineNumber){
		 
		 
		 TemperatureDAOImpl temperatureDAOImpl = new TemperatureDAOImpl();
		 LiveStatusDetails tempObject = temperatureDAOImpl.getTimeAndTemperature(counter,engineNumber);
		 counter++;
		 return tempObject;
		 
	 }
}
