package com.genpact.microservice.service.model;

public class RandomDataModel {

	//private String time;
	private int randomNumber;
	
	
	public int getRandomNumber() {
		return randomNumber;
	}
	public void setRandomNumber(int randomNumber) {
		this.randomNumber = randomNumber;
	}
	
	
	
}
