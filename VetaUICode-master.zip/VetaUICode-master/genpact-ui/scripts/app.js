/** global angular, require */
/**
 * Load controllers, directives, filters, services before bootstrapping the application.
 * NOTE: These are named references that are defined inside of the config.js RequireJS configuration file.
 */
define([
    'jquery',
    'angular',
    'main',
    'controllers/main',
    'services/main',
    'routes',
    'interceptors',
    'px-datasource'
], function ($, angular,controllers,routes) {
    'use strict';

    /**
     * Application definition
     * This is where the AngularJS application is defined and all application dependencies declared.
     * @type {module}
     */
    var predixApp = angular.module('predixApp', [
        'app.routes',
        'app.interceptors',
        'app.controllers',
        'app.services',
        'sample.module',
        'predix.datasource'
    ]);

    predixApp.run([
        '$rootScope',
        '$state','$stateParams',function ($rootScope, $state, $stateParams) {
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
        }]);
    /**
     * Main Controller
     * This controller is the top most level controller that allows for all
     * child controllers to access properties defined on the $rootScope.
     */
    predixApp.controller('MainCtrl', ['$scope', '$rootScope','$location', function ($scope, $rootScope,$location) {

        console.log("entered mainctrl code");
        //Global application object
        window.App = $rootScope.App = {
            version: '1.0',
            name: 'VetaUI',
            session: {},
            tabs: [
                {icon: 'fa-home', state: 'home', label: 'home',link:'#/home'},
                {icon: 'fa-home', state: 'technicalModelling', label: 'technical-modelling',link:'#/technicalModelling'}
            ]
        };


        $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
            if (angular.isObject(error) && angular.isString(error.code)) {
                switch (error.code) {
                    case 'UNAUTHORIZED':
                        //redirect
                        predixUserService.login(toState);
                        break;
                    default:
                    //go to other error state
                }
            }
            else {
                // unexpected error
            }
        });

        $scope.tabClass = function(tab) {
            if ("#" + $location.path() == tab.link) {
                return "active";
            } else {
                return "";
            }
        };

        $.noConflict();

        $('.main-nav li').click(function(){
            $('.main-nav li').removeClass('selected'); // remove selected from any other item first
            $(this).addClass('selected'); //add selected to the one just clicked.
        });
        $scope.navOpen=true;
        $(".nav-icon").click(function(){
            if($scope.navOpen==true){
                $(".left-pane").addClass("nav-left-min");
                $(".nav-item").addClass("nav-item-min");
                $(".nav-item-min").removeClass("nav-item");
                $(".right-pane").removeClass("col-md-10");
                $(".right-pane").addClass("nav-right-max");
                $scope.navOpen=!$scope.navOpen;
            }
            else{

                $(".left-pane").removeClass("nav-left-min");
                $(".nav-item-min").addClass("nav-item");
                $(".nav-item").removeClass("nav-item-min");
                $(".right-pane").removeClass("nav-right-max");
                $(".right-pane").addClass("col-md-10");
                $scope.navOpen=!$scope.navOpen;
            }

        });

    }]);


    //Set on window for debugging
    window.predixApp = predixApp;

    //Return the application  object
    return predixApp;
});
