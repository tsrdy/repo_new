/**
 * Router Config
 * This is the router definition that defines all application routes.
 */
/*global define */
define(['angular', 'angular-ui-router'], function(angular) {
    'use strict';
    return angular.module('app.routes', ['ui.router']).config(['$stateProvider', '$urlRouterProvider', '$locationProvider',function($stateProvider, $urlRouterProvider, $locationProvider) {

        //Turn on or off HTML5 mode which uses the # hash
        //$locationProvider.html5Mode(true).hashPrefix('!');
        $locationProvider.html5Mode(false);
        console.log("hello routes");
        /**
         * Router paths
         * This is where the name of the route is matched to the controller and view template.
         */
        $stateProvider
            .state('secure', {
                template: '<ui-view/>',
                abstract: true,
                resolve: {
                    authenticated: ['$q', 'PredixUserService', function ($q, predixUserService) {
                        var deferred = $q.defer();
                        predixUserService.isAuthenticated().then(function(userInfo){
                            deferred.resolve(userInfo);
                        }, function(){
                            deferred.reject({code: 'UNAUTHORIZED'});
                        });
                        return deferred.promise;
                    }]
                }
            })
            .state('home', {
                parent: 'secure',
                url: '/home',
                templateUrl: 'views/home.html',
                controller:'homeCtrl'
            })
            .state('technicalModelling', {
                parent: 'secure',
                url: '/technicalModelling',
                templateUrl: 'views/technical-modelling.html',
                controller:'technicalModellingCtrl'
            })
            .state('contractDetails', {
                parent: 'secure',
                url: '/contractDetails/:quoteID',
                templateUrl: 'views/contract-details.html',
                controller:'contractDetailsCtrl'
            })
            .state('partInfo', {
                parent: 'secure',
                url: '/partInfo/:quoteID',
                templateUrl: 'views/part-info.html',
                controller:'partInfoCtrl'
            })
            .state('failureInfo', {
                parent: 'secure',
                url: '/failureInfo/:quoteID',
                templateUrl: 'views/failure-info.html',
                controller:'failureInfoCtrl'
            })
            .state('ppfInfo', {
                parent: 'secure',
                url: '/ppfInfo/:quoteID',
                templateUrl: 'views/ppf_fm_info.html',
                controller:'ppfInfoCtrl'
            })
            .state('costInfo', {
                parent: 'secure',
                url: '/costInfo/:quoteID/:costTypeSelected',
                templateUrl: 'views/cost-info.html',
                controller:'costInfoCtrl'
            })
            .state('engineService', {
                parent: 'secure',
                url: '/engineService/:quoteID',
                templateUrl: 'views/engine-service.html',
                controller:'engineServiceCtrl'
            })
            .state('output', {
                parent: 'secure',
                url: '/output',
                templateUrl: 'views/output.html',
                controller:'outputCtrl'
            })
         .state('scenarioManager', {
                parent: 'secure',
                url: '/scenarioManager',
                templateUrl: 'views/scenario-manager.html',
                controller:'scenarioManagerCtrl'
            })
            .state('about', {
                url: '/about',
                templateUrl: 'views/about.html'
            })

       $urlRouterProvider
            .otherwise('home');
    }]);
});
