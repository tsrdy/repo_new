define(['angular','jquery','highcharts','exporting','controllers-module'],
    function (angular,jquery,highcharts,exporting,controllers) {
    'use strict';

    // Controller definition
    controllers.controller('scenarioManagerCtrl',
        ['$scope', '$rootScope','$http', '$log', '$location',
            '$stateParams',
            function ($scope,$rootScope,$http, $log , $location ,
                      $stateParams) {



                $('a[data-toggle="collapse"]').on('click', function() {
                    var objectID = $(this).attr('id');
                    if ($(objectID).hasClass('in')) {
                        $(objectID).collapse('hide');
                    } else {
                        $(objectID).collapse('show');
                    }
                });

                $('#expandAll').on('click', function() {

                    $('a[data-toggle="collapse"]').each(function() {
                        var objectID = $(this).attr('href');
                        if ($(objectID).hasClass('in') === false) {
                            $(objectID).collapse('show');
                        }
                    });
                });

                $('#collapseAll').on('click', function() {

                    $('a[data-toggle="collapse"]').each(function() {
                        var objectID = $(this).attr('href');
                        $(objectID).collapse('hide');
                    });
                });

                $(function() {
                    var chart = new Highcharts.Chart({
                        credits: {
                            enabled: false
                        },
                        itemHoverStyle: {
                            color: '#000'
                        },
                        chart: {
                            type: 'line',
                            renderTo: 'SVStream',
                            borderWidth: 1,
                            height: 250,
                            borderColor: '#cccccc',
                            animation: true,

                        },
                        shadow: {
                            color: 'yellow',
                            width: 10,
                            offsetX: 0,
                            offsetY: 0
                        },
                        title: {
                            text: 'SV Stream',
                            x: -20, //center,
                            style: {
                                color: 'black'
                            }
                        },
                        subtitle: {
                            text: '',
                            x: -20
                        },
                        xAxis: {
                            labels: {
                                style: {
                                    color: 'black'  //left label color
                                }
                            },
                            gridLineColor: '#d3d3d3',   //horizontal lines color
                            categories: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
                        },
                        yAxis: {
                            labels: {
                                style: {
                                    color: 'black'  //left label color
                                }
                            },
                            gridLineColor: '#d3d3d3',   //horizontal lines color

                            title: {
                                text: ''
                            },
                            plotLines: [{
                                value: 0.00,
                                width: 1,
                                color: '#808080'
                            }]
                        },
                        tooltip: {
                            valueSuffix: ''
                        },
                        legend: {
                            layout: 'vertical',
                            align: 'right',
                            verticalAlign: 'middle',
                            borderWidth: 0
                        },
                        series: [{
                            name: 'SV Stream',
                            data: [1.7, 5.1, 2.3, 4, 5.1, 1.1, 2.3, 2.9, 1.1, 1.1, 1.1]
                        }]
                    });

                    var chart1 = new Highcharts.Chart({

                        credits:{
                            enabled:false
                        },
                        chart: {
                            type: 'line',
                            renderTo: 'DBStream',
                            borderWidth:1,
                            height:250,
                            borderColor:'#cccccc',
                        },
                        title: {
                            text: 'DB Stream',
                            x: -20 //center
                        },
                        subtitle: {
                            text: '',
                            x: -20
                        },
                        xAxis: {
                            categories: [1,2,3,4,5,6,7,8,9,10,11,12]
                        },
                        yAxis: {
                            title: {
                                text: 'Cost $'
                            },
                            plotLines: [{
                                value: 0,
                                width: 1,
                                color: '#808080'
                            }]
                        },
                        tooltip: {
                            valueSuffix: '$'
                        },
                        legend: {
                            layout: 'vertical',
                            align: 'right',
                            verticalAlign: 'middle',
                            borderWidth: 0
                        },
                        series: [{
                            name: 'Current',
                            data: [-1, -1.2, 2.2, -1.4, -0.2, 0.5, 0.5, 0.5, 0.5,  0.7, -0.8, 0.0]
                        },
                            {
                                name: '2nd Best',
                                data: [-1, -1.2, 0.6, -1.4, -0.2, -0.2, -0.2, -0.2, -0.2, 0.4, -0.8, 0.0]
                            },
                            {
                                name: 'Best',
                                data: [-1, -1.2, 0.5, -1.4, -0.2, -0.2, -0.2, -0.2, -0.2, 0.2, -0.8, 0.0]
                            },
                            {
                                name: 'Worst',
                                data: [-1, -1.2, 2.3, -1.4, -0.2, -0.2, -0.2, -0.2, -0.2, 0.2, -0.8, 0.0]
                            }]

                    });

                    var chart2 = new Highcharts.Chart({
                        credits:{
                            enabled:false
                        },
                        chart: {
                            type: 'line',
                            renderTo: 'CFStream',
                            borderWidth:1,
                            height:250,
                            borderColor:'#cccccc',
                        },
                        title: {
                            text: 'CF Stream',
                            x: -20 //center
                        },
                        subtitle: {
                            text: '',
                            x: -20
                        },
                        xAxis: {
                            categories: [1,2,3,4,5,6,7,8,9,10,11,12]
                        },
                        yAxis: {
                            title: {
                                text: 'Cost $'
                            },
                            plotLines: [{
                                value: 0,
                                width: 1,
                                color: '#808080'
                            }]
                        },
                        tooltip: {
                            valueSuffix: '$'
                        },
                        legend: {
                            layout: 'vertical',
                            align: 'right',
                            verticalAlign: 'middle',
                            borderWidth: 0
                        },
                        series: [{
                            name: 'Current',
                            data: [-1, -1.2, 2.2, -1.4, -0.2, 0.5, 0.5, 0.5, 0.5,  0.7, -0.8, 0.0]
                        },
                            {
                                name: '2nd Best',
                                data: [-1, -1.2, 0.6, -1.4, -0.2, -0.2, -0.2, -0.2, -0.2, 0.4, -0.8, 0.0]
                            },
                            {
                                name: 'Best',
                                data: [-1, -1.2, 0.5, -1.4, -0.2, -0.2, -0.2, -0.2, -0.2, 0.2, -0.8, 0.0]
                            },
                            {
                                name: 'Worst',
                                data: [-1, -1.2, 2.3, -1.4, -0.2, -0.2, -0.2, -0.2, -0.2, 0.2, -0.8, 0.0]
                            }]

                    });
                });
            }]);
});
