define(['./dashboard',
        './data-control',
        './homeCtrl',
        './technicalModellingCtrl',
        './contractDetailsCtrl',
        './partInfoCtrl',
        './failureInfoCtrl',
        './ppfInfoCtrl',
        './costInfoCtrl',
        './engineServiceCtrl',
        './outputCtrl',
        './scenarioManagerCtrl'], function() {

});
