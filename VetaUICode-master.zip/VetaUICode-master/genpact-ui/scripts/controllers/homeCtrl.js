/**
 * Renders all the widgets on the tab and triggers the datasources that are used by the widgets.
 * Customize your widgets by:
 *  - Overriding or extending widget API methods
 *  - Changing widget settings or options
 */
/* jshint unused: false */
define(['angular','highcharts',
    'controllers-module'
], function (angular,highcharts,controllers) {
    'use strict';

    // Controller definition
    controllers.controller('homeCtrl', ['$scope','$http', function ($scope,$http) {

        $scope.message="GE Aviation is a world-leading provider of jet and turboprop engines, components and integrated systems for commercial, military, business and general aviation aircraft, and ship propulsion applications. GE Aviation has a global service network to support these offerings.";
        /*$http.get('http://customerandcontractdataservice.run.aws-usw02-pr.ice.predix.io/getContractList').success(function(result){
            $scope.customerContractDetails=result;
            console.log("result customerContractDetails is::"+angular.toJson( $scope.customerContractDetails));
        })*/
        console.log("Flow in home controller:");

        var chart = new Highcharts.Chart({

            credits:{
                enabled:false
            },
            exporting: { enabled: false },
            tooltip: { enabled: false },
            chart: {
                type: 'line',
                renderTo: 'DelImp',
                borderWidth:0,
                height:300,
                borderColor:'#cccccc',
                animation:false,
            },
            shadow: {
                color: 'yellow',
                width: 10,
                offsetX: 0,
                offsetY: 0
            },
            title: {
                text: 'Risk-Return Spectrum of Customized Service Contracts',
                x: -20, //center,
                style: {
                    color: 'black',
                    fontSize:16
                }
            },
            subtitle: {
                text: '',
                x: -20
            },
            xAxis: {
                labels: {
                    rotation: 0,
                    style: {
                        color: 'black',  //left label color

                    }
                },
                lineColor: 'transparent',
                title: {
                    text: 'Risk Transfer',
                },
                gridLineColor: 'black',   //horizontal lines color
                categories: ["Customer", "", "Business"],
                plotLines: [{
                    value: 0,
                    width: 0,
                    color: '#808080'
                }]
            },
            yAxis: {
                /*categories: ['low','high','low'],*/
                showAxis:false,
                labels: {
                    style: {
                        color: 'black'  //left label color
                    }
                },
                gridLineColor: 'transparent',   //horizontal lines color
                lineColor: '#ff0000',
                title: {
                    text: 'COST PREDICTABILITY ($)',
                },
                plotLines: [{
                    value: 0.00,
                    width: 1,
                    color: '#808080'
                }]
            },

            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                showInLegend:false,
                name: 'SV Stream',
                data: [{ y: 1, color: '#7CB5EC'}, { y: 2, color: '#7CB5EC'}, { y: 3, color: '#7CB5EC'}]
            }]

        });
    }]);
});
