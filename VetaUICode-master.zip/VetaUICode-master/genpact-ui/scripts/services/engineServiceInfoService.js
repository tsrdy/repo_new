/**
 * Created by predix on 1/4/16.
 */
define(['angular', 'services-module'], function (angular, services) {
    'use strict';

    services.factory('engineServiceInfoService', ['$q', '$http', function ($q, $http) {

        var  getEngineServiceInfoData = function(quoteId){
            return $http.get("http://csa-enginedetails-service-new.run.aws-usw02-pr.ice.predix.io/getControlViewInfo?quoteID="+quoteId);
            //return $http.get(testData);

        }


        return {
            getEngineServiceInfoData: getEngineServiceInfoData
        };
    }]);
});
