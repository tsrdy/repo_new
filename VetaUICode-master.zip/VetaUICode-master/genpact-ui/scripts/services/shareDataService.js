myApp.factory('shareDataService', function(){

	/*Share Contract Details*/
	var shareContract={};
    shareContract.contractData=[];
	shareContract.contractDetails=function(cData){
		shareContract.contractData=cData;
	}

	return shareContract;
})