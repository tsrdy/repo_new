/* 
 * AAE Team Grunt automation
 * 
 * Build developer: Chia
 */
module.exports = function (grunt) {
    
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
    });
    
    
    grunt.registerTask('cf-push-ins', 'Running the app in the CF Envs.', function() {

        var _ref,exec=require('child_process').exec,
	    ncb = this.async(),
	    _yml=grunt.file.readYAML('manifest.yml'),
	    _s='cf push '+_yml.applications[0].name +' -c \'node index\' -b https://github.com/cloudfoundry/buildpack-nodejs.git';

	_ref=exec(_s, {}, function(err, stdout, stderr) {
	    console.log('\nStart the '+_yml.applications[0].name+' CF instance');
        });            
	
	_ref.stdout.on('data', function (data) {
            console.log(data);
        });
        
        _ref.stderr.on('data', function (data) {
            console.log(data);
        });
        
        _ref.on('close', function (code) {
            console.log(_yml.applications[0].name+' exited with code ' + code);
            ncb();
        });
    });

    grunt.registerTask('cf-delete-ins', 'Delete the app in the CF Envs.', function() {

        var _ref,exec=require('child_process').exec,
	    ncb = this.async(),
	    _yml=grunt.file.readYAML('manifest.yml'),
	    _s='cf delete -f -r '+_yml.applications[0].name;

	_ref=exec(_s, {}, function(err, stdout, stderr) {
	    console.log('\nDelete the '+_yml.applications[0].name+' CF instance');
        });            
	
	_ref.stdout.on('data', function (data) {
            console.log(data);
        });
        
        _ref.stderr.on('data', function (data) {
            console.log(data);
        });
        
        _ref.on('close', function (code) {
            console.log(_yml.applications[0].name+' exited with code ' + code);
            ncb();
        });
    });

    grunt.registerTask('cf-bind-rabbitmq', 'Binding the app to the rabbitmq instance.', function() {

        var _ref,exec=require('child_process').exec,
	    ncb = this.async(),
	    _yml=grunt.file.readYAML('manifest.yml'),
	    _s='cf bind-service '+_yml.applications[0].name+ ' p-rabbitmq-tokyo';

	_ref=exec(_s, {}, function(err, stdout, stderr) {
	    console.log('\nBind the '+_yml.applications[0].name+' CF instance');
        });            
	
	_ref.stdout.on('data', function (data) {
            console.log(data);
        });
        
        _ref.stderr.on('data', function (data) {
            console.log(data);
        });
        
        _ref.on('close', function (code) {
            console.log(_yml.applications[0].name+' exited with code ' + code);
            ncb();
        });
    });

    grunt.registerTask('cf-restage', 'Restaging the app.', function() {

        var _ref,exec=require('child_process').exec,
	    ncb = this.async(),
	    _yml=grunt.file.readYAML('manifest.yml'),
	    _s='cf restage '+_yml.applications[0].name;

	_ref=exec(_s, {}, function(err, stdout, stderr) {
	    console.log('\nRestage the '+_yml.applications[0].name+' CF instance');
        });            
	
	_ref.stdout.on('data', function (data) {
            console.log(data);
        });
        
        _ref.stderr.on('data', function (data) {
            console.log(data);
        });
        
        _ref.on('close', function (code) {
            console.log(_yml.applications[0].name+' exited with code ' + code);
            ncb();
        });
    });

    grunt.registerTask('clean','Clean up unregistered files',function(){
	var exec = require('child_process').exec,
            ncb = this.async(),pkg=require('./package.json');

	var _ref4=exec('find . -name \'*.*~\' -type f -delete && find . -name \'#*\' -type f -delete && find . -name \'.#*\' -type f -delete', {}, function(err, stdout, stderr) {
            console.log('\Cleans up the waste.');
        });
        
        _ref4.stdout.on('data', function (data) {
            console.log(data);
        });
        
        _ref4.stderr.on('data', function (data) {
            console.log(data);
        });
        
        _ref4.on('close', function (code) {
            console.log('task exited with code: ' + code);
            ncb();
        });
    });

    grunt.registerTask('vulcanise','push everything into one file.',function(){
	
    });

    grunt.registerTask('default', ['cf-push']);
    grunt.registerTask('cf-push', ['cf-push-ins'/*,'cf-bind-rabbitmq','cf-restage'*/]);
};
