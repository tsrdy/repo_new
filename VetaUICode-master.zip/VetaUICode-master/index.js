/*
 * PredixLabs RabbitMQ Nodejs Demo
 * Author: 212359746
 */

var obj={host:'http://localhost',apppath:'',frontendpath:'',port:'3131',isdev:false,index:'index.html'},
    _tau=require('taurus-express-light'),
    _tel=new _tau();
    _url=require('url'),
    _fs=require('fs');
    _pkg=require('./package.json'),
    _uaa=require('./lib/uaa-predixlabs'),
    _util=require('./lib/util-predixlabs'),
    __formData=require('form-data'),
    _svcInfo=(process.env.VCAP_SERVICES&&JSON.parse(process.env.VCAP_SERVICES)),
    _appInfo=(process.env.VCAP_APPLICATION&&JSON.parse(process.env.VCAP_APPLICATION)),
    _exchange=null,
    _killCORS=function(req,res,next){
	if(req.url.indexOf('.css')>0)
            res.setHeader('Content-Type','text/css');

	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
	res.setHeader('Access-Control-Allow-Headers', 'Authorization');
	
	next();
    },
    _auth=function(req,res,next){

	var _clientInfo=_tel.getClientInfo(req);

	console.log('_clientInfo');
	console.log(_clientInfo);

	if (!_clientInfo.uaa_token){
	    res.isAuthenticated=false;
	    res.statusCode=302;
	    res.setHeader('Location','/login');
	    return res.end();
	}
	
    };

console.log('__dirname:'+__dirname);

//client id/sec
_appInfo&&(_appInfo.cid='tokyo');
_appInfo&&(_appInfo.cse='tokyo');

_tel.path(obj.apppath);

_tel.index(obj.index);

//mock '/login' call from px-login polymer component
_tel.get(['/login'],function(req,res,next){
    
    if (!_appInfo){
	res.writeHead(200, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({status:'No UAA instance. Application\'s running locally.'}));
    }

    var _ref=(_appInfo.cid||'tokyo'),
	_cbUrl=('https://'+_appInfo.application_uris[0]+'/callback');

    console.log('Get auth code..');
    _uaa.getAuthCode(_ref,_cbUrl,res);
});

//mock '/callback' call from px-login polymer component
//requred after UAA redirection
_tel.get('/callback',function(req,res,next){
     var url=require('url'),
         url_parts=url.parse(req.url, true),
	 _ref=url_parts.query.code;
    
    console.log('Get access token..');
    
    //Promise call structure- ECMA262
    _uaa.getAccessToken(_ref,_appInfo.cid,_appInfo.cse,'https://'+_appInfo.application_uris[0]+'/callback')
        .catch(function(err){
	    console.log('err: '+err);
	})
	.then(function(val){
	    console.log('Got access token! ' + val);
	    return _uaa.getUserInfo(val,_appInfo.cid,_appInfo.cse);
	})
	.then(function(obj){
	    //var _buf=new Buffer(JSON.stringify(obj.userInfo));
	    console.log('Got user information!');
	    console.log(obj);

	    _tel.setClientInfo(req,
			       {
				   uaa_token:obj.token,
				   user_info:obj.userInfo
			       });
	    	    
	    res.statusCode=302;
	    res.setHeader('Location','https://'+_appInfo.application_uris[0]);
	    
	    return res.end();
	});
    
});

//mock '/logout' call from px-login polymer component
_tel.get('/logout',function(req,res,next){
    _tel.removeClientInfo(req);
    res.statusCode=302;
    res.setHeader('Location','/login');
    res.end();
    return res.isAuthenticated=false;
});

//mock '/userinfo' call from px-login polymer component
_tel.get('/userinfo',function(req,res,next){
    res.end();
});

//mock '/about' call from px-login polymer component
_tel.get('/about',function(req,res,next){
    res.end();
});

_tel.pre(_killCORS);

//ui entry
_tel.static('/','./genpact-ui',_auth);

if (_svcInfo){

    if (_svcInfo['predix-uaa']&&_svcInfo['predix-uaa'][0]){
	console.log('initialising predix-uaa');
	_uaa.init(_svcInfo['predix-uaa'][0].credentials);
    }
}

_tel.listen(process.env.PORT||obj.port);
