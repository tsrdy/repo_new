# predix-boot-cf-nojitsu
This repo is to demonstrate how to build the a nodejs microservices based on CF instance such as rabbitMq, postgesSql, UAA, etc.

Required CF bind-service:
rabbitmq.
postgresSQL.
predix-uaa.

##Deploy your application to cloud:
1. cd predix-boot-cf-nojitsu
2. cf p

#Prerequisites
##UAA instance creation:
1. cf cs predix-uaa Beta predix-uaa-demo -c '{"adminClientSecret":"demo"}'
2. cf s
3. Ensure predix-uaa-demo is created

#Bind UAA to your application:
1. cf bs <your_application> predix-uaa-demo
2. cf restage <your_application>
3. cf e <your_application> : to see environment variables for your application

## Create Predix Analytics catalog instance:
1. Get issuerId from UAA instance
2. cf e <your_application>
3. Use predix-uaa.credentials.issuerId from environment
4. Create predix analytics catalog with trusted issuer id
5. cf cs predix-analytics-catalog Beta predix-analytics-catalog-demo -c '{"trustedIssuerIds":["https://7596e662-7002-4696-9672-52fd5c421055.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token"]}'
6. Bind Analytics Catalog with your application
7. cf bs <your_application> predix-analytics-catalog-demo
8. cf restage <your_application>
9. cf e <your_application> : to see environment variables for your application

##Create Predix Analytics runtime instance:
1. Get issuerId from UAA instance
2. cf e <your_application>
3. use predix-uaa.credentials.issuerId
4. Create predix analytics runtime with trusted issuer id
5. cf cs predix-analytics-runtime Beta predix-analytics-runtime-demo -c '{"trustedIssuerIds":["https://7596e662-7002-4696-9672-52fd5c421055.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token"]}'
6. Bind Analytics Runtime with your application
7. cf bs <your_application> predix-analytics-runtime-demo
8. cf restage <your_application>
9. cf e <your_application> : to see environment variables for your application

##Configure UAA to access Predix Analytics
1. Get predix-uaa.credentials.uri, cf e <your_application>
2. uaac target <predix-uaa.credentials.uri>
3. uaac token client get admin
4. Use adminClientSecret as password, which is 'demo' in this case
5. Get "zone-oauth-scope" for analytics catalog and runtime.
6. cf e <your-application>
7. For Analytics catalog, zone-oauth-scope is present in predix-analytics-catalog.credentials.zone-oauth-scope
8. For Analytics runtime,  zone-oauth-scope is present in predix-analytics-runtime.credentials.zone-oauth-scope
9. Create a new client id
10. uaac client add predix-analytics-client -s predix-analytics-client --authorities "uaa.resource" --scope "openid, <predix-analytics-catalog.credentials.zone-oauth-scope>, <predix-analytics-runtime.credentials.zone-oauth-scope>" --autoapprove "openid" --authorized_grant_types “authorization_code"
11. Create a new user
12. uaac user add demo -p demo --email demo@demo.com
13. Create a group with same name of Analytics catalog zone
14. uaac group add <predix-analytics-catalog.credentials.zone-oauth-scope>
15. Add user to the group
16. uaac member add <predix-analytics-catalog.credentials.zone-oauth-scope> demo
17. Create a group with same name of Analytics runtime zone
18. uaac group add <predix-analytics-runtime.credentials.zone-oauth-scope>
19. Add user to the group
20. uaac member add <predix-analytics-runtime.credentials.zone-oauth-scope> demo
21. View client details
22. uaac client get predix-analytics-client
23. View user details
24. uaac user get demo

## Access application
1. Login using <your_application_url>/login
2. use demo/demo as credentials
