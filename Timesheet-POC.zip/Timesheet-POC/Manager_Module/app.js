var mainApp = angular.module("mainApp", ['ngRoute']);
         mainApp.config(['$routeProvider','$locationProvider', function($routeProvider,$locationProvider) {
            $routeProvider.
            
            when('/dashboard', {
               templateUrl: 'dashboard.htm',
               controller: 'DashboardController'
            }).
            
            when('/newproject', {
               templateUrl: 'newproject.htm',
               controller: 'NewProjectController'
            }).
            
            when('/assigntask', {
                templateUrl: 'assigntask.htm',
                controller: 'AssignTaskController'
             }).
             
             when('/projectdetails', {
                 templateUrl: 'projectdetails.htm',
                 controller: 'ProjectDetailsController'
              }).
              
              when('/pendingtsapprovals', {
                  templateUrl: 'pendingtsapprovals.htm',
                  controller: 'PendingTSApprovelsController'
               }).
            
               when('/pendingleavesapprovals', {
                   templateUrl: 'pendingleavesapprovals.htm',
                   controller: 'PendingLeaveApprlsController'
                }).
                
                 when('/reports', {
                     templateUrl: 'reports.htm',
                     controller: 'ReportsController'
                  }).
                  
            otherwise({
               redirectTo: '/dashboard'
            });
         }]);
         
         mainApp.controller('DashboardController', function($scope,$rootScope) {
        	                   
        	 $rootScope.selectedLabel = 'Dashboard';
         });
         
         mainApp.controller('NewProjectController', function($scope,$rootScope) {
        	 $rootScope.selectedLabel = 'NewProject';
        	 $scope.listOfemps = ["Sanjeev","Vivek","Ram","Pradeep","Sunny","Abhi"];
        	 $scope.masterlistofemps = angular.copy($scope.listOfemps);
        	 
        	 $scope.project_inf = [ {
        			id : "Project1",
        			number : "10115531",
        			name : "Predix",
        			client : "GE",
        			size : 25,
        			start_date : new Date(2015, 10, 15),
        			end_date : new Date(2015, 11, 30),
        			location: "Bangalore",
        			manager: "Rajesh",
        			priority:"High",
        			status:"Ongoing",
        			billingStatus:"Billable",
        			timings : "09:30 AM to 06:30 PM",
        			supervisorname : "Anshul Srivastava",
        			assignedTo : ["Sanjeev","Ram","Pradeep"]
        		}, {
        			id : "Project2",
        			number : "20116531",
        			name : "Analytics",
        			client : "Vodafone",
        			size : 25,
        			start_date : new Date(2016, 09, 15),
        			end_date : new Date(2015, 12, 21),
        			location: "Hyderabad",
        			manager: "Anshul",
        			priority:"High",
        			status:"Approved",
        			billingStatus:"Billable",
        			timings : "11:30 AM to 09:30 PM",
        			supervisorname : "Ravi",
        			assignedTo : ["Vivek","Abhi","Sunny"]
        		} ];
        	 
        	 $scope.master = {};
        	 $scope.button_name = "Create";
        	 $scope.selectedEmps  = [];
        	 $scope.projectinf = {};
        	 $scope.editIndex = -1;
        	 $scope.edit_project = function(obj,index) {
 				$scope.listOfemps = angular.copy($scope.masterlistofemps);
 				$scope.projectinf = angular.copy(obj);
 				
 				$scope.selectedEmps = obj.assignedTo;
 				$scope.moveElements($scope.projectinf.assignedTo,$scope.listOfemps);
 			    
 				$scope.editIndex = index;
 				
 				$scope.master = angular.copy(obj);
 				$scope.button_name = "Update";
 			}
        	
        	 
        	 $scope.reset = function() {
        		 $scope.edit_project($scope.master);
        	  };
        	     
        	  $scope.moveElements = function(source,dest) {
        		  for (var i = 0; i < source.length; i++) {
						var index=-1;
						var found =false;
						for(var j = 0; j < dest.length; j++)
							{
								if(dest[j] == source[i])
									{
										index=j;
										found = true;
										break;
									}
							}
						
					//alert(obj.assignedTo[i]);
						if(found){
							dest.splice(index,1);	
						}
				}
        		  
         	  };
         	  
         	  $scope.moveElementsToLeft = function() {
       		   
         		 var value = $scope.listOfemps.length;
       		  for (var i = 0; i < $scope.projectinf.assignedTo.length; i++) {
       			  $scope.listOfemps[value] = $scope.projectinf.assignedTo[i];
       			  value++;
				 }
       		 $scope.moveElements($scope.listOfemps,$scope.selectedEmps);
        	  };
        	
        	  $scope.moveElementsToRight = function() {
        		  var value = $scope.selectedEmps.length;
        		  for (var i = 0; i < $scope.loe.length; i++) {
        			  $scope.selectedEmps[value] = $scope.loe[i];
        			  value++;
				 }
        		 $scope.moveElements($scope.selectedEmps,$scope.listOfemps);
           		  
        	  };
        	  
        	  $scope.create = function(){
  				$scope.project_inf.push($scope.projectinf);
        	  };
        	  
        	  $scope.save = function() {
        		  if($scope.button_name == 'Create'){
        			  $scope.create();
        		  }else
    			  {
        			  for (var i = 0; i < $scope.project_inf.length; i++) {
        				  if(i == $scope.editIndex){
        					
        					  $scope.project_inf[i] = $scope.projectinf;
        					  $scope.project_inf[i].assignedTo = $scope.selectedEmps;
        				  }
        				 }
    			  }
        		  	$scope.selectedEmps  = [];
        		  	$scope.projectinf = {};
        			$scope.listOfemps = angular.copy($scope.masterlistofemps);
        	  }
        	  
        	  $scope.reset = function() {
        		  $scope.projectinf = {};
        		  $scope.listOfemps = angular.copy($scope.masterlistofemps);
        		  $scope.selectedEmps = [];
        		  $scope.button_name = 'Create';
         	  };
        	  
         });
         
         mainApp.controller('AssignTaskController', function($scope,$rootScope) {
        	 $rootScope.selectedLabel = 'AssignTask';
        	 
             
         });
         
         mainApp.controller('ProjectDetailsController', function($scope,$rootScope) {
        	 
        	 $rootScope.selectedLabel = 'ProjectDetails';
             
        	$scope.projectDetails = [
				              {projectName:"GE Predix",client:"GE",startDate:"21-Dec-2015",endDate:"22-Dec-2015"},
				              {projectName:"Care Mark",client:"CVS",startDate:"22-Dec-2015",endDate:"23-Dec-2015"},
				              {projectName:"CaterXpert",client:"Aquila",startDate:"23-Dec-2015",endDate:"24-Dec-2015"},
				              ];
        	
        	 $scope.status_list=["Billable","Non-Billable","On Going"];
             
         });
         
         mainApp.controller('PendingTSApprovelsController', function($scope,$rootScope) {
        	 $rootScope.selectedLabel = 'PendingTimeSheetApprovals';
        	 $scope.status_list=["Pending","Approved","Rejected"];
             
         });
         
         mainApp.controller('PendingLeaveApprlsController', function($scope,$rootScope) {
        	 $rootScope.selectedLabel = 'PendingLeaveApprovals';
        	 $scope.status_list=["Pending","Approved","Rejected"];
             
         });
          
         mainApp.controller('ProjectsListController', function($scope,$rootScope) {
                                
         });
         
          mainApp.controller('mainController', function($scope,$rootScope) {
            $scope.user_menu = [{
            	                  name:"Dashboard",id:"dashboard"},
            	                  {name:"New Project",id:"newproject"},
            	                  {name:"Assign Task",id:"assigntask"},
            	                  {name:"Project Details",id:"projectdetails"},
            	                  {name:"Pending Approvels",id:"pendingapprovels"},
            	                  {name:"Reports",id:"reports"
            	                }];
            $scope.logo   = "genpact.jpg";
            $scope.logout = "logout.png";
            $scope.edit   = "edit.jpg";
            $scope.del    = "delete.jpg";
            $rootScope.selected_color = 'selectedcolor';
            
            $scope.project_list = [
           	                     {projectName:"Recon",clientName:"CITI-GRE",startDate:"01-Jan-2010",endDate:"01-Jan-2012",status:"onGoing"},
           	                     {projectName:"Frontier",clientName:"AT&T",startDate:"01-Jan-2000",endDate:"01-Jan-2008",status:"Open"},
           	                     {projectName:"Predix",clientName:"GE",startDate:"01-Jan-2005",endDate:"01-Jan-2009",status:"Completed"},
           	                     ];
            
            $rootScope.penTSApprlData = [
            	                     {name:"Anshul",ohrid:"703082995",projectName:"GE Predix",taskName:"Dash Board"},
            	                     {name:"Sanny",ohrid:"703163214",projectName:"GE Predix",taskName:"Approvel"},
            	                     {name:"Sanjeev",ohrid:"850020946",projectName:"GE Predix",taskName:"Assign Task"},
            	                     ];
            
            $rootScope.penLeaveApprlData = [
                    	                     {name:"Anshul",ohrid:"703082995",projectName:"GE Predix",date:"01-Jan-2016 to 15-Jan-2016"},
                    	                     {name:"Pradeep",ohrid:"703170245",projectName:"GE Predix",date:"01-Feb-2016 to 15-Feb-2016"},
                    	                     {name:"Abhi",ohrid:"703170260",projectName:"GE Predix",date:"01-March-2016 to 15-March-2016"},
                    	                     {name:"Abhi",ohrid:"703170260",projectName:"GE Predix",date:"01-March-2016 to 15-March-2016"},
                    	                     ];
            
            $scope.timesheet_count = $rootScope.penTSApprlData.length;
            $scope.pending_count = $rootScope.penLeaveApprlData.length;
         });
          
          mainApp.controller('ReportsController', function($scope,$rootScope) {
        	  $rootScope.selectedLabel = 'Reports';          
                                 
          });
          
