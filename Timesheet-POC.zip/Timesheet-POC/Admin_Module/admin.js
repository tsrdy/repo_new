var adminmodule = angular.module("adminModule" , [ 'ui.grid']);

adminmodule.controller('adminData',['$scope',function($scope)
{
	$scope.userType=["Admin","Manager","User"];
	$scope.deptType=["IT","HR","Admin","Finance"];
	$scope.mgrType=["Anshul","Rahul","Sanjay","Pankaj"];
	$scope.desigType=["Manager","Team Leader","Programmer"];
	$scope.locType=["Mumbai","Banglore","Delhi","Hyderabad"];
	$scope.r1Type=["Raj","Verma","raj123","raj@genpact.com","9835060992",""];
    $scope.userRole=["Admin","Manager","User"];
    $scope.myData = [
                 {
                     "firstName": "Cox",
                     "lastName": "Carney",
                     "userId": "Enormo",
                     "email-id": "xyz@gmail.com"
                 },
                 {
                     "firstName": "Lorraine",
                     "lastName": "Wise",
                     "userId": "Comveyer",
                     "email-id": "abc@gmail.com"
                 },
                 {
                     "firstName": "Nancy",
                     "lastName": "Waters",
                     "userId": "Fuelton",
                     "email-id": "def@gmail.com"
                 }
             ];
    
    
var users =[["tuser1","tuser1","Manager"],
               ["tuser2" ,"tuser2","Admin"],
               ["tuser3" ,"tuser3","User"]];
$scope.reset = function() 
{
	$scope.fName="";
	$scope.mName="";
	$scope.lName="";
	
}

$scope.logo="genpact.jpg";

$scope.submitform = function()
{
 var flag = true;
 for(var i=0;i<users.length;i++)
  {

     var userType=$scope.userType;
     var userRole=users[i];
     if(userRole[2] == userType)
      {
        if((userRole[0]==$scope.userName)&&(userRole[1]==$scope.userPassword))
         {
           /* alert("login succesful");*/
           window.location.href=userRole[2] +"_page.html";
           flag=false;
         }
      }    
  }
if(flag)
 {
  alert("login failed");
 }
}
}
])