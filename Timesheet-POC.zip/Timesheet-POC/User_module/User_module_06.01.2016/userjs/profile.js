mainApp.controller('profileController', function($scope, $rootScope) {
	$rootScope.selectedLabel = 'Profile';
	
});