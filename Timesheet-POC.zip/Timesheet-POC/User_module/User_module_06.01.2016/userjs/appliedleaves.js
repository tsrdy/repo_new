mainApp.controller('appliedleavesController', function($scope, $rootScope,
		$filter) {
	$rootScope.selectedLabel = 'UserLeaves';
	$scope.applieddata = [ {
		leavename : "Sick Leaves",
		leavedescription : "I am suffering from fever",
		startdate : new Date("12/10/2015"),
		enddate : new Date("12/12/2015"),
		status : "pending"
	}, {
		leavename : "Maternatity Leaves",
		leavedescription : "metarnity",
		startdate : new Date("12/15/2015"),
		enddate : new Date("12/22/2015"),
		status : "pending"
	}, {
		leavename : "Casual Leaves",
		leavedescription : "getting marriege",
		startdate : new Date("12/16/2015"),
		enddate : new Date("12/20/2015"),
		status : "Rejected"
	} ];
	$scope.appliedleaves = {};
	$scope.appliedleaves.status = "Pending";
	$scope.master = {};
	$scope.editindex = -1;
	$scope.diffDays = 0;
	$scope.print = function() {

		if ($scope.appliedleaves.startdate && $scope.appliedleaves.enddate) {
			if (new Date($scope.appliedleaves.startdate).getTime() > new Date(
					$scope.appliedleaves.enddate).getTime()) {
				window.alert("Start Date Always Before or Equal to the End Date");
				$scope.appliedleaves.startdate = null;
				$scope.appliedleaves.enddate = null;
				$scope.diffDays = 0;

			} else {
				var start_date = new Date($scope.appliedleaves.startdate);
				var end_date = new Date($scope.appliedleaves.enddate);
				$scope.diffDays = 0;

				while (start_date.getTime() <= end_date.getTime()) {

					if ($rootScope.isWorkingday(start_date)) {
						$scope.diffDays++;

					}
					start_date = new Date(start_date.setDate(start_date
							.getDate() + 1));

				}
			}

		}
	}
	$scope.edit_option = false;
	$scope.reset = function() {
		if (!$scope.edit_option) {
			$scope.appliedleaves = {};
			$scope.appliedleaves.status = "Pending";
			$scope.diffDays = "";
		} else {
			$scope.appliedleaves = angular.copy($scope.master);
		}

	}
	$scope.submit = function() {
		if (!$scope.edit_option) {
			$scope.applieddata.push($scope.appliedleaves);

		} else {

			for (var i = 0; i < $scope.applieddata.length; i++) {
				if ($scope.editindex == i) {
					$scope.applieddata[i] = angular.copy($scope.appliedleaves);
				}
			}

		}
		$scope.appliedleaves = {};
		$scope.appliedleaves.status = "Pending";
		$scope.diffDays = "";
		$scope.edit_option = false;
	}
	$scope.edit = function(obj, index) {
		$scope.appliedleaves = angular.copy(obj);
		console.log(JSON.stringify($scope.appliedleaves));
		$scope.master = angular.copy(obj);
		$scope.print();
		$scope.edit_option = true;
		$scope.editindex = index;
	}

});