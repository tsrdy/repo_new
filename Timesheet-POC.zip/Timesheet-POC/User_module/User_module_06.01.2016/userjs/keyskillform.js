mainApp.controller('keyskillsController', function($scope, $rootScope) {
	
	$scope.loe_list = [ {level : "Beginner"}, {level : "Intermediate"}, {level : "proficient"} ];
	
	$scope.addskill = function()
	{
		
		$scope.skill_list.push ({name : "",
				version:"",
				YOE:"",
				lastused:"",
				LOE : ""
				});
		
		
	}
	$scope.submit_keyskill = function()
	{
		$("#profile_page").click();
	}
	$scope.masters= angular.copy($rootScope.skill_list);
	
	$scope.reset = function() {
		
		
		$rootScope.skill_list = angular.copy($scope.masters);
		
	};
	$scope.cancel = function() {
		
		$rootScope.skill_list = angular.copy($scope.masters);
		$("#profile_page").click();
		
	};
});
