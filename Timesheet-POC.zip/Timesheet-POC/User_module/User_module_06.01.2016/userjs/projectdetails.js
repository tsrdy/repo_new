mainApp.controller('projectDetailsController', function($scope, $rootScope) {
	$rootScope.selectedLabel = 'ProjectDetails';
	$scope.projectinf = [ {
		id : "Project1",
		number : "10115531",
		name : "Predix",
		client : "GE",
		size : 25,
		start_date : new Date(2015, 10, 15),
		timings : "09:30 AM to 06:30 PM",
		supervisorname : "Anshul Srivastava",
		end_date : new Date(2016, 10, 10),
		status : "On-going",
		no_of_efforts:20
	}, {
		id : "Project2",
		number : "10116531",
		name : "Analytics",
		client : "Vodafone",
		size : 25,
		start_date : new Date(2015, 06, 15),
		timings : "11:30 AM to 09:30 PM",
		supervisorname : "Ravi",
		end_date : new Date(2015, 10, 14),
		status : "Completed",
		no_of_efforts:15
	} ];

	$scope.data_values = JSON.stringify($scope.projectinf[0]);
	$scope.projectdetails = angular.fromJson($scope.data_values);

	$scope.GetProject = function() {

		$scope.projectdetails = angular.fromJson($scope.data_values);

	}

});