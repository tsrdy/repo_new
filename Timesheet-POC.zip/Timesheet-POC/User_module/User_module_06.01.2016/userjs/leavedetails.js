mainApp.controller('leavedetailsController', function($scope,$rootScope) {
	$rootScope.selectedLabel = 'OrganizationLeaves';
	$rootScope.Leavedata = [{leavename:"Casual Leaves",numberofleaves:"25",description:"Adding  1 day of each and every Month "},{leavename:"Maternatity Leaves",numberofleaves:"85",description:"for womens"},{leavename:"Sick Leaves",numberofleaves:"10",description:"For sick"}];

            }); 