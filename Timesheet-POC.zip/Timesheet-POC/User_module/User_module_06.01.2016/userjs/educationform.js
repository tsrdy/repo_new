mainApp.controller('educationdetailsController', function($scope, $rootScope) {
	$scope.masters = angular.copy($rootScope.education_inf);
	$scope.course_types = [ {
		name : "SSC"
	}, {
		name : "PUC"
	}, {
		name : "Graduate"
	}, {
		name : "Post Graduate"
	}, {
		name : "Ph.d"
	} ];
	$scope.addcourse = function() {
		$rootScope.education_inf.push({
			course : "",
			organizationname : "",
			universityname : "",
			specialization : "",
			passout : "",
			aggregate : ""
		});
	}
	$scope.submit_education = function() {

		$("#profile_page").click();
	}


	$scope.reset = function() {

		$rootScope.education_inf = angular.copy($scope.masters);

	};
	$scope.cancel = function() {

		$rootScope.education_inf = angular.copy($scope.masters);
		$("#profile_page").click();

	};
});