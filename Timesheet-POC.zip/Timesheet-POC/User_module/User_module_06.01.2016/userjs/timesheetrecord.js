mainApp.controller('timesheetrecordController', function($scope, $rootScope) {
	$rootScope.selectedLabel = 'TimeSheetRecord';
	$scope.ProjectIds = [ {
		id : 1011551,
		name : "Predix"
	}, {
		id : 1011553,
		name : "GE Internal"
	} ];
	$scope.ProjectType = [ {
		name : "Billable"
	}, {
		name : "Non-Billable"
	} ];
	$scope.TaskType = [ {
		name : "Training"
	}, {
		name : "Development"
	} ];
	
	
	$scope.manager_name = "Anshul Shrivastava";
	$scope.status = "Pending";
	

	$scope.GetValue = function() {
		$scope.list_of_dates = angular.fromJson($scope.ddlvalue);
		var value = 1;
		for (value = 1; value < $scope.counter; value++) {
			$(".sum" + value).html("");
		}
		$scope.rows = [ 1, 2 ];

		$scope.counter = 2;

	}
	$scope.ddlvalue = JSON.stringify($rootScope.JsonArray[0].list_of_dates);
	$scope.list_of_dates = angular.fromJson($scope.ddlvalue);
	$scope.rows = [ 1, 2 ];

	$scope.counter = 2;

	$scope.addRow = function() {
		$scope.counter++;
		$scope.rows.push($scope.counter);

	}

	$scope.removeRow = function() {

		if ($scope.counter > 1) {
			$scope.rows.splice($scope.counter - 1, $scope.counter);
			$scope.counter--;
		}

	}

});
function sumfun(input_class) {
	var class_name = input_class.getAttribute("data");
	var sum = 0;

	$(".hour" + class_name).each(function() {

		// add only if the value is number
		if (!isNaN(this.value) && this.value.length != 0) {
			sum += parseFloat(this.value);
		}

	});

	$(".sum" + class_name).html(sum.toFixed(2));
}