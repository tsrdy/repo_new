var mainApp = angular.module("mainApp", [ 'ngRoute' ]);
mainApp.config([ '$routeProvider', '$locationProvider',
		function($routeProvider, $locationProvider) {
			$locationProvider.hashPrefix('!');
			$routeProvider.

			when('/home', {
				templateUrl : 'usermenu/homepage.htm',
				controller : 'HomeController'
			}).when('/timesheetrecord', {
				templateUrl : 'usermenu/timesheetrecord.htm',
				controller : 'timesheetrecordController'
			}).when('/projectdetails', {
				templateUrl : 'usermenu/projectdetails.htm',
				controller : 'projectDetailsController'
			}).when('/profile', {
				templateUrl : 'usermenu/profile.html',
				controller : 'profileController'
			}).when('/performance', {
				templateUrl : 'usermenu/performance.htm',
				controller : 'performanceController'
			}).when('/dailytasks', {
				templateUrl : 'usermenu/dialytasks.htm',
				controller : 'dialytasksController'
			}).when('/personnalform', {
				templateUrl : 'usermenu/employeeform.html',
				controller : 'employeeformController'
			}).when('/educationform', {
				templateUrl : 'usermenu/educationform.html',
				controller : 'educationdetailsController'
			}).when('/keyskillform', {
				templateUrl : 'usermenu/keyskillform.html',
				controller : 'keyskillsController'
			}).when('/organizationleaves', {
	               templateUrl: 'usermenu/leavedetails.html',
	               controller: 'leavedetailsController'
	            }).when('/userleaves', {
	               templateUrl: 'usermenu/appliedleaves.html',
	               controller: 'appliedleavesController'
	            }).otherwise({
				redirectTo : '/home'
			});
		} ]);




mainApp.controller('mainController',
		function($scope, $rootScope, $location) {
	$rootScope.selected_color = 'selectedcolor';
	  $('.datePicker')
      .datepicker({
          format: 'mm/dd/yyyy'
      })
      .on('changeDate', function(e) {
          // Revalidate the date field
      });
			$scope.user_menu = [ {
				name : "Home",
				id : "home"
			}, {
				name : "TimeSheet Record",
				id : "timesheetrecord"
			}, {
				name : "Project Details",
				id : "projectdetails"
			}, {
				name : "Leave Details",
				id : "leavedetails"
			}, {
				name : "Performance Assessment",
				id : "performanceassessment"
			}, {
				name : "Daily Tasks",
				id : "dailytasks"
			}, {
				name : "Incidetns",
				id : "incidents"
			}, {
				name : "Awards",
				id : "awards"
			} ];
			
			
			$scope.menuClass = function(page) {
			    var current = $location.path().substring(1);
			    	if(page === current)
			    		{
			    			alert(page + "" +selected_color);
			    		}
			    return page === current ? "selected_color" : "";
			  };
			$scope.logo = "images/genpact.jpg";
			
			$rootScope.education_inf = [ {
				course : "SSC",
				organizationname : "Vijananabharathi",
				universityname : "BOARD Of SSC AP",
				specialization : "MPC",
				passout : "2005",
				aggregate : "67"
			}, {
				course : "PUC",
				organizationname : "Narayana",
				universityname : "BOARD Of INTERMEDIATE AP",
				specialization : "MPC",
				passout : "2007",
				aggregate : "84"
			}, {
				course : "Graduate",
				organizationname : "St.Theressa",
				universityname : "JNTUK",
				specialization : "Graduate",
				passout : "2011",
				aggregate : "65"
			} ];
			
			$rootScope.skill_list = [ {
				name : "JAVA",
				version : "1.5",
				YOE : "3 years",
				lastused : "06/01/2015",
				LOE : "Intermediate"

			}, {
				name : "BIG DATA",
				version : "1.0X",
				YOE : "1 years",
				lastused : "04/01/2015",
				LOE : "Intermediate"
			}, {
				name : "Angular JS",
				version : "1.12.3",
				YOE : "3 Months",
				lastused : "10/15/2015",
				LOE : "Beginner"
			} ];
			
			$rootScope.userdetails = {
					firstname : "Pradeep",
					lastname : "Bavirisetty",
					fathername : "Jagannadha Rao",
					mothername : "Lalitha",
					gender : "Male",
					dob : "21/06/1990",
					permanantaddress : "#18/19,Bangalore,India",
					currentaddress : "DNO:13-6-5,Vizianagaram,AP",
					emailid : "pradeep.b@gmail.com",
					mobile : "9996636936"
				};
			$rootScope.task_status_list = [ "Pending", "On-going", "Completed" ];
			$rootScope.task_list = [ {
				projectid : "1005531",
				projecttype : "Predix",
				tasktype : "Documentation",
				taskdescription : "Prepare the Documentation",
				status : "Completed",
				description : "Good Work",
				rating : "A"
			}, {
				projectid : "1005531",
				projecttype : "Predix",
				tasktype : "User Module",
				taskdescription : "Build the User Module Menu",
				status : "Completed",
				description : "Good",
				rating : "B"
			}, {
				projectid : "1005531",
				projecttype : "Predix",
				tasktype : "Dash board/Home in Menu",
				taskdescription : "Design Home menu",
				status : "On-going",
				description : "",
				rating : ""
			}, {
				projectid : "1005531",
				projecttype : "Predix",
				tasktype : "Timesheet Record Menu",
				taskdescription : "Design Timesheet menu",
				status : "Pending",
				description : "",
				rating : ""
			} ];

			
			var date = new Date();
			var first_date = new Date(date.getFullYear(), date.getMonth(), 1);

			var lastDayOfMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0);

			// create JSON Array
			$rootScope.JsonArray = [];

			$scope.JsonObject = {};

			$scope.Json_list_Array = {};
			// create JSON Object
			if (first_date.getDay() != 1) {
				$scope.JsonObject = {};
				$scope.date = new Date(first_date.getFullYear(), first_date.getMonth(),
						1);
				$scope.datevalue = $scope.date;
				$scope.JsonObject.first_date = new Date(first_date.getFullYear(),
						first_date.getMonth(), 1);
				$scope.Json_list_Array = [];
				$scope.JsonObject.list_of_dates = $scope.Json_list_Array;
				$scope.JsonArray.push($scope.JsonObject);
			}
			
			while (date.getMonth() == first_date.getMonth()) {

				if (first_date.getDay() == 1) {
					$scope.JsonObject = {};
					$scope.date = new Date(first_date.getFullYear(), first_date
							.getMonth(), first_date.getDate());
					$scope.JsonObject.first_date = $scope.date;
					$scope.Json_list_Array = [];
					$scope.JsonObject.list_of_dates = $scope.Json_list_Array;
					$scope.JsonArray.push($scope.JsonObject);
				}
				if (first_date.getDay() == 0) {
					$scope.date = new Date(first_date.getFullYear(), first_date
							.getMonth(), first_date.getDate());
					$scope.JsonObject.end_date = $scope.date;

				}
				if (first_date.getDate() == lastDayOfMonth.getDate()) {
					$scope.date = new Date(first_date.getFullYear(), first_date
							.getMonth(), first_date.getDate());
					$scope.JsonObject.end_date = $scope.date;

				}
				$scope.Json_Object = {};
				$scope.Json_Object.date = new Date(first_date.getFullYear(), first_date
						.getMonth(), first_date.getDate());
				$scope.Json_list_Array.push($scope.Json_Object);
				first_date.setDate(first_date.getDate() + 1);
			}
			
			
			
			
		
			
		});

$(document).ready(function() {
    $('.datePicker')
        .datepicker({
            format: 'yyyy-mm-dd'
        });

   
	
 
});


