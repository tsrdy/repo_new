mainApp.controller('dialytasksController', function($scope, $rootScope) {

	$scope.task_status_list = [ "Pending", "On-going", "Completed" ];
	$rootScope.selectedLabel = 'DailyTasks';
});