mainApp.controller('employeeformController', function($scope, $rootScope) {
	$scope.masters= angular.copy($rootScope.userdetails);
	$scope.submit_emp_form = function() {
		
		$("#profile_page").click();
	};
	$scope.reset = function() {
		
		
		$rootScope.userdetails = angular.copy($scope.masters);
		
	};
	$scope.cancel = function() {
		
		$rootScope.userdetails = angular.copy($scope.masters);
		$("#profile_page").click();
		
	};
});