mainApp.controller('timesheetrecordController', function($scope, $rootScope) {
	$rootScope.selectedLabel = 'TimeSheetRecord';
	$scope.ProjectIds = [ {
		id : 1011551,
		name : "Predix"
	}, {
		id : 1011553,
		name : "GE Internal"
	} ];
	$scope.ProjectType = [ {
		name : "Billable"
	}, {
		name : "Non-Billable"
	} ];
	$scope.TaskType = [ {
		name : "Training"
	}, {
		name : "Development"
	} ];
	
	
	$scope.manager_name = "Anshul Shrivastava";
	$scope.status = "Pending";
	$scope.selected_timesheet_index =-1;
	
	for(var i=0;i<$rootScope.JsonArray.length;i++)
	{
		var date = new Date();
		var first_date = new Date($rootScope.JsonArray[i].first_date);
		var end_date = new Date($rootScope.JsonArray[i].end_date);
		if(date.getTime() >= first_date.getTime() && date.getTime() <= end_date.getTime())
		{
			$scope.ddlvalue = JSON.stringify($rootScope.JsonArray[i].list_of_dates);
			$scope.selected_timesheet_index = i;
			$scope.list_of_dates = angular.fromJson($scope.ddlvalue);
			break;
		}
	}

	$scope.GetValue = function() {
		$scope.list_of_dates = angular.fromJson($scope.ddlvalue);
		var value = 1;
		for (value = 1; value < $scope.counter; value++) {
			$(".sum" + value).html("");
		}
		$scope.rows = [ 1, 2 ];

		$scope.counter = 2;

	}

	$scope.rows = [ 1, 2 ];

	$scope.counter = 2;

	$scope.addRow = function() {
		$scope.counter++;
		$scope.rows.push($scope.counter);

	}

	$scope.removeRow = function() {

		if ($scope.counter > 1) {
			$scope.rows.splice($scope.counter - 1, $scope.counter);
			$scope.counter--;
		}

	}

});
function sumfun(input_class) {
	var class_name = input_class.getAttribute("data");
	var sum = 0;

	$(".hour" + class_name).each(function() {

		// add only if the value is number
		if (!isNaN(this.value) && this.value.length != 0) {
			sum += parseFloat(this.value);
		}

	});

	$(".sum" + class_name).html(sum.toFixed(2));
}