mainApp.controller('HomeController',
		function($scope, $rootScope, limitToFilter) {
			$rootScope.selectedLabel = 'Home';
			$scope.loginData = [ {
				login : "08:30",
				logout : "09:00"
			}, {
				login : "10:30",
				logout : "10:35"
			}, {
				login : "12:30",
				logout : "13:30"
			} ];
			$scope.emp_list = [ {
				ohrid : "703170260",
				name : "abishek",
				email : "XXXXXX",
				mobile : "XXXXX"
			}, {
				ohrid : "703082995",
				name : "Anshul",
				email : "XXXXX",
				mobile : "XXXXX"
			}, {
				ohrid : "703089563",
				name : "Sunny",
				email : "XXXXX",
				mobile : "XXXXX"
			} ];
			$rootScope.holidayslist = [ {
				name : "New Year",
				date : new Date("2016-01-01"),
				place : "All"
			}, {
				name : "Sankranthi",
				date : new Date("2016-01-14"),
				place : "Bangalore,AndhraPradesh"
			}, {
				name : "Republic Day",
				date : new Date("2016-01-26"),
				place : "India"
			}, {
				name : "Mahasivarathri",
				date : new Date("2016-02-16"),
				place : "India"
			}, {
				name : "Ugadi",
				date : new Date("2016-04-02"),
				place : "Bangalore,AndhraPradesh"
			}, {
				name : "May Day",
				date : new Date("2016-05-01"),
				place : "India"
			} ];
			
			$rootScope.attendance = [ {
				
				date : new Date("2016-01-04"),
				start_time:new Date("2016-01-04 08:30:00"),
				end_time: new Date("2016-01-04 17:30:00")
			}, {
				date : new Date("2016-01-05"),
				start_time:new Date("2016-01-05 08:35:00"),
				end_time: new Date("2016-01-05 17:25:00")
			}, {
				date : new Date("2016-01-06"),
				start_time:new Date("2016-01-06 09:30:00"),
				end_time: new Date("2016-01-06 18:25:00")
			}, {
				date : new Date("2016-01-07"),
				start_time:new Date("2016-01-07 09:35:00"),
				end_time: new Date("2016-01-07 17:20:00")
			}, {
				date : new Date("2016-01-08"),
				start_time:new Date("2016-01-08 09:25:00"),
				end_time: new Date("2016-01-08 17:20:00")
			}];
			
			$scope.selected_attendance_index =-1;
			
			for(var i=0;i<$rootScope.JsonArray.length;i++)
			{
				var date = new Date();
				var first_date = new Date($rootScope.JsonArray[i].first_date);
				var end_date = new Date($rootScope.JsonArray[i].end_date);
				if(date.getTime() >= first_date.getTime() && date.getTime() <= end_date.getTime())
				{
					$scope.attendancedates = JSON.stringify($rootScope.JsonArray[i].list_of_dates);
					$scope.selected_attendance_index = i;
					$scope.list_of_attendance_dates = angular.fromJson($scope.attendancedates);
					break;
				}
			}
			$scope.Getattendance = function()
			{
				
				$scope.list_of_attendance_dates = angular.fromJson($scope.attendancedates);
				
			}
			
			$rootScope.isWorkingday = function(date_value)
			{
				
				var current_date =new Date(date_value);
				
				var days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
				for(var i=0;i<$rootScope.holidayslist.length;i++)
				{
					if($rootScope.holidayslist[i].date.getFullYear()  === current_date.getFullYear() && $rootScope.holidayslist[i].date.getMonth()  === current_date.getMonth() && $rootScope.holidayslist[i].date.getDate()  === current_date.getDate())
						{
							return false;
						}
				}
				if(days[current_date.getDay()] === 'Sun' || days[current_date.getDay()] === 'Sat')
				{
				
					return false;
				}
				
				else
				{
					
					return true;
				}
				
				
			}
			
			$scope.diff_date = function(actual_date)
			{
				var current_date = new Date(actual_date);
				for(var i=0;i<$rootScope.attendance.length;i++)
				{
					if($rootScope.attendance[i].date.getFullYear()  === current_date.getFullYear() && $rootScope.attendance[i].date.getMonth()  === current_date.getMonth() && $rootScope.attendance[i].date.getDate()  === current_date.getDate())
						{
						var hours = Math.round(Math.abs(new Date($rootScope.attendance[i].start_time) - new Date($rootScope.attendance[i].end_time)) / 36e5);
						$rootScope.attendance[i].hours = hours + "Hrs";
							return $rootScope.attendance[i];
						}
				}
				return {};
			}
			$scope.getDayName = function(date_value)
			{
				
				var current_date =new Date(date_value);
				
				var days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
				for(var i=0;i<$rootScope.holidayslist.length;i++)
				{
					if($rootScope.holidayslist[i].date.getFullYear()  === current_date.getFullYear() && $rootScope.holidayslist[i].date.getMonth()  === current_date.getMonth() && $rootScope.holidayslist[i].date.getDate()  === current_date.getDate())
						{
							return $scope.holidayslist[i].name;
						}
				}
				if(days[current_date.getDay()] === 'Sun' )
				{
				
					return 'Sunday';
				}
				else 
				{
					
					return 'Saturday';
				}
				
				
			}
			$scope.getDayName = function(date_value)
			{
				
				var current_date =new Date(date_value);
				
				var days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
				for(var i=0;i<$scope.holidayslist.length;i++)
				{
					if($scope.holidayslist[i].date.getFullYear()  === current_date.getFullYear() && $scope.holidayslist[i].date.getMonth()  === current_date.getMonth() && $scope.holidayslist[i].date.getDate()  === current_date.getDate())
						{
							return $scope.holidayslist[i].name;
						}
				}
				if(days[current_date.getDay()] === 'Sun' )
				{
				
					return 'Sunday';
				}
				else 
				{
					
					return 'Saturday';
				}
				
				
			}
			$scope.taskpage = function()
			{
			$("#task_page").click();
			}
			$scope.ideas = [ [ 'Task1', 1 ], [ 'Task2', 8 ], [ 'Task3', 5 ] ];

			$scope.limitedIdeas = limitToFilter($scope.ideas, 3);
			$scope.selected_chart = "pie";
			$scope.pie_chart_visible = true;
			$scope.chagechart = function()
			{
				
				if($scope.pie_chart_visible)
					{
					
					$scope.pie_chart_visible=false;
					}
				else
					{
					
					$scope.pie_chart_visible=true;
					}
			}
		});

mainApp.directive('hcPie', function() {
	return {
		restrict : 'C',
		replace : true,
		scope : {
			items : '='
		},
		controller : function($scope, $element, $attrs) {
			console.log(2);

		},
		template : '<div id="container" style="margin: 0">not working</div>',
		link : function(scope, element, attrs) {
			console.log(3);
			var chart = new Highcharts.Chart({
				chart : {
					renderTo : 'container',
					plotBackgroundColor : null,
					plotBorderWidth : null,
					plotShadow : false
				},

				tooltip : {
					pointFormat : '{series.name}: </b>',
					percentageDecimals : 1
				},
				plotOptions : {
					pie : {
						allowPointSelect : true,
						cursor : 'pointer',
						dataLabels : {
							enabled : true,
							color : '#000000',
							connectorColor : '#000000',
							formatter : function() {
								return '<b>' + this.point.name + '</b>: '
										+ Math.round(this.percentage) + ' %';
							}
						}
					}
				},
				series : [ {
					type : 'pie',

					data : scope.items
				} ]
			});
			scope.$watch("items", function(newValue) {
				chart.series[0].setData(newValue, true);
			}, true);

		}
	}
});
mainApp.directive('hcBar', function() {
	return {
		restrict : 'C',
		replace : true,
		scope : {
			items : '='
		},
		controller : function($scope, $element, $attrs) {
			console.log(2);

		},
		template : '<div id="container1" style="margin: 0">not working</div>',
		link : function(scope, element, attrs) {
			console.log(3);
			var chart = new Highcharts.Chart({
				chart : {
					renderTo : 'container1',
					plotBackgroundColor : null,
					plotBorderWidth : null,
					plotShadow : false
				},
				
				series : [ {
					type : 'bar',

					data : scope.items
				} ]
			});
			scope.$watch("items", function(newValue) {
				chart.series[0].setData(newValue, true);
			}, true);

		}
	}
});
