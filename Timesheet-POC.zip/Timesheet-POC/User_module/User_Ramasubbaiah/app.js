


var mainApp = angular.module("mainApp", ['ngRoute']);
         mainApp.config(['$routeProvider','$locationProvider', function($routeProvider,$locationProvider) {
            $routeProvider.
            
            when('/home', {
               templateUrl: 'homepage.htm',
               controller: 'HomeController'
            }).when('/timesheetrecord', {
               templateUrl: 'timesheetrecord.htm',
               controller: 'timesheetrecordController'
            }).when('/leavedetails', {
               templateUrl: 'leavedetails.htm',
               controller: 'leavedetailsController'
            }).when('/appliedleaves', {
               templateUrl: 'appliedleaves.htm',
               controller: 'appliedleavesController'
            }).otherwise({
               redirectTo: '/'
            });
         }]);
         
         mainApp.controller('HomeController', function($scope) {
            $scope.loginData = [{login:"08:30",logout:"09:00"},{login:"10:30",logout:"10:35"},{login:"12:30",logout:"13:30"}];
                                $scope.holidayslist = [{name:"New Year",date:"January 1",place:"All"},{name:"Sankranthi",date:"January 14",place:"Bangalore,AndhraPradesh"},{name:"Republic Day",date:"January 26",place:"India"},{name:"Mahasivarathri",date:"February 16",place:"India"},{name:"Ugadi",date:"March 26",place:"Bangalore,AndhraPradesh"},{name:"May Day",date:"May 1st",place:"India"}];
                                
                                
         });
         
         mainApp.controller('timesheetrecordController', function($scope) {

                                $scope.ProjectIds = [{id:1011551,name:"Predix"},{id:1011553,name:"GE Internal"}];
                                $scope.ProjectType = [{name:"Billable"},{name:"Non-Billable"}];
                                $scope.TaskType = [{name:"Training"},{name:"Development"}];
                                var date = new Date();
                                var first_date = new Date(date.getFullYear(),date.getMonth(),1);
                                
                                var lastDayOfMonth = new Date(date.getFullYear(), date.getMonth()+1, 0);
                                

                                                //create JSON Array
                                                $scope.JsonArray= [];
                                                
                                                $scope.JsonObject = {};

                                                $scope.Json_list_Array = {};
                                                //create JSON Object
                                                                if(first_date.getDay()!=1){
                                                                $scope.JsonObject = {};
                                                                $scope.date = new Date(first_date.getFullYear(),first_date.getMonth(),1);
                                                                $scope.datevalue = $scope.date;
                                                                $scope.JsonObject.first_date = new Date(first_date.getFullYear(),first_date.getMonth(),1);                
                                                                $scope.Json_list_Array = [];
                                                                $scope.JsonObject.list_of_dates = $scope.Json_list_Array;
                                                                $scope.JsonArray.push($scope.JsonObject);
                                                                }
                                                                $scope.manager_name = "Anshul Shrivastava";
                                                                $scope.status = "Pending";
                                                while(date.getMonth() == first_date.getMonth())
                                                {
                                                                
                                                                if(first_date.getDay()==1){
                                                                $scope.JsonObject = {};
                                                                $scope.date = new Date(first_date.getFullYear(),first_date.getMonth(),first_date.getDate());
                                                                $scope.JsonObject.first_date = $scope.date;
                                                                $scope.Json_list_Array = [];
                                                                $scope.JsonObject.list_of_dates = $scope.Json_list_Array;
                                                                $scope.JsonArray.push($scope.JsonObject);
                                                                }
                                                                if(first_date.getDay()==0){
                                                                $scope.date = new Date(first_date.getFullYear(),first_date.getMonth(),first_date.getDate());
                                                                $scope.JsonObject.end_date = $scope.date;

                                                                }
                                                                if(first_date.getDate() == lastDayOfMonth.getDate()){
                                                                $scope.date = new Date(first_date.getFullYear(),first_date.getMonth(),first_date.getDate());
                                                                $scope.JsonObject.end_date = $scope.date;

                                                                }
                                                                $scope.Json_Object = {};
                                                                $scope.Json_Object.date = new Date(first_date.getFullYear(),first_date.getMonth(),first_date.getDate());
                                                                $scope.Json_list_Array.push($scope.Json_Object);
                                                                first_date.setDate(first_date.getDate()+1);
                                                }                                              

                                                console.log($scope.JsonArray);
                                
                                                console.log(JSON.stringify($scope.JsonArray));
                                                $scope.GetValue = function () {
                                                $scope.list_of_dates = angular.fromJson($scope.ddlvalue);
                                                var value=1;
                                                for(value=1;value<$scope.counter;value++){
                                                $(".sum"+value).html("");
                                                }

                
                                }
                                $scope.ddlvalue = JSON.stringify($scope.JsonArray[0].list_of_dates);
                                $scope.list_of_dates = angular.fromJson($scope.ddlvalue)
                                $scope.rows = [1, 2];
  
                                $scope.counter = 2;
  
  $scope.addRow = function() {
    $scope.counter++;
    $scope.rows.push($scope.counter);
    
  }
                                
$scope.removeRow = function() {
                alert($scope.counter);
    if($scope.counter>1){
    $scope.rows.splice($scope.counter-1,$scope.counter);
               $scope.counter--;
                }
    
  }
                                                
         });
                                function sumfun(input_class)
                                {
                                                var class_name=input_class.getAttribute("data");
                                                   var sum = 0;
       
                                                $(".hour"+class_name).each(function() {

            //add only if the value is number
            if(!isNaN(this.value) && this.value.length!=0) {
                sum += parseFloat(this.value);
            }

        });   
       
        $(".sum"+class_name).html(sum.toFixed(2));
                                }
                mainApp.controller('mainController', function($scope) {
            $scope.user_menu = [{name:"Home",id:"home"},{name:"TimeSheet Record",id:"timesheetrecord"},{name:"Project Details",id:"projectdetails"},{name:"Leave Details",id:"leavedetails"},{name:"Performance Assessment",id:"performanceassessment"},{name:"Daily Tasks",id:"dailytasks"},{name:"Incidetns",id:"incidents"},{name:"Awards",id:"awards"}];
                   // $scope.user_menu_id = ["home","timesheetrecord","projectdetails","leavedetails","performanceassessment","dailytasks","incidetns","awards"];
                    $scope.logo="genpact.jpg";
         });

  

mainApp.controller('leavedetailsController', function($scope,$rootScope) {
            $rootScope.Leavedata = [{leavename:"Casual Leaves",numberofleaves:"25",description:"Adding  1 day of each and every Month "},{leavename:"Maternatity Leaves",numberofleaves:"85",description:"for womens"},{leavename:"Sick Leaves",numberofleaves:"10",description:"For sick"}];

            });  

	mainApp.controller('appliedleavesController', function($scope,$filter) {
            $scope.applieddata = [{leavename:"Sick Leave",leavedescription:"I am suffering from fever",startdate:"10/12/2015 ",enddate:"12/12/2015",status:"pending"},{leavename:"Metarnity Leave",leavedescription:"metarnity",startdate:"15/12/2015 ",enddate:"22/12/2015",status:"pending"},{leavename:"Normal Leave",leavedescription:"getting marriege",startdate:"16/12/2015 ",enddate:"20/12/2015",status:"Rejected"}];

		$scope.print = function()
		{
		
		if($scope.sdate && $scope.edate){
		var start_date = new Date($scope.sdate);
		var end_date = new Date($scope.edate);
		var oneDay = 24*60*60*1000;
		 $scope.diffDays = Math.round(Math.abs((start_date.getTime() - end_date.getTime())/(oneDay)));
		
		}
		}

            });
