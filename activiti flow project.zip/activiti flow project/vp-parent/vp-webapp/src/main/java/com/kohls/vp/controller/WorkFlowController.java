package com.kohls.vp.controller;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.activiti.engine.FormService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.rest.service.api.form.FormDataResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kohls.vp.service.DocumentManagementService;
import com.kohls.vp.service.WorkFlowService;




@Controller

public class WorkFlowController {
	@Autowired
	private ProcessEngine processEngine;
	@Autowired
	private FormService formService;

	@Autowired
	private RuntimeService runtimeService;
	@Autowired
	WorkFlowService workFlowService;

	@Autowired
	private TaskService taskService;

	@Autowired
	DocumentManagementService documentManagementService;

	/**
	 * Size of a byte buffer to read/write file
	 */
	private static final int BUFFER_SIZE = 4096;

	@RequestMapping(value = "ViewTask", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView viewTask(@RequestParam(value="taskId", required=false) String taskId,@RequestParam(value="taskName", required=false) String taskName,HttpServletRequest request,HttpServletResponse response)
	{
		List<Map<String,Object>> attachements=null;
		List<Map<String,Object>> relatedContents=null;
		Task task=taskService.createTaskQuery().
				includeProcessVariables().taskId(taskId).singleResult();
		Map<String, Object> processVariables=task.getProcessVariables();
		if(processVariables!=null){
			Object preTaskId=processVariables.get("taskId");
			if(preTaskId!=null && preTaskId.toString().trim().length() >0){
				attachements=documentManagementService.getAttachementByTaskId(preTaskId.toString().trim());
			}
		}

		if(taskId!=null && taskId.toString().trim().length() >0){
			relatedContents=documentManagementService.getRelatedContentsByTaskId(taskId.trim());
		}

		ModelAndView model=new ModelAndView("ViewTask");
		model.addObject("taskName", taskName);
		FormDataResponse formDataResponse=workFlowService.getFormData(taskId, null);
		model.addObject("attachements", attachements);
		model.addObject("relatedContents", relatedContents);
		model.addObject("formDataResponse", formDataResponse);
		return model;


	}

	@RequestMapping(value = "ViewTasks", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView viewTasks(@RequestParam(value="taskId", required=false) String taskId,HttpServletRequest request,HttpServletResponse response)
	{

		String user = (String) request.getSession().getAttribute("user");

		ModelAndView model=new ModelAndView("ViewTasks");
		List<Task> tasks=workFlowService.getTasks(user);

		model.addObject("tasks", tasks);
		return model;

	}

	@RequestMapping(value = "StartProces", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView startProces(@RequestParam(value="taskId", required=false) String taskId, @RequestParam(value="processDefinitionId", required=false) String processDefinitionId, @RequestParam(value="name", required=false) String name,HttpServletRequest request,HttpServletResponse response)
	{
		ModelAndView model=new ModelAndView("StartProcess");

		model.addObject("processName", name);
		FormDataResponse formDataResponse=workFlowService.getFormData(taskId, processDefinitionId);
		model.addObject("formDataResponse", formDataResponse);
		return model;

	}
	@RequestMapping(value = "completeTask", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView completeTask(@RequestParam(value="taskId", required=false) String taskId, @RequestParam(value="processDefinitionId", required=false) String processDefinitionId,@RequestParam(value="taskName", required=false) String taskName,HttpServletRequest request, HttpServletResponse response)
	{

		ModelAndView model=new ModelAndView("SuccessTask");
		model.addObject("taskName", taskName+" task completed");
		/* if (submitRequest == null) {
	      throw new ActivitiException("A request body was expected when executing the form submit.");
	    }*/
		if ((taskId == null || taskId.length() ==0) && (processDefinitionId == null || processDefinitionId.length() ==0)) {
			//throw new ActivitiIllegalArgumentException("The taskId or processDefinitionId property has to be provided");
		}

		Enumeration<String> parameters=request.getParameterNames();

		Map<String, Object> propertyMap = new HashMap<String, Object>();
		propertyMap.put("assignee","praveen");
		while (parameters.hasMoreElements()) {
			String parameter=parameters.nextElement();
			//if(!parameter.equalsIgnoreCase("taskId") && !parameter.equalsIgnoreCase("processDefinitionId") && !parameter.equalsIgnoreCase("formKey") && !parameter.equalsIgnoreCase("deploymentId") && !parameter.equalsIgnoreCase("processDefinitionUrl")){
			if(!parameter.equalsIgnoreCase("processDefinitionId") && !parameter.equalsIgnoreCase("formKey") && !parameter.equalsIgnoreCase("deploymentId") && !parameter.equalsIgnoreCase("processDefinitionUrl")){
				propertyMap.put(parameter, request.getParameter(parameter));
			}

		}

		if (taskId != null && taskId.length() >0)
		{
			this.taskService.complete(taskId, propertyMap);
		}
		return model;

	}
	@RequestMapping(value = "submitForm", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView submitForm(@RequestParam(value="taskId", required=false) String taskId, @RequestParam(value="processDefinitionId", required=false) String processDefinitionId, @RequestParam(value="processName", required=false) String processName,HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView model=new ModelAndView("SuccessTask");
		model.addObject("taskName", processName+" process started");
		/* if (submitRequest == null) {
	      throw new ActivitiException("A request body was expected when executing the form submit.");
	    }*/
		if ((taskId == null || taskId.length() ==0) && (processDefinitionId == null || processDefinitionId.length() ==0)) {
			//throw new ActivitiIllegalArgumentException("The taskId or processDefinitionId property has to be provided");
		}

		Enumeration<String> parameters=request.getParameterNames();

		Map<String, String> propertyMap = new HashMap<String, String>();
		propertyMap.put("assignee","praveen");
		while (parameters.hasMoreElements()) {
			String parameter=parameters.nextElement();
			//if(!parameter.equalsIgnoreCase("taskId") && !parameter.equalsIgnoreCase("processDefinitionId") && !parameter.equalsIgnoreCase("formKey") && !parameter.equalsIgnoreCase("deploymentId") && !parameter.equalsIgnoreCase("processDefinitionUrl")){
			if(!parameter.equalsIgnoreCase("processDefinitionId") && !parameter.equalsIgnoreCase("formKey") && !parameter.equalsIgnoreCase("deploymentId") && !parameter.equalsIgnoreCase("processDefinitionUrl")){
				propertyMap.put(parameter, request.getParameter(parameter));
			}

		}

		if (taskId != null && taskId.length() >0)
		{
			this.formService.submitTaskFormData(taskId, propertyMap);
		}else{
			this.formService.submitStartFormData(processDefinitionId, propertyMap);
		}
		return model;
	}
	@RequestMapping(value = "ProcesList", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView getProcesList(HttpServletRequest request,HttpServletResponse response,ModelMap map)
	{
		ModelAndView model=new ModelAndView("ProcesList");

		List<Map<String,String>> processInfoMap=workFlowService.getProcessList();


		model.addObject("process", processInfoMap);
		return model;
	}

	@RequestMapping(value = "files/{file_id}", method = RequestMethod.GET)
	public void getFile(
			@PathVariable("file_id") String fileId,HttpServletRequest request, 
			HttpServletResponse response) {
		try {
			List<Map<String,Object>> attachements=documentManagementService.getAttachementById(fileId);
			Map<String,Object> attachement=attachements.get(0);
			System.out.println(attachements);
			// get your file as InputStream
			String filePathToBeServed = (String)attachement.get("url");//complete file name with path;
			File fileToDownload = new File(filePathToBeServed);
			InputStream is = new FileInputStream(fileToDownload);
			// copy it to response's OutputStream
			// org.apache.commons.io.IOUtils.copy(is, response.getOutputStream());
			//response.flushBuffer();

			//  ServletContext context = request.getServletContext();
			// get MIME type of the file
			//String mimeType = context.getMimeType(filePathToBeServed);
			String mimeType =null;
			if (mimeType == null) {
				// set to binary type if MIME mapping not found
				mimeType = "application/octet-stream";
			}
			System.out.println("MIME type: " + mimeType);

			// set content attributes for the response
			response.setContentType(mimeType);
			response.setContentLength((int) fileToDownload.length());

			// set headers for the response
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"",
					fileToDownload.getName());
			response.setHeader(headerKey, headerValue);

			// get output stream of the response
			OutputStream outStream = response.getOutputStream();

			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead = -1;

			// write bytes read from the input stream into the output stream
			while ((bytesRead = is.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
			}

			is.close();
			outStream.close();

		} catch (IOException ex) {
			// log.info("Error writing file to output stream. Filename was '{}'", fileName, ex);
			throw new RuntimeException("IOError writing file to output stream");
		}

	}
}
