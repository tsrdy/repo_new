package com.kohls.vp.common;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kohls.vp.model.Item;
import com.kohls.vp.service.ItemReaderService;



@Controller
public class ItemController {
	
    
	
	private static final Logger logger = LoggerFactory.getLogger(ItemController.class);
	
	@Autowired
	private ItemReaderService itemReaderService;
	
	@RequestMapping(value = "/items", method = RequestMethod.GET)
	public String items(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		List<Item> items = itemReaderService.readItems();
		model.addAttribute("Product_id", items.get(0).getProductId() );
		model.addAttribute("Product_name", items.get(0).getProductName() );
		
		return "home";
	}

}
