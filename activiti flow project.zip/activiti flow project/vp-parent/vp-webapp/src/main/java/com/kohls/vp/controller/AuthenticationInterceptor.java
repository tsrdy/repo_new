package com.kohls.vp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * @author praveen
 *
 */
public class AuthenticationInterceptor extends HandlerInterceptorAdapter {

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		String uri=request.getRequestURI();
		String context=request.getContextPath();
		if(!"".equals(context))
		{
			uri =uri.replaceFirst(context, "");
		}
		HttpSession session = request.getSession(false);
		 
		System.out.println("New - AuthenticationInterceptor called " + uri);
		String userName = (String) request.getSession().getAttribute("loginSession");
		if(!uri.startsWith("/login") && !uri.startsWith("/generateProductImageUrl") && !uri.startsWith("/signup") && !uri.startsWith("/storeUserRegister") && !uri.startsWith("/forgetPassword") && !uri.startsWith("/resetPassword") && !uri.startsWith("/getFeatureStore") && !uri.startsWith("/getStoreOrderedItemQty") && !uri.startsWith("/activateUser") && !uri.startsWith("/addEmail") && userName == null) {
			response.sendRedirect("login");
			return false;
		}if(uri.startsWith("/login") && userName != null && session != null)
		{
			response.sendRedirect("index");
			return false;
		}
		return true;
	}
}
