$(document).ready(function(){
	$('#upload_btn').on('click', function(){
		if($('#file').val() == ""){
			alert('Please choose a file to upload');
			return false;
			
		}
		
		var formData = new FormData($('#upload_form')[0]);
        $.ajax({
            url: 'uploadFile',  //server script to process data
            type: 'POST', 
            // Ajax events
            success:  function(data) { 
            		
                   $('#upload_list').append('<li>'+$('#name').val()+'</li>');   
                   $('#upload_form')[0].reset();
                   $('.close').trigger('click');
                   $('.close').trigger('click'); 
              
            },
            error: errorHandler = function() {
                alert("Something went wrong!");
            },
            // Form data
            data: formData,
            // Options to tell jQuery not to process data or worry about the content-type
            cache: false,
            contentType: false,
            processData: false
        });
	});
});