package com.kohls.vp.dataacess;

import java.util.List;
import java.util.Map;

import com.kohls.vp.model.Document;




public interface DocumentManagementDao {
	int storeAttachement(Document doc);
	List<Map<String,Object>> getAttachementById(String id);
	List<Map<String,Object>> getAttachementByTaskId(String taskId);
	List<Map<String,Object>> getRelatedContentsByTaskId(String taskId);
	int updateAttachement(Document doc);
	List<Map<String,Object>> getAttachements();
	
}
