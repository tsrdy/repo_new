package com.kohls.vp.dataacess;

import java.util.List;

import com.kohls.vp.model.Item;

public interface ItemReaderDAO {
	
	public List<Item> readItems();

}
