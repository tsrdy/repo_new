package com.kohls.vp.dataacess;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.kohls.vp.model.Item;

@Repository
public class ItemReaderDaoImpl implements ItemReaderDAO{
	
	public List<Item> readItems(){
		List<Item> itemList = new ArrayList<Item>();
	    Item it = new Item();
	    it.setProductId("876asdfbjhwe23jkhkwe");
	    it.setProductName("BISSELL Crosswave Multi-Surface Cleaner");
	    itemList.add(it);
		return itemList;
	}

}
