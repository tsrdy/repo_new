package com.kohls.vp.dataaccess.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.kohls.vp.dataacess.DocumentManagementDao;
import com.kohls.vp.model.Document;




@Repository
public class DocumentManagementDaoImpl implements DocumentManagementDao {
     @Autowired
	JdbcTemplate jdbcTemplate;
	

	@Override
	public int storeAttachement(Document doc) {
	     int row =  jdbcTemplate.update("INSERT INTO act_attachment(REV_ ,USER_ID_,NAME_,DESCRIPTION_,TYPE_,TASK_ID_,PROC_INST_ID_,URL_, TIME_) VALUES(?,?,?,?,?,?,?,?,now())",  doc.getRev(),doc.getUserId(),doc.getName(),doc.getDescription(),doc.getType(),doc.getTaskId(),doc.getProcInstId(),doc.getUrl());
		return row;
	}

	@Override
	public List<Map<String,Object>> getAttachementById(String id)
	{
		List<Map<String,Object>> attachement=jdbcTemplate.queryForList("select ID_ as id,REV_ as rev ,NAME_ as name,DESCRIPTION_ as description,URL_ as url from act_attachment where ID_="+id);
		return attachement;
	}
	@Override
	public List<Map<String,Object>> getAttachementByTaskId(String taskId)
	{
		List<Map<String,Object>> attachement=jdbcTemplate.queryForList("select ID_ as id,REV_ as rev ,NAME_ as name,DESCRIPTION_ as description,URL_ as url,TASK_ID_ as taskId from act_attachment where TASK_ID_="+taskId);
		return attachement;
	}
	@Override
	public List<Map<String,Object>> getRelatedContentsByTaskId(String taskId)
	{
		List<Map<String,Object>> attachement=jdbcTemplate.queryForList("select ID_ as id,REV_ as rev ,NAME_ as name,DESCRIPTION_ as description,URL_ as url,TASK_ID_ as taskId from act_attachment where TASK_ID_="+taskId);
		return attachement;
	}
	@Override
	public int updateAttachement(Document doc)
	{
		return 0;
	}
	
	@Override
	public List<Map<String,Object>> getAttachements() {
		List<Map<String,Object>> attachements=jdbcTemplate.queryForList("select ID_ as id,REV_ as rev ,NAME_ as name,DESCRIPTION_ as description from act_attachment");
		return attachements;
	}
	
}
