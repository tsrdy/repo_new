package com.kohls.vp.bpmn.Listener;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.delegate.TaskListener;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class ByerUploadPacket   implements TaskListener,ExecutionListener{
	@Autowired
	private RuntimeService runtimeService;
	@Override
	public void notify(DelegateTask delegateTask) {
		delegateTask.setVariable("test", delegateTask.getExecutionId());
		System.out.println("---notify--DelegateTask:"+runtimeService);
				
		
	}
	
	@Override
	public void notify(DelegateExecution execution) throws Exception {
		System.out.println("---notify--DelegateExecution:"+execution.getEventName());
		System.out.println("---notify--DelegateExecution Id:"+execution.getId());
		System.out.println("---notify--DelegateExecution runtimeService:"+runtimeService);
		execution.setVariable("test", execution.getId());
	}

	

}
