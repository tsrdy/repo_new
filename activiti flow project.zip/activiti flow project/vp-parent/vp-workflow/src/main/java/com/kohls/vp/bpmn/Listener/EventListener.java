package com.kohls.vp.bpmn.Listener;

import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;

public class EventListener implements ActivitiEventListener{
	@Override
	public void onEvent(ActivitiEvent event) {
		// TODO Auto-generated method stub
		
		System.out.println("-------onEvent--------"+event.getProcessDefinitionId());
	}

	@Override
	public boolean isFailOnException() {
		System.out.println("--isFailOnException-----");
		return false;
	}
}
