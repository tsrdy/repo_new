package com.kohls.vp.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kohls.vp.dataacess.DocumentManagementDao;
import com.kohls.vp.model.Document;



@Service("documentManagementService")
public class DocumentManagementServiceImpl  implements  DocumentManagementService{
	@Autowired
	DocumentManagementDao documentManagementDao;
	
	@Override
	public int storeAttachement(Document doc) {
		return documentManagementDao.storeAttachement(doc);
	}
	@Override
	public List<Map<String,Object>> getAttachementById(String id)
	{
		return documentManagementDao.getAttachementById(id);
	}
	@Override
	public List<Map<String,Object>> getAttachementByTaskId(String taskId)
	{
		return documentManagementDao.getAttachementByTaskId(taskId);
	}
	@Override
	public List<Map<String,Object>> getRelatedContentsByTaskId(String taskId)
	{
		return documentManagementDao.getRelatedContentsByTaskId(taskId);
	}
	@Override
	public int updateAttachement(Document doc) {
		return documentManagementDao.updateAttachement(doc);
		
	}

	@Override
	public List<Map<String,Object>> getAttachements() {
		return documentManagementDao.getAttachements();
	}
	
	
}
