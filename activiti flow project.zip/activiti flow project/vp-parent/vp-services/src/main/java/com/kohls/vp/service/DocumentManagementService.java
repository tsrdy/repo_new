package com.kohls.vp.service;

import java.util.List;
import java.util.Map;

import com.kohls.vp.model.Document;




public interface DocumentManagementService {
	int storeAttachement(Document doc);
	List<Map<String,Object>> getAttachementById(String id);
	List<Map<String,Object>> getAttachementByTaskId(String taskid);
	List<Map<String,Object>> getRelatedContentsByTaskId(String taskId);
	int updateAttachement(Document doc);
	List<Map<String,Object>> getAttachements();
	
}
