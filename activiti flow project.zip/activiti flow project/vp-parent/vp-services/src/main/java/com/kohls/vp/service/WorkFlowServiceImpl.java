package com.kohls.vp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.FormService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.form.FormData;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.history.HistoricTaskInstanceQuery;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.rest.service.api.form.FormDataResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kohls.vp.service.util.WorkFlowUtil;




@Service("workFlowService")
public class WorkFlowServiceImpl implements WorkFlowService{

	@Autowired
	private RuntimeService runtimeService;
	@Autowired
	private TaskService taskService;
	@Autowired
	private FormService formService;
	@Autowired
	private ManagementService managementService; 
	@Autowired
	private ProcessEngine processEngine; 
	@Autowired
	private	HistoryService historyService;
	@Autowired
	private IdentityService identityService;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	

	

	
	@Transactional
	@Override
	public void startProcess(String processId) {
		//processEngine.getRepositoryService().createProcessDefinitionQuery().list().get(0).getName();
		runtimeService.startProcessInstanceByKey(processId);
	}
	public int getPreviousTaskId(String taskId)
	{
		HistoricTaskInstanceQuery ff=historyService.createHistoricTaskInstanceQuery().taskId(taskId);
		HistoricTaskInstance cc=ff.singleResult();
		return 1;
	}
	@Transactional
	@Override
	public FormDataResponse getFormData(String taskId,String processDefinitionId) {
		FormData formData = null;
	    String id = null;
	    if (taskId != null)
	    {
	      formData = this.formService.getTaskFormData(taskId);
	      id = taskId;
	    }
	    else
	    {
	      formData = this.formService.getStartFormData(processDefinitionId);
	      id = processDefinitionId;
	    }
	    if (formData == null) {
	     // throw new ActivitiObjectNotFoundException("Could not find a form data with id '" + id + "'.", FormData.class);
	    }
	    
	    //Gson gson = new Gson();
	    //return gson.toJson(ActivitiUtil.createFormDataResponse(formData));
	    return WorkFlowUtil.createFormDataResponse(formData);
	}
	
	@Transactional
	@Override
	public List<org.activiti.engine.task.Task> getTasks() {
		return taskService.createTaskQuery().list();
	}

	@Override
	public List<Task> getTasks(String candidateOrAssigned)
	{

		List<org.activiti.engine.task.Task> tasks = taskService.createTaskQuery().
				includeProcessVariables().
				taskCandidateOrAssigned(candidateOrAssigned).
				orderByTaskCreateTime().asc().list();
		return tasks;

	}
	
	@Override
	public List<Task> findAllTask() {
		return null;
	}
	@Override
	public List<Map<String,String>> getProcessList()
	{
		List<Map<String,String>> processInfoMap=new ArrayList<Map<String,String>>();
		List<ProcessDefinition> processDefinitions =processEngine.getRepositoryService().createProcessDefinitionQuery().list();
		if(processDefinitions!=null){
			for(ProcessDefinition process:processDefinitions){
				
				Map<String,String> processInfo=new HashMap<String, String>();
				processInfo.put("key", process.getKey());
				processInfo.put("id", process.getId());
				processInfo.put("name", process.getName());
				
				processInfoMap.add(processInfo);
				
				
			}
		}
		
		return processInfoMap;
	}
	public void checkUnfinishedExecution() {

		for (ProcessInstance temp : runtimeService.createProcessInstanceQuery()

				.list()) {

			System.out.println(temp.getId());

		}

	}

}
