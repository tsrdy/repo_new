package com.kohls.vp.service;
import com.kohls.vp.model.Item;
import com.kohls.vp.dataacess.ItemReaderDAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("itemReaderService")
public class ItemReaderServerImpl implements ItemReaderService {
	
	@Autowired
	private ItemReaderDAO itemReaderDao;
	
	public List<Item> readItems(){
		return itemReaderDao.readItems();
		
	}

}
