package com.kohls.vp.service;

import java.util.List;
import java.util.Map;

import org.activiti.engine.task.Task;
import org.activiti.rest.service.api.form.FormDataResponse;





public interface WorkFlowService {
	List<Task> findAllTask(); 
	int getPreviousTaskId(String taskId); 
	List<Task> getTasks(String candidateOrAssigned);
	void startProcess(String processId);
	List<org.activiti.engine.task.Task> getTasks();
	FormDataResponse getFormData(String taskId,String processDefinitionId);
	List<Map<String,String>> getProcessList();
	
	
}
