package com.kohls.vp.service;
import java.util.List;

import com.kohls.vp.model.Item;


public interface ItemReaderService {
	
	public List<Item> readItems();

}
