package com.example.delegate;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("accountDelgate")
public class AccountDelgate {

AccountService service = AccountService.createAccountService();

@Profile("accountDelgate")
public int getAccountBalance(DelegateExecution execution,
String accountNumber) {
int amount = service.getAccountBalance(accountNumber);
return amount;
}

public boolean transferMoney(DelegateExecution execution,
String accountNumber1, String accountNumber2, int transferAmount) {

int balance = (Integer) execution.getVariable("accountBalance");

boolean result = false;
if (balance > transferAmount) {
result = service.transferMoney(accountNumber1, accountNumber2,
transferAmount);
}
return result;
}

/*
* Without delegation parameter also it works but to get the access to the
* execution context variables we have to pass DelegateExecution
*/
public int getAccountBalance(String accountNumber) {
int amount = service.getAccountBalance(accountNumber);
return amount;
}
}