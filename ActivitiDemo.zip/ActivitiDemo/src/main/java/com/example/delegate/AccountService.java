package com.example.delegate;
import java.util.ArrayList;
import java.util.List;

public class AccountService {

private static AccountService accountService= null;
List<Account> accountList = new ArrayList();


public static AccountService createAccountService(){
if(accountService == null){
accountService = new AccountService();
}
return accountService;
}

public Account createAccount(String customerName,int minBalance){
Account account = new Account(customerName,minBalance);
accountList.add(account);
return account;
}
public int getAccountBalance(String accountNumber) {

Account account = findAccount(accountNumber);
int balance = 0;
if(account!=null){
balance = account.getBalance();
}
return balance;
}

public boolean transferMoney(String accountNumber1,String accountNumber2, int transferAmount) {
System.out.println("Transferring Money from "+accountNumber1 + " to "+ accountNumber2 +" an amount of Rs."+transferAmount);
Account account1 = findAccount(accountNumber1);
Account account2 = findAccount(accountNumber2);
System.out.println("accountNumber2 balance before transfer is "+account2.getBalance());
if(account1.getBalance()>transferAmount){
account1.setBalance(account1.getBalance()-transferAmount);
account2.setBalance(account2.getBalance()+transferAmount);
}else{
return false;
}
System.out.println("accountNumber2 balance after transfer is "+account2.getBalance());
return true;
}

public boolean depositMoney(String accountNumber, int amount){
Account account = findAccount(accountNumber);
account.setBalance(account.getBalance()+amount);
System.out.println("Rs."+amount+" successfully depositted in "+accountNumber);
return true;
}

public boolean withdrawMoney(String accountNumber, int amount){
Account account = findAccount(accountNumber);
account.setBalance(account.getBalance()-amount);
return true;
} 

public Account findAccount(String accountNumber){

//System.out.println("accountNumber = "+accountNumber + "Size="+accountList.size());
for(Account a:accountList){
//System.out.println("Account Number = "+a.getAccountNumber());
if(a.getAccountNumber().equalsIgnoreCase(accountNumber)){
return a;
}
}
//System.out.println("Size="+accountList.size());
return null;
}

}
