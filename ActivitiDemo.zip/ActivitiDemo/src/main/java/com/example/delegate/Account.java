package com.example.delegate;

import java.io.Serializable;

public class Account implements Serializable {

private static final long serialVersionUID = 1L;

private String accountNumber;
private String customerName;
private int balance;
private String type;
private static int num;


public Account(String customerName,int minBalance){
this.accountNumber = "DBN-"+customerName.substring(0,2)+"-0100"+(num++);
this.customerName=customerName;
this.type="SA";
balance=minBalance;
}

public String getAccountNumber() {
return accountNumber;
}

public void setAccountNumber(String accountNumber) {
this.accountNumber = accountNumber;
}

public String getCustomerName() {
return customerName;
}

public void setCustomerName(String customerName) {
this.customerName = customerName;
}

public int getBalance() {
return balance;
}

public void setBalance(int balance) {
this.balance = balance;
}

public String getType() {
return type;
}

public void setType(String type) {
this.type = type;
}

}