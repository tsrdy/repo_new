package com.example.delegate;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.impl.cfg.StandaloneProcessEngineConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivitiDemoApplication {

	public static void main(String[] args) {
		BankService bankService = new BankService();
		bankService.createDummyAccounts();
		
		
		
		ProcessEngine processEngine = new StandaloneProcessEngineConfiguration()
	 	          .setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_FALSE)
	 			  .setJdbcDriver("com.mysql.jdbc.Driver")
	 			  .setJdbcUrl("jdbc:mysql://localhost:3306/test")
	 			  .setJdbcUsername("root")
	 			  .setJdbcPassword("root")
	 			  .setMailServerPort(587)
	 			  /*.setMailServerHost("smtp.gmail.com")
	 			  .setMailServerUseTLS(true)
	 			  .setMailServerUsername("noreply.mlo@gmail.com")
	 			  .setMailServerPassword("mlo@noreply")*/
	 			  .setAsyncExecutorEnabled(true)
	 			  .setAsyncExecutorActivate(true)
	 			  .setJobExecutorActivate(true)
	 			  .buildProcessEngine();
	 			RuntimeService runtimeService = processEngine.getRuntimeService();
	 			RepositoryService repositoryService = processEngine.getRepositoryService();
	 			repositoryService.createDeployment()
	 			.addClasspathResource("processes/myProcess.bpmn")
	 			.deploy();
	 		   runtimeService.startProcessInstanceByKey("myProcess");
	 		   processEngine.close();
		      SpringApplication.run(ActivitiDemoApplication.class, args);
		
	}
}



