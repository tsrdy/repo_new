package com.example.delegate;
public class BankService {

public int getNumberOfAccounts(){
return 50;
}

public boolean createDummyAccounts(){
AccountService service = AccountService.createAccountService();
service.createAccount("MALLIKARJUN", 5000);
service.createAccount("RAO", 5000);
service.createAccount("MALLI", 5000);
service.depositMoney("DBN-MA-01000", 20000);
return true;
}
}