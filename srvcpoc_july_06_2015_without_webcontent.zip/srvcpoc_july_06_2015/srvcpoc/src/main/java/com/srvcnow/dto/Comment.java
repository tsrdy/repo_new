package com.srvcnow.dto;

import java.util.Calendar;
import java.util.Date;

public class Comment {

	public Integer id;
	public String comment;
	public String loggedBy;
	public Date loggedDate;
	public String incidentId;
	public String loggedByName;
	
	public Comment(String comment,String loggedByName, String loggedBy, Date loggedDate, String incidentId) {
		super();		
		this.comment = comment;
		this.loggedBy = loggedBy;
		this.loggedDate = loggedDate;
		this.incidentId = incidentId;
		this.loggedByName =loggedByName;
	}

	public Comment() {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getLoggedBy() {
		return loggedBy;
	}

	public void setLoggedBy(String loggedBy) {
		this.loggedBy = loggedBy;
	}

	

	/**
	 * @return the loggedDate
	 */
	public Date getLoggedDate() {
		return loggedDate;
	}

	public void setLoggedDate(Date date) {
		this.loggedDate = date;
	}

	/**
	 * @return the incidentId
	 */
	public String getIncidentId() {
		return incidentId;
	}

	/**
	 * @param incidentId the incidentId to set
	 */
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}

	/**
	 * @return the loggedByName
	 */
	public String getLoggedByName() {
		return loggedByName;
	}

	/**
	 * @param loggedByName the loggedByName to set
	 */
	public void setLoggedByName(String loggedByName) {
		this.loggedByName = loggedByName;
	}

	
}
