package com.srvcnow.extractor;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.srvcnow.dto.Application;
import com.srvcnow.util.SystemGoUtil;

public class AssetsMapper   implements RowMapper<Application> {

	@Override
	public Application mapRow(ResultSet rs, int rowNum) throws SQLException {
		Application appInfo =new Application();
		appInfo.setIncId(SystemGoUtil.getValue(rs.getString("INC")));
		appInfo.setIncAssetId(SystemGoUtil.getValue(rs.getString("ASSET")));
		appInfo.setIncCiName(SystemGoUtil.getValue(rs.getString("CI")));
		appInfo.setIncCiStatus(SystemGoUtil.getValue(rs.getString("STATUS")));
		
		return appInfo;
	}


}
