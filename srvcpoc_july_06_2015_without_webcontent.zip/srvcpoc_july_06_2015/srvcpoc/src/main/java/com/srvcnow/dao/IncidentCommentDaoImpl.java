package com.srvcnow.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.srvcnow.dto.Comment;

@Repository("commentDao")
public class IncidentCommentDaoImpl {
	private final Log logger = LogFactory.getLog(IncidentCommentDaoImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Transactional(readOnly = true)
	public List<Comment> findAll() {
		logger.info("findAll");		
		return jdbcTemplate.query("select comment_id,comment_desc,created_by_sso,created_on,incident_id from srvcnow_ci_relation.comment", new CommentMapper());
	}

	@Transactional(readOnly = true)
	public List<Comment> getCommentByIncident(String incidentId) {
		logger.info("getCommentByIncident");
		return jdbcTemplate.query("select comment_id,comment_desc,created_by_sso,created_on,incident_id from srvcnow_ci_relation.comment where incident_id =?", new Object[] { incidentId },
				new CommentMapper());
	}	

	public int addComments(Comment comment) {
		logger.info("addComments");
		return jdbcTemplate.update(
				"insert into srvcnow_ci_relation.comment(comment_desc,created_by_name,created_by_sso,created_on,incident_id)values (?,?,?,now(),?)",
				new Object[] { comment.getComment(),comment.getLoggedByName(), comment.getLoggedBy(), comment.getIncidentId() });
		// return count;
	}

	private static final class CommentMapper implements RowMapper<Comment> {
		public Comment mapRow(ResultSet rs, int rowNum) throws SQLException {
			Comment objComment = new Comment();
			objComment.setId(rs.getInt("comment_id"));
			objComment.setComment(rs.getString("comment_desc"));
			objComment.setLoggedBy(rs.getString("created_by_sso"));
			objComment.setIncidentId(rs.getString("incident_id"));
			objComment.setLoggedDate(rs.getDate("created_on"));
			return objComment;
		}
	}
}
