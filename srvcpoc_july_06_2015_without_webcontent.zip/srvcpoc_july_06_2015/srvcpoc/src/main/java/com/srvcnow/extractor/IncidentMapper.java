package com.srvcnow.extractor;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.srvcnow.dto.Incident;
import com.srvcnow.util.SystemGoUtil;

public class IncidentMapper  implements RowMapper<Incident> {

	@Override
	public Incident mapRow(ResultSet rs, int rowNum) throws SQLException {
		Incident incidenceInfo =new Incident();
		incidenceInfo.setIncidentId(SystemGoUtil.getValue(rs.getString("number")));
		incidenceInfo.setDescription(SystemGoUtil.getValue(rs.getString("short_description")));
		incidenceInfo.setPriority(SystemGoUtil.getValue(rs.getString("priority")));
		incidenceInfo.setCi(SystemGoUtil.getValue(rs.getString("inc_ci")));
		
		return incidenceInfo;
	}

}
