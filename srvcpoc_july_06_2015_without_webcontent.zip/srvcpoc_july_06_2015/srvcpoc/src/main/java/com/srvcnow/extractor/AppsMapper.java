package com.srvcnow.extractor;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.srvcnow.dto.Asset;
import com.srvcnow.util.SystemGoUtil;

public class AppsMapper  implements RowMapper<Asset> {

	@Override
	public Asset mapRow(ResultSet rs, int rowNum) throws SQLException {
		Asset asset =new Asset();
		asset.setAppId(SystemGoUtil.getValue(rs.getString("biz_app_ci")));
		asset.setAppName(SystemGoUtil.getValue(rs.getString("related_ci_asset_name")));
		return asset;
	}

}
