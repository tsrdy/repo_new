package com.srvcnow.dto;

public class Application {

	String incId;
	String incAssetId;
	String incCiName;
	String incCiStatus;

	/**
	 * @return the incId
	 */
	public String getIncId() {
		return incId;
	}

	/**
	 * @param incId
	 *            the incId to set
	 */
	public void setIncId(String incId) {
		this.incId = incId;
	}

	/**
	 * @return the incAssetId
	 */
	public String getIncAssetId() {
		return incAssetId;
	}

	/**
	 * @param incAssetId
	 *            the incAssetId to set
	 */
	public void setIncAssetId(String incAssetId) {
		this.incAssetId = incAssetId;
	}

	/**
	 * @return the incCiName
	 */
	public String getIncCiName() {
		return incCiName;
	}

	/**
	 * @param incCiName
	 *            the incCiName to set
	 */
	public void setIncCiName(String incCiName) {
		this.incCiName = incCiName;
	}

	/**
	 * @return the incCiStatus
	 */
	public String getIncCiStatus() {
		return incCiStatus;
	}

	/**
	 * @param incCiStatus
	 *            the incCiStatus to set
	 */
	public void setIncCiStatus(String incCiStatus) {
		this.incCiStatus = incCiStatus;
	}

}
