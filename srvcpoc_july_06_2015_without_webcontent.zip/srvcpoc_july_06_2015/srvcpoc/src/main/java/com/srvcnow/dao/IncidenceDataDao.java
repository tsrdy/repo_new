package com.srvcnow.dao;

import java.util.List;
import java.util.Map;

public interface IncidenceDataDao {

	boolean checkDataFromDb(String incidentNo);

	List<String> retriveAppList(String incidencData, List<String> ciAssetsList);

	Map<String, String> retriveDBData(String incidenceNo);

	List<String> retriveConfmAssetListDB(String incidenceNo);

	List<String> retriveConfmAppsListDB(String incidenceNo);

	List<String> retrivePotentialAssetListDB(String incidenceNo);

	List<String> retrivePotentialAppListDB(String incidencData);

}
