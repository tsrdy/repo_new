package com.srvcnow.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MappingJsonFactory;

public final class SystemGoUtil {

	/**
	 * 
	 * @return
	 */
	public static RestTemplate createRestTemplate() {

		CredentialsProvider credsProvider = new BasicCredentialsProvider();
//		credsProvider.setCredentials(new AuthScope(new HttpHost("gedev.service-now.com")),
//				new UsernamePasswordCredentials("502645465", "Welcome_12a"));
		
		credsProvider.setCredentials(new AuthScope(new HttpHost("gesandbox1.service-now.com")),
				new UsernamePasswordCredentials("502592270", "El1t3T3@m"));
		

		HttpHost proxy = new HttpHost("PITC-Zscaler-Americas-Alpharetta3pr.proxy.corporate.ge.com", 80);
		HttpClientBuilder clientBuilder = HttpClientBuilder.create();

		clientBuilder.setProxy(proxy).setDefaultCredentialsProvider(credsProvider).disableCookieManagement();

		HttpClient httpClient = clientBuilder.build();
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		factory.setHttpClient(httpClient);

		return new RestTemplate(factory);

	}

	/**
	 * 
	 * @param jsonData
	 *            :All Json Data
	 * @param jsonArray
	 *            : Parent field in most cases it would be "records"
	 * @param jsonKey
	 *            :e.g. "u_impacted_ci_list"
	 * @return
	 */
	public static Map<String, String> getParsedData(String jsonData, String jsonKey) {
		String jsonVal = "";
		String jsonErrKey = "JSON_ERR";
		String jsonErrVal = "";
		String jsonArray = "records";

		Map<String, String> jsonKeyValueData = new HashMap<String, String>();
		JsonFactory f = new MappingJsonFactory();
		try {
			JsonParser jp = f.createParser(jsonData.toString());
			JsonToken current;

			current = jp.nextToken();
			if (current != JsonToken.START_OBJECT) {
				System.out.println("Error: root should be object: quiting.");
				jsonErrVal = "Error: root should be object: quiting";
				jsonKeyValueData.put(jsonErrKey, jsonErrVal);
			}

			while (jp.nextToken() != JsonToken.END_OBJECT) {
				String fieldName = jp.getCurrentName();
				current = jp.nextToken();
				if (fieldName.equals(jsonArray)) {
					if (current == JsonToken.START_ARRAY) {
						while (jp.nextToken() != JsonToken.END_ARRAY) {
							JsonNode node = jp.readValueAsTree();
							jsonVal = node.get(jsonKey).textValue();
							jsonKeyValueData.put(jsonKey, jsonVal);

						}
					} else {
						System.out.println("Error: records should be an array: skipping.");
						jp.skipChildren();
					}
				} else {
					System.out.println("Unprocessed property: " + fieldName);
					jp.skipChildren();
				}
			}

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonKeyValueData;
	}

	/**
	 * Key=Value e.g. siebel = emea - generic issue-ge capital-gec international
	 * - hq-QA, sap = pre-ge power-pwr - water and process
	 * technologies-Development-Business Application
	 * 
	 * @param tokens
	 * @return
	 */
	private static Map<String, String> getAssetKeyValData(String[] tokens) {
		Map<String, String> val = new HashMap<String, String>();
		for (String str : tokens) {
			val.put(str.substring(0, str.indexOf("-")), str.substring(str.indexOf("-") + 1, str.length()));
		}
		return val;
	}

	/**
	 * e.g. Arraylist Value :-[chrome, sap , siebel ]
	 * 
	 * @param tokens
	 * @return
	 */
	public static List<String> getAssetListValData(String[] tokens) {
		List<String> listVal = new ArrayList<String>();
		for (String str : tokens) {
			listVal.add(str.substring(0, str.indexOf("-")));
		}
		return listVal;
	}

	/**
	 * 
	 * @param val
	 * @return
	 */
	public static String[] parseString(String val) {
		String phrase = val;
		String[] tokens = {};
		if (phrase != null) {
			String delims = "[,]";
			tokens = phrase.split(delims);
		}
		return tokens;

	}

	public static String getValue(String value) {
		String val = "NA";
		if (value != null) {
			val = value;
		}

		return val;
	}

}
