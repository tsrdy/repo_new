package com.srvcnow.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.srvcnow.dto.Application;
import com.srvcnow.dto.Asset;
import com.srvcnow.dto.Incident;
import com.srvcnow.extractor.AppsMapper;
import com.srvcnow.extractor.AssetsMapper;
import com.srvcnow.extractor.IncidentMapper;
import com.srvcnow.util.QueryUtil;

@Repository
public class IncidenceDataDaoImpl implements IncidenceDataDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	 @Autowired
	 @Qualifier("jdbcTemplate2")
	 protected JdbcTemplate jdbcTemplate2;

	@Override
	/**
	 * CHECK IF DATA PRESENT for mention INC in DB
	 */
	public boolean checkDataFromDb(String incidentNo) {

		boolean flag = false;
		Map<String, Object> dataList = new HashMap<String, Object>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());

		parameters.addValue("incidentNo", incidentNo);

		dataList = template.queryForMap(QueryUtil.checkDbData, parameters);
		if (Integer.parseInt(dataList.get("count").toString()) > 0) {
			flag = true;
		}
		return flag;
	}
	
	@Override
	/**
	 * FIRST TIME "POT APPS LIST" RETRIVAL based on "ASSETS LIST" PROVIDED BY "API/JSON" - (GREENPLUME i.e. corp_it/edw)
	 */
	public List<String> retriveAppList(String incidencData, List<String> ciAssetsList) {
		List<String> applicationList = new ArrayList<String>();
		List<Asset> appList = new ArrayList<Asset>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("ciAssetsList", ciAssetsList);
		NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(jdbcTemplate2.getDataSource());
		appList = template.query(QueryUtil.appListQuery, parameters, new AppsMapper());
		if (!appList.isEmpty()) {
			for (Asset apps : appList) {
				applicationList.add(apps.getAppName());
			}
		}

		return applicationList;
	}

	@Override
	/**
	 * RETRIVE INC,DESC,CI,PRIORITY from DB once saved from UI -(srvcnow_ci_relation)
	 */
	public Map<String, String> retriveDBData(String incidenceNo) {
		Map<String, String> incidenceInfo = new HashMap<String, String>();
		List<Incident> incList = new ArrayList<Incident>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());

		parameters.addValue("incidenceNo", incidenceNo);

		incList = template.query(QueryUtil.incIdCiDescQuery, parameters, new IncidentMapper());

		if (incList.size() > 0) {
			for (Incident inc : incList) {
				incidenceInfo.put("number", inc.getIncidentId());
				incidenceInfo.put("short_description", inc.getDescription());
				incidenceInfo.put("priority", inc.getPriority());
				incidenceInfo.put("inc_ci", inc.getCi());
			}
		}
		return incidenceInfo;
	}
	
	

	@Override
	/**
	 * RETRIVE "CONFRM APP LIST" once "confirmed apps" list saved in DB - (srvcnow_ci_relation)
	 */
	public List<String> retriveConfmAppsListDB(String incidenceNo) {
		List<String> confmAppList = new ArrayList<String>();
		List<Application> appList = new ArrayList<Application>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("incidentNo", incidenceNo);
		NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		appList = template.query(QueryUtil.incConfAppsQuery, parameters, new AssetsMapper());
		if (!appList.isEmpty()) {
			for (Application apps : appList) {
				confmAppList.add(apps.getIncCiName());
			}
		}
		return confmAppList;
	}
	
	@Override
	/**
	 * RETRIVE "CONFRM ASSET LIST" once "confirmed asset" list saved in DB - (srvcnow_ci_relation)
	 */
	
	public List<String> retriveConfmAssetListDB(String incidenceNo) {
		List<String> confmAssetList = new ArrayList<String>();
		List<Application> assetList = new ArrayList<Application>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("incidentNo", incidenceNo);
		NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		assetList = template.query(QueryUtil.incConfAssetQuery, parameters, new AssetsMapper());
		if (!assetList.isEmpty()) {
			for (Application apps : assetList) {
				confmAssetList.add(apps.getIncCiName());
			}
		}
		return confmAssetList;
	}

	@Override
	/**
	 * RETRIVE "POTENTIAL IMPACT ASSET LIST" once "impcted asset" list saved in DB (srvcnow_ci_relation)
	 */
	
	public List<String> retrivePotentialAssetListDB(String incidenceNo) {
		List<String> potAssetList = new ArrayList<String>();
		List<Application> appList = new ArrayList<Application>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("incidentNo", incidenceNo);
		NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		appList = template.query(QueryUtil.incAssetListQuery, parameters, new AssetsMapper());
		if (!appList.isEmpty()) {
			for (Application apps : appList) {
				potAssetList.add(apps.getIncCiName());
			}
		}
		return potAssetList;
	}

	@Override
	/**
	 * RETRIVE "POTENTIAL IMPACT APPS LIST" once "impacted apps" list saved in DB - (srvcnow_ci_relation)
	 */
	public List<String> retrivePotentialAppListDB(String incidenceNo) {
		List<String> potAppList = new ArrayList<String>();
		List<Application> appList = new ArrayList<Application>();
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("incidentNo", incidenceNo);
		NamedParameterJdbcTemplate template = new NamedParameterJdbcTemplate(jdbcTemplate.getDataSource());
		appList = template.query(QueryUtil.incAppListQuery, parameters, new AssetsMapper());
		if (!appList.isEmpty()) {
			for (Application apps : appList) {
				potAppList.add(apps.getIncCiName());
			}
		}
		return potAppList;
	}
	

}
