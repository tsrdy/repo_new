package com.echidna.eiq.mlo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MloApplication {
	public static void main( String args[]){

		SpringApplication.run(MloApplication.class, args );
		System.out.println("MLO service  started... ");
	}
}
