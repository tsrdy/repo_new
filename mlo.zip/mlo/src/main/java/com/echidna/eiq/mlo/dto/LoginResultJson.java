package com.echidna.eiq.mlo.dto;

public class LoginResultJson {
	
	private String userName;
	private String result;
	private int count;
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public LoginResultJson(int count, String result) {
		super();
		this.count = count;
		this.result = result;
	}
	@Override
	public String toString() {
		return "LoginResultJson [userName=" + userName + ", result=" + result + "]";
	}
	public LoginResultJson() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
