package com.echidna.eiq.mlo.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.echidna.eiq.mlo.dto.LoginRequestJson;
import com.echidna.eiq.mlo.dto.LoginResultJson;
import com.echidna.eiq.mlo.dto.User;
import com.echidna.eiq.mlo.dto.UserList;

@CrossOrigin
@RestController
public class MloService {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String msg() {
		return "user service Running Succesfully";
	}

	// To retrieve info

	@RequestMapping(value = "/getusers", method=RequestMethod.GET)
	public List<User> getUserInfo() {
		System.out.println("Users List");
		List<User> listOfUsers = null;

		String sql = "select * from userinfo";
		System.out.println("result::::" + sql);
		listOfUsers = jdbcTemplate.query(sql, new RowMapper<User>() {
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new User(rs.getString("user_id"), rs.getString("user_Name"), rs.getString("password"));
			}
		});
		System.err.println(listOfUsers);

		UserList ul = new UserList();
		ul.setUserList(listOfUsers);
		// User ss = ul.getUserList().get(1);
		System.out.println("list of users:::" + ul.toString());
		return listOfUsers;

		/*
		 * JSONObject obj = new JSONObject(); obj.put("data", listOfUsers);
		 * return obj.toString();
		 */
	}

	@RequestMapping(value = "/getconfirmation", method = RequestMethod.POST, consumes = "application/json")
	public LoginResultJson getUserformdetails(@RequestBody LoginRequestJson rj) {
		System.out.println("Users getUserformdetails");
		//boolean isvalidUser = false;
		String sql="select count(user_id) count,user_name from userinfo where user_id=? and password=?";
		System.out.println("result::::" + sql);
		/*loginResultJson = jdbcTemplate.query(sql, new RowMapper<LoginResultJson>() {

			public LoginResultJson mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new LoginResultJson(rs.getInt("count"), rs.getString("user_name"));

			}

		});*/
		
		
		@SuppressWarnings("unchecked")
		LoginResultJson customer = (LoginResultJson)jdbcTemplate.queryForObject(
				sql, new Object[] { rj.getUserId(),rj.getPassword() }, new LoginResultJsonRowMapper());
		System.out.println("customer details"+customer.toString());


			if (customer.getCount() > 0) {
				customer.setUserName(customer.getUserName());
				customer.setResult("Success");
			}else{
				customer.setUserName("Invalid User");
				customer.setResult("Failure");
			}
		

		
//		String sql="select count(*) from userinfo where user_id='"+rj.getUserId()+"' and password='"+rj.getPassword()+"'";
		/*LoginResultJson loginResultJson = new LoginResultJson();
		String sql="select count(user_id),user_name from userinfo where user_id=? and password=?";
	
		
		int count=jdbcTemplate.queryForInt(sql,new Object[]{rj.getUserId(),rj.getPassword()});
		
		if(count!=0){
			loginResultJson.setUserName(user_Name);
			return "success";
		}
		
		return "Failure";*/
		return customer;
	}
	
	
	public class LoginResultJsonRowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			LoginResultJson customer = new LoginResultJson();
			customer.setUserName(rs.getString("user_name"));
			customer.setCount(rs.getInt("count"));
			return customer;
		}

	}

	@RequestMapping(value = "/sk", method=RequestMethod.GET)
	public List<User> getTest(){
		
		String sql = "select * from userinfo";
		System.out.println("result::::" + sql);
		List<User> ulList= jdbcTemplate.query(sql, new RowMapper<User>() {

			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new User(rs.getString("user_id"), rs.getString("user_Name"), rs.getString("password"));

			}

		});
		
		return ulList;
	}
	
	@RequestMapping(value = "/aa", method=RequestMethod.GET)
	public MyData getData(){
		
		return new MyData(1, 2);
	}
}
