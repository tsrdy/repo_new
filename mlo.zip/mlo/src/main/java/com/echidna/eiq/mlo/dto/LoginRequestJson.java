package com.echidna.eiq.mlo.dto;

public class LoginRequestJson {

	private String userId;
	public String password;
	
	/*
		{
			"userId":"xxxxxx",
			"password":"yyyyy"
		}
*
*/
	
	
	public LoginRequestJson() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public LoginRequestJson(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
