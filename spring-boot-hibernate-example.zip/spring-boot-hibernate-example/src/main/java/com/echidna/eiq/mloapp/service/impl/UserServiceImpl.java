/**
 * 
 */
package com.echidna.eiq.mloapp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.echidna.eiq.mloapp.dao.UserDao;
import com.echidna.eiq.mloapp.model.UserDetails;
import com.echidna.eiq.mloapp.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao userDao;

	public List<UserDetails> getUserDetails() {
		return userDao.getUserDetails();

	}

	@Override
	public Boolean validateUser(String emailId, String password) {
		// TODO Auto-generated method stub
		System.out.println("---*****in userserviceimpl ********--("+emailId+","+password+")");

		return userDao.validateUser(emailId, password);
	}

}
