package com.echidna.eiq.mloapp.dao;

import java.util.List;

import com.echidna.eiq.mloapp.model.UserDetails;

public interface UserDao {
	
	List<UserDetails> getUserDetails();
	Boolean validateUser(String emailId, String Password);

}
