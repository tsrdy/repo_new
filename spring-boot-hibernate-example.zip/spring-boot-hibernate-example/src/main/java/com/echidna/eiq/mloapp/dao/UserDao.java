package com.echidna.eiq.mloapp.dao;

import java.util.List;

import com.echidna.eiq.mloapp.model.UserDetails;

public interface UserDao {
	
	List<UserDetails> getUserDetails();
	String validateUser(String emailId, String Password);
	String validUserName(String emailId, String result);

}
