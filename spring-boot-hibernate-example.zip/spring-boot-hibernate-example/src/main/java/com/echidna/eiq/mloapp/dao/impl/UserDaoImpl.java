package com.echidna.eiq.mloapp.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.echidna.eiq.mloapp.dao.UserDao;
import com.echidna.eiq.mloapp.model.UserDetails;

@Component
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public List<UserDetails> getUserDetails() {
		Criteria criteria = sessionFactory.openSession().createCriteria(UserDetails.class);
		return criteria.list();
	}
	
	public Boolean validateUser(String emailId,String password){
		System.out.println("---*****in userDAOimpl ********--("+emailId+","+password+")");
		Criteria criteria = sessionFactory.openSession().createCriteria(UserDetails.class);
		criteria.add(Restrictions.eq("emailId", emailId))
        	.add(Restrictions.eq("password", password));
		System.out.println("Criteria returned is :::-----"+criteria);
		
		List credentials = criteria.list();
		
		int size = credentials.size();
		if(!(size==0))
			return false;
		else
		    return true;
		
	}

	
}
