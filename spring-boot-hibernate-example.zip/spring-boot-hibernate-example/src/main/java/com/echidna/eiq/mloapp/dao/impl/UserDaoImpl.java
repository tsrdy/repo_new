package com.echidna.eiq.mloapp.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.echidna.eiq.mloapp.dao.UserDao;
import com.echidna.eiq.mloapp.model.LoginResultJson;
import com.echidna.eiq.mloapp.model.UserDetails;

@Component
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;
	LoginResultJson loginResultJson = new LoginResultJson();
	public List<UserDetails> getUserDetails() {
		Criteria criteria = sessionFactory.openSession().createCriteria(UserDetails.class);
		return criteria.list();
	}

	public String validateUser(String email, String password) {
		String result = "invalid";
		//System.out.println("---*****in userDAOimpl ********--(" + email + "," + password + ")");
		Criteria criteria = sessionFactory.openSession().createCriteria(UserDetails.class);
		ProjectionList p1 = Projections.projectionList();
		p1.add(Projections.property("email"));
		p1.add(Projections.property("password"));
		p1.add(Projections.property("firstName"));

		criteria.setProjection(p1);
		List l = criteria.list();
		Iterator it = l.iterator();

		while (it.hasNext()) {
			Object ob[] = (Object[]) it.next();
			//System.out.println("from db they are "+ob[0] + "--------" + ob[1]);
			//System.out.println("from db they are "+ob[2]);
			if(ob[0].equals(email) && ob[1].equals(password)){
				result = "valid";
			}
		}

		//System.out.println("retrieving result from pojo"+result.getResult());
		return (result);
		

	}

	@Override
	public String validUserName(String emailId, String result) {
		// TODO Auto-generated method stub
		Criteria criteria = sessionFactory.openSession().createCriteria(UserDetails.class);
		ProjectionList p1 = Projections.projectionList();
		p1.add(Projections.property("email"));
		p1.add(Projections.property("firstName"));
        String name = null;
		criteria.setProjection(p1);
		List l = criteria.list();
		Iterator it = l.iterator();

		while (it.hasNext()) {
			Object ob[] = (Object[]) it.next();
			//System.out.println("from db they are "+ob[0] + "--------" + ob[1]);
			//System.out.println("from db they are "+ob[2]);
			if(emailId.equals(ob[0])){
				if(result.equals("valid"))
				name = ob[1].toString();
			}
		}

		//System.out.println("retrieving result from pojo"+result.getResult());
		return (name);
	}

}
