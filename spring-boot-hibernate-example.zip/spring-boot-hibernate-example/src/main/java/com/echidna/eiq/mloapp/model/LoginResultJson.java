package com.echidna.eiq.mloapp.model;

public class LoginResultJson {
	
	private String userName;
	private String result;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	@Override
	public String toString() {
		return "LoginResultJson [userName=" + userName + ", result=" + result + "]";
	}
	public LoginResultJson() {
		super();
	}
	

}
