package com.echidna.eiq.mloapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.echidna.eiq.mloapp.model.LoginRequestJson;
import com.echidna.eiq.mloapp.model.LoginResultJson;
import com.echidna.eiq.mloapp.model.UserDetails;
import com.echidna.eiq.mloapp.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ResponseEntity<List<UserDetails>> userDetails() {
        
		List<UserDetails> userDetails = userService.getUserDetails();
		return new ResponseEntity<List<UserDetails>>(userDetails, HttpStatus.OK);
	}

	
	
	// To validate the user login details with db
		@RequestMapping(value = "/validateuser", method = RequestMethod.POST, consumes = "application/json")
		public LoginResultJson validateUser(@RequestBody LoginRequestJson rj) {
			LoginResultJson user = new LoginResultJson();
			System.out.println("---*****in controller ********--("+rj.getEmail()+","+rj.getPassword()+")");
			String result = userService.validateUser(rj.getEmail(),rj.getPassword());
			String name = userService.validUserName(rj.getEmail(),result);
			System.out.println("Result is ::::"+result);
				user.setResult(result);
				user.setUserName("HELLO "+ name);
			return user;
		}
}
