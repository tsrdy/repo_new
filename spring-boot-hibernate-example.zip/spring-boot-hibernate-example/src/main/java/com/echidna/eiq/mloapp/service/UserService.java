/**
 * 
 */
package com.echidna.eiq.mloapp.service;

import java.util.List;

import com.echidna.eiq.mloapp.model.UserDetails;

public interface UserService {

	List<UserDetails> getUserDetails();
	Boolean validateUser(String emailId, String Password);

}
