/**
 * 
 */
package com.echidna.eiq.mloapp.service;

import java.util.List;

import com.echidna.eiq.mloapp.model.UserDetails;

public interface UserService {

	List<UserDetails> getUserDetails();
	String validateUser(String emailId, String Password);
	String validUserName(String emailId, String result);
}
