springbootexample
=================

This example is composed of 3 projects. To run, simply import the projects on Eclipse, and then run the examples with run configurations. To set the port for the Spring Boot, add the following system property on the run:

-Dserver.port=your port