package com.example.ldap.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.ldap.userdetails.LdapUserDetailsImpl;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app")
public class LDAPController {

	@GetMapping("/demo")
	public String sayHello(Principal principal,HttpServletRequest httpServletRequest) {

		Object loginedUser = ((Authentication) principal).getPrincipal();
		System.out.println("loggedin user Info " + loginedUser.toString());
		System.out.println("Logged in user is :: " + principal.getName());

		/*Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String name = auth.getName(); // get logged in username
		System.out.println("Authentication Logged in user is :: " + name);*/
		
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (!(authentication instanceof AnonymousAuthenticationToken)) {
		    String currentUserName = authentication.getName();
		    System.out.println("Authentication Logged in user is :: " + currentUserName);
		}
		
		Principal principalUser = httpServletRequest.getUserPrincipal();
		System.out.println("httpservletrequest Logged in user is :: " + principalUser.getName());
		
		
		//
		 UsernamePasswordAuthenticationToken authenticatio =
	                (UsernamePasswordAuthenticationToken)
	                        SecurityContextHolder.getContext().getAuthentication();

	        LdapUserDetailsImpl principa = (LdapUserDetailsImpl) authenticatio.getPrincipal();

	        System.out.println("authentication: " + authentication);
	        System.out.println("principal: " + principa);
		
		return "Hello LDAP";
	}

}
