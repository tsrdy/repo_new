package com.example.ldap.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.access.AccessDeniedHandler;

@EnableWebSecurity
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
    private AccessDeniedHandler accessDeniedHandler;
	
	@Value("${ldap.urls}")
	private String ldapUrls;
	
	@Value("${ldap.base.dn}")
	private String ldapBaseDn;
	
	@Value("${ldap.username}")
	private String ldapSecurityPrincipal;
	
	@Value("${ldap.password}")
	private String ldapPrincipalPassword;
	
	@Value("${ldap.user.dn.pattern}")
	private String ldapUserDnPattern;
	
	@Value("${ldap.enabled}")
	private String ldapEnabled;
	
	public String getLdapUrls() {
		return ldapUrls;
	}

	public void setLdapUrls(String ldapUrls) {
		this.ldapUrls = ldapUrls;
	}

	public String getLdapBaseDn() {
		return ldapBaseDn;
	}

	public void setLdapBaseDn(String ldapBaseDn) {
		this.ldapBaseDn = ldapBaseDn;
	}

	public String getLdapSecurityPrincipal() {
		return ldapSecurityPrincipal;
	}

	public void setLdapSecurityPrincipal(String ldapSecurityPrincipal) {
		this.ldapSecurityPrincipal = ldapSecurityPrincipal;
	}

	public String getLdapPrincipalPassword() {
		return ldapPrincipalPassword;
	}

	public void setLdapPrincipalPassword(String ldapPrincipalPassword) {
		this.ldapPrincipalPassword = ldapPrincipalPassword;
	}

	public String getLdapUserDnPattern() {
		return ldapUserDnPattern;
	}

	public void setLdapUserDnPattern(String ldapUserDnPattern) {
		this.ldapUserDnPattern = ldapUserDnPattern;
	}

	public String getLdapEnabled() {
		return ldapEnabled;
	}

	public void setLdapEnabled(String ldapEnabled) {
		this.ldapEnabled = ldapEnabled;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http
			.csrf().disable()
			.authorizeRequests()
			.antMatchers("/", "/home", "/login").permitAll()
					//.antMatchers("/**").hasAnyRole("MATHEMATICIANS")
				//.antMatchers("/login**").permitAll()
				//.antMatchers("/admin/**").hasAnyRole("ADMIN")
				//.antMatchers("/user/**").hasAnyRole("USER")
				
				.anyRequest()
				.authenticated()
		.and()
			.formLogin()
				.loginPage("/login")
				.failureUrl("/login?error")
	            .permitAll()
	           .and()
	        .logout()
	         .logoutUrl("/logout")
	            .logoutSuccessUrl("/")
	            .permitAll()
		.and()
		.exceptionHandling().accessDeniedHandler(accessDeniedHandler);
	        
		 }
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		/*auth
		.ldapAuthentication()
		.userDnPatterns("uid={0},ou=people")
		 .groupSearchBase("ou=groups")
		 .contextSource()
		 .url("ldap://localhost:8389/dc=springframework,dc=org")
		 .and()
		 .passwordCompare()
	     //.passwordEncoder(new LdapShaPasswordEncoder())
		 .passwordAttribute("userPassword");*/
		
		auth
		.ldapAuthentication()
		.contextSource()
			.url(ldapUrls + ldapBaseDn)
				.managerDn(ldapSecurityPrincipal)
				.managerPassword(ldapPrincipalPassword)
			.and()
				.userDnPatterns(ldapUserDnPattern);
		
	}

	/*@Bean
	public AccessDeniedHandler accessDeniedHandler(){
	    return new MyAccessDeniedHandler(); 
	}*/}

