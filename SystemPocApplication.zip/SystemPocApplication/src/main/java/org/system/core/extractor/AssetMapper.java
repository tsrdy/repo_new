package org.system.core.extractor;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.system.core.dto.AssetDTO;

public class AssetMapper implements RowMapper<AssetDTO> {

	
	public AssetDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		AssetDTO assetDTO = new AssetDTO();
		assetDTO.setAssetId(rs.getInt("assetId"));
		assetDTO.setAssetName(rs.getString("assetName"));
		assetDTO.setAppName(rs.getString("appName"));
		return assetDTO;
	}

}
