package org.system.core.extractor;

public class IncidentMapper {

}
