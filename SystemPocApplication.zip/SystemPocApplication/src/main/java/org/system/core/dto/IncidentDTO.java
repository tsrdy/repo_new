package org.system.core.dto;

public class IncidentDTO {
	
	private Integer incidentId;
	private String incidentName;
	public Integer getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(Integer incidentId) {
		this.incidentId = incidentId;
	}
	public String getIncidentName() {
		return incidentName;
	}
	public void setIncidentName(String incidentName) {
		this.incidentName = incidentName;
	}
	@Override
	public String toString() {
		return "IncidentDTO [incidentId=" + incidentId + ", incidentName="
				+ incidentName + "]";
	}
	
	
	

}
