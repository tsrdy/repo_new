package org.system.core.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.system.core.dto.AssetDTO;
import org.system.core.extractor.AssetMapper;

@RestController
public class AssetServices {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@RequestMapping(value = "/getassetlist", method = RequestMethod.GET, produces = { "application/json",
			"application/xml" }, headers = "Accept=application/json,application/xml")
	public List<AssetDTO> getCountryList() {
		String sql = "select * from AssetDetail_table";
		List<AssetDTO> countryList = jdbcTemplate.query(sql, new AssetMapper());
		return countryList;
	}
}
