package org.system.core.dto;

public class AssetDTO {
	private Integer assetId;
	private String assetName;
	private String appName;

	public Integer getAssetId() {
		return assetId;
	}

	public void setAssetId(Integer assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	
	

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Override
	public String toString() {
		return "AssetDTO [assetId=" + assetId + ", assetName=" + assetName
				+ ", appName=" + appName + "]";
	}

	

}
