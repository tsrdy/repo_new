define(['angular', './sample-module'], function(angular, sampleModule) {
    'use strict';

    sampleModule.value('version', '0.1');

    return   sampleModule.factory('fetchData',['$http',function($http){
     var dataFactory={};
     var zeroArray=[]
     var oneArray=[]
     dataFactory.getData= function(){
            return $http.get('sample-data/INC9692073appData.js').then(function success(response){
             var zeroArray=response.data;
             console.log(zeroArray);
             dataFactory.fetchedData=response.data;
              dataFactory.getFArry(response.data);
             return dataFactory.fetchedData;
            },function error(response){
            console.log('Error fetching data');})
        }
        
        dataFactory.getFArry=function(value){

        	
        	return this.fArray
        }

        dataFactory.updateData=function(){

        }

        dataFactory.setData= function(arr){

           var array=arr;
           console.log(array);

           var parameter = JSON.stringify(array);
            
        }

        dataFactory

    return dataFactory;
   }
]);
});