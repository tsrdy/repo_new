define(['angular', './sample-module'], function(angular, sampleModule) {
    'use strict';
    return sampleModule.controller('SampleCtrl',['$http','$state','$stateParams','$scope', function($http,$state,$stateParams,$scope) {


         //console.log($stateParams.priority);
										            $scope.priority = $stateParams.priority;
										$scope.CIforTable = $stateParams.CI;
										$scope.textModel1 = '';
										$scope.textModel = '';
										$scope.Modeltext1 = '';

										$scope.value = $stateParams.No;
										$scope.val = $stateParams.shtDesc;
            /*

				Potentially Impacted Application-  impactedData

				Confirmed application Impacted-  appData


				Potentially Impacted Assets-   impactedAssetData

				Confirmed Assets Impacted-  assetData

            */
           
		   

        
		      /*
					Applications Impacted-  applicationData

				Potentially Impacted Applications-  impactedData1
      

				Assests Impacted-   assetDatum

				Potentially Impacted Assests-  impactedAssetData1
		      */

          $scope.movePAssettoCAsset=function(val){

            //console.log(val);
           
            $scope.assetDatum.push(val);
              console.log($scope.impactedAssetData1.indexOf(val));
              $scope.impactedAssetData1.splice($scope.impactedAssetData1.indexOf(val),1);
              $scope.changedList='';


          }
          
          
		      $scope.moveCAppToPApp=function(value){
            $scope.impactedData1.push(value);
            $scope.appData.splice($scope.appData.indexOf(value),1);
            
             $scope.searchList='';
          }
    
          $scope.moveCAssetToPAsset=function(val){
             $scope.impactedAssetData1.push(val);
             $scope.assetDatum.splice($scope.assetDatum.indexOf(val),1);
            // $scope.countCAppfn();
             $scope.searchText='';
          }


           $scope.movePAtoCA= function(value){
          /*Push to Confirmed Affected*/
           // console.log(value);
            //$scope.impactedData.splice($scope.impactedData.indexOf(value),1);
             /*Push to Confirmed Affected*/
              $scope.appData.push(value);
             /*Delete from Array using Index*/
               $scope.impactedData1.splice($scope.impactedData1.indexOf(value),1);

              $scope.List='';
             }


          
            $http.get('sample-data/'+$stateParams.No+'appData.js').then(function success(response){
              $scope.appData=response.data;
              //$scope.countCAppfn1();
            })

            $http.get('sample-data/'+$stateParams.No+'assetData.js').then(function success(response){
              $scope.assetData=response.data;
              //$scope.countCAppfn1();
            })

            $http.get('sample-data/'+$stateParams.No+'ImpactedData.js').then(function success(response){
              $scope.impactedData=response.data;
               var List=[]
                angular.forEach($scope.impactedData,function(value,key){
                  List.push(value.appName);
                  $scope.appList=List;
              })
              
            })

            $http.get('sample-data/'+$stateParams.No+'ImpactedAsset.js').then(function success(response){
              $scope.impactedAssetData=response.data;
                var arrayList=[]
                angular.forEach($scope.impactedAssetData,function(value,key){
                 arrayList.push(value.assetName);
                  $scope.listToUpdate=arrayList;
              })
                  })

            $http.get('sample-data/'+$stateParams.No+'appData.js').then(function success(response){
              $scope.applicationData=response.data;
              $scope.countCAppfn();
            })

             $http.get('sample-data/'+$stateParams.No+'assetData.js').then(function success(response){
              $scope.assetDatum=response.data;
              $scope.assetDatum.push({'assetId':0,'assetName':$scope.CIforTable});
              //console.log($scope.assetDatum);
              $scope.countCAppfn();

            })

             $http.get('sample-data/'+$stateParams.No+'ImpactedData.js').then(function success(response){
              $scope.impactedData1=response.data;  
              $scope.lengthOfImpactedApp=$scope.impactedData1.length;

              //console.log($scope.lengthOfImpacted);
              $scope.countCAppfn(); 
            }) 

            $http.get('sample-data/'+$stateParams.No+'ImpactedAsset.js').then(function success(response){
              $scope.impactedAssetData1=response.data;
              var arr=[];
               angular.forEach($scope.impactedAssetData1,function(v,k){
                arr.push(v.assetName);
                $scope.impactedAsset1=arr;
               })
              $scope.countCAppfn(); 
            })



        


                   


/*
				    $scope.countCAppfn1= function(){

                    	 $scope.countCApp1=$scope.appData;
                    	 $scope.countCAsset1=$scope.assetData;
            }*/

           


				    $scope.countCAppfn= function(){
               $scope.countCApp1=$scope.appData;
                    	 $scope.countCApp=$scope.applicationData;
                    	 $scope.countCAsset=$scope.assetDatum;
                    	 $scope.countPApp=$scope.impactedData1;
                    	 $scope.countPAsset=$scope.impactedAssetData1;
                    ;
                    }
                   
               
                   $scope.addToListAsset1=function(val){
                     var len=$scope.listToUpdate.length;
                     var str=$scope.Model;
                     Polymer.dom(document).querySelector("#five").modalButtonClicked();
                     
                   	  if(str.length!==0){    	  	
	                    
                   	  	var addData=$scope.Model;
                   	  	$scope.impactedAssetData.push({'assetId':len+1,'assetName':addData});
                   	  	//console.log($scope.impactedAssetData)
                   	  }
                   	   if(val.length!==0){   
                        var len2=$scope.impactedAsset1.length;	

                   	  	$scope.impactedAssetData1.push({'assetId':len2+1,'assetName':val});
                   	  	
                   	  }
                      $scope.Model='';

                   }

                   $scope.addToListApp1=function(val){
                   	//console.log(val.length);
                   	var len=$scope.appList.length;
                    Polymer.dom(document).querySelector("#four").modalButtonClicked();
                   	if(val.length!==0){
                   		$scope.appList.push();
                   		$scope.impactedData.push({'appId':len+1,'appName':val});
                   	}
                   	if(val.length!==0){   	
                      var len1=$scope.lengthOfImpactedApp
                   	  	$scope.impactedData1.push({'appId':len1+1,'appName':val});
                   	  	
                   	  }
                   	  $scope.Modeltext1='';
                   }

                   $scope.cls='green';
                   
                   $scope.changeColor=function(id, sec,par){
                    
                   	//$scope.cls=$scope.cls==='green'?'red':'green';
                   		if($('.cr_'+sec+'_'+id).hasClass('green')){
                       /* $scope.checked=false;
                        $('.cr_'+sec+'_'+id).*/
                        $('.cr_'+par+'_'+id).removeClass('fa-toggle-on');
                        $('.cr_'+par+'_'+id).addClass('fa-toggle-off');
                   			$('.cr_'+sec+'_'+id).removeClass('green');
                   			$('.cr_'+sec+'_'+id).addClass('red');
                   		}else{
                         $('.cr_'+par+'_'+id).addClass('fa-toggle-on');
                        $('.cr_'+par+'_'+id).removeClass('fa-toggle-off');
                        //$scope.checked=true;
                   			$('.cr_'+sec+'_'+id).addClass('green')
                   			$('.cr_'+sec+'_'+id).removeClass('red')                   			
                   		}

                   	 
                   }

                  

                $scope.commandList=[];
                $scope.cmdCenter='';
                $scope.addToCommandCenter=function(obj){
                    var dateVal=new Date();
          					var datev=dateVal.getTime();
          					
                   
                   	if(obj!==null){
                   		$scope.commandList.push({'id':datev,'val':$scope.cmdCenter});
                   		//console.log($scope.commandList);
                   	}
                    // console.log($scope.commandList);
                     var len=$scope.commandList.length;
                      var arr=[];
               
              /*      for(var i=len-1;i>=0;i--){
                   
                       console.log(arr[i]);
                       for(var j=0 ; j<=len-1 ;j++){
                          
                          var ob=$scope.commandList[j];
                          arr[i]=ob;
                        console.log($scope.commandList[j]);
                                               }
                       console.log(arr);
                    }*/
                }
                  
            
    }]);
});
