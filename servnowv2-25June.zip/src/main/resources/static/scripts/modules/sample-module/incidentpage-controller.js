define(['angular', './sample-module'], function (angular, sampleModule) {
    'use strict';
    return sampleModule.controller('IncidentPageCtrl', ['$http', '$state', '$stateParams', '$scope', function ($http, $state, $stateParams, $scope) {
    	
    	$scope.incidentNo = $stateParams.incidentNo;
    	$scope.incidentid = '';
    	$scope.description='';
    	// Confirmed Assets Impacted  Array
    	$scope.assetDatum=[];
    	//Potentially Impacted Assets 
    	$scope.impactedAssetData1 =[];
    	$scope.impactedAsset1=[];
    	$scope.impactedAssetData=[]; 
    	$scope.listToUpdate=[];
    	// Array for Applications
    	$scope.impactedData1=[];
    	$scope.appData=[];
    	// COmmand Center Comments
    	$scope.commandList = [];
    	
    	
    	
    	$scope.priority = $stateParams.priority;
        $scope.CIforTable = $stateParams.CI;
        $scope.textModel1 = '';
        $scope.textModel = '';
        $scope.Modeltext1 = '';
        $scope.Incidentdata='';

        
        //$scope.value = $stateParams.param1;
        //$scope.val = $stateParams.shtDesc;
        //
        // Move the asset to confirmed app list
        $scope.movePAssettoCAsset = function (val) {
            $scope.assetDatum.push(val);
            //console.log($scope.impactedAssetData1.indexOf(val));
            $scope.impactedAssetData1.splice($scope.impactedAssetData1.indexOf(val), 1);
            $scope.changedList = '';
        }
		//
        $scope.moveCAppToPApp = function (value) {
            $scope.impactedData1.push(value);
            $scope.appData.splice($scope.appData.indexOf(value), 1);

            $scope.searchList = '';
        }
        //
        $scope.moveCAssetToPAsset = function (val) {
            $scope.impactedAssetData1.push(val);
            $scope.assetDatum.splice($scope.assetDatum.indexOf(val), 1);
            // $scope.countCAppfn();
            $scope.searchText = '';
        }
        //
        $scope.movePAtoCA = function (value) {
            $scope.appData.push(value);
            /*Delete from Array using Index*/
            $scope.impactedData1.splice($scope.impactedData1.indexOf(value), 1);

            $scope.List = '';
        }
        
        
        // new method to load the Incident Data
        $http.get('/getincident/'+$scope.incidentNo).then(function success(response) {
            $scope.incidentid= response.data.id;
            $scope.description= response.data.description;
            $scope.priority= response.data.priority;
            $scope.ci= response.data.ci;
            // while loading the data add the current Incident CI to the List of CI
            $scope.assetDatum.push({ 'assetId': 0, 'ciname': $scope.ci });
        })
        
        // Load the Potentially Impacted Assets for that Incident
        $http.get('/getPotentiallyImpactAssets/'+$scope.incidentNo).then(function success(response) {
            $scope.impactedAssetData1=response.data;
            console.log(response.data);
        })
        
        $http.get('/getPotentiallyImpactApps/'+$scope.incidentNo).then(function success(response) {
            $scope.impactedData1=response.data;
            console.log(response.data);
        })
        
         $http.get('/getComments/'+$scope.incidentNo).then(function success(response) {
            $scope.commandList=response.data;
            console.log(response.data);
        })
        
        /*//
        $http.get('sample-data/' + $stateParams.No + 'assetData.js').then(function success(response) {
            $scope.assetData = response.data;
            //$scope.countCAppfn1();
        })
        
        

        //
        $http.get('sample-data/' + $stateParams.No + 'ImpactedData.js').then(function success(response) {
            $scope.impactedData = response.data;
            var List = []
            angular.forEach($scope.impactedData, function (value, key) {
                List.push(value.appName);
                $scope.appList = List;
            })

        })

        $http.get('sample-data/' + $stateParams.No + 'ImpactedAsset.js').then(function success(response) {
            $scope.impactedAssetData = response.data;
            var arrayList = []
            angular.forEach($scope.impactedAssetData, function (value, key) {
                arrayList.push(value.assetName);
                $scope.listToUpdate = arrayList;
            })
        })

        $http.get('sample-data/' + $stateParams.No + 'appData.js').then(function success(response) {
            $scope.applicationData = response.data;
            $scope.countCAppfn();
        })

        //Confirmed Assets Impacted
        $http.get('sample-data/' + $stateParams.No + 'assetData.js').then(function success(response) {
            $scope.assetDatum = response.data;
            $scope.assetDatum.push({ 'assetId': 0, 'assetName': $scope.CIforTable });
            //console.log($scope.assetDatum);
            $scope.countCAppfn();

        })

        $http.get('sample-data/' + $stateParams.No + 'ImpactedData.js').then(function success(response) {
            $scope.impactedData1 = response.data;
            $scope.lengthOfImpactedApp = $scope.impactedData1.length;

            //console.log($scope.lengthOfImpacted);
            $scope.countCAppfn();
        })

        $http.get('sample-data/' + $stateParams.No + 'ImpactedAsset.js').then(function success(response) {
            $scope.impactedAssetData1 = response.data;
            var arr = [];
            angular.forEach($scope.impactedAssetData1, function (v, k) {
                arr.push(v.assetName);
                $scope.impactedAsset1 = arr;
            })
            $scope.countCAppfn();
        })
*/
		    $scope.countCAppfn = function () {
            $scope.countCApp1 = $scope.appData;
            $scope.countCApp = $scope.applicationData;
            $scope.countCAsset = $scope.assetDatum;
            $scope.countPApp = $scope.impactedData1;
            $scope.countPAsset = $scope.impactedAssetData1;
            ;
        }


        // Function to add the new Asset to the Potential Assets
        $scope.addToListAsset1 = function (val) {
            var len = $scope.listToUpdate.length;
            var str = $scope.Model;
            Polymer.dom(document).querySelector("#five").modalButtonClicked();

            if (str.length !== 0) {

                var addData = $scope.Model;
                $scope.impactedAssetData.push({ 'ciname': addData });
                //console.log($scope.impactedAssetData)
            }
            if (val.length !== 0) {
                var len2 = $scope.impactedAsset1.length;

                $scope.impactedAssetData1.push({'ciname': val });

            }
            $scope.Model = '';

        }

        $scope.addToListApp1 = function (val) {
            //console.log(val.length);
            var len = $scope.appList.length;
            Polymer.dom(document).querySelector("#four").modalButtonClicked();
            if (val.length !== 0) {
                $scope.appList.push();
                $scope.impactedData.push({ 'appId': len + 1, 'appName': val });
            }
            if (val.length !== 0) {
                var len1 = $scope.lengthOfImpactedApp
                $scope.impactedData1.push({ 'appId': len1 + 1, 'appName': val });

            }
            $scope.Modeltext1 = '';
        }

        $scope.cls = 'green';

        $scope.changeColor = function (id, sec, par) {
                    
            //$scope.cls=$scope.cls==='green'?'red':'green';
            if ($('.cr_' + sec + '_' + id).hasClass('green')) {
                /* $scope.checked=false;
                 $('.cr_'+sec+'_'+id).*/
                $('.cr_' + par + '_' + id).removeClass('fa-toggle-on');
                $('.cr_' + par + '_' + id).addClass('fa-toggle-off');
                $('.cr_' + sec + '_' + id).removeClass('green');
                $('.cr_' + sec + '_' + id).addClass('red');
            } else {
                $('.cr_' + par + '_' + id).addClass('fa-toggle-on');
                $('.cr_' + par + '_' + id).removeClass('fa-toggle-off');
                //$scope.checked=true;
                $('.cr_' + sec + '_' + id).addClass('green')
                $('.cr_' + sec + '_' + id).removeClass('red')
            }

        }
        
        $scope.cmdCenter = '';
        $scope.addToCommandCenter = function (obj) {
            var dateVal = new Date();
            var datev = dateVal.getTime();


            if (obj !== null) {
                $scope.commandList.push({ 'id': datev, 'comment': $scope.cmdCenter,'loggedBy':Date.now() });
                //console.log($scope.commandList);
            }
            // console.log($scope.commandList);
            var len = $scope.commandList.length;
            var arr = [];
        }

    }]);
});
