[
    {
        "appId": 1,
        "appName": "PotentailApplication--1"
    },
    {
        "appId": 2,
        "appName": "PotentailApplication--2"
    },
    {
        "appId": 3,
        "appName": "PotentailApplication--3"
    },
    {
        "appId": 4,
        "appName": "PotentailApplication--4"
    },
    {
        "appId": 5,
        "appName": "PotentailApplication--5"
    },
    {
        "appId": 6,
        "appName": "PotentailApplication--6"
    },
    {
        "appId": 7,
        "appName": "PotentailApplication--7"
    },
    {
        "appId": 8,
        "appName": "PotentailApplication--8"
    },
    {
        "appId": 9,
        "appName": "PotentailApplication--9"
    },
    {
        "appId": 10,
        "appName": "PotentailApplication--10"
    },
    {
        "appId": 11,
        "appName": "PotentailApplication--11"
    },
    {
        "appId": 12,
        "appName": "PotentailApplication--12"
    },
    {
        "appId": 13,
        "appName": "PotentailApplication--13"
    },
    {
        "appId": 14,
        "appName": "PotentailApplication--14"
    },
    {
        "appId": 15,
        "appName": "PotentailApplication--15"
    }
]