package com.srvcnow.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.util.DateUtils;

import com.srvcnow.dto.CI;
import com.srvcnow.dto.Comment;
import com.srvcnow.dto.Incident;

import scala.annotation.meta.setter;

@RestController
public class IncidentController {

	@RequestMapping(value = "/getincident/{incidentId}")
	public @ResponseBody Incident getincident(@PathVariable("incidentId") String incidentId) {
		
		Incident inc=  new Incident();
		inc.setIncidentId(incidentId);
		inc.setDescription("this is the descriouob if te adg fhsa  sahge asgf dj sjekashdfkhdfs");
		inc.setCi("CI Name");
		return inc;
	}

	@RequestMapping(value = "/getPotentiallyImpactAssets/{incidentId}")
	public @ResponseBody List getPotentiallyImpactAssets(@PathVariable("incidentId") String incidentId) {
		
		List al =  new ArrayList();
		
		CI inc=  new CI();
		inc.setCiname("CI Name 1");
		al.add(inc);
		
		inc=  new CI();
		inc.setCiname("CI Name 2");
		al.add(inc);
		
		inc=  new CI();
		inc.setCiname("CI Name 3");
		al.add(inc);
		
		inc=  new CI();
		inc.setCiname("CI Name 4");
		al.add(inc);
		return al;
	}
	
	@RequestMapping(value = "/getPotentiallyImpactApps/{incidentId}")
	public @ResponseBody List getPotentiallyImpactApps(@PathVariable("incidentId") String incidentId) {
		
		List al =  new ArrayList();
		
		CI inc=  new CI();
		inc.setCiname("App Nam1 1");
		al.add(inc);
		
		inc=  new CI();
		inc.setCiname("App Name 2");
		al.add(inc);
		
		inc=  new CI();
		inc.setCiname("App Name 3");
		al.add(inc);
		
		inc=  new CI();
		inc.setCiname("App Name 4");
		al.add(inc);
		return al;
	}
	
	@RequestMapping(value = "/getComments/{incidentId}")
	public @ResponseBody List getComments(@PathVariable("incidentId") String incidentId) {
		
		List al =  new ArrayList();
		Comment c1 = new Comment(); 
		c1.setComment("0 New comments"); 
		c1.setId(Integer.parseInt("1"));
		c1.setLoggedDate(DateUtils.createNow()); al.add(c1);
		
		c1 = new Comment(); 
		c1.setComment("1 This stages them for the first commit 1. "); 
		c1.setId(Integer.parseInt("1")); 
		c1.setLoggedDate(DateUtils.createNow()); al.add(c1);
		
		c1 = new Comment();
		c1.setComment("2 New Commit the files that you've staged in your local repository ."); c1.setId(Integer.parseInt("1")); 
		c1.setLoggedDate(DateUtils.createNow()); al.add(c1);
		
		c1 = new Comment();
		c1.setComment("3 New At the top of your GitHub repository's Quick Setup page, cli"); c1.setId(Integer.parseInt("1")); 
		c1.setLoggedDate(DateUtils.createNow()); al.add(c1);
		
		c1 = new Comment();
		c1.setComment("4 New Push the changes in your local repository to GitHub."); c1.setId(Integer.parseInt("1")); 
		c1.setLoggedDate(DateUtils.createNow()); al.add(c1);
		
		
		return al;
	}
	
	
	
}
