package com.srvcnow.dto;

import java.util.Calendar;
import java.util.Date;

public class Comment {

	public Integer id;
	public String comment;
	public String loggedBy;
	public Calendar loggedDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getLoggedBy() {
		return loggedBy;
	}

	public void setLoggedBy(String loggedBy) {
		this.loggedBy = loggedBy;
	}

	public Calendar getLoggedDate() {
		return loggedDate;
	}

	public void setLoggedDate(Calendar loggedDate) {
		this.loggedDate = loggedDate;
	}

}
