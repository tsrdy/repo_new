package com.gehc.wire.common.form;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.gehc.wire.common.service.CommonService;


/**
 * @author 703092428
 * @FileName AjaxForm.java
 * @CreateDate Nov 26, 2012
 */
public class AjaxForm {
	public AjaxForm(){}
    
	private String country = null;
	private String sso = null;
	private String year = null;	
	private String view = null;
	private String date1Year1 = null;	
	private String date2Year1 = null;	
	private String date3Year1 = null;	
	private String date4Year1 = null;	
	private String date1Year2 = null;	
	private String date2Year2 = null;	
	private String date3Year2 = null;	
	private String date4Year2 = null;	
	
	
	private String oprate = null;
	private String timeLineType=null;
	private String[] region = null;
	private String[] modality = null;
	private String startYear = null;
	private String endYear = null;
	private String macroIndicater= null;
	private String reportType=null;
	private String pageType=null;
	private String controllerName=null;
	private String procID = null;
	private String[] competitors=null;
	private String[] variable=null;
	private String[] selection=null;
	private String viewVariable=null;
	private String fromType=null;
	
	private String region1 = null;
	private String modality1 = null;
	private String region2 = null;
	private String modality2 = null;
	private String region3 = null;
	private String modality3 = null;
	private String modalityArray = null;
	private String regionArray = null;
	
	private String regionVsOne= null;
	private String regionVsTwo= null;
	private String regionVsThree= null;
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the sso
	 */
	public String getSso() {
		return sso;
	}
	/**
	 * @param sso the sso to set
	 */
	public void setSso(String sso) {
		this.sso = sso;
	}
	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}
	/**
	 * @return the view
	 */
	public String getView() {
		return view;
	}
	/**
	 * @param view the view to set
	 */
	public void setView(String view) {
		this.view = view;
	}
	/**
	 * @return the date1Year1
	 */
	public String getDate1Year1() {
		return date1Year1;
	}
	/**
	 * @param date1Year1 the date1Year1 to set
	 */
	public void setDate1Year1(String date1Year1) {
		this.date1Year1 = date1Year1;
	}
	/**
	 * @return the date2Year1
	 */
	public String getDate2Year1() {
		return date2Year1;
	}
	/**
	 * @param date2Year1 the date2Year1 to set
	 */
	public void setDate2Year1(String date2Year1) {
		this.date2Year1 = date2Year1;
	}
	/**
	 * @return the date3Year1
	 */
	public String getDate3Year1() {
		return date3Year1;
	}
	/**
	 * @param date3Year1 the date3Year1 to set
	 */
	public void setDate3Year1(String date3Year1) {
		this.date3Year1 = date3Year1;
	}
	/**
	 * @return the date4Year1
	 */
	public String getDate4Year1() {
		return date4Year1;
	}
	/**
	 * @param date4Year1 the date4Year1 to set
	 */
	public void setDate4Year1(String date4Year1) {
		this.date4Year1 = date4Year1;
	}
	/**
	 * @return the date1Year2
	 */
	public String getDate1Year2() {
		return date1Year2;
	}
	/**
	 * @param date1Year2 the date1Year2 to set
	 */
	public void setDate1Year2(String date1Year2) {
		this.date1Year2 = date1Year2;
	}
	/**
	 * @return the date2Year2
	 */
	public String getDate2Year2() {
		return date2Year2;
	}
	/**
	 * @param date2Year2 the date2Year2 to set
	 */
	public void setDate2Year2(String date2Year2) {
		this.date2Year2 = date2Year2;
	}
	/**
	 * @return the date3Year2
	 */
	public String getDate3Year2() {
		return date3Year2;
	}
	/**
	 * @param date3Year2 the date3Year2 to set
	 */
	public void setDate3Year2(String date3Year2) {
		this.date3Year2 = date3Year2;
	}
	/**
	 * @return the date4Year2
	 */
	public String getDate4Year2() {
		return date4Year2;
	}
	/**
	 * @param date4Year2 the date4Year2 to set
	 */
	public void setDate4Year2(String date4Year2) {
		this.date4Year2 = date4Year2;
	}
	/**
	 * @return the oprate
	 */
	public String getOprate() {
		return oprate;
	}
	/**
	 * @param oprate the oprate to set
	 */
	public void setOprate(String oprate) {
		this.oprate = oprate;
	}
	/**
	 * @return the timeLineType
	 */
	public String getTimeLineType() {
		return timeLineType;
	}
	/**
	 * @param timeLineType the timeLineType to set
	 */
	public void setTimeLineType(String timeLineType) {
		this.timeLineType = timeLineType;
	}
	/**
	 * @return the region
	 */
	public String[] getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(String[] region) {
		this.region = region;
	}
	/**
	 * @return the modality
	 */
	public String[] getModality() {
		return modality;
	}
	/**
	 * @param modality the modality to set
	 */
	public void setModality(String[] modality) {
		this.modality = modality;
	}
	/**
	 * @return the startYear
	 */
	public String getStartYear() {
		return startYear;
	}
	/**
	 * @param startYear the startYear to set
	 */
	public void setStartYear(String startYear) {
		this.startYear = startYear;
	}
	/**
	 * @return the endYear
	 */
	public String getEndYear() {
		return endYear;
	}
	/**
	 * @param endYear the endYear to set
	 */
	public void setEndYear(String endYear) {
		this.endYear = endYear;
	}
	/**
	 * @return the macroIndicater
	 */
	public String getMacroIndicater() {
		return macroIndicater;
	}
	/**
	 * @param macroIndicater the macroIndicater to set
	 */
	public void setMacroIndicater(String macroIndicater) {
		this.macroIndicater = macroIndicater;
	}
	/**
	 * @return the reportType
	 */
	public String getReportType() {
		return reportType;
	}
	/**
	 * @param reportType the reportType to set
	 */
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	/**
	 * @return the pageType
	 */
	public String getPageType() {
		return pageType;
	}
	/**
	 * @param pageType the pageType to set
	 */
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	/**
	 * @return the controllerName
	 */
	public String getControllerName() {
		return controllerName;
	}
	/**
	 * @param controllerName the controllerName to set
	 */
	public void setControllerName(String controllerName) {
		this.controllerName = controllerName;
	}
	/**
	 * @return the procID
	 */
	public String getProcID() {
		return procID;
	}
	/**
	 * @param procID the procID to set
	 */
	public void setProcID(String procID) {
		this.procID = procID;
	}
	/**
	 * @return the competitors
	 */
	public String[] getCompetitors() {
		return competitors;
	}
	/**
	 * @param competitors the competitors to set
	 */
	public void setCompetitors(String[] competitors) {
		this.competitors = competitors;
	}
	/**
	 * @return the variable
	 */
	public String[] getVariable() {
		return variable;
	}
	/**
	 * @param variable the variable to set
	 */
	public void setVariable(String[] variable) {
		this.variable = variable;
	}
	/**
	 * @return the selection
	 */
	public String[] getSelection() {
		return selection;
	}
	/**
	 * @param selection the selection to set
	 */
	public void setSelection(String[] selection) {
		this.selection = selection;
	}
	/**
	 * @return the viewVariable
	 */
	public String getViewVariable() {
		return viewVariable;
	}
	/**
	 * @param viewVariable the viewVariable to set
	 */
	public void setViewVariable(String viewVariable) {
		this.viewVariable = viewVariable;
	}
	/**
	 * @return the fromType
	 */
	public String getFromType() {
		return fromType;
	}
	/**
	 * @param fromType the fromType to set
	 */
	public void setFromType(String fromType) {
		this.fromType = fromType;
	}
	/**
	 * @return the region1
	 */
	public String getRegion1() {
		return region1;
	}
	/**
	 * @param region1 the region1 to set
	 */
	public void setRegion1(String region1) {
		this.region1 = region1;
	}
	/**
	 * @return the modality1
	 */
	public String getModality1() {
		return modality1;
	}
	/**
	 * @param modality1 the modality1 to set
	 */
	public void setModality1(String modality1) {
		this.modality1 = modality1;
	}
	/**
	 * @return the region2
	 */
	public String getRegion2() {
		return region2;
	}
	/**
	 * @param region2 the region2 to set
	 */
	public void setRegion2(String region2) {
		this.region2 = region2;
	}
	/**
	 * @return the modality2
	 */
	public String getModality2() {
		return modality2;
	}
	/**
	 * @param modality2 the modality2 to set
	 */
	public void setModality2(String modality2) {
		this.modality2 = modality2;
	}
	/**
	 * @return the region3
	 */
	public String getRegion3() {
		return region3;
	}
	/**
	 * @param region3 the region3 to set
	 */
	public void setRegion3(String region3) {
		this.region3 = region3;
	}
	/**
	 * @return the modality3
	 */
	public String getModality3() {
		return modality3;
	}
	/**
	 * @param modality3 the modality3 to set
	 */
	public void setModality3(String modality3) {
		this.modality3 = modality3;
	}
	/**
	 * @return the modalityArray
	 */
	public String getModalityArray() {
		return modalityArray;
	}
	/**
	 * @param modalityArray the modalityArray to set
	 */
	public void setModalityArray(String modalityArray) {
		this.modalityArray = modalityArray;
	}
	/**
	 * @return the regionArray
	 */
	public String getRegionArray() {
		return regionArray;
	}
	/**
	 * @param regionArray the regionArray to set
	 */
	public void setRegionArray(String regionArray) {
		this.regionArray = regionArray;
	}
	/**
	 * @return the regionVsOne
	 */
	public String getRegionVsOne() {
		return regionVsOne;
	}
	/**
	 * @param regionVsOne the regionVsOne to set
	 */
	public void setRegionVsOne(String regionVsOne) {
		this.regionVsOne = regionVsOne;
	}
	/**
	 * @return the regionVsTwo
	 */
	public String getRegionVsTwo() {
		return regionVsTwo;
	}
	/**
	 * @param regionVsTwo the regionVsTwo to set
	 */
	public void setRegionVsTwo(String regionVsTwo) {
		this.regionVsTwo = regionVsTwo;
	}
	/**
	 * @return the regionVsThree
	 */
	public String getRegionVsThree() {
		return regionVsThree;
	}
	/**
	 * @param regionVsThree the regionVsThree to set
	 */
	public void setRegionVsThree(String regionVsThree) {
		this.regionVsThree = regionVsThree;
	}
	
	
	
	
}
