package com.gehc.wire.common.utilities;

import java.io.File;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.URLName;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.Part; 



public class SendMail {
	public void doPostCCBCCMail(String recipients[], String ccRecipients[], String bccRecipients[], String subject, String message, String from) throws MessagingException {
		boolean debug = false;
		
		/*
	     //Set the host smtp address
	     Properties props = new Properties();
	     props.put("mail.smtp.host", "mail.ad.ge.com");
	     //props.put("mail.smtp.host", "58.2.58.174"); // genpact mail server 
	     
	    // create some properties and get the default Session
	    Session session = Session.getDefaultInstance(props, null);
	    session.setDebug(debug);
*/
		
		//ResourceBundle resbundle = ResourceBundle.getBundle("properties.Config");
		/*String SMTPServer=resbundle.getString("GENPACT_MAILSERVER");
		String SMTPUsername=resbundle.getString("GENPACT_MAILSERVER_USERNAME");
		String SMTPPassword=resbundle.getString("GENPACT_MAILSERVER_PASSWORD");
		*/
		String SMTPServer="mail.ad.ge.com";
		String SMTPUsername="r00180327";
		String SMTPPassword="Pa55word";
		
		
		System.out.println("SMTPServer is..."+SMTPServer);
		System.out.println("username for smtp is..."+SMTPUsername);
		System.out.println("password for smtp is..."+SMTPPassword);
		
		
		Session session = null;
		Properties props = new Properties();
		props.put("mail.smtp.host", SMTPServer);
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.connectiontimeout", "5000");
		props.put("mail.debug", "false");
		
		
		if("NA".equalsIgnoreCase(SMTPUsername))
		{
			props.put("mail.smtp.auth", "false");
			
			session = Session.getDefaultInstance(props, null);
		}
		else
		{
			props.put("mail.smtp.auth", "true");
			Authenticator loAuthenticator = new MailAuthenticator(SMTPUsername,SMTPPassword);            
		    session = Session.getDefaultInstance(props,loAuthenticator);
		}
	    // create a message
	    Message msg = new MimeMessage(session);

	    // set the from and to address
	    InternetAddress addressFrom = new InternetAddress(from);
	    msg.setFrom(addressFrom);

	    InternetAddress[] addressTo = new InternetAddress[recipients.length]; 
	    for (int i = 0; i < recipients.length; i++)
	    {
	        addressTo[i] = new InternetAddress(recipients[i]);
	    }
	    msg.setRecipients(Message.RecipientType.TO, addressTo);
	    
	    
	    
	    
	    InternetAddress[] addressCCTo = new InternetAddress[ccRecipients.length]; 
	    for (int i = 0; i < ccRecipients.length; i++)
	    {
	    	addressCCTo[i] = new InternetAddress(ccRecipients[i]);
	    }
	    msg.setRecipients(Message.RecipientType.CC, addressCCTo);
	   
	    InternetAddress[] addressBccTo = new InternetAddress[bccRecipients.length]; 
	    for (int i = 0; i < bccRecipients.length; i++)
	    {
	    	addressBccTo[i] = new InternetAddress(bccRecipients[i]);
	    }
	    msg.setRecipients(Message.RecipientType.BCC, addressBccTo);
	    
	    // Optional : You can also set your custom headers in the Email if you Want
	    msg.addHeader("MyHeaderName", "myHeaderValue");

	    // Setting the Subject and Content Type
	    msg.setSubject(subject);
	    //msg.setContent(message, "text/plain");
	    msg.setContent(message, "text/html");
	    
	    //Transport.send(msg);
	    
		try {
			Transport.send(msg);
		} catch (SendFailedException sfe) {
			msg.setRecipients(Message.RecipientType.TO, sfe.getValidUnsentAddresses());
			msg.setRecipients(Message.RecipientType.CC, sfe.getValidUnsentAddresses());
			Transport.send(msg);

		}

	}

 // End of public class SendMail


public void doPostCCBCCMailWithAttachment(String recipients[], String ccRecipients[], String bccRecipients[], String subject, String message, String from,File oFile,String fileName) throws MessagingException {
	boolean debug = false;
	
	/*
     //Set the host smtp address
     Properties props = new Properties();
     props.put("mail.smtp.host", "mail.ad.ge.com");
     //props.put("mail.smtp.host", "58.2.58.174"); // genpact mail server 
     
    // create some properties and get the default Session
    Session session = Session.getDefaultInstance(props, null);
    session.setDebug(debug);
*/
	
	//ResourceBundle resbundle = ResourceBundle.getBundle("properties.Config");
	/*String SMTPServer=resbundle.getString("GENPACT_MAILSERVER");
	String SMTPUsername=resbundle.getString("GENPACT_MAILSERVER_USERNAME");
	String SMTPPassword=resbundle.getString("GENPACT_MAILSERVER_PASSWORD");
	*/
	String SMTPServer="mail.ad.ge.com";
	String SMTPUsername="r00180327";
	String SMTPPassword="Pa55word";
	
	
	System.out.println("SMTPServer is..."+SMTPServer);
	System.out.println("username for smtp is..."+SMTPUsername);
	System.out.println("password for smtp is..."+SMTPPassword);
	
	
	Session session = null;
	Properties props = new Properties();
	props.put("mail.smtp.host", SMTPServer);
	props.put("mail.transport.protocol", "smtp");
	props.put("mail.smtp.connectiontimeout", "5000");
	props.put("mail.debug", "false");
	
	
	if("NA".equalsIgnoreCase(SMTPUsername))
	{
		props.put("mail.smtp.auth", "false");
		
		session = Session.getDefaultInstance(props, null);
	}
	else
	{
		props.put("mail.smtp.auth", "true");
		Authenticator loAuthenticator = new MailAuthenticator(SMTPUsername,SMTPPassword);            
	    session = Session.getDefaultInstance(props,loAuthenticator);
	}
    // create a message
    Message msg = new MimeMessage(session);

    // set the from and to address
    InternetAddress addressFrom = new InternetAddress(from);
    msg.setFrom(addressFrom);

    InternetAddress[] addressTo = new InternetAddress[recipients.length]; 
    for (int i = 0; i < recipients.length; i++)
    {
        addressTo[i] = new InternetAddress(recipients[i]);
    }
    msg.setRecipients(Message.RecipientType.TO, addressTo);
    
    
    
    
    InternetAddress[] addressCCTo = new InternetAddress[ccRecipients.length]; 
    for (int i = 0; i < ccRecipients.length; i++)
    {
    	addressCCTo[i] = new InternetAddress(ccRecipients[i]);
    }
    msg.setRecipients(Message.RecipientType.CC, addressCCTo);
   
    InternetAddress[] addressBccTo = new InternetAddress[bccRecipients.length]; 
    for (int i = 0; i < bccRecipients.length; i++)
    {
    	addressBccTo[i] = new InternetAddress(bccRecipients[i]);
    }
    msg.setRecipients(Message.RecipientType.BCC, addressBccTo);
    
    // Optional : You can also set your custom headers in the Email if you Want
    msg.addHeader("MyHeaderName", "myHeaderValue");

    // Setting the Subject and Content Type
    msg.setSubject(subject);
    //msg.setContent(message, "text/plain");
    msg.setContent(message, "text/html");
    
    BodyPart messageBodyPart = new MimeBodyPart();
    messageBodyPart.setContent(message, "text/html");
    
    Multipart multipart = new MimeMultipart();
    multipart.addBodyPart(messageBodyPart);
    
    
    messageBodyPart = new MimeBodyPart();
    String filename = fileName+".xls";
    DataSource source = new FileDataSource(oFile);
    messageBodyPart.setContent(message, "text/html");
    messageBodyPart.setDataHandler(new DataHandler(source));
    messageBodyPart.setFileName(filename);
    multipart.addBodyPart(messageBodyPart);
    
    msg.setContent(multipart);
    //Transport.send(msg);
    
	try {
		Transport.send(msg);
	} catch (SendFailedException sfe) {
		msg.setRecipients(Message.RecipientType.TO, sfe.getValidUnsentAddresses());
		msg.setRecipients(Message.RecipientType.CC, sfe.getValidUnsentAddresses());
		Transport.send(msg);

	}

}  // End of public class SendMa

public void doPostCCBCCTaskMailWithAttachment(String recipients[], String ccRecipients[], String bccRecipients[], String subject, String message, String from, String uploadedPath,String taskId) throws MessagingException {
	boolean debug = false;
	
	/*
     //Set the host smtp address
     Properties props = new Properties();
     props.put("mail.smtp.host", "mail.ad.ge.com");
     //props.put("mail.smtp.host", "58.2.58.174"); // genpact mail server 
     
    // create some properties and get the default Session
    Session session = Session.getDefaultInstance(props, null);
    session.setDebug(debug);
*/
	
	//ResourceBundle resbundle = ResourceBundle.getBundle("properties.Config");
	/*String SMTPServer=resbundle.getString("GENPACT_MAILSERVER");
	String SMTPUsername=resbundle.getString("GENPACT_MAILSERVER_USERNAME");
	String SMTPPassword=resbundle.getString("GENPACT_MAILSERVER_PASSWORD");
	*/
	String SMTPServer="mail.ad.ge.com";
	String SMTPUsername="r00180327";
	String SMTPPassword="Pa55word";
	String fileName = "";
	
	System.out.println("SMTPServer is..."+SMTPServer);
	System.out.println("username for smtp is..."+SMTPUsername);
	System.out.println("password for smtp is..."+SMTPPassword);
	
	
	Session session = null;
	Properties props = new Properties();
	props.put("mail.smtp.host", SMTPServer);
	props.put("mail.transport.protocol", "smtp");
	props.put("mail.smtp.connectiontimeout", "5000");
	props.put("mail.debug", "false");
	
	
	if("NA".equalsIgnoreCase(SMTPUsername))
	{
		props.put("mail.smtp.auth", "false");
		
		session = Session.getDefaultInstance(props, null);
	}
	else
	{
		props.put("mail.smtp.auth", "true");
		Authenticator loAuthenticator = new MailAuthenticator(SMTPUsername,SMTPPassword);            
	    session = Session.getDefaultInstance(props,loAuthenticator);
	}
    // create a message
    Message msg = new MimeMessage(session);

    // set the from and to address
    InternetAddress addressFrom = new InternetAddress(from);
    msg.setFrom(addressFrom);

    InternetAddress[] addressTo = new InternetAddress[recipients.length]; 
    for (int i = 0; i < recipients.length; i++)
    {
        addressTo[i] = new InternetAddress(recipients[i]);
    }
    msg.setRecipients(Message.RecipientType.TO, addressTo);
    
    
    
    
    InternetAddress[] addressCCTo = new InternetAddress[ccRecipients.length]; 
    for (int i = 0; i < ccRecipients.length; i++)
    {
    	addressCCTo[i] = new InternetAddress(ccRecipients[i]);
    }
    msg.setRecipients(Message.RecipientType.CC, addressCCTo);
   
    InternetAddress[] addressBccTo = new InternetAddress[bccRecipients.length]; 
    for (int i = 0; i < bccRecipients.length; i++)
    {
    	addressBccTo[i] = new InternetAddress(bccRecipients[i]);
    }
    msg.setRecipients(Message.RecipientType.BCC, addressBccTo);
    
    // Optional : You can also set your custom headers in the Email if you Want
    msg.addHeader("MyHeaderName", "myHeaderValue");

    // Setting the Subject and Content Type
    msg.setSubject(subject);
    //msg.setContent(message, "text/plain");
    msg.setContent(message, "text/html");
    
    BodyPart messageBodyPart = new MimeBodyPart();
    messageBodyPart.setContent(message, "text/html");
    
    Multipart multipart = new MimeMultipart();
    multipart.addBodyPart(messageBodyPart);
    
    
    messageBodyPart = new MimeBodyPart();
    
    File file = new File(uploadedPath);
    
    if(file.exists()){
    File[] files = file.listFiles(); 
    
    for (int i = 0; i < files.length; i++)  
    {  
	    System.out.println(files[i].getName());  
	    DataSource source = new FileDataSource(uploadedPath+"/"+files[i].getName());
	    messageBodyPart.setContent(message, "text/html");
	    messageBodyPart.setDataHandler(new DataHandler(source));
	    messageBodyPart.setFileName(files[i].getName());
	    multipart.addBodyPart(messageBodyPart);
    } 
    }
    
    msg.setContent(multipart);
    //Transport.send(msg);
    
	try {
		Transport.send(msg);
	} catch (SendFailedException sfe) {
		msg.setRecipients(Message.RecipientType.TO, sfe.getValidUnsentAddresses());
		msg.setRecipients(Message.RecipientType.CC, sfe.getValidUnsentAddresses());
		Transport.send(msg);

	}

}

}  // End of public class SendMa


class MailAuthenticator extends Authenticator
{
	String smtpUsername = "";
	String smtpPassword ="";
	public MailAuthenticator(String smtpUsername,String smtpPassword)
	{
		this.smtpUsername = smtpUsername;
		this.smtpPassword = smtpPassword;
	}
	public PasswordAuthentication getPasswordAuthentication() 
	{
		return new PasswordAuthentication(smtpUsername,smtpPassword);
	}
} 
