package com.gehc.wire.common.utilities;

public class PaginationUtil {

	public static String Pagination(int numOfRec, int recPerPage, int currPage, String url) {
		StringBuffer ressurl = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append(url).append(spChar).append("pageNo=1&pagenation=Y&numofrec=").append(numOfRec).append("\">First</a></u></b>\n");
    	   // Link to previous page
    	   if (currPage > 1) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append(url).append(spChar).append("pageNo=").append(currPage - 1).append("&pagenation=Y&numofrec=").append(numOfRec).append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append(url).append(spChar).append("pageNo=").append(currPage + 1).append("&pagenation=Y&numofrec=").append(numOfRec).append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append(url).append(spChar).append("pageNo=").append(pages).append("&pagenation=Y&numofrec=").append(numOfRec).append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pageNo\" name=\"pageNo\" style=\"font-size:9px\" onchange=\"pagination()\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   ressurl.append("<script type\"=text/javascript\">\n");
    	   ressurl.append("function pagination() {\n");
    	   ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");
    	  }
    	  return ressurl.toString();
    	 }

	public static String PaginationWithFilter(int numOfRec, int recPerPage, int currPage, String url, String filterData) {
		StringBuffer ressurl = new StringBuffer();
		StringBuffer urlBuffer = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		
		//url = url+filterData;
		urlBuffer.append(url);
		
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   urlBuffer.append(spChar).append("pNo=1").toString();
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('1','"+url+"');").append("\">First</a></u></b>\n");
    	   
    	  // ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append(url).append(spChar).append("pNo=1&pagenation=Y&numofrec=").append(numOfRec).append("\">First</a></u></b>\n");
    	   
    	   
    	   
    	   // Link to previous page
    	   if (currPage > 1) {
    		   urlBuffer = new StringBuffer();
    		   urlBuffer.append(url);
    		   urlBuffer.append(spChar).append("pNo=").append(currPage - 1).toString();
    		   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('"+(currPage - 1)+"','"+url+"');").append("\"><<</a></u></b>\n");
    	       //ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append(url).append(spChar).append("pNo=").append(currPage - 1).append("&pagenation=Y&numofrec=").append(numOfRec).append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    		   urlBuffer = new StringBuffer();
    		   urlBuffer.append(url);
    		   urlBuffer.append(spChar).append("pNo=").append(currPage + 1).toString();
    		   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('"+(currPage + 1)+"','"+url+"');").append("\">>></a></u></b>\n");
    	       //ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append(url).append(spChar).append("pNo=").append(currPage + 1).append("&pagenation=Y&numofrec=").append(numOfRec).append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   urlBuffer = new StringBuffer();
    	   urlBuffer.append(url);
    	   urlBuffer.append(spChar).append("pNo=").append(pages).toString();
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('"+(pages)+"','"+url+"');").append("\">Last</a></u></b>\n");
    	   //ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append(url).append(spChar).append("pNo=").append(pages).append("&pagenation=Y&numofrec=").append(numOfRec).append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pNo\" name=\"pNo\" style=\"font-size:9px\" onchange=\"pagination('"+url+"')\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   /*ressurl.append("<script type\"=text/javascript\">\n");
    	   //ressurl.append("function pagination() {\n");
    	  // ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");*/
    	  }
    	  return ressurl.toString();
	}

}
