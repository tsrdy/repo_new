package com.gehc.wire.common.constants;



/**
 * @author 703092428
 * @FileName SDMConstants.java
 * @DataOfCreation Jun 24, 2013
 */
public class MPRConstants{

	/*
	 * The below constants are used in Ajax calls
	 */
	public static final Object APP_ADMINLOOKUP_TARGETTYPE_COMBO = "comboBox";
	public static final Object APP_ADMINLOOKUP_TARGETTYPE_TEXT = "textData";
	public static final String APP_ADMINLOOKUP_TARGETTYPE_DEFAULT = "comboBox";
	public static final String APP_ADMINLOOKUP_TARGETOBJECTS = "targetObjects";
	public static final String APP_REQUEST_CANINCLUDE_INACTIVE = "canIncludeInactive";
	public static final String APP_ADMINLOOKUP_SELECTEDOPTION = "selectedOption";

	

	/*
	 * The below Constant is user to identify user's session object
	 */
	public static final String APP_LOGINUSER_INFO = "loginUserInfo";
	
	/*
	 * Application properties file name
	 */
	public static final String APP_PRPPERTIES_FILE = "app";
	/*
	 * Data Source related constants
	 */
	public static final String APP_DS_NAME = "APP_DS_NAME";
	public static final String APP_DS_ENV = "APP_DS_ENV";
	public static final String APP_UPLOAD_PATH = "APP_UPLOAD_PATH";
	
	public static final String APP_FINANCE_FILE = "APP_FINANCE_FILE";
	public static final String APP_REMOTE_FILE = "APP_REMOTE_FILE";
	
	
	
	
	public static final String APP_DOWNLOAD_PATH = "APP_DOWNLOAD_PATH";
	public static final String APP_LOCAL_HEADER_PATH = "APP_LOCAL_HEADER_PATH";
	public static final String APP_LOCAL_FOOTER_PATH = "APP_LOCAL_FOOTER_PATH";

	public static final String APP_DB_SCHEMA = "APP_DB_SCHEMA";
	
	
	public static final String APP_PICKLIST_QUARTER = "APP_PICKLIST_QUARTER";
	public static final String APP_SERVER = "APP_SERVER";
	public static final String APP_FILTER_YEAR = "YEAR";
	public static final String APP_FILTER_YEAR_DATE = "YEAR_DATE";
	public static final String APP_FILTER_REGION = "REGION";
	public static final String APP_FILTER_MODALITY = "MODALITY";
	public static final String APP_FILTER_VIEW = "VIEW";
	public static final String PROC_GET_SUB_REGION_DATA = "subRegionview";	
	public static final String APP_FILTER_DATES_YEAR = "DATESYEAR";
	public static final String APP_FILTER_TIME_LINE_TYPE = "TIME_LINE_TYPE";
	public static final String APP_FILTER_BU_TIMELINE = "TIMELINE_BU";
	public static final String APP_MAIL_SERVER = "APP_MAIL_SERVER";
	public static final String APP_MAILSERVER_USERNAME = "APP_MAILSERVER_USERNAME";
	public static final String APP_MAILSERVER_PASSWORD = "APP_MAILSERVER_PASSWORD";
	public static final String APP_PICKLIST_HIGHLEVELGROUPING = "APP_PICKLIST_HIGHLEVELGROUPING";
	public static final String APP_PICKLIST_QUOTETERM = "APP_PICKLIST_QUOTETERM";
	public static final String APP_PICKLIST_NUMBEROFYEARS = "APP_PICKLIST_NUMBEROFYEARS";
	public static final String APP_PICKLIST_QUOTEPCSOPTIONS = "APP_PICKLIST_QUOTEPCSOPTIONS";
	public static final String APP_PICKLIST_TELEMETARYOPTIONS = "APP_PICKLIST_TELEMETARYOPTIONS";
	public static final String APP_PICKLIST_SQFT = "APP_PICKLIST_SQFT";
	public static final String APP_PICKLIST_BILLINGTYPE = "APP_PICKLIST_BILLINGTYPE";
	public static final String APP_ADMINLOOKUP_TYPE = "type";
	public static final String APP_ADMINLOOKUP_SEVERITY = "severity";
	public static final String APP_ADMINLOOKUP_SUBJECT = "subject";
	public static final String APP_ADMINLOOKUP_FEEDBACKDESC = "feedIssiesDesc";
	public static final String APP_ADMINLOOKUP_ISSUEID = "issueId";
	public static final String APP_ADMINLOOKUP_COMMENTS = "comments";
	public static final String APP_ADMINLOOKUP_STATUS = "feedBackStatus";
	public static final String APP_FILTER_COMPETITIORS_LIST = "COMPETITIORS_LIST";
	public static final String APP_FILTER_VIEW_VARIABLE_LIST = "VIEW_VARIABLE_LIST";
	public static final String APP_FILTER_VIEW_VARIABLE_OP_LIST = "VIEW_VARIABLE_OP_LIST";
	public static final String APP_DB_DNS = "APP_DB_DNS";
	public static final String APP_PICKLIST_FOREXEXCHANGE = "ForexExchange";
	public static final String APP_PICKLIST_GROUP = "GROUP";
	
	public static final String APP_USER_STATUS_VALID = "Y";
	public static final String APP_USER_STATUS_PENDING = "pending";
	public static final String APP_USER_STATUS_REJECTED = "rejected";
	public static final String APP_USER_STATUS_NEW = "new";
	public static final String APP_PICKLIST_YEAR = "year";
	public static final String APP_PICKLIST_QTR = "qtr";
	public static final String APP_PICKLIST_MONTH = "month";
	public static final String APP_PICKLIST_FWEEK = "fweek";
	public static final String APP_PICKLIST_SERVICE_COCKPIT_FWEEK = "cockPitfweek";
	public static final String APP_PICKLIST_SERVICE_COCKPIT_YEAR = "cockPityear";
	public static final String APP_PICKLIST_BUSINESS = "business";
	public static final String APP_PICKLIST_MODALITY1 = "modality1";
	public static final String APP_PICKLIST_MODALITY2 = "modality2";
	public static final String APP_PICKLIST_PRODUCT = "product";
	public static final String APP_PICKLIST_SERVICE_REGION = "serviceRegion";
	public static final String APP_PICKLIST_SUB_REGION = "subRegion";
	public static final String APP_PICKLIST_SUB_REGION_PRE_ADJUSTMENTS = "preAdjustSubRegion";
	public static final String APP_PICKLIST_SUB_REGION_SALES = "subRegionSales";
	public static final String APP_PICKLIST_COUNTRY_ZONE = "countryZone";
	public static final String APP_PICKLIST_LCT = "lct";
	public static final String APP_PICKLIST_SUBMODALITY = "subModality";
	public static final String APP_PICKLIST_SEGMENT = "segment";
	public static final String APP_PICKLIST_REPORT_TYPE = "reportType";
	public static final String APP_PICKLIST_STATUS_TYPE = "statusType";
	public static final String APP_PICKLIST_USER_ROLE = "userROle";
	public static final String APP_PICKLIST_SCHEDULE_HOUR= "scheduleHour";
	public static final String APP_PICKLIST_SCHEDULE_MIN = "scheduleMin";
	public static final String APP_PICKLIST_SCHEDULE_FREQUENCY = "scheduleFreq";
	public static final String APP_PICKLIST_SCHEDULE_TIME_ZONE = "scheduleZone";
	public static final String APP_PICKLIST_METRICS = "metrics";
	public static final String APP_PICKLIST_SUB_METRICS = "submetrics";
	public static final String APP_PICKLIST_ISSUE_TYPE = "issuetype";
	
	
	public static final String APP_PICKLIST_IB_FILTER_COLUMN = "ibFilterColumn";
	public static final String APP_PICKLIST_IB_DROPDOWNS = "ibDropDowns";
	
	public static final String APP_PICKLIST_IB_JAPAN_FILTER_COLUMN = "ibJapanFilterColumn";
	public static final String APP_PICKLIST_IB_DROPDOWNS_JAPAN = "ibJapanDropDowns";
	
	public static final String APP_PICKLIST_OPEN_DISPATCH_FILTER_COLUMN = "openDispatchFilterColumn";
	public static final String APP_PICKLIST_OPEN_DISPATCH_DROPDOWNS= "openDispatchDropDowns";
	
	public static final String APP_PICKLIST_CLOSED_DISPATCH_FILTER_COLUMN = "closedDispatchFilterColumn";
	public static final String APP_PICKLIST_CLOSED_DISPATCH_DROPDOWNS= "closedDispatchDropDowns";
	
	public static final String APP_PICKLIST_OPEN_DISPATCH_REPORT_TYPE = "openDisptachReportType";
	public static final String APP_PICKLIST_ETTR_REPORT_TYPE = "ETTRReportType";
	public static final String APP_PICKLIST_FINANCE_REPORT_TYPE = "FinanceReportType";
	public static final String APP_PICKLIST_SERVICE_TYPE = "ServiceType";
	
	public static final String APP_PICKLIST_PARENT_FOLDERS = "parent";
	public static final String APP_PICKLIST_SUB_PARENT_FOLDERS = "SubParent";
	public static final String APP_REPORT_FINANCE = "Finance";
	public static final String APP_REPORT_PRODUCTIVITY = "Productivity";
	public static final String APP_REPORT_SALES = "Sales";
	public static final String APP_REPORT_DFR = "DFR";
	
	public static final String APP_REPORT_REMOTE = "Remote";
	
	public static final String APP_REPORT_GST = "GST";
	public static final String APP_PICKLIST_DATASET = "DataSet";
	
	public static final String APP_PICKLIST_FMI_MODALITY = "fmiModality";
	
	public static final String APP_PICKLIST_MODALITY_PATPI = "patPIModality";
	public static final String APP_PICKLIST_COUNTRY_ZONE_PATPI = "patPICountry";
	public static final String APP_PICKLIST_SEGMENT_PATPI = "patPISegment";
	
	public static final String APP_PICKLIST_MODALITY_CSO = "csoModality";
	public static final String APP_PICKLIST_SUB_MODALITY_CSO = "csoSubModality";
	public static final String APP_PICKLIST_SEGMENT_CSO = "csoSegment";
	public static final String APP_PICKLIST_PRODUCT_CSO = "csoProduct";
	public static final String APP_PICKLIST_FOA_REPORT_TYPE = "foaReportType";
	public static final String APP_PICKLIST_INVENTORY_MODALITY = "inventoryModality";
	
	
	
	
	
	public static final String APP_PICKLIST_SETTINGS_QUARTER = "settingsQuarter";
	public static final String APP_PICKLIST_SETTINGS_YEAR = "settingsYear";
	public static final String APP_PICKLIST_SETTINGS_REGION = "settingsRegion";
	public static final String APP_PICKLIST_ASSIGNED_TO = "assignedTo";
	public static final String APP_PICKLIST_SETTINGS_SUB_REGION = "settingsSubRegion";
	
	public static final String APP_PICKLIST_SETTINGS_GROUP = "group";
	public static final String APP_PICKLIST_SETTINGS_MODALITY1 = "modality1";
	public static final String APP_PICKLIST_SETTINGS_MODALITY = "modality1";
	public static final String APP_PICKLIST_SETTINGS_MODALITY2 = "modality2";
	public static final String APP_PICKLIST_SETTINGS_SUBMODALITY = "submodality";
	public static final String APP_PICKLIST_SETTINGS_SEGMENT = "segment";
	public static final String APP_PICKLIST_SETTINGS_PRODUCT = "product";
	public static final String APP_PICKLIST_SETTINGS_COUNTRY = "country";
	public static final String APP_PICKLIST_SETTINGS_REGIONS = "region";
	public static final String APP_PICKLIST_SETTINGS_SUBREGION = "subregioin";
	public static final String APP_PICKLIST_SETTINGS_STATE = "sState";
	
	public static final String APP_PICKLIST_SUPPORT_STATUS = "status";
	public static final String APP_PICKLIST_SUPPORT_PROBLEMTYPE = "problemtype";
	public static final String APP_PICKLIST_SUPPORT_PROBLEMSUBTYPE = "problemsubtype";
	public static final String APP_PICKLIST_SUPPORT_PROBLEMPRIORITY = "problempriority";
	
	
	public static final String APP_PICKLIST_SERVICE_REGION_ONE = "serviceRegionOne";
	public static final String APP_PICKLIST_SERVICE_REGION_TWO = "serviceRegionTwo";
	
	public static final String APP_PICKLIST_COLUMNS = "columns";
	public static final String APP_PICKLIST_TYPE = "type";
	
	
	
	
}