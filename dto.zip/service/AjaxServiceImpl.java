package com.gehc.wire.common.service;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.dao.AjaxDao;
import com.gehc.wire.common.dao.PickListDao;
import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.common.exceptions.BusinessDefinedException;



public class AjaxServiceImpl extends BaseService implements AjaxService{


	
	@Autowired
	PickListDao oPickListDao;
	AjaxDao oAjaxDao;
	private DBService dBService;

	
	@Autowired
	public void setPickListDAO(PickListDao oPickListDao) {
		this.oPickListDao = oPickListDao;
	}

	
	@Autowired
	public void setAjaxDao(AjaxDao oAjaxDao) {
		this.oAjaxDao = oAjaxDao;
	}

	@Autowired
	public void setDBService(DBService dBService) {
		this.dBService = dBService;
	}


	
	public StringBuffer onChangeYear(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map quarter = new HashMap ();  
		  
		
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	quarter =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_QUARTER,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), null,null,null,null,oUserMaster.getSSO());
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (quarter.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(quarter, "", sTargetObjects,sTargetObjects));		            	
            } 
           
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}
	
	
	public StringBuffer onChangeGroup(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map modality = new HashMap ();  
		  
		
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	modality =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_MODALITY1,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION),null, null,null,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (modality.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(modality, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}
	
	

	
	public StringBuffer onChangeModality1(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map modality = new HashMap ();  
		String req1=request.getParameter("requiredObj1");
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	modality =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_MODALITY2,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), req1,null,null,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (modality.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(modality, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}
	
	
	
	
	public StringBuffer onChangeModality2(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map modality = new HashMap ();  
		String req1=request.getParameter("requiredObj1");
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	modality =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_SUBMODALITY,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), req1,null,null,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (modality.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(modality, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}
	
	
	
	
	
	
	public StringBuffer onChangeSubModality(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map modality = new HashMap ();  
		  
		String req1=request.getParameter("requiredObj1");
		String req2=request.getParameter("requiredObj2");
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	modality =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_SEGMENT,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), req1,req2,null,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (modality.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(modality, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}
	
	public StringBuffer onChangeSegment(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map modality = new HashMap ();  
		String req1=request.getParameter("requiredObj1");
		String req2=request.getParameter("requiredObj2");
		String req3=request.getParameter("requiredObj3");
		
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	modality =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_PRODUCT,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), req1,req2,req3,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (modality.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(modality, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}


	@Override
	public StringBuffer onChangesRegion(HttpServletRequest request)
			throws Exception {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map subRegion = new HashMap ();  
		String req1=request.getParameter("requiredObj1");
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	subRegion =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_SUBREGION,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), null,null,null,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (subRegion.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(subRegion, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}
	

	public StringBuffer onChangeRegion(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map modality = new HashMap ();  
		  
		
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	modality =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_SUBREGION,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), null,null,null,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (modality.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(modality, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}
	
	

	
	public StringBuffer onChangeSubRegion(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map modality = new HashMap ();  
		String req1=request.getParameter("requiredObj1");
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	modality =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_SUBREGION,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), req1,null,null,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (modality.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(modality, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}


	@Override
	public StringBuffer onChangeCountry(HttpServletRequest request)
			throws Exception {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		String region = request.getParameter("region");
		String subRegion = request.getParameter("subRegion");
		Map sState = new HashMap ();  
		  
		
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	sState =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SETTINGS_STATE,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), region,subRegion,null,null,null);
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (sState.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(sState, "", sTargetObjects,sTargetObjects));		            	
            } 
	              
	            sbBuiltXML.append("</result>");	
	    		
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}


	@Override
	public String getProblemStatementForRead(String prepareDataID,String columnType) throws Exception {
		Connection conn = null;
		String columnValue = "";
		try{
		conn = dBService.getDBConnection();
		// columnValue = oAjaxDao.getProblemStatement(conn, prepareDataID,columnType);
		}catch (Exception e) {
			throw e;
		}finally{
			try{
				dBService.releaseResources(conn);
			}catch (Exception e) {
				throw e;
			}
		}
			return columnValue;

	}


	@Override
	public StringBuffer onChangePreAdjustSubRegion(HttpServletRequest request)throws Exception {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map quarter = new HashMap ();  
		  
		
		try{
			conn = dBService.getDBConnection();
			
    		UserDto oUserMaster = getUserInfo(request);
    		sTargetObjects = CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS);
    			   
            if (CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_TARGETOBJECTS).trim().length() > 0){
            	quarter =oPickListDao.getListValues(conn, MPRConstants.APP_PICKLIST_SUB_REGION_PRE_ADJUSTMENTS,CommonService.getStringParameter(request, MPRConstants.APP_ADMINLOOKUP_SELECTEDOPTION), "Yes",null,null,null,oUserMaster.getSSO());
                  		
    		} 
            sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
            sbBuiltXML.append("<result>");
            
           
            if (quarter.size() > 0){
            	sbBuiltXML.append(CommonService.generateOptionsXMLByMap(quarter, "", sTargetObjects,sTargetObjects));		            	
            } else{
            	
            	sbBuiltXML.append("<params>");
	    		sbBuiltXML.append("<target>"+sTargetObjects+"</target>");
	    		sbBuiltXML.append("<objType>comboBox</objType>");
	    		sbBuiltXML.append("</params>");
            }
           
	              
	            sbBuiltXML.append("</result>");	
	    		
    		System.out.println("sbBuiltXML:   "+sbBuiltXML);
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}


	
	
	public StringBuffer getTurboDynValues(HttpServletRequest request) throws BusinessDefinedException {
		Connection conn = null;
		String sTargetObjects = null;
		StringBuffer sbBuiltXML = new StringBuffer();
		Map quarter = new HashMap ();  
		  
		
		try{
			conn = dBService.getDBConnection();
 
			  oAjaxDao.getTurbDynaValues(conn);
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return sbBuiltXML;
	}
}
