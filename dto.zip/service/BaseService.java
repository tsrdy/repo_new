package com.gehc.wire.common.service;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.common.dto.UserSessionDto;


/**
 * @author 703092428
 * @FileName BaseService.java
 * @CreateDate Nov 26, 2012
 */
public class BaseService {
	private static final Logger logger = Logger.getLogger(BaseService.class);
	public static UserSessionDto setUserInfo(HttpServletRequest request,UserDto oUserDto) throws Exception{
	
    		request.getSession().setAttribute(MPRConstants.APP_LOGINUSER_INFO, oUserDto);
    		UserSessionDto oUserSessionDto = new UserSessionDto();
    		oUserSessionDto.setSso(oUserDto.getSSO());
    		oUserSessionDto.setHost(request.getRemoteHost());
    		oUserSessionDto.setServerHost(request.getServerName());
    		oUserSessionDto.setSessionid(request.getSession().getId());
    		return oUserSessionDto;
    	}
    	
	
	public static UserDto getUserInfo(HttpServletRequest request) throws Exception{
			UserDto oUserDto = null;		
			logger.error("Third::"+request.getSession().getId());
			oUserDto = (UserDto)request.getSession().getAttribute(MPRConstants.APP_LOGINUSER_INFO);
		
    	return oUserDto;
	}
	
	public static boolean isValidUser(HttpServletRequest request)throws Exception{
		boolean isValidUser = true;
		UserDto oLoginUserDto = (UserDto)request.getSession().getAttribute("loginUserInfo");
		if(oLoginUserDto==null || oLoginUserDto.getSSO()==null || oLoginUserDto.getSSO().equalsIgnoreCase("")){
			isValidUser = false;
		}
		return isValidUser;
	}
}
