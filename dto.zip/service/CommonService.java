
package com.gehc.wire.common.service;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import javax.servlet.http.HttpServletRequest;

import com.gehc.wire.common.constants.BGConstants;
import com.gehc.wire.common.dto.KeyValueDto;
import com.gehc.wire.common.dto.TableDto;

import java.util.Random;


/**
 * @author 703092428
 * @FileName CommonService.java
 * @CreateDate Nov 26, 2012
 */
public class CommonService {
	static DecimalFormat f = new DecimalFormat("#.###");
    /**
     * Checks and returns true if the value is null. Else returns false
     * @param a_param Parameter name to retrieve parameter value
     * @return Returns the parameter value
     */
    public static boolean isNullValue(String sParam) {
       
        return sParam==null?true:(sParam.length()==0?true:false);
    }
    
    /**
     * Checks and returns true if the value is null. Else returns false
     * @param a_request Request to retrieve parameter value
     * @param sParam Parameter name to retrieve parameter value
     * @return Returns the parameter value
     */
    public static boolean isNullValue(HttpServletRequest request, String sParam) {
        
        return request.getParameter(sParam) == null?true:
            (request.getParameter(sParam).trim().equals("")?true:false);
    }
    
    /**
     * Replaces a string value to null 
     * @param sParam String to check for NULL value
     * @return Returns a string value without NULL
     */
    public static String replaceNull(String sParam) {
        
    	//if (sParam != null && sParam.trim().equalsIgnoreCase("NA"))
    		//sParam = "";
        return sParam == null?"":sParam.trim();
    }
    
    /**
     * Replaces a null or NA to empty
     * @param sParam String to check for NULL or NA value
     * @return Returns a string value without NULL
     */
    public static String replaceNullorNA(String sParam) {
        
    	if (sParam != null && sParam.trim().equalsIgnoreCase("NA"))
    		sParam = "";
        return sParam == null?"":sParam.trim();
    }
    
    /**
     * Replaces a string value to null 
     * @param sParam String to check for NULL value
     * @return Returns a string value without NULL
     */
    public static StringBuffer replaceNull(StringBuffer sParam) {
        
        return sParam==null ? new StringBuffer("") : sParam;
    }
    
    /**
     * Sets the string value from request
     * @param request Request to retrieve parameter value
     * @param sParam Parameter name to retrieve parameter value
     * @return Returns the parameter value in String format
     */
    public static String getStringParameter(HttpServletRequest request, 
            String sParam) {
       
        return (request.getParameter(sParam) == null || 
                request.getParameter(sParam).equals(""))?"":
                    request.getParameter(sParam).trim();
    }
    
    /**
     * Sets the string value from request to integer
     * @param request Request to retrieve parameter value
     * @param sParam Parameter name to retrieve parameter value
     * @return Returns the parameter value type-casted to int
     */
    public static int getIntParameter(HttpServletRequest request, 
            String sParam) {
        
        return (request.getParameter(sParam) == null || 
                request.getParameter(sParam).equals(""))?0:
                    Integer.parseInt(request.getParameter(sParam));
    }
    
    /**
     * Sets the string value from request to float
     * @param request Request to retrieve parameter value
     * @param sParam Parameter name to retrieve parameter value
     * @return Returns the parameter value type-casted to float
     */
    public static float getFloatParameter(HttpServletRequest request, String sParam) {
       
        return (request.getParameter(sParam) == null || 
                request.getParameter(sParam).equals(""))?0:
                    Float.parseFloat(request.getParameter(sParam));
    }
    
    /**
     * Sets the string value from request to double
     * @param request Request to retrieve parameter value
     * @param sParam Parameter name to retrieve parameter value
     * @return Returns the parameter value type-casted to double
     */
    public static double getDoubleParameter(HttpServletRequest request, 
            String sParam) {
        
        return (request.getParameter(sParam) == null || 
                request.getParameter(sParam).equals(""))?0:
                    Double.parseDouble(request.getParameter(sParam));
    }
    
    /**
     * Converts from <i>String</i> to <i>double</i>
     * @param sParam String value to be converted to double
     * @return Returns the double value
     */
    public static String replaceSpacialChars(String sParam) {
        String sNewParam = (sParam == null || sParam.equals("")) ? "" : sParam;
        sNewParam = sNewParam.replaceAll("&", "%26");
        sNewParam = sNewParam.replaceAll("'", "%26apos;");
        sNewParam = sNewParam.replaceAll("\"", "%26quot;");
        sNewParam = sNewParam.replaceAll("<", "%26lt;");
        sNewParam = sNewParam.replaceAll(">", "%26gt;");
        //sNewParam = sNewParam.replaceAll("%26", "&amp;");
        return sNewParam;
    }
    /**
     * Sets the string value from request to long
     * @param request Request to retrieve parameter value
     * @param sParam Parameter name to retrieve parameter value
     * @return Returns the parameter value type-casted to double
     */
    public static long getLongParameter(HttpServletRequest request, String sParam) {
        
    	 return (request.getParameter(sParam) == null || 
                 request.getParameter(sParam).equals(""))?0:
            Long.parseLong(request.getParameter(sParam));
    }
    
    /**
     * This method accepts the ResultSet object and column name/index, and 
     * retrieves the column value.
     * It also handles the NULL value.
     * @param rs ResultSet object to retrieve value from database
     * @param columnName column name/column index for retrieving the value 
     * @return returns the column value in string format
     * @throws SQLException in case of invalid column name, ResultSet object, etc
     */
    public static String getString(ResultSet rs, String columnName) 
                            throws SQLException {
        
        String temp = rs.getString(columnName);
        return rs.wasNull() ? " " : temp.trim();
    }
    
    /*
     * This method returns empty String is passed column is null in the database.
     * @param rs ResultSet object to retrieve value from database
     * @param columnName column name/column index for retrieving the value 
     * @return returns the empty
     */
    public static String getStringNoException(ResultSet rs, String columnName){
        try {
            String temp = rs.getString(columnName);
            return rs.wasNull() ? " " : temp.trim();
        }catch(SQLException sqlEx) {
            return " ";
        }
        catch(Exception ex){
            return " ";
        }
    }
    
    /*
     * This method returns empty String is passed column is null in the database.
     * @param rs ResultSet object to retrieve value from database
     * @param columnName column name/column index for retrieving the value 
     * @return returns the empty
     */
    public static String getStringNoException(ResultSet rs, int columnNumber){
        
        try {
            
            String temp = rs.getString(columnNumber);
            return rs.wasNull() ? " " : temp.trim();
            
        }catch(SQLException sqlEx) {
            
            return " ";
        }
        catch(Exception ex){
            
            return " ";
        }
    }
    
    /**
     * This method accepts the ResultSet object and column name/index, and 
     * retrieves the column value.
     * It also handles the NULL value.
     * @param rs ResultSet object to retrieve value from database
     * @param columnName column name/column index for retrieving the value 
     * @return returns the column value in int format
     * @throws SQLException in case of invalid column name, ResultSet object, etc
     */
    public static int getInt(ResultSet rs, String columnName) 
                            throws SQLException {
        
        int temp = rs.getInt(columnName);
        return rs.wasNull() ? 0:temp;
    }
    
    /**
     * This method accepts the ResultSet object and column name/index, and 
     * retrieves the column value.
     * It also handles the NULL value.
     * @param rs ResultSet object to retrieve value from database
     * @param columnName column name/column index for retrieving the value 
     * @return returns the column value in float format
     * @throws SQLException in case of invalid column name, ResultSet object, etc
     */
    public static float getFloat(ResultSet rs, String columnName) 
                                    throws SQLException {
        
        float temp = rs.getFloat(columnName);
        return rs.wasNull()?0:temp;
    }
    
    /**
     * Converts from <i>string</i> to <i>int</i>
     * @param sParam String to be converted to int
     * @return Returns the int value
     */
    public static int getIntValue(String sParam) {
       
        return (sParam == null || sParam.equals("")) ? 0:
            (isNaN(sParam)?0:Integer.parseInt(sParam));
    }
    
    /**
     * Converts from <i>float</i> to <i>int</i>
     * @param sParam Float value to be converted to int
     * @return Returns the int value
     */
    public static int getIntValue(float sParam) {
        
        return Integer.parseInt(String.valueOf(sParam));
    }
    
    /**
     * Converts from <i>string</i> to <i>float</i>
     * @param sParam String value to be converted to float
     * @return Returns the float value
     */
    public static float getFloatValue(String sParam) {
        
        return (sParam == null || sParam.equals(""))?0:
            Float.valueOf(sParam).floatValue();
    }
    
    /**
     * Converts from <i>double</i> to <i>float</i>
     * @param sParam Double value to be converted to float
     * @return Returns the float value
     */
    public static float getFloatValue(double sParam) {
        
        return new Float(sParam).floatValue();
    }

    /**
     * Converts from <i>String</i> to <i>double</i>
     * @param sParam String value to be converted to double
     * @return Returns the double value
     */
    public static double getDoubleValue(String sParam) {
        return (sParam == null || sParam.equals("")) ? 0 : new Double(sParam).doubleValue();
    }
    /**
     * Converts from <i>String</i> to <i>double</i>
     * @param sParam String value to be converted to double
     * @return Returns the double value
     */
    public static double getCondorDoubleValue(String sParam) {
        return (sParam == null || sParam.equals("")) ? 0 : new Double(sParam).doubleValue();
    }
    
    /**
     * Converts from <i>string</i> to <i>string</i>
     * @param sParam String value to be converted to string
     * @return Returns the string value
     */
    public static String getStringValue(String sParam) {
        
        return (sParam == null || sParam.equals(""))?"":sParam.trim();
    }
    
    /**
     * Converts from <i>int</i> to <i>string</i>
     * @param sParam Int value to be converted to string
     * @return Returns the string value
     */
    public static String getStringValue(int sParam) {
        
        return sParam==0?"":String.valueOf(sParam);
    }
    
    /**
     * Sets the string value from request to long
     * @param request Request to retrieve parameter value
     * @param sParam Parameter name to retrieve parameter value
     * @return Returns the parameter value type-casted to double
     */
    public static long getLongValue(String sParam) {
        
    	return (sParam == null || sParam.equals(""))?0:
            Long.valueOf(sParam).longValue();
    }
    
    /**
     * Sets the string value from request to boolean
     * @param request Request to retrieve parameter value
     * @param sParam Parameter name to retrieve parameter value
     * @return Returns the parameter value type-casted to double
     */
    public static boolean getBooleanValue(String sParam) {
        
    	return (sParam == null || sParam.equals(""))? false:
            Boolean.valueOf(sParam).booleanValue();
    }
    
    /**
     * Checks if the string value is NULL or not
     * @param sParam string value to check if it is a number or not
     * @return Returns <i>true</i> if value is a number; Else returns <i>false</i>
     */
    public static boolean isNaN(String sParam){
        try {
            Double.parseDouble(sParam);
            return false;
        }catch(NumberFormatException numEx) {
            return true;
        }
        catch(Exception ex){
            return true;
        }
    }
    
    /**
     * Returns rounded value of the value specified, rounded to the decimal 
     * position specified
     * @param unroundedValue double value to round
     * @param decimalPosition int value specifiying the decimal position to round
     * @return returns the rounded value as a string
     */
    public static String round(double unroundedValue, int decimalPosition) {
        
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(decimalPosition);
        
        return replaceString(numberFormat.format(unroundedValue), ",", "");
    }
    
    /**
     * Returns rounded value of the value specified, rounded to the decimal 
     * position specified
     * @param unroundedValue float value to round
     * @param decimalPosition int value specifiying the decimal position to round
     * @return returns the rounded value as a string
     */
    public static String round(float unroundedValue, int decimalPosition) {
        
        NumberFormat numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setMaximumFractionDigits(decimalPosition);
        
        return replaceString(numberFormat.format(unroundedValue), ",", "");
    }
    
    /**
     * This method accepts a string, delimiter and an index; splits the string 
     * using the specified delimiter
     * and returns the value available at the specified index, in the retrieved array
     * @param splitString string value to split
     * @param delimiter string delimiter to split the specified string
     * @param index int index based on which value at the specified index in the 
     * array is returned 
     * @return returns a string value available at the specified index <br>
     *         returns a blank string - if splitString is empty or if any 
     *         exception is raised
     */
    public static String safeSplit(String splitString, String delimiter, int index) {
       
        String returnValue = "";
        
        try {
            
            returnValue = isNullValue(splitString)?"":splitString.split(delimiter)[index];
        } catch (Exception ex) {
            returnValue = "";
        }
        return returnValue;
        
    }   
    /**
     * Function to replace the string
     * @author 100002235
     */
    public static String replace(String replaceString){
        return replaceString.replaceAll("#", "\n");
    }
    
    
    /**
     * This method accepts a string to be split, a delimiter to perform split, 
     * and returns the first value that is retrieved after the split.
     * 
     * @param splitString String to be split.
     * @param delimiter String delimiter to perform split.
     * @return Returns the first value that is retrieved after the split.
     */
    public static String splitString(String splitString,String delimiter) {
        return (splitString!=null && !splitString.trim().equalsIgnoreCase(delimiter))? splitString.split(delimiter)[0] : "";
    }
    
    /**
     * This method accepts a string and replace it with _ if the string is blank.
     * Else the string will not be replaced.
     * 
     * @param replaceString String to be replaced
     * @return Returns the replaced string, if it is blank. Else returns the same string.
     */
    public static String replacewith_(String replaceString) {
        
        return (replaceString == null || replaceString.trim().equals(""))?"-":replaceString;
    }
    
    /**
     * This method accepts a string and replaces it with blank string, if it is null.
     * Else returns the same string. 
     * 
     * @param replaceString String to be replaced
     * @return Returns the replaced string, if it is null. Else returns the same string.
     */
    public static String replaceNullWith_(String replaceString) {
        
        return (replaceString == null || replaceString.trim().equals(""))?"":replaceString;
    }
    
    /**
     * This method accepts a string and replaces it with 0, if it is null or blank.
     * Else returns the same string. 
     * 
     * @param replaceString String to be replaced
     * @return Returns the replaced string, if it is null. Else returns the same string.
     */
    public static String replaceNullWithZero(String replaceString) {
        return (replaceString == null || replaceString.trim().equals("")) ? 
                                                            "0" : replaceString;
    }
    
    /**
     * This method accepts three string values, searches for the second string 
     * in the first string and replaces it with the third string.
     * 
     * @param replaceString String to be searched-in.
     * @param firstString String to be replaced.
     * @param secondString String to be replaced-with.
     * @return Returns the replaced string.
     */
    public static String replaceString(String replaceString,
                                       String firstString,
                                       String secondString) {
        return (replaceString == null || replaceString.trim().equals(""))?
                replaceString:replaceString.replaceAll(firstString, secondString);
    }
    
    /**
     * This method returns the power factor for the specified number.
     * 
     * @param stringItem Number in string format, for which power factor has to be retrieved
     * @return Returns the power factor of the specified number
     */
    public static String formatPowerFactor(String stringItem) {
        String pf = "";
        if (stringItem == null || stringItem.trim().equals("" ))
            pf = "";
        else if (stringItem != null && stringItem.equalsIgnoreCase("NA") || 
                stringItem.equalsIgnoreCase("N/A") || stringItem.equalsIgnoreCase("none"))
              pf = "NA";
        else if (stringItem != null && Float.parseFloat(stringItem) > 100)
              pf = "ERROR: VALUE CANNOT BE > 100";
        else    
            pf = stringItem + "(" + Float.parseFloat(stringItem)/100 + ")";
        return pf;
    }
    
    /**
     * This method returns the deformatted power factor for the specified string.
     * 
     * @param stringItem String to be deformatted.
     * @return Returns the deformatted string.
     */
    public static String deformatPowerFactor(String stringItem)  {
        String pf = "";
        if (stringItem == null || stringItem.trim().equals("" ))
            pf = "";
        else if (stringItem != null && stringItem.equalsIgnoreCase("NA") || 
                stringItem.equalsIgnoreCase("N/A") || stringItem.equalsIgnoreCase("none"))
              pf = "NA";
        else if(stringItem.indexOf("(") != -1) {   
            pf = stringItem.substring(0,stringItem.indexOf("("));
        }
        return pf;
    }
    
    /**
     * This method accepts an email id, validates the same and returns a boolean
     * value depending on the validation.
     * 
     * @param email_address Email id to be validated.
     * @return Returns a boolean value, true/false, depending on the validation.
     * <br>Returns True - if email id is valid.
     * <br>Returns False - if email id is not valid.
     */
    public static boolean emailAddressValidator(String email_address) {
		
		boolean isValid = true;
		
		if (email_address == null) {			
			isValid = false;
		}
		
		if (email_address.length() < 6) {
			isValid = false;
		}
				
		if (isValid) {
			StringTokenizer stTokenizer = new StringTokenizer(email_address, "@");
			if (stTokenizer == null){
				isValid = false;
			}else if (stTokenizer.countTokens() == 2){
				String sUsername = stTokenizer.nextToken();
				String sHostname = stTokenizer.nextToken();
				
				//now validate the host name
				StringTokenizer stHostToken = new StringTokenizer(sHostname,".");
				if (stHostToken == null){
					isValid = false;
				}else if (stHostToken.countTokens() > 0){
					isValid = true;
				}else{
					isValid = false;
				}				
			}else{
				isValid = false;
			}			
		}
		return isValid;
    }
    
    /* (non-Javadoc)
     * @see java.lang.String#generateOptionsXML(java.util.ArrayList, java.lang.String, java.lang.String, java.lang.String)
     * This method is used to generate the options tag
     */
    public static String generateOptionsXML(ArrayList alOptionsList, String sTextValue, String sTargetObjects, 
    		String sTargetObjectName) {
    	StringBuffer sbBuiltXML = new StringBuffer("");
    	
    	try{    	
    		KeyValueDto oTargetDetails = getTargetByName(sTargetObjects, sTargetObjectName);
        
    		if (oTargetDetails.getKey() != null && oTargetDetails.getKey().trim().length() > 0){    			
    			if (oTargetDetails.getValue().equals(BGConstants.APP_ADMINLOOKUP_TARGETTYPE_COMBO)) {
    				if (alOptionsList.size() > 0){		            	
    					for(int i = 0; i < alOptionsList.size(); i++) {	            		
    						KeyValueDto oKeyValueVo = (KeyValueDto)alOptionsList.get(i);
    						sbBuiltXML.append("<options-"+oTargetDetails.getKey()+"><opname>"
    				        + URLEncoder.encode(oKeyValueVo.getValue()+"&&"+oKeyValueVo.getKey(), "UTF-8")
        		            + "</opname></options-"+oTargetDetails.getKey()+">\r\n");
    					}
    					
    					sbBuiltXML.append("<params>");
    		    		sbBuiltXML.append("<target>"+oTargetDetails.getKey()+"</target>");
    		    		sbBuiltXML.append("<objType>"+oTargetDetails.getValue()+"</objType>");
    		    		sbBuiltXML.append("</params>");
    				}    		
    			} else if (oTargetDetails.getValue().equals(BGConstants.APP_ADMINLOOKUP_TARGETTYPE_TEXT)) {
    				
    				if (sTextValue != null && sTextValue.trim().length() > 0){
    					sbBuiltXML.append("<options-"+oTargetDetails.getKey()+"><opname>"
    							+ sTextValue + "</opname></options-"+oTargetDetails.getKey()+">\r\n");
    					
    					sbBuiltXML.append("<params>");
    		    		sbBuiltXML.append("<target>"+oTargetDetails.getKey()+"</target>");
    		    		sbBuiltXML.append("<objType>"+oTargetDetails.getValue()+"</objType>");
    		    		sbBuiltXML.append("</params>");
    				}
    			}
    		}   	
    		
    	}catch(Exception e){};
		
    	return sbBuiltXML.toString();
    }
    
    public static String generateOptionsXMLByMap(Map<String,String> mapOptions, String sTextValue, String sTargetObjects, 
    		String sTargetObjectName) {
    	StringBuffer sbBuiltXML = new StringBuffer("");
    	
    	try{    	
    		KeyValueDto oTargetDetails = getTargetByName(sTargetObjects, sTargetObjectName);
        
    		if (oTargetDetails.getKey() != null && oTargetDetails.getKey().trim().length() > 0){    			
    			if (oTargetDetails.getValue().equals(BGConstants.APP_ADMINLOOKUP_TARGETTYPE_COMBO)) {
    				if (mapOptions.size() > 0){		            	
    					for(Map.Entry<String,String> entry :mapOptions.entrySet()){
    					
    						sbBuiltXML.append("<options-"+oTargetDetails.getKey()+"><opname>"
    								 + URLEncoder.encode(entry.getValue()+"&&"+entry.getKey(), "UTF-8")
    								 + "</opname></options-"+oTargetDetails.getKey()+">\r\n");
    					}
    					
    					
    					sbBuiltXML.append("<params>");
    		    		sbBuiltXML.append("<target>"+oTargetDetails.getKey()+"</target>");
    		    		sbBuiltXML.append("<objType>"+oTargetDetails.getValue()+"</objType>");
    		    		sbBuiltXML.append("</params>");
    				}    		
    			} else if (oTargetDetails.getValue().equals(BGConstants.APP_ADMINLOOKUP_TARGETTYPE_TEXT)) {
    				
    				if (sTextValue != null && sTextValue.trim().length() > 0){
    					sbBuiltXML.append("<options-"+oTargetDetails.getKey()+"><opname>"
    							+ sTextValue + "</opname></options-"+oTargetDetails.getKey()+">\r\n");
    					
    					sbBuiltXML.append("<params>");
    		    		sbBuiltXML.append("<target>"+oTargetDetails.getKey()+"</target>");
    		    		sbBuiltXML.append("<objType>"+oTargetDetails.getValue()+"</objType>");
    		    		sbBuiltXML.append("</params>");
    				}
    			}
    		}   	
    		
    	}catch(Exception e){};
		
    	return sbBuiltXML.toString();
    }
    
    
    /* (non-Javadoc)
     * @see in.com.rbc.quality.common.vo.KeyValueDto#getTargetByName(java.lang.String, java.lang.String)
     * This method will look out if targetName name exists in targetObjects string
     */
    public static KeyValueDto getTargetByName(String sTargetObjects, String sLookUpTargetName){
    	KeyValueDto oKeyValueVo = new KeyValueDto();
		if (sTargetObjects != null && sTargetObjects.trim().length() > 0){
			// Tokenize the target objects by ","
			StringTokenizer stToken = new StringTokenizer(sTargetObjects, ",");
			if (stToken != null){				
				while (stToken.hasMoreTokens()){
					String sTokenValue = stToken.nextToken();
					// check if targetType has been specified or not
					if (sTokenValue.indexOf(":") != -1){
						//Tokenizing the token value with ":" - to get targetName and targetType 					
						StringTokenizer stTypeComboToken = new StringTokenizer(sTokenValue,":");						
						if (stTypeComboToken != null && stTypeComboToken.countTokens() > 0){			
							if (stTypeComboToken.hasMoreTokens()){
								String sTokenValue2 = stTypeComboToken.nextToken();
								// check if it matches the lookup target name value
								if (sTokenValue2.toUpperCase().indexOf(sLookUpTargetName.toUpperCase()) != -1){
									oKeyValueVo.setKey(sTokenValue2);
									if (stTypeComboToken.hasMoreTokens()){
										oKeyValueVo.setValue(stTypeComboToken.nextToken());
									}
								}
							}
						}
					}else{		
						if (sTokenValue.toUpperCase().indexOf(sLookUpTargetName.toUpperCase()) != -1){
							if(sTokenValue.toUpperCase().equalsIgnoreCase(sLookUpTargetName.toUpperCase())){
								oKeyValueVo.setKey(sTokenValue);
								oKeyValueVo.setValue(BGConstants.APP_ADMINLOOKUP_TARGETTYPE_DEFAULT);							
							}
						}
					}
				}
			}
		}
		return oKeyValueVo;
	}
    /**
     * Replaces a string value to null 
     * @param sParam String to check for NULL value
     * @return Returns a string value without NULL
     */
    public static String replaceEmptyWithNull(String sParam) {
        
    	//if (sParam != null && sParam.trim().equalsIgnoreCase("NA"))
    		//sParam = "";
        return sParam == null?sParam:sParam.trim().equals("")?null:sParam;
    }
    
    /**
     * Replaces a string value to null 
     * @param sParam String to check for NULL value
     * @return Returns a string value without NULL
     */
    public static String getCurrentDate() {
    	Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy:mm:dd:HH:mm:ss");
		String dateNow = formatter.format(currentDate.getTime());
		 return dateNow == null?dateNow:dateNow.trim().equals("")?null:dateNow;
    }
    
    public static String generateRandomString() {
    	String sParam = null;
    	String validChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    	String resultID = "";
    	int maxIndex = validChars.length();
    	Random rnd = new Random();
    	for (int i = 0; i < 5; i++) {
    		int rndPos = Math.abs(rnd.nextInt() % maxIndex);
    		sParam = resultID + validChars.charAt(rndPos);
    	}
	   return sParam == null?sParam:sParam.trim().equals("")?null:sParam;
		
	}
    
    public static String getFindFileSize(File file)
    {
    	String fileLength = String.valueOf(file.length());
    	int fileLengthDigitCount = fileLength.length();
    	double fileLengthLong = file.length();
    	double decimalVal = 0.0D;
    	String howBig = "";
    	double fileSizeKB = 0.0D;
    	if (file.length() > 0L) {
    		if (fileLengthDigitCount < 5) {
    			fileSizeKB = Math.abs(fileLengthLong);
    			howBig = "Byte(s)";
    		} else if ((fileLengthDigitCount >= 5) && (fileLengthDigitCount <= 6)) {
    			fileSizeKB = Math.abs(fileLengthLong / 1024.0D);
    			howBig = "KB";
    		} else if ((fileLengthDigitCount >= 7) && (fileLengthDigitCount <= 9)) {
    			fileSizeKB = Math.abs(fileLengthLong / 1048576.0D);
    			howBig = "MB";
    		} else if (fileLengthDigitCount > 9) {
    			fileSizeKB = Math.abs(fileLengthLong / 1073741824.0D);
    			decimalVal = fileLengthLong % 1073741824.0D;
    			howBig = "GB";
    		}
    	}

    	String finalResult = getRoundedValue(fileSizeKB);

    	return finalResult + howBig;
    }
    private static String  getRoundedValue(double decimalVal)
    {
    	long beforeDecimalValue = decimalTokenize(decimalVal, 1);
        long afterDecimalValue = decimalTokenize(decimalVal, 2);
        long decimalValueLength = String.valueOf(afterDecimalValue).length();
        long dividerVal = divider(decimalValueLength - 1L);
        long dividedValue = afterDecimalValue / dividerVal;
        String finalResult = String.valueOf(beforeDecimalValue) + "." + 
        String.valueOf(dividedValue);
   
        return finalResult;
     }
   
    private  static long  divider(long argLength) {
    	long varDivider = 1L;

    	for (int i = 0; i < argLength - 1L; i++) {
    		varDivider *= 10L;
    	}

    	return varDivider;
    }
    
    private static long decimalTokenize(double decimalVal, int position)
    {
    	long returnDecimalVal = 0L;
    	String strDecimalVal = "";

    	if (decimalVal > 0.0D) {
    		strDecimalVal = String.valueOf(decimalVal);
    	}
    	if (strDecimalVal.length() > 0) {
    		StringTokenizer decimalToken = new StringTokenizer(strDecimalVal, ".");

    		if (position == 1) {
    			returnDecimalVal = Long.parseLong(decimalToken.nextToken());
    		} else if (position == 2) {
    			decimalToken.nextToken();
    			returnDecimalVal = Long.parseLong(decimalToken.nextToken());
    		}
    	}
    	return returnDecimalVal;
    }

	 /**
     * Converts from <i>String</i> to <i>double</i>
     * @param sParam String value to be converted to double
     * @return Returns the double value
     */
    public static String replaceWomensHealthCare(String sParam) {
        String sNewParam = (sParam == null || sParam.equals("")) ? "" : sParam;
        if(sNewParam.equalsIgnoreCase("Womens Health")){
        	sNewParam = sNewParam.replaceAll("Womens Health", "Women's Health");
        }
        return sNewParam;
    }
    /**
     * Converts from <i>String</i> to <i>double</i>
     * @param sParam String value to be converted to double
     * @return Returns the double value
     */
    public static String replaceSpecialCharforWH(String sParam) {
        String sNewParam = (sParam == null || sParam.equals("")) ? "" : sParam;
        if(sNewParam.equalsIgnoreCase("Womens Health")){
        	sNewParam = sNewParam.replaceAll("Womens Health", "Women%26apos;s Health");
        }
        return sNewParam;
    }
    
    public static String emailHeader(HttpServletRequest request)throws Exception {
    	 String sFrom = "IMPAdmin@ge.com";
    	 String sMessage = "";
    	 StringBuffer sb = new StringBuffer();
    	 int serverPort = request.getServerPort();
    	 DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    	 InetAddress ownIP = InetAddress.getLocalHost();
    	  String serverHost = ownIP.getHostAddress();

         sb.append("<table valign=\"top\" cellspacing=\"0\" cellpadding=\"0\" style=\"background-color:#EBEBEB\" >");
         sb.append("<tr>");
         sb.append("<td style=\"font-family:arial;font-size:12px;\" style=\"\">");
         sb.append("<img src=\"http://" + serverHost + ":" + serverPort + "/IMP/content/images/Top-header.png\"/>");
         sb.append("<table width=\"1000px\" cellspacing=\"0\" cellpadding=\"0\" style=\"background-color:#EBEBEB\">");
         sb.append("<tr>");
         sb.append("<td style=\"font-family:arial;font-size:12px;padding-left:5px;\" valign=\"top\">");
         sb.append("<font style=\"font-weight:bold;color:#3B73B9;\">From: </font>"+sFrom);
         sb.append("</td>");
         sb.append("<td style=\"font-family:arial;font-size:12px;\" width=\"63%\">");
         sb.append("</td>");
         sb.append("<td style=\"font-family:arial;font-size:12px;\">");
         Date date = new Date();
         sb.append("<font style=\"font-weight:bold;color:#3B73B9;font-size:12px;\">Date: </font>"+dateFormat.format(date));
         sb.append("<br/><font style=\"font-weight:bold;color:#3B73B9;font-size:12px;\">Location: </font>Image Management Protal");
         sb.append("</td>");
         sb.append("</tr><br>");
         sb.append("</table>");
         sb.append("</td>");
         sb.append("</tr><br>");
         sb.append("</table>");
         
        
         sMessage = sb.toString();
        return sMessage;
    }
    
    public static String emailFooter(HttpServletRequest request) throws UnknownHostException {
   	 String sFrom = "IMPAdmin@ge.com";
	 String sMessage = "";
	 StringBuffer sb = new StringBuffer();
	 int serverPort = request.getServerPort();
	 DateFormat dateFormat = new SimpleDateFormat("dd/mm/yyyy");
	 InetAddress ownIP = InetAddress.getLocalHost();
	  String serverHost = ownIP.getHostAddress();
   	   	
        sb.append("<table valign=\"top\" cellspacing=\"0\" cellpadding=\"0\">");
        sb.append("<tr style=\"background-color:#EBEBEB;\">");
        sb.append("<td width=\"1%\" style=\"background-color:#EBEBEB;\">");
        sb.append("<td  style=\"font-family:arial;color:#3B73B9;font-size:12px;background-color:#EBEBEB;\">");
        sb.append("<B>Thanks,<br>Team Image Management Portal Tool.<B>");
        sb.append("</td>");
        sb.append("</tr><br>");
        sb.append("<tr style=\"background-color:#EBEBEB;\">");
        sb.append("<td width=\"1%\" style=\"background-color:#EBEBEB;\">");
        sb.append("<td style=\"font-family:arial;font-size:12px;background-color:#EBEBEB;\">");
        sb.append("<a href=\"http://" + serverHost + ":" + serverPort + "/IMP\">Click here</a>to access Image Management Portal");
        sb.append("</td>");
        sb.append("</tr><br>");
        sb.append("<tr style=\"background-color:#EBEBEB;\">");
        sb.append("<td width=\"1%\" >");
        sb.append("<td  style=\"font-family:arial;font-size:12px;background-color:;\">");
        sb.append("(Note: Please do not reply, its an unattended mailbox.)");
        sb.append("</td><br/><br/>");
        sb.append("</tr>");
        sb.append("<tr>");
        
        sb.append("<td style=\"font-family:arial;font-size:12px;\" vlign=\"top\" colspan=\"2\">");
        sb.append("<img src=\"http://" + serverHost + ":" + serverPort + "/IMP/content/images/Botton-logo.jpg\"/>");
        sb.append("</td>");
        sb.append("</tr><br>"); 
        sb.append("</table>");
        
       
        sMessage = sb.toString();
       return sMessage;
   }
    
    public static String generateTableXML(ArrayList alOptionsList,int PageNumber,int TotalNumberofRecords) {
    	//TotalNumberofRecords = 30;
		StringBuffer sbBuiltXML = new StringBuffer();
		 sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>"); 
		 sbBuiltXML.append("<rows>");
		 sbBuiltXML.append("<page>"+PageNumber+"</page>");
		 sbBuiltXML.append("<total>"+TotalNumberofRecords+"</total>");
		
		for(int i=0;i<alOptionsList.size();i++){
			TableDto oTableDto = (TableDto)alOptionsList.get(i);
			
			 sbBuiltXML.append("<row id='"+i+"'>");
			 sbBuiltXML.append("<cell><![CDATA["+i+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn1()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn2()+"]]></cell>");
			 String requirement = "<a href=\"#\" class=\"clickTip1 copyCommentsBasic\" onclick=\"openRequirementTrackerDetails('"+oTableDto.getColumn1()+"')\" onmouseover=\"viewProblemStatementOnMouseHover('"+oTableDto.getColumn1()+"');\">"+oTableDto.getColumn3()+"</a>";
			
			 sbBuiltXML.append("<cell><![CDATA["+requirement+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn4()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn5()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn6()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn7()+"]]></cell>");
			 String updateLabel = "<a href=javascript:updateRequirementStatus('"+oTableDto.getColumn7()+"')>Update</a>";
			 sbBuiltXML.append("<cell><![CDATA["+updateLabel+"]]></cell>");
			 sbBuiltXML.append("</row>");
		 }
		 sbBuiltXML.append("</rows>");
    	
    	return sbBuiltXML.toString();
    }
    
    public static String generateQuotesTableXML(ArrayList alOptionsList,int PageNumber,int TotalNumberofRecords) {
    	//TotalNumberofRecords = 30;
		StringBuffer sbBuiltXML = new StringBuffer();
		 sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>"); 
		 sbBuiltXML.append("<rows>");
		 sbBuiltXML.append("<page>"+PageNumber+"</page>");
		 sbBuiltXML.append("<total>"+TotalNumberofRecords+"</total>");
		
		for(int i=0;i<alOptionsList.size();i++){
			TableDto oTableDto = (TableDto)alOptionsList.get(i);
			
			 sbBuiltXML.append("<row id='"+i+"'>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn1()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn2()+"]]></cell>");
			 String requirement = "<a href=\"#\" class=\"clickTip1 copyCommentsBasic\" onclick=\"openRequirementTrackerDetails('"+oTableDto.getColumn1()+"')\" onmouseover=\"viewProblemStatementOnMouseHover('"+oTableDto.getColumn1()+"');\">"+oTableDto.getColumn3()+"</a>";
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn3()+"]]></cell>");
			// sbBuiltXML.append("<cell><![CDATA["+requirement+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn4()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn5()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn6()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn7()+"]]></cell>");
			 sbBuiltXML.append("<cell><![CDATA["+oTableDto.getColumn8()+"]]></cell>");
			 String updateLabel = "<a href=javascript:updateQuotes('"+oTableDto.getColumn1()+"')>Quote</a>";
			 sbBuiltXML.append("<cell><![CDATA["+updateLabel+"]]></cell>");
			 sbBuiltXML.append("</row>");
		 }
		 sbBuiltXML.append("</rows>");
    	
    	return sbBuiltXML.toString();
    }
    
    public static StringBuffer getErrorMessageForDropdowns() {
    StringBuffer sbBuiltXML = new StringBuffer();
	
	sbBuiltXML.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
    sbBuiltXML.append("<result>");
    sbBuiltXML.append("<error>Techinical Error</error>");
    sbBuiltXML.append("</result>");	
   
    
    return sbBuiltXML;
    }
    public static ArrayList<TableDto> getDataTable(ResultSet rs) throws  SQLException
    {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			rsmd = rs.getMetaData();
			oTableDto = new TableDto();
			
			for(int i=1;i<=rsmd.getColumnCount();i++)
			{
				oTableDto.setColumnValue(i, rsmd.getColumnName(i));
			}
			oTableDto.setColumnCount(rsmd.getColumnCount());
			alData.add(oTableDto);
			
			while(rs.next() ){
				oTableDto = new TableDto();
				for(int i=1;i<=rsmd.getColumnCount();i++)
				{
					oTableDto.setColumnValue(i, rs.getString(i));
				}
				alData.add(oTableDto);
			}
		}
    	return alData;
    }
    public static ArrayList<TableDto> getDataTableForViewModifyHistoricData(ResultSet rs) throws  SQLException
    {
       ResultSetMetaData rsmd   = null;
       TableDto oTableDto = null;
       TableDto oHeaderDto = null;
       ArrayList<TableDto> alData = new ArrayList<TableDto>();
       
       
       String freshCombo = "";
              String oldCombo = "";
              LinkedHashMap<String,LinkedHashMap> htMain = new LinkedHashMap<String,LinkedHashMap>();
              LinkedHashMap<String,TableDto> htInner = new LinkedHashMap<String,TableDto>();
              Set<String> hsCombo = new LinkedHashSet<String>();
              Set<String> hsCols = new LinkedHashSet<String>();
              int iCounter =0;
              
       if(rs!=null){
                     rsmd = rs.getMetaData();
                     oHeaderDto = new TableDto();
                     StringBuffer sbHeader = new StringBuffer("");
                     for(int i=1;i<=9;i++)
                     {
                           oHeaderDto.setColumnValue(i, rsmd.getColumnName(i));
                           sbHeader.append(rsmd.getColumnName(i));
                           if(i!=9)
                                  sbHeader = sbHeader.append("~");
                     }
              
                     
                     
                     
                     while(rs.next() ){
                           
                           sbHeader = new StringBuffer("");
                           for(int i=1;i<=9;i++)
                           {
                                  sbHeader.append(rs.getString(i));
                                  if(i!=9)
                                         sbHeader.append("~");
                           }
                           freshCombo = sbHeader.toString();
                           
                           hsCombo.add(freshCombo);
                           hsCols.add(rs.getString(10));
                           
                           if(oldCombo.equals(freshCombo)){
                                  htInner.put(rs.getString(10),new TableDto(rs.getString(11),rs.getString(12),rs.getString(13),rs.getString(14)));
                                  
                                  
                           }else{
                                  
                                  if(iCounter!=0)
                                  {
                                         htMain.put(oldCombo, htInner);
                                         htInner = new LinkedHashMap<String,TableDto>();
                                  }
                                  
                                  htInner.put(rs.getString(10),new TableDto(rs.getString(11),rs.getString(12),rs.getString(13),rs.getString(14)));
                                  
                                  oldCombo = freshCombo;
                           }
                           
                           iCounter++;
                     }
                     htMain.put(oldCombo, htInner);
                           
                           
                           
              }
       
       
       //Constructing Header
       iCounter=10;
       int iCounterMarket = hsCols.size()+iCounter+1;
       Iterator itrCols = hsCols.iterator();
       while(itrCols.hasNext()){
              String sTem = (String) itrCols.next();
              oHeaderDto.setColumnValue(iCounter,"GE-"+sTem);
              iCounter++;
              oHeaderDto.setColumnValue(iCounterMarket,"Mrkt-"+sTem);
              iCounterMarket++;
       }
       iCounter=10;
       oHeaderDto.setColumnCount(iCounter+2+(hsCols.size()*2));
       alData.add(oHeaderDto);
       
       TableDto oData = null;
       iCounterMarket = hsCols.size()+iCounter+2;
       //Row by Row
       
        Set<String> keys = htMain.keySet();
         for(String key: keys){
               oData = new TableDto();
               
               String[] saIntialColValues = key.split("~");
               for(int i=1;i<=saIntialColValues.length;i++)
                      oData.setColumnValue(i,saIntialColValues[i-1]);
               LinkedHashMap htTemp = htMain.get(key); 
               iCounter=10;
               iCounterMarket = hsCols.size()+iCounter+2;
               for(String cols: hsCols){
                      oData.setColumnValue(iCounter,((TableDto)htTemp.get(cols)).getColumn1());
                     iCounter++;
                     oData.setColumnValue(iCounterMarket,((TableDto)htTemp.get(cols)).getColumn3());
                     iCounterMarket++;
                     
                     if(iCounter==10){
                            oData.setColumnValue(iCounter+hsCols.size()+1,((TableDto)htTemp.get(cols)).getColumn2());
                            oData.setColumnValue(iCounter+hsCols.size()+2+hsCols.size(),((TableDto)htTemp.get(cols)).getColumn4());
                     }
                     
                      
               }
              
               alData.add(oData); 
            
         }
       
       
       return alData;
    }

    public static ArrayList<TableDto> getDataTableForMPR(ResultSet rs,ResultSet rs1) throws  SQLException
    {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			
			
			
			int iFixedXCols = 0;
			int iNoOfQtrs =0;
			
			while(rs.next() ){
				if(rs.isFirst())
				{
					oTableDto = new TableDto();
					iFixedXCols =9;// rs.getInt("Columns_Count");
					iNoOfQtrs = 1;//rs.getInt("Quarters_count");
					rsmd = rs.getMetaData();
					oTableDto.setFixedCols(iFixedXCols);
					oTableDto.setNoOfQtrs(iNoOfQtrs);
					for(int i=1;i<=iFixedXCols;i++)
					{
						oTableDto.setColumnValue(i, rsmd.getColumnName(i));
					}
					int iColSpace = iFixedXCols+1;
					int isCQCount = 1;
					boolean isCQ =false;
					for(int i=(iFixedXCols+1);i<=(iFixedXCols+iNoOfQtrs);i++)
					{
						if(isCQCount == iNoOfQtrs) isCQ=true;
						
						oTableDto.setColumnValue(iColSpace, rsmd.getColumnName(i+iFixedXCols+iNoOfQtrs+1));iColSpace++;
						if(isCQ){
							oTableDto.setColumnValue(iColSpace,  "GE V%");iColSpace++;}
						oTableDto.setColumnValue(iColSpace,  "Mrkt"+ rsmd.getColumnName(i));iColSpace++;
						if(isCQ){
							oTableDto.setColumnValue(iColSpace,  "Market V%");iColSpace++;}
						
						//isCQ=true;
						isCQCount++;
						
					}
					oTableDto.setColumnCount(iFixedXCols+(iNoOfQtrs*2)+2);
					alData.add(oTableDto);
					
				}
				oTableDto = new TableDto();
				for(int i=1;i<=iFixedXCols;i++)
				{
					oTableDto.setColumnValue(i, rs.getString(i));
				}
				int iColSpace = iFixedXCols+1;
				boolean isCQ=false;
				int isCQCount = 1;
				for(int i=(iFixedXCols+1);i<=(iFixedXCols+iNoOfQtrs);i++)
				{
					if(isCQCount == iNoOfQtrs) isCQ=true;
					oTableDto.setColumnValue(iColSpace, rs.getString(i+iFixedXCols+iNoOfQtrs+1));iColSpace++;
					if(isCQ){
						oTableDto.setColumnValue(iColSpace,  "");iColSpace++;}
					oTableDto.setColumnValue(iColSpace, rs.getString(i));iColSpace++;
					if(isCQ){
						oTableDto.setColumnValue(iColSpace,  "");iColSpace++;}
					
					isCQCount++;
				}
				alData.add(oTableDto);
			}
			
			
		}
    	return alData;
    }
    
    
    public static ArrayList<TableDto> getDataTableForMPR(ResultSet rs) throws  SQLException
    {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			int iFixedXCols = 0;
			int iNoOfQtrs =0;
			
			while(rs.next()){
				if(rs.isFirst())
				{
					oTableDto = new TableDto();
					rsmd = rs.getMetaData();
					iFixedXCols = rsmd.getColumnCount();// rs.getInt("Columns_Count");
					iNoOfQtrs = 1;//rs.getInt("Quarters_count");
					oTableDto.setFixedCols(iFixedXCols);
					oTableDto.setNoOfQtrs(iNoOfQtrs);
					for(int i=1;i<=(iFixedXCols-2);i++)
					{
						oTableDto.setColumnValue(i, rs.getString(i));
					}
					alData.add(oTableDto);
					oTableDto.setColumnCount(rsmd.getColumnCount()-2);
				}
				else
				{
				oTableDto = new TableDto();
				for(int i=1;i<(iFixedXCols-2);i++)
				{
					oTableDto.setColumnValue(i, rs.getString(i));
				}
				alData.add(oTableDto);
				}
			}
		}
    	return alData;
    }
    
    public static ArrayList<TableDto> getReportTable(ResultSet rs) throws  SQLException
    {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			int iFixedXCols = 0;
			int iNoOfQtrs =0;
			
			while(rs.next()){
				if(rs.isFirst())
				{
					oTableDto = new TableDto();
					rsmd = rs.getMetaData();
					iFixedXCols = rsmd.getColumnCount();// rs.getInt("Columns_Count");
					iNoOfQtrs = 1;//rs.getInt("Quarters_count");
					oTableDto.setFixedCols(iFixedXCols);
					oTableDto.setNoOfQtrs(iNoOfQtrs);
					for(int i=1;i<=iFixedXCols;i++)
					{
						oTableDto.setColumnValue(i, rs.getString(i));
					}
					alData.add(oTableDto);
					oTableDto.setColumnCount(rsmd.getColumnCount());
				}
				else
				{
				oTableDto = new TableDto();
				for(int i=1;i<=iFixedXCols;i++)
				{
					oTableDto.setColumnValue(i, rs.getString(i));
				}
				alData.add(oTableDto);
				}
			}
		}
    	return alData;
    }
    
    
    public static ArrayList<TableDto> getHistoricDataTables(ResultSet rs) throws  SQLException
    {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			
			
			
			int iFixedXCols = 0;
			int iNoOfQtrs =0;
			
			while(rs.next()){
				if(rs.isFirst())
				{
					oTableDto = new TableDto();
					iFixedXCols =20;// rs.getInt("Columns_Count");
					iNoOfQtrs = 1;//rs.getInt("Quarters_count");
					rsmd = rs.getMetaData();
					oTableDto.setFixedCols(iFixedXCols);
					oTableDto.setNoOfQtrs(iNoOfQtrs);
					int j=0;
					for(int i=1;i<=iFixedXCols;i++)
					{
						oTableDto.setColumnValue(i, rs.getString(i));
						j = i;
					}
					
							j = j+11;
							oTableDto.setColumnValue(16, rs.getString(j));j++;
							oTableDto.setColumnValue(17, rs.getString(j));j++;
							oTableDto.setColumnValue(18, rs.getString(j));j++;
							oTableDto.setColumnValue(19, rs.getString(j));j++;
							oTableDto.setColumnValue(20, rs.getString(j));j++;
							oTableDto.setColumnValue(21, rs.getString(j));j++;
					
					alData.add(oTableDto);
					oTableDto.setColumnCount(rsmd.getColumnCount()-2);
				}
			
				oTableDto = new TableDto();
				int j=0;
				for(int i=1;i<=iFixedXCols;i++)
				{
					oTableDto.setColumnValue(i,rs.getString(i));
					j = i;
				}
				j = j+11;
				oTableDto.setColumnValue(16, rs.getString(j));j++;
				oTableDto.setColumnValue(17, rs.getString(j));j++;
				oTableDto.setColumnValue(18, rs.getString(j));j++;
				oTableDto.setColumnValue(19,rs.getString(j));j++;
				oTableDto.setColumnValue(20, rs.getString(j));j++;
				oTableDto.setColumnValue(21, rs.getString(j));j++;
				oTableDto.setColumnValue(22, rs.getString(j));j++;
				alData.add(oTableDto);
			}
    	}
    	return alData;
    }
    
    
    public static ArrayList<TableDto> getHistoricDataTable(ResultSet rs) throws  SQLException
    {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			rsmd = rs.getMetaData();
			oTableDto = new TableDto();
			while(rs.next() ){
				oTableDto = new TableDto();
				for(int i=1;i<=(rsmd.getColumnCount()-2);i++)
				{
					oTableDto.setColumnValue(i, rs.getString(i));
				}
				oTableDto.setColumnCount(rsmd.getColumnCount()-2);
				alData.add(oTableDto);
			}
		}
    	return alData;
    }
    
    
    
    
    public static String getMultiList(String[] strArryValue) {
		String sReturnStrVal = "";
		if (strArryValue != null) {
			int ecatLength = strArryValue.length;
			for (int i = 0; i < ecatLength; i++) {
				if (strArryValue[i] != "") {
					sReturnStrVal += strArryValue[i];
					sReturnStrVal += "~";
				}
			}
			if (sReturnStrVal.lastIndexOf("~") != -1)
				sReturnStrVal = sReturnStrVal.substring(0, sReturnStrVal
						.lastIndexOf("~"));
		}
		System.out.println(sReturnStrVal);
	
		return sReturnStrVal.equalsIgnoreCase("") ? null : sReturnStrVal.replaceAll("","");
	}
    public static String getRemover(String[] strArryValue) {
		String sReturnStrVal = "";
		if (strArryValue != null) {
			
			sReturnStrVal=strArryValue[0];
			int ecatLength = sReturnStrVal.length();
		sReturnStrVal=sReturnStrVal.substring(1, ecatLength-1);
	    sReturnStrVal = sReturnStrVal.replaceAll(",", "~");
		}
		return sReturnStrVal.equalsIgnoreCase("") ? null : sReturnStrVal.replaceAll("","");
	}
    
    public static String getRemoverss(String strArryValue) {
		String sReturnStrVal = "";
		if (strArryValue != null) {
			
			sReturnStrVal=strArryValue;
			int ecatLength = sReturnStrVal.length();
		sReturnStrVal=sReturnStrVal.substring(1, ecatLength-1);
	    sReturnStrVal = sReturnStrVal.replaceAll(",", "~");
		}
		return sReturnStrVal.equalsIgnoreCase("") ? null : sReturnStrVal.replaceAll("","");
	}
    
    public static int getRemoverI(int strArryValue) {
		String sReturnStrVal = "";
		/*if (strArryValue != null) {
			
			sReturnStrVal=strArryValue[0];
			int ecatLength = sReturnStrVal.length();
		sReturnStrVal=sReturnStrVal.substring(1, ecatLength-1);
	    sReturnStrVal = sReturnStrVal.replaceAll(",", "~");
		}*/
		return 0;
		//return Interger.parseInt(sReturnStrVal);
		//return sReturnStrVal.equalsIgnoreCase("") ? null : sReturnStrVal.replaceAll("","");
	}
    
    
    
    
    public static Map getMultiListArray(String[] strArryValue) {
		String sReturnStrVal = "";
		Map<String,String> hmPickList = new LinkedHashMap<String,String>();
		if (strArryValue != null) {
			int ecatLength = strArryValue.length;
			for (int i = 0; i < ecatLength; i++) {
				if (strArryValue[i] != "") {
					sReturnStrVal += strArryValue[i];
					sReturnStrVal += "~";
					hmPickList.put(strArryValue[i],strArryValue[i]);
				}
			}
			
		}
		System.out.println(sReturnStrVal);
		return hmPickList;
	}
    
    public static String getDelimeterSaperate(String strArryValue) {
		String sReturnStrVal = "";
		int i;
		if (strArryValue != null) {
			
			i = strArryValue.indexOf(","); 
			if(i != -1)  
				sReturnStrVal = strArryValue.substring(0, i); 
			else
				sReturnStrVal = strArryValue;
			
		}	
			
		System.out.println(sReturnStrVal);
		return sReturnStrVal.equalsIgnoreCase("") ? null : sReturnStrVal;
	}

	public static ArrayList getPivotDataTable(ArrayList alData) {
		ArrayList alPivot = new ArrayList();
		TableDto oTableDto = null;
		Set<String> hsColumns = new  LinkedHashSet<String>();
		Set<String> hsRows = new  LinkedHashSet<String>();
		ListIterator itr =  alData.listIterator();
		while(itr.hasNext()){
			hsColumns.add(((TableDto)itr.next()).getColumnValue((1)));
		}
		/*Get the Original Column ROW from DATA*/
		TableDto oOriginalHeader = ((TableDto)alData.get(0));
		
		/*Get the Display ROW COUNT*/
		int iRowCount = oOriginalHeader.getColumnCount();
		
		/*Get the Display ROW First values*/
		for(int i=1;i<=iRowCount;i++){
			oTableDto = new TableDto();
			if(i!=1)
				hsRows.add(oOriginalHeader.getColumnValue(i));
		}
		
		/*Preparing Display Table*/
			/*Preparing Display Table First ROW*/
			oTableDto = new TableDto();
			oTableDto.setColumn1("");
			int iCounter=1;
			Iterator<String> itrC = hsColumns.iterator();
			while(itrC.hasNext())
			{
				String sTemp =  itrC.next();
				//if(iCounter!=1){
					oTableDto.setColumnValue(iCounter,sTemp); 
					iCounter++;
				//}
			}
			oTableDto.setColumnCount(hsColumns.size());
			alPivot.add(oTableDto);
		
			/**Preparing Display Table ROW by ROW*/
			for(int i=1;i<(iRowCount);i++){
				oTableDto = new TableDto();
				oTableDto.setColumn1(oOriginalHeader.getColumnValue(i+1));
				oTableDto = getReportURL(oTableDto);
				for(int j=1;j<hsColumns.size();j++){
					oTableDto.setColumnValue(j+1,((TableDto)alData.get(j)).getColumnValue(i+1));
					
				}
				alPivot.add(oTableDto);
			}
		return alPivot;
	}
	
	
	public static ArrayList getPivotDataTableForSales(ArrayList alData) {
		ArrayList alPivot = new ArrayList();
		TableDto oTableDto = null;
		Set<String> hsColumns = new LinkedHashSet<String>();
		Set<String> hsRows = new LinkedHashSet<String>();
		ListIterator itr = alData.listIterator();
		while (itr.hasNext()) {
			hsColumns.add(((TableDto) itr.next()).getColumnValue((1)));
		}
		/* Get the Original Column ROW from DATA */
		TableDto oOriginalHeader = ((TableDto) alData.get(0));

		/* Get the Display ROW First values */
		/* Get the Display ROW First values */
		itr = alData.listIterator();
		int iR = 0;
		while (itr.hasNext()) {
			if (iR > 0) {
				hsRows.add(((TableDto) itr.next()).getColumnValue(2));
			}
			iR++;
		}
		/* Preparing Display Table */
		/* Preparing Display Table First ROW */
		oTableDto = new TableDto();
		oTableDto.setColumn1("");
		int iCounter = 1;
		Iterator<String> itrC = hsColumns.iterator();
		while (itrC.hasNext()) {
			String sTemp = itrC.next();
			// if(iCounter!=1){
			oTableDto.setColumnValue(iCounter, sTemp);
			iCounter++;
			// }
		}
		oTableDto.setColumnCount(hsColumns.size());
		alPivot.add(oTableDto);

		/** Preparing Display Table ROW by ROW */
		String sOldRegion = "";
		int iRowSpanCounter=1;
		if (alData.size() > 1) {
			Iterator itrR = hsRows.iterator();
			while (itrR.hasNext()) {
				String sRow = (String) itrR.next();
				if (!"Region".equalsIgnoreCase(sRow)) {
					oTableDto = new TableDto();
					oTableDto.setColumn1(sRow.split("~")[2]);
					itrC = hsColumns.iterator();
					int ic = 1;
					while (itrC.hasNext()) {
						if (ic >1) {
							String sCol = itrC.next();
							for (int i = 1; i < (alData.size()); i++) {
								TableDto CurrentRow = (TableDto) alData.get(i);
								if (CurrentRow.getColumn2().equalsIgnoreCase(
										sRow)
										&& CurrentRow.getColumn1()
												.equalsIgnoreCase(sCol))
										oTableDto.setColumnValue(ic,
												CurrentRow.getColumn3());
							}
							
						}
						ic++;
					}
					if (!sOldRegion.equals(sRow.split("~")[1])) {
						oTableDto.setColumn10(sRow.split("~")[1]);
						oTableDto.setColumn11(sRow.split("~")[0]);
						sOldRegion = sRow.split("~")[1];
					}
					iRowSpanCounter++;
					alPivot.add(oTableDto);
				}
			}
		}

		return alPivot;
	}
	
	public static TableDto getReportURL(TableDto oTableDto){
		
		if(oTableDto!=null){
			if("Install Base (ex Devices)".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("IBReport.jpage");
			else if("Contract Revenue($K) (ex Devices)".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("IBUCReport.jpage");
			else if("Connectivity (CT, MR, VAS & PET)".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("ConnectivityReport.jpage");
			else if("CSO Open > 40 DAYS".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("CSOReport.jpage");
			else if("DFR Critical".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("DFRReport.jpage");
			else if("SR Quality".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("PATPIReport.jpage");
			else if("FMI Past Due (Recalls)".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("FMIReport.jpage");
			else if("FE Applied Time(Per mth Per FE in Hrs)".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("AppliedTimeReport.jpage");
			else if("Open Dispatch Count".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("OpenDispatchReport.jpage");
			else if("ETTR (3mth in Hrs)".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("ETTRReport.jpage");
			else if("Debrief Span (3mth in Hrs)".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("DebriefSpanReport.jpage");
			else if("EMG Reporting Span (3mth in Hrs)".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("EMGSpanReport.jpage");
			else if("FRFT10 YTD".equalsIgnoreCase(oTableDto.getColumn1()))
				oTableDto.setReportURL("FRFTReport.jpage");
			 else if("Inventory ($K)".equalsIgnoreCase(oTableDto.getColumn1()))
					oTableDto.setReportURL("InventoryReport.jpage");
			 else if("PMQ30 (12mths)".equalsIgnoreCase(oTableDto.getColumn1()))
					oTableDto.setReportURL("PMQ30Report.jpage");
			 else if("FOA($K)".equalsIgnoreCase(oTableDto.getColumn1()))
					oTableDto.setReportURL("FOAReport.jpage");
			 else if("Finance ($K)".equalsIgnoreCase(oTableDto.getColumn1()))
					oTableDto.setReportURL("FinanceReport.jpage");
			 else if ("Upcoming IB (CQ sales)".equalsIgnoreCase(oTableDto.getColumn1()))
					oTableDto.setReportURL("SalesReport.jpage");
			 else if ("Training & Competency".equalsIgnoreCase(oTableDto.getColumn1()))
					oTableDto.setReportURL("TrainingReport.jpage");
			 else if ("Productivity YTD ($K)".equalsIgnoreCase(oTableDto.getColumn1()))
					oTableDto.setReportURL("ProductivityReport.jpage");
			 else if ("GST".equalsIgnoreCase(oTableDto.getColumn1()))
					oTableDto.setReportURL("GSTReport.jpage");
			else
				oTableDto.setReportURL("underCon.jpage");
			
		}
		
		return oTableDto;
	}

	public static ArrayList getCostDeepDiveDataTable(ResultSet rs) throws SQLException {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			rsmd = rs.getMetaData();
			oTableDto = new TableDto();
			
			for(int i=1;i<=rsmd.getColumnCount();i++)
			{
				oTableDto.setColumnValue(i, rsmd.getColumnName(i));
			}
			oTableDto.setColumnCount(rsmd.getColumnCount());
			alData.add(oTableDto);
			
			DecimalFormat format = new DecimalFormat("#,##0");
			 
			while(rs.next() ){
				oTableDto = new TableDto();
				for(int i=1;i<=rsmd.getColumnCount();i++)
				{
				if(i!=3 && i!=4 && i!=8 && i!=9)
					oTableDto.setColumnValue(i, rs.getString(i));
				else
					oTableDto.setColumnValue(i,format.format(Float.parseFloat(rs.getString(i))));
				}
				alData.add(oTableDto);
			}
		}
    	return alData;
    }
	
	public static ArrayList getCostDeepDiveTable(ResultSet rs) throws SQLException {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			rsmd = rs.getMetaData();
			oTableDto = new TableDto();
			
			for(int i=1;i<=rsmd.getColumnCount();i++)
			{
				oTableDto.setColumnValue(i, rsmd.getColumnName(i));
			}
			oTableDto.setColumnCount(rsmd.getColumnCount());
			alData.add(oTableDto);
			
			DecimalFormat format = new DecimalFormat("#,##0");
			 
			while(rs.next() ){
				oTableDto = new TableDto();
				for(int i=1;i<=rsmd.getColumnCount();i++)
				{
				if(i!=4 &&  i!=6)
					oTableDto.setColumnValue(i, rs.getString(i));
				else
					oTableDto.setColumnValue(i,format.format(Float.parseFloat(rs.getString(i))));
				}
				alData.add(oTableDto);
			}
		}
    	return alData;
    }
	
	public static ArrayList getCostDeepDiveTableThree(ResultSet rs) throws SQLException {
    	ResultSetMetaData rsmd   = null;
    	TableDto oTableDto = null;
    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
    	if(rs!=null){
			rsmd = rs.getMetaData();
			oTableDto = new TableDto();
			
			for(int i=1;i<=rsmd.getColumnCount();i++)
			{
				oTableDto.setColumnValue(i, rsmd.getColumnName(i));
			}
			oTableDto.setColumnCount(rsmd.getColumnCount());
			alData.add(oTableDto);
			
			DecimalFormat format = new DecimalFormat("#,##0");
			 
			while(rs.next() ){
				oTableDto = new TableDto();
				for(int i=1;i<=rsmd.getColumnCount();i++)
				{
				if(i!=4)
					oTableDto.setColumnValue(i, rs.getString(i));
				else
					oTableDto.setColumnValue(i,format.format(Float.parseFloat(rs.getString(i))));
				}
				alData.add(oTableDto);
			}
		}
    	return alData;
    }
	
	   public static ArrayList<TableDto> getDataTableChuv(ResultSet rs) throws  SQLException
	    {
	    	ResultSetMetaData rsmd   = null;
	    	TableDto oTableDto = null;
	    	ArrayList<TableDto> alData = new ArrayList<TableDto>();
	    	if(rs!=null){
				rsmd = rs.getMetaData();
				oTableDto = new TableDto();
				
				for(int i=1;i<=rsmd.getColumnCount();i++)
				{
					oTableDto.setColumnValue(i, rsmd.getColumnName(i));
				}
				oTableDto.setColumnCount(rsmd.getColumnCount());
				alData.add(oTableDto);
				
				while(rs.next() ){
					oTableDto = new TableDto();
					for(int i=1;i<=rsmd.getColumnCount();i++)
					{
						oTableDto.setColumnValue(i, rs.getString(i));
					}
					alData.add(oTableDto);
				}
			}
	    	return alData;
	    }
   
}
