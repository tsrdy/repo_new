package com.gehc.wire.common.dao;

import java.sql.Connection;
import java.util.ArrayList;

import com.gehc.wire.common.form.AjaxForm;


public interface AjaxDao{


	String getTurbDynaValues(Connection conn)throws Exception;
	
}
