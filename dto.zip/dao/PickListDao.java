
package com.gehc.wire.common.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * @author 703092428
 * @FileName PickListDao.java
 * @CreateDate Nov 26, 2012
 */
public interface PickListDao {
	
	

	//public ArrayList getListValues(Connection conn,String listType, String filter1,String filter2,String filter3,String filter4,String loggedSSO) throws Exception;
	public Map<String, String> getListValues(Connection conn,String listType, String filter1,String filter2,String filter3,String filter4,String filter5,String loggedSSO) throws Exception;

	public Map<String, String> getStaticListValues(String listType ) throws Exception;
	
	public ArrayList getRegionListValues(Connection conn,String listType ) throws Exception;

	public ArrayList getModalityListValues(Connection conn) throws Exception;
	
	public ArrayList getQtrListValues(Connection conn,String listType ) throws Exception;

	
	
	
}
