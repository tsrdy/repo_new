package com.gehc.wire.common.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.dto.KeyValueDto;
import com.gehc.wire.common.dto.TableDto;
import com.gehc.wire.common.service.DBService;



/**
 * @author 703092428
 * @FileName PickListDaoImpl.java
 * @CreateDate Nov 26, 2012
 */
public class PickListDaoImpl implements PickListDao {

	public Map<String, String> getListValues(Connection conn, String listType, String filter1,String filter2,String filter3,String filter4,String filter5,String loggedSSO) throws Exception {
		
		Map<String,String> hmPickList = new LinkedHashMap<String,String>();
		PreparedStatement pstmt = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		StringBuffer sbQuery = new StringBuffer(); 
		boolean validFlag = false; 
		if(filter1!=null && !filter1.equalsIgnoreCase("") && !filter1.equalsIgnoreCase("0") && !filter1.equalsIgnoreCase("--select--")&& filter1.length()>0){
			filter1 = "'"+filter1+"'";
		}else{
			filter1 = null;
		}
		if(filter2!=null && !filter2.equalsIgnoreCase("") && !filter2.equalsIgnoreCase("0") && !filter2.equalsIgnoreCase("--select--")&& filter2.length()>0){
			filter2 = "'"+filter2+"'";
		}else{
			filter2 = null;
		}
		if(filter3!=null && !filter3.equalsIgnoreCase("") && !filter3.equalsIgnoreCase("0") && !filter3.equalsIgnoreCase("--select--")&& filter3.length()>0){
			filter3 = "'"+filter3+"'";
		}else{
			filter3 = null;
		}
		if(filter4!=null && !filter4.equalsIgnoreCase("") && !filter4.equalsIgnoreCase("0") && !filter4.equalsIgnoreCase("--select--")&& filter4.length()>0){
			filter4 = "'"+filter4+"'";
		}else{
			filter4 = null;
		}
		//filter1 = filter1==null?filter1:(filter1.equalsIgnoreCase("")||filter1.equalsIgnoreCase("0"))?null:"'"+filter1+"'";
		//filter2 = filter2==null?filter2:(filter2.equalsIgnoreCase("")||filter2.equalsIgnoreCase("0"))?null:"'"+filter2+"'";
		//filter3 = filter3==null?filter3:(filter3.equalsIgnoreCase("")||filter3.equalsIgnoreCase("0"))?null:"'"+filter3+"'";
		//filter4 = filter4==null?filter4:(filter4.equalsIgnoreCase("")||filter4.equalsIgnoreCase("0"))?null:"'"+filter4+"'";
		System.out.println("filter1::"+filter1);
		System.out.println("filter2::"+filter2);
		System.out.println("filter3::"+filter3);
		System.out.println("filter4::"+filter4);
		
		
		if (listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_YEAR)){
			sbQuery.append("{call [MPR_213_Fetch_Years]()}");
		}else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_QUARTER))
		{
		sbQuery.append("{call [MPR_001_DD_Quarters]("+filter1+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SERVICE_REGION))
		{
			sbQuery.append("{call MPR_204_Proc_Fetch_Region("+loggedSSO+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_REGION))
		{
			sbQuery.append("{call MPR_204_Proc_Fetch_Region("+loggedSSO+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_GROUP))
		{
			sbQuery.append("{call [MPR_207_Proc_Fetch_Group]()}");
		}else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_SUBREGION))
		{
			sbQuery.append("{call [MPR_205_Proc_Fetch_Sub_Region]("+filter1+","+filter2+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_REGIONS))
		{
			sbQuery.append("{call [MPR_204_Proc_Fetch_Region]("+loggedSSO+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_SUBREGION))
		{
			sbQuery.append("{call [MPR_205_Proc_Fetch_Sub_Region]("+filter1+","+filter2+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_COUNTRY))
		{
			sbQuery.append("{call [MPR_206_Proc_Fetch_Country]("+filter1+","+filter2+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_STATE))
		{
			sbQuery.append("{call [MPR_216_Proc_Fetch_State]("+filter2+","+filter3+","+filter1+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SUB_REGION))
		{
			sbQuery.append("{call [MPR_205_Proc_Fetch_Sub_Region]("+filter1+","+filter2+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_FOREXEXCHANGE))
		{
			sbQuery.append("{call [MPR_215_Proc_Fetch_Currency]()}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SUB_REGION_PRE_ADJUSTMENTS))
		{
			sbQuery.append("{call [MPR_205_Proc_Fetch_Sub_Region]("+filter1+","+filter2+")}");
		}
		
		
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_GROUP))
		{
			sbQuery.append("{call [MPR_207_Proc_Fetch_Group]()}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_MODALITY1))
		{
			sbQuery.append("{call [MPR_208_Proc_Fetch_Modality]("+filter1+","+loggedSSO+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_MODALITY2))
		{
			sbQuery.append("{call [MPR_209_Proc_Fetch_Modality_2]("+filter1+","+filter2+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_SUBMODALITY))
		{
			sbQuery.append("{call [MPR_210_Proc_Fetch_Sub_Modality]("+filter1+","+filter2+","+filter3+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_SEGMENT))
		{
			sbQuery.append("{call [MPR_211_Proc_Fetch_Segment]("+filter1+","+filter2+","+filter3+","+filter4+")}");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_PRODUCT))
		{
			sbQuery.append("{call [MPR_212_Proc_Fetch_Product]("+filter1+","+filter2+","+filter3+","+filter4+","+filter5+")}");
		}else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_ASSIGNED_TO))
		{
			sbQuery.append("{call [MPR_283_Proc_Fetch_Users_Under_Admin]("+loggedSSO+")}");
		}else if(listType.equalsIgnoreCase(MPRConstants.PROC_GET_SUB_REGION_DATA))
		{
			sbQuery.append("{call [MPR_205_Proc_Fetch_Sub_Region]("+filter1+")}");
		}
		
		
		System.out.println(sbQuery.toString());
		cstmt = conn.prepareCall(sbQuery.toString());
		rs = cstmt.executeQuery();
		while(rs.next()){
			
           if(!listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_QUARTER)){
        	   hmPickList.put(rs.getString(1), rs.getString(1));
			}else{
				hmPickList.put(rs.getString(2), rs.getString(1));
			}
		}

		
		new DBService().releaseResources(rs, cstmt);

		return hmPickList;
	}
	

	
	public Map<String,String> getStaticListValues( String listType) throws Exception {
		
		
		Map<String,String> hmPickList = new LinkedHashMap<String,String>();
		KeyValueDto oKeyValueDto = null;
		
		
		if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_QUARTER))
		{
			
			hmPickList.put("Q1","Q1");
			hmPickList.put("Q2","Q2");
			hmPickList.put("Q3","Q3");
			hmPickList.put("Q4","Q4");
			
		}
		
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_TYPE)){
			
			hmPickList.put("Estimated","Estimated");
			hmPickList.put("Final","Final");
			
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_COLUMNS)){
					
					hmPickList.put("Region","Region");
					hmPickList.put("Sub Region","Sub Region");
					hmPickList.put("Country","Country");
					hmPickList.put("States","States");
					hmPickList.put("Groups","Groups");
					hmPickList.put("Modality","Modality");
					hmPickList.put("Sub Modality","Sub Modality");
					hmPickList.put("Segments","Segments");
					hmPickList.put("Product","Product");
					
					
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SERVICE_REGION_ONE)){
			hmPickList.put("Europe","Europe");
			hmPickList.put("EAGM","EAGM");
			hmPickList.put("LATAM","LATAM");
			hmPickList.put("US/CAN","US/CAN");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SERVICE_REGION_TWO)){
			
			hmPickList.put("INDIA","INDIA");
			hmPickList.put("APAC","APAC");
			hmPickList.put("China","China");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_YEAR)){
			hmPickList.put("2006","2006");
			hmPickList.put("2007","2007");
			hmPickList.put("2008","2008");
			hmPickList.put("2009","2009");
			hmPickList.put("2010","2010");
			hmPickList.put("2011","2011");
			hmPickList.put("2012","2012");
			hmPickList.put("2013","2013");
		}else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_COUNTRY)){
			hmPickList.put("EAGM","EAGM");
			hmPickList.put("USCAN","USCAN");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_REGIONS)){
			hmPickList.put("EAGM","EAGM");
			hmPickList.put("USCAN","USCAN");
		}else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SETTINGS_SUBREGION)){
			hmPickList.put("EAGM","EAGM");
			hmPickList.put("USCAN","USCAN");
		}else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_YEAR)){
			hmPickList.put("2013","2013");
		}

		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_QTR)){
			hmPickList.put("Q1","Q1");
			hmPickList.put("Q2","Q2");
			hmPickList.put("Q3","Q3");
			hmPickList.put("Q4","Q4");
			

		}
		
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SUPPORT_STATUS)){
			hmPickList.put("Completed","Completed");
			hmPickList.put("In Progress","In Progress");
			hmPickList.put("Pending","Pending");
			hmPickList.put("Not Applicable","Not Applicable");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SUPPORT_PROBLEMTYPE)){
			hmPickList.put("Issue","Issue");
			hmPickList.put("New Requirement","New Requirement");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SUPPORT_PROBLEMSUBTYPE)){
			hmPickList.put("Functional","Functional");
			hmPickList.put("Data Integrity","Data Integrity");
			hmPickList.put("User Exception","User Exception");
			hmPickList.put("Show Stopper","Show Stopper");
		}
		else if(listType.equalsIgnoreCase(MPRConstants.APP_PICKLIST_SUPPORT_PROBLEMPRIORITY)){
			hmPickList.put("Low","Low");
			hmPickList.put("Medium","Medium");
			hmPickList.put("Urgent","Urgent");
		}
	return hmPickList;
	}

	

	/* (non-Javadoc)
	 * @see com.ge.everest.common.dao.PickListDao#getFeData(java.lang.String)
	 */
	public ArrayList getRegionListValues(Connection conn,String sQuery) throws Exception {
		/*DBUtility oDBUtility = new DBUtility();
		Connection conn = null;
		conn = oDBUtility.getDBConnection();*/
		CallableStatement cstmt = conn.prepareCall("{ call Bridge_Proc_101_Regions_List(?)}");
		cstmt.setString(1, sQuery);
		ResultSet rs = cstmt.executeQuery();
		ArrayList alRegionList =  new ArrayList();
		KeyValueDto oKeyValueDto = null;
		if(rs!=null){
			while(rs.next()){
				
				TableDto oTableDto = new TableDto();
				
				oTableDto.setColumn1(rs.getString(1)); 
				oTableDto.setColumn2(rs.getString(2)); 
				
				alRegionList.add(oTableDto);
			}
		}
		return alRegionList;
	}
	public ArrayList getQtrListValues(Connection conn,String sQuery) throws Exception {
		/*DBUtility oDBUtility = new DBUtility();
		Connection conn = null;
		conn = oDBUtility.getDBConnection();*/
		/*CallableStatement cstmt = conn.prepareCall("{ call Bridge_Proc_101_Regions_List(?)}");
		cstmt.setString(1, sQuery);
		ResultSet rs = cstmt.executeQuery();*/
		ArrayList alqtrList =  new ArrayList();
		KeyValueDto oKeyValueDto = null;
		/*if(rs!=null){
			while(rs.next()){*/
				
				TableDto oTableDto = new TableDto();
				
				oTableDto.setColumn1("Q1"); 
				oTableDto.setColumn2("Q2");
				oTableDto.setColumn3("Q3"); 
				oTableDto.setColumn4("Q4"); 
				
				alqtrList.add(oTableDto);
		/*	}
		}*/
		return alqtrList;
	}
	//getQtrListValues
	public ArrayList getModalityListValues(Connection conn) throws Exception {
		
		CallableStatement cstmt = conn.prepareCall("{ call Bridge_Proc_105_DRP_Modality}");
		
		ResultSet rs = cstmt.executeQuery();
		ArrayList alModalityList =  new ArrayList();
		KeyValueDto oKeyValueDto = null;
		if(rs!=null){
			while(rs.next()){
				
				TableDto oTableDto = new TableDto();
				
				
					oTableDto.setColumn1(rs.getString(1)); 
					oTableDto.setColumn2(rs.getString(2)); 
				
				
				alModalityList.add(oTableDto);
			}
		}
	
		return alModalityList;
	}



	
}
