var appBo = angular.module('appBo', [ 'ngRoute' ]);

appBo.config([ '$routeProvider', '$locationProvider',
		function($routeProvider, $locationProvider) {
			$locationProvider.hashPrefix('!');
			console.log($locationProvider);
			$routeProvider.

			when('/LAPTOPS', {
				templateUrl : 'laptops.html',
				controller : 'myCtrl'
			}).when('/SEDAN', {
				templateUrl : 'sedan.html',
				controller : 'myCtrl'
			}).when('/HATCHBACK', {
				templateUrl : 'hatchback.html',
				controller : 'myCtrl'
			})

			.otherwise({
				redirectTo : '/'
			});
		} ]);

appBo.controller('TreelistController', function($scope, $rootScope) {

	$scope.categories = [ {
		title : "TV",
		children : [ {
			name : "LED",
			href : "#!/LED"
		}, {
			name : "LCD",
			href : "#!/LCD"
		}, {
			name : "CRT",
			href : "#!/CRT"
		} ]
	}, {
		title : "CARS",
		children : [ {
			name : "VAN/MPV",
			href : "#!/VAN/MPV"
		}, {
			name : "HATCHBACK",
			href : "#!/HATCHBACK"
		}, {
			name : "SEDAN",
			href : "#!/SEDAN"
		} ]
	}, {
		title : "MOBILES",
		children : [ {
			name : "ANDROID",
			href : "#!/ANDROID"
		}, {
			name : "IOD",
			href : "#!/IOD"
		}, {
			name : "BASIC",
			href : "#!/BASIC"
		} ]
	}, {
		title : "BIKES",
		children : [ {
			name : "SCOOTER",
			href : "#!/SCOOTER"
		}, {
			name : "BIKE",
			href : "#!/BIKE"
		},

		]
	}, {
		title : "COMPUTERS",
		children : [ {
			name : "LAPTOPS",
			href : "#!/LAPTOPS"
		}, {
			name : "DESKTOPS",
			href : "#!/DESKTOPS"
		},

		]
	}, {
		title : "Others",
		children : [ {
			name : "accessories",
			href : "#!/accessories"
		}, {
			name : "accessoreis2",
			href : "#!/accessoreis2"
		},

		]
	} ]

});