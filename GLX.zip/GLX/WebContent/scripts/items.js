appBo.controller('myCtrl', function($scope, $rootScope) {

	$scope.productlist_visible = true;
	$scope.individ_notebook = {};
	$scope.displayblock = function(notebook) {
		$scope.productlist_visible = false;
		$scope.individ_notebook = notebook;

	}
	$scope.homedisplayblock = function() {
		$scope.productlist_visible = true;
		$scope.individ_notebook = {};
	}
	$scope.notebooks = [ {
		"image" : 'lenovo-yoga-900s.jpg',
		"name" : "Lenovo",
		"procesor" : "Intel i5",
		"age" : 2011,
		"posted_by" : "Sanjeev",
		"email_id" : "sanjeevareddyt@genpact.com",
		"location" : "Bangalore-surya Park",
		"price" : 13000,
		"contact_no" : 9019481918

	}, {
		"image" : 'thoshiba.jpg',
		"name" : "Toshiba",
		"procesor" : "Intel i7",
		"age" : 2010
	}, {
		"image" : 'thoshiba2.jpg',
		"name" : "Toshiba",
		"procesor" : "Intel core 2",
		"age" : 2008
	}, {
		"image" : 'hp.jpg',
		"name" : "HP",
		"procesor" : "Intel core 2",
		"age" : 2012
	}, {
		"image" : 'hp2.jpg',
		"name" : "HP",
		"procesor" : "Intel core 2",
		"age" : 2009
	}, {
		"image" : 'acer.jpg',
		"name" : "Acer",
		"procesor" : "AMD",
		"age" : 2006
	}, {
		"image" : 'acer2.jpg',
		"name" : "Acer",
		"procesor" : "AMD",
		"age" : 2009
	}, {
		"image" : 'lenovo2.jpg',
		"name" : "Lenovo",
		"procesor" : "Intel i5",
		"age" : 2009
	}, {
		"image" : 'thoshiba3.jpg',
		"name" : "Toshiba",
		"procesor" : "Intel i7",
		"age" : 2008
	}, {
		"image" : 'lenovo3.jpg',
		"name" : "Lenovo",
		"procesor" : "Intel i5",
		"age" : 2011
	},

	];
	// scope.orderList = "name";

	$scope.cars_sedan = [ {
		"image" : 'sx4.jpg',
		"make" : "Maruti Suzuki",
		"model" : "SX4",
		"color" : "White",
		"age" : 2011
	}, {
		"image" : 'Mahindrabolero.jpg',
		"make" : "Mahindra",
		"model" : "Bolero",
		"color" : "Cherry",
		"age" : 2005
	}, {
		"image" : 'VolkswagenPolo.jpg',
		"make" : "Volkswagen",
		"model" : "Polo",
		"color" : "Electric Red",
		"age" : 2013
	}, {
		"image" : 'VolkswagenVento.jpg',
		"make" : "Volkswagen",
		"model" : "Vento",
		"color" : "Gold",
		"age" : 2005
	}

	];

	$scope.cars_hatchback = [ {
		"image" : '.jpg',
		"make" : "Hyundai",
		"model" : "Verna",
		"color" : "White",
		"age" : 2011
	}, {
		"image" : '.jpg',
		"make" : "Toyota",
		"model" : "Yaris",
		"color" : "Cherry",
		"age" : 2005
	}, {
		"image" : '.jpg',
		"make" : "Hyundai",
		"model" : "Santa",
		"color" : "Red",
		"age" : 2013
	}, {
		"image" : '.jpg',
		"make" : "Ford",
		"model" : "Fiesta",
		"color" : "Yellow",
		"age" : 2005
	}

	];

});
