
appBo.controller('myCtrl', function($scope, $rootScope,$interval) {

	$scope.productlist_visible = true;
	$scope.individ_notebook = {};
	$scope.path = [];
	$rootScope.favourites=[];
	$scope.logo   = "..images/genpact.jpg";
	var i=0;
	$scope.displayblock = function(notebook) {
		$scope.productlist_visible = false;
		$scope.individ_notebook = notebook;
		$rootScope.favourites.push($scope.individ_notebook);
		$scope.path = notebook.images;
		$scope.individ_notebook_images = "images/"+$scope.path[0];
		$interval( function(){ $scope.callAtInterval(); }, 2000);
		
	}
	$scope.callAtInterval = function() {
		
		$scope.individ_notebook_images = "images/"+$scope.path[i];
		   if(i < $scope.path.length - 1) i++; else i = 0;
    }

    
	$scope.homedisplayblock = function() {
		$scope.productlist_visible = true;
		$scope.individ_notebook = {};
		
	}
	$scope.notebooks = [ {
		"images" : ['lenovo-yoga-900s.jpg','thoshiba.jpg','hp.jpg'],
		"name" : "Lenovo",
		"procesor" : "Intel i5",
		"age" : 2011,
		"posted_by" : "Sanjeev",
		"email_id" : "sanjeevareddyt@genpact.com",
		"location" : "Bangalore-surya Park",
		"price" : 13000,
		"contact_no" : 9019481918

	}, {
		"images" : ['thoshiba.jpg'],
		"name" : "Toshiba",
		"procesor" : "Intel i7",
		"age" : 2010
	}, {
		"images" : ['thoshiba2.jpg'],
		"name" : "Toshiba",
		"procesor" : "Intel core 2",
		"age" : 2008
	}, {
		"images" : ['hp.jpg'],
		"name" : "HP",
		"procesor" : "Intel core 2",
		"age" : 2012
	}, {
		"images" : ['hp2.jpg'],
		"name" : "HP",
		"procesor" : "Intel core 2",
		"age" : 2009
	}, {
		"images" : ['acer.jpg'],
		"name" : "Acer",
		"procesor" : "AMD",
		"age" : 2006
	}, {
		"images" : ['acer2.jpg'],
		"name" : "Acer",
		"procesor" : "AMD",
		"age" : 2009
	}, {
		"images" : ['lenovo2.jpg'],
		"name" : "Lenovo",
		"procesor" : "Intel i5",
		"age" : 2009
	}, {
		"images" : ['thoshiba3.jpg'],
		"name" : "Toshiba",
		"procesor" : "Intel i7",
		"age" : 2008
	}, {
		"images" : ['lenovo3.jpg'],
		"name" : "Lenovo",
		"procesor" : "Intel i5",
		"age" : 2011
	}

	];
	// scope.orderList = "name";
	
	$scope.cars_sedan = [ {
		"image" : 'sx4.jpg',
		"make" : "Maruti Suzuki",
		"model" : "SX4",
		"color" : "White",
		"age" : 2011
	}, {
		"image" : 'Mahindrabolero.jpg',
		"make" : "Mahindra",
		"model" : "Bolero",
		"color" : "Cherry",
		"age" : 2005
	}, {
		"image" : 'VolkswagenPolo.jpg',
		"make" : "Volkswagen",
		"model" : "Polo",
		"color" : "Electric Red",
		"age" : 2013
	}, {
		"image" : 'VolkswagenVento.jpg',
		"make" : "Volkswagen",
		"model" : "Vento",
		"color" : "Gold",
		"age" : 2005
	}

	];

	$scope.cars_hatchback = [ {
		"image" : '.jpg',
		"make" : "Hyundai",
		"model" : "Verna",
		"color" : "White",
		"age" : 2011
	}, {
		"image" : '.jpg',
		"make" : "Toyota",
		"model" : "Yaris",
		"color" : "Cherry",
		"age" : 2005
	}, {
		"image" : '.jpg',
		"make" : "Hyundai",
		"model" : "Santa",
		"color" : "Red",
		"age" : 2013
	}, {
		"image" : '.jpg',
		"make" : "Ford",
		"model" : "Fiesta",
		"color" : "Yellow",
		"age" : 2005
	}

	];

});
