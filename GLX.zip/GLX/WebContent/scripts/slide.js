
var i = 0;
var path = new Array();
 
// LIST OF IMAGES
path[0] = "thoshiba.jpg";
path[1] = "thoshiba2.jpg";
path[2] = "thoshiba3.jpg";

function swapImage()
{
   document.slide.src = path[i];
   if(i < path.length - 1) i++; else i = 0;
   setTimeout("swapImage()",3000);
}
window.onload=swapImage;
