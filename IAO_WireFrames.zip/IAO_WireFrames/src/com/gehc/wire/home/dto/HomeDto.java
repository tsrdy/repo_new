package com.gehc.wire.home.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gehc.wire.common.service.CommonService;


/**
 * 
 */
public class HomeDto {
	

	private String sso = null;
	private String templateType = null;
	private String userName=null;
	private String userAccessComments=null;
	private String email = null;
	private String hRole = null;
	
	private String[] year = null;
	private String[] qtr = null;
	private String[] month = null;
	private String[] fweek = null;
	private String[] business = null;
	private String[] modality = null;
	private String[] subModality = null;
	private String[] segment = null;
	private String[] product = null;
	private String[] serviceRegion = null;
	private String[] subRegion = null;
	private String[] countryZone = null;
	private String[] lct = null;
	private String[] reportType = null;

	private Map hmYear = null;
	private Map hmQtr = null;
	private Map hmMonth = null;
	private Map hmFWeek = null;
	private Map hmBusiness = null;
	private Map hmModality = null;
	private Map hmSegment = null;
	private Map hmSubModality = null;
	private Map hmProduct = null;
	private Map hmServiceRegion = null;
	private Map hmSubRegion = null;
	private Map hmCountryZone = null;
	private Map hmLct = null;
	private Map hmReportType = null;
	private ArrayList alRevenue = new ArrayList();
	private ArrayList alProductivity = new ArrayList();
	private ArrayList alFE = new ArrayList();
	private ArrayList alIB = new ArrayList();
	
	private ArrayList alRemote = new ArrayList();
	private ArrayList alOps = new ArrayList();
	private ArrayList alQuality = new ArrayList();
	private ArrayList alDataOne = new ArrayList();
	private ArrayList alDataTwo = new ArrayList();
	private ArrayList alDataThree = new ArrayList();
	private String hiddenRegion = null;
	private String reportPage = null;
	
	private Map hmRole = null;
	private String hModality2 = null;
	private String hModality1 = null;
	private String hRegion = null;
	private String hSubRegion = null;
	private String hCountry = null;
	private String hState = null;
	
	private ArrayList alServiceRegion = new ArrayList();
	private ArrayList alSubRegion = new ArrayList();
	private ArrayList alCountry = new ArrayList();
	private ArrayList alState = new ArrayList();
	private ArrayList alModality1 = new ArrayList();
	private ArrayList alModality2 = new ArrayList();
	
	private List   alTableData = new ArrayList();
	
	private String userSso = null;
	
	public ArrayList getDataSetMonths() {
		return dataSetMonths;
	}
	public void setDataSetMonths(ArrayList dataSetMonths) {
		this.dataSetMonths = dataSetMonths;
	}
	public ArrayList getDataSetChw() {
		return dataSetChw;
	}
	public void setDataSetChw(ArrayList dataSetChw) {
		this.dataSetChw = dataSetChw;
	}
	public ArrayList getDataSetKcw() {
		return dataSetKcw;
	}
	public void setDataSetKcw(ArrayList dataSetKcw) {
		this.dataSetKcw = dataSetKcw;
	}
	public ArrayList getDataSetNot() {
		return dataSetNot;
	}
	public void setDataSetNot(ArrayList dataSetNot) {
		this.dataSetNot = dataSetNot;
	}
	public ArrayList getDataSetTop() {
		return dataSetTop;
	}
	public void setDataSetTop(ArrayList dataSetTop) {
		this.dataSetTop = dataSetTop;
	}
	public ArrayList getDataSetChwTotal() {
		return dataSetChwTotal;
	}
	public void setDataSetChwTotal(ArrayList dataSetChwTotal) {
		this.dataSetChwTotal = dataSetChwTotal;
	}
	public ArrayList getDataSetKcwTotal() {
		return dataSetKcwTotal;
	}
	public void setDataSetKcwTotal(ArrayList dataSetKcwTotal) {
		this.dataSetKcwTotal = dataSetKcwTotal;
	}
	public ArrayList getDataSetNotTotal() {
		return dataSetNotTotal;
	}
	public void setDataSetNotTotal(ArrayList dataSetNotTotal) {
		this.dataSetNotTotal = dataSetNotTotal;
	}
	public ArrayList getDataSetTopTotal() {
		return dataSetTopTotal;
	}
	public void setDataSetTopTotal(ArrayList dataSetTopTotal) {
		this.dataSetTopTotal = dataSetTopTotal;
	}
	private ArrayList dataSetMonths = new ArrayList();
	private ArrayList dataSetChw = new ArrayList();
	private ArrayList dataSetKcw = new ArrayList();
	private ArrayList dataSetNot = new ArrayList();
	private ArrayList dataSetTop = new ArrayList();
	private ArrayList dataSetChwTotal = new ArrayList();
	private ArrayList dataSetKcwTotal = new ArrayList();
	private ArrayList dataSetNotTotal = new ArrayList();
	private ArrayList dataSetTopTotal = new ArrayList();
	
	
	public String getTemplateType() {
		return templateType;
	}
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
	public String getUserSso() {
		return userSso;
	}
	public void setUserSso(String userSso) {
		this.userSso = userSso;
	}
	public String gethModality2() {
		return hModality2;
	}
	public void sethModality2(String hModality2) {
		this.hModality2 = hModality2;
	}
	public String gethModality1() {
		return hModality1;
	}
	public void sethModality1(String hModality1) {
		this.hModality1 = hModality1;
	}
	public String gethRegion() {
		return hRegion;
	}
	public void sethRegion(String hRegion) {
		this.hRegion = hRegion;
	}
	public String gethSubRegion() {
		return hSubRegion;
	}
	public void sethSubRegion(String hSubRegion) {
		this.hSubRegion = hSubRegion;
	}
	public String gethCountry() {
		return hCountry;
	}
	public void sethCountry(String hCountry) {
		this.hCountry = hCountry;
	}
	public String gethState() {
		return hState;
	}
	public void sethState(String hState) {
		this.hState = hState;
	}
	public ArrayList getAlServiceRegion() {
		return alServiceRegion;
	}
	public void setAlServiceRegion(ArrayList alServiceRegion) {
		this.alServiceRegion = alServiceRegion;
	}
	public ArrayList getAlSubRegion() {
		return alSubRegion;
	}
	public void setAlSubRegion(ArrayList alSubRegion) {
		this.alSubRegion = alSubRegion;
	}
	public ArrayList getAlCountry() {
		return alCountry;
	}
	public void setAlCountry(ArrayList alCountry) {
		this.alCountry = alCountry;
	}
	public ArrayList getAlState() {
		return alState;
	}
	public void setAlState(ArrayList alState) {
		this.alState = alState;
	}
	public ArrayList getAlModality1() {
		return alModality1;
	}
	public void setAlModality1(ArrayList alModality1) {
		this.alModality1 = alModality1;
	}
	public ArrayList getAlModality2() {
		return alModality2;
	}
	public void setAlModality2(ArrayList alModality2) {
		this.alModality2 = alModality2;
	}
	
	public Map getHmRole() {
		return hmRole;
	}
	public void setHmRole(Map hmRole) {
		this.hmRole = hmRole;
	}

	public String gethRole() {
		return hRole;
	}
	public void sethRole(String hRole) {
		this.hRole = hRole;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserAccessComments() {
		return userAccessComments;
	}
	public void setUserAccessComments(String userAccessComments) {
		this.userAccessComments = userAccessComments;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the reportPage
	 */
	public String getReportPage() {
		return reportPage;
	}
	/**
	 * @param reportPage the reportPage to set
	 */
	public void setReportPage(String reportPage) {
		this.reportPage = reportPage;
	}
	/**
	 * @return the hiddenRegion
	 */
	public String getHiddenRegion() {
		return hiddenRegion;
	}
	/**
	 * @param hiddenRegion the hiddenRegion to set
	 */
	public void setHiddenRegion(String hiddenRegion) {
		this.hiddenRegion = hiddenRegion;
	}
	/**
	 * @return the alDataOne
	 */
	public ArrayList getAlDataOne() {
		return alDataOne;
	}
	/**
	 * @param alDataOne the alDataOne to set
	 */
	public void setAlDataOne(ArrayList alDataOne) {
		this.alDataOne = alDataOne;
	}
	/**
	 * @return the alDataTwo
	 */
	public ArrayList getAlDataTwo() {
		return alDataTwo;
	}
	/**
	 * @param alDataTwo the alDataTwo to set
	 */
	public void setAlDataTwo(ArrayList alDataTwo) {
		this.alDataTwo = alDataTwo;
	}
	/**
	 * @return the alDataThree
	 */
	public ArrayList getAlDataThree() {
		return alDataThree;
	}
	/**
	 * @param alDataThree the alDataThree to set
	 */
	public void setAlDataThree(ArrayList alDataThree) {
		this.alDataThree = alDataThree;
	}
	public String[] getReportType() {
		return reportType;
	}
	public void setReportType(String[] reportType) {
		this.reportType = reportType;
	}
	public Map getHmReportType() {
		return hmReportType;
	}
	public void setHmReportType(Map hmReportType) {
		this.hmReportType = hmReportType;
	}
	public String[] getSegment() {
		return segment;
	}
	public void setSegment(String[] segment) {
		this.segment = segment;
	}
	public Map getHmSegment() {
		return hmSegment;
	}
	public void setHmSegment(Map hmSegment) {
		this.hmSegment = hmSegment;
	}
	public ArrayList getAlProductivity() {
		return alProductivity;
	}
	public void setAlProductivity(ArrayList alProductivity) {
		this.alProductivity = alProductivity;
	}
	public ArrayList getAlFE() {
		return alFE;
	}
	public void setAlFE(ArrayList alFE) {
		this.alFE = alFE;
	}
	public ArrayList getAlIB() {
		return alIB;
	}
	public void setAlIB(ArrayList alIB) {
		this.alIB = alIB;
	}
	public ArrayList getAlRemote() {
		return alRemote;
	}
	public void setAlRemote(ArrayList alRemote) {
		this.alRemote = alRemote;
	}
	public ArrayList getAlOps() {
		return alOps;
	}
	public void setAlOps(ArrayList alOps) {
		this.alOps = alOps;
	}
	public ArrayList getAlQuality() {
		return alQuality;
	}
	public void setAlQuality(ArrayList alQuality) {
		this.alQuality = alQuality;
	}
	public ArrayList getAlRevenue() {
		return alRevenue;
	}
	public void setAlRevenue(ArrayList alRevenue) {
		this.alRevenue = alRevenue;
	}
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public String[] getYear() {
		return year;
	}
	public void setYear(String[] year) {
		this.year = year;
	}
	public String[] getQtr() {
		return qtr;
	}
	public void setQtr(String[] qtr) {
		this.qtr = qtr;
	}
	public String[] getMonth() {
		return month;
	}
	public void setMonth(String[] month) {
		this.month = month;
	}
	public String[] getFweek() {
		return fweek;
	}
	public void setFweek(String[] fweek) {
		this.fweek = fweek;
	}
	public String[] getBusiness() {
		return business;
	}
	public void setBusiness(String[] business) {
		this.business = business;
	}
	public String[] getModality() {
		return modality;
	}
	public void setModality(String[] modality) {
		this.modality = modality;
	}
	public String[] getSubModality() {
		return subModality;
	}
	public void setSubModality(String[] subModality) {
		this.subModality = subModality;
	}
	public String[] getProduct() {
		return product;
	}
	public void setProduct(String[] product) {
		this.product = product;
	}
	public String[] getServiceRegion() {
		return serviceRegion;
	}
	public void setServiceRegion(String[] serviceRegion) {
		this.serviceRegion = serviceRegion;
	}
	public String[] getSubRegion() {
		return subRegion;
	}
	public void setSubRegion(String[] subRegion) {
		this.subRegion = subRegion;
	}
	public String[] getCountryZone() {
		return countryZone;
	}
	public void setCountryZone(String[] countryZone) {
		this.countryZone = countryZone;
	}
	public String[] getLct() {
		return lct;
	}
	public void setLct(String[] lct) {
		this.lct = lct;
	}
	public Map getHmYear() {
		return hmYear;
	}
	public void setHmYear(Map hmYear) {
		this.hmYear = hmYear;
	}
	public Map getHmQtr() {
		return hmQtr;
	}
	public void setHmQtr(Map hmQtr) {
		this.hmQtr = hmQtr;
	}
	public Map getHmMonth() {
		return hmMonth;
	}
	public void setHmMonth(Map hmMonth) {
		this.hmMonth = hmMonth;
	}
	public Map getHmFWeek() {
		return hmFWeek;
	}
	public void setHmFWeek(Map hmFWeek) {
		this.hmFWeek = hmFWeek;
	}
	public Map getHmBusiness() {
		return hmBusiness;
	}
	public void setHmBusiness(Map hmBusiness) {
		this.hmBusiness = hmBusiness;
	}
	public Map getHmModality() {
		return hmModality;
	}
	public void setHmModality(Map hmModality) {
		this.hmModality = hmModality;
	}
	public Map getHmSubModality() {
		return hmSubModality;
	}
	public void setHmSubModality(Map hmSubModality) {
		this.hmSubModality = hmSubModality;
	}
	public Map getHmProduct() {
		return hmProduct;
	}
	public void setHmProduct(Map hmProduct) {
		this.hmProduct = hmProduct;
	}
	public Map getHmServiceRegion() {
		return hmServiceRegion;
	}
	public void setHmServiceRegion(Map hmServiceRegion) {
		this.hmServiceRegion = hmServiceRegion;
	}
	public Map getHmSubRegion() {
		return hmSubRegion;
	}
	public void setHmSubRegion(Map hmSubRegion) {
		this.hmSubRegion = hmSubRegion;
	}
	public Map getHmCountryZone() {
		return hmCountryZone;
	}
	public void setHmCountryZone(Map hmCountryZone) {
		this.hmCountryZone = hmCountryZone;
	}
	public Map getHmLct() {
		return hmLct;
	}
	public void setHmLct(Map hmLct) {
		this.hmLct = hmLct;
	}
	public List getAlTableData() {
		return alTableData;
	}
	public void setAlTableData(List alTableData) {
		this.alTableData = alTableData;
	}
	
	
	
	
	
}
