package com.gehc.wire.home.service;


import java.sql.Connection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.gehc.wire.common.dao.AjaxQueries;
import com.gehc.wire.common.exceptions.BusinessDefinedException;
import com.gehc.wire.common.service.BaseService;
import com.gehc.wire.common.service.DBService;
import com.gehc.wire.home.dao.GraphDAO;
import com.gehc.wire.home.dto.GraphDto;


/**
 * @author 703092428
 * @FileName HomeServiceImpl.java
 * @CreateDate Nov 26, 2012
 */
public class GraphServiceImpl extends BaseService  implements GraphService{
	
	
	@Autowired
	private GraphDAO oGraphDao;
	@Autowired
	private DBService dBService;


	public void setoGraphDao(GraphDAO oGraphDao) {
		this.oGraphDao = oGraphDao;
	}


	public void setdBService(DBService dBService) {
		this.dBService = dBService;
	}

	private static final Map<String, String> QUERY_MAP = createMap();

    private static Map<String, String> createMap() {
        Map<String, String> map = new HashMap<String, String>();
        
        map.put("PROC_IAO_WIREFRAME_ALARMDETECTION_NORMALSHUTDOWN", AjaxQueries.PROC_IAO_WIREFRAME_ALARMDETECTION_NORMALSHUTDOWN);
        map.put("PROC_IAO_WIREFRAME_ALARMDETECTION_TRIPCASE1",      AjaxQueries.PROC_IAO_WIREFRAME_ALARMDETECTION_TRIPCASE1);
        map.put("PROC_IAO_WIREFRAME_ALARMDETECTION_TRIPCASE2",      AjaxQueries.PROC_IAO_WIREFRAME_ALARMDETECTION_TRIPCASE2);
        map.put("PROC_IAO_WIREFRAME_ALARMDETECTION_FALIEDSTART",    AjaxQueries.PROC_IAO_WIREFRAME_ALARMDETECTION_FALIEDSTART);
       
		return Collections.unmodifiableMap(map);
    }
	
	@Override
	public GraphDto getTurboDynValues(GraphDto oGraphDto)
			throws Exception {
		Connection conn = null;
		String sTargetObjects = null;
		Map quarter = new HashMap ();  
		  
		
		try{
			conn = dBService.getDBConnection();
 
			oGraphDto=oGraphDao.getTurbDynaValues(conn,oGraphDto);
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return oGraphDto;
	}


	@Override
	public GraphDto getDTFailureDynaValues(GraphDto oGraphDto) throws Exception {
		Connection conn = null;
		String sTargetObjects = null;
		Map quarter = new HashMap ();  
		  
		
		try{
			conn = dBService.getDBConnection();
 
			oGraphDto=oGraphDao.geDTFailureDynaValues(conn,oGraphDto);
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return oGraphDto;
	}


	@Override
	public GraphDto getfailureRateV1DynaValues(GraphDto oGraphDto)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public GraphDto getfailureRateV2DynaValues(GraphDto oGraphDto)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public GraphDto getAlarmDetectionValues(GraphDto oGraphDto, String chartCase)
			throws Exception {
		
			Connection conn = null;
			
			try{
				conn = dBService.getDBConnection();
	            
				String query = SelectQuery(chartCase);
				
				oGraphDto=oGraphDao.getAlarmDetectionValues(conn, oGraphDto, query);
	    		
			}catch (Exception e) {
				e.printStackTrace();
				throw new BusinessDefinedException(e.getMessage());
			}
			finally{
			try{
				dBService.releaseResources(conn);
			}catch (Exception e) {
				throw new BusinessDefinedException(e.getMessage());
			}
		}
			return oGraphDto;
		}


	private static String SelectQuery(String chartCase) {
		
		String queryName = "PROC_IAO_WIREFRAME_ALARMDETECTION_";
		queryName = queryName + chartCase.toUpperCase();
		
		return QUERY_MAP.get(queryName);
	}


	@Override
	public GraphDto getEGTChartData(GraphDto oGraphDto, String chartCase)
			throws Exception {
		Connection conn = null;
		
		try{
			conn = dBService.getDBConnection();
            
			String query = "IAO_600_Rawdata_Temp_1";//SelectQuery(chartCase);
			
			oGraphDto = oGraphDao.getEGTChartData(conn, oGraphDto, query, chartCase);
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return oGraphDto;
	}
	

	@Override

	public GraphDto getEGTChartDataFour(GraphDto oGraphDto, String chartCase)
			throws Exception {
		Connection conn = null;
		
		try{
			conn = dBService.getDBConnection();
            
			String query = "IAO_600_Rawdata_Temp_1";//SelectQuery(chartCase);
			
			oGraphDto = oGraphDao.getEGTChartDataFour(conn, oGraphDto, query, chartCase);
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return oGraphDto;
	}

	@Override

	public GraphDto getEGTChartData3(GraphDto oGraphDto, String chartCase)
			throws Exception {
		Connection conn = null;
		
		try{
			conn = dBService.getDBConnection();
            
			String query = "IAO_600_Rawdata_Temp_1";//SelectQuery(chartCase);
			
			oGraphDto = oGraphDao.getEGTChartData3(conn, oGraphDto, query, chartCase);
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return oGraphDto;
	}
	

	@Override

	public GraphDto getEGTChartDataTwo(GraphDto oGraphDto, String chartCase)
			throws Exception {
		Connection conn = null;
		
		try{
			conn = dBService.getDBConnection();
            
			String query = "IAO_600_Rawdata_Temp_1";//SelectQuery(chartCase);
			
			oGraphDto = oGraphDao.getEGTChartDataTwo(conn, oGraphDto, query, chartCase);
    		
		}catch (Exception e) {
			e.printStackTrace();
			throw new BusinessDefinedException(e.getMessage());
		}
		finally{
		try{
			dBService.releaseResources(conn);
		}catch (Exception e) {
			throw new BusinessDefinedException(e.getMessage());
		}
	}
		return oGraphDto;
	}
	


  	
}
	
	

