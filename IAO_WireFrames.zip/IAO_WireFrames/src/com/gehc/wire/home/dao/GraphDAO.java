package com.gehc.wire.home.dao;

import java.sql.Connection;

import com.gehc.wire.home.dto.GraphDto;
import com.gehc.wire.home.dto.HomeDto;




/**
 * @author 703092428
 * @FileName HomeDAO.java
 * @CreateDate Nov 26, 2012
 */
public interface GraphDAO {

	GraphDto getTurbDynaValues(Connection conn,GraphDto oGraphDto)throws Exception;

	GraphDto geDTFailureDynaValues(Connection conn, GraphDto oGraphDto)throws Exception;

	GraphDto geFailureRateV1DynaValues(Connection conn, GraphDto oGraphDto)throws Exception;

	GraphDto getAlarmDetectionValues(Connection conn, GraphDto oGraphDto, String query) throws Exception;

	GraphDto getEGTChartData(Connection conn, GraphDto oGraphDto, String query, String chartCase) throws Exception;
	
	GraphDto getEGTChartDataTwo(Connection conn, GraphDto oGraphDto, String query, String chartCase) throws Exception;

	GraphDto getEGTChartData3(Connection conn, GraphDto oGraphDto,String query, String chartCase)throws Exception;

	GraphDto getEGTChartDataFour(Connection conn, GraphDto oGraphDto,
			String query, String chartCase) throws Exception;

	

	/*GraphDto geFailureRateV2DynaValues(Connection conn, GraphDto oGraphDto)throws Exception;*/

	
	
	
	
	
}
