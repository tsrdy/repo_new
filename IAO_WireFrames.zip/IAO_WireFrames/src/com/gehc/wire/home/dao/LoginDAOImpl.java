package com.gehc.wire.home.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

import com.gehc.wire.common.dto.UserDto;
import com.gehc.wire.common.dto.UserSessionDto;
import com.gehc.wire.common.exceptions.BusinessDefinedException;
import com.gehc.wire.common.service.DBService;
import com.gehc.wire.home.dto.LoginDto;


/**
 * @author 703092428
 * @FileName LoginDAOImpl.java
 * @CreateDate Nov 26, 2012
 */
public class LoginDAOImpl implements LoginDAO,LoginQueries {
	private static final Logger logger = Logger.getLogger(LoginDAOImpl.class);
	
	public boolean validateUser(Connection conn, LoginDto oLoginDto)
			throws Exception {
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		StringBuffer sbQuery = new StringBuffer();
		boolean  isValidUser = false;
		
		sbQuery.append(PROC_VALIDATE_USERID);
	
		
		
		cstmt = conn.prepareCall(sbQuery.toString());
		cstmt.setString(1, oLoginDto.getSsoId());
		
		rs = cstmt.executeQuery();
		
		if(rs!=null && rs.next()){
			
			    if(rs.getString(2).equals(oLoginDto.getPassword())){
				            isValidUser = true;
			    }
			    else{
			     	throw new BusinessDefinedException("Incorrect password");
			    }
		}
		else{
			throw new BusinessDefinedException("Incorrect username");
		}
		
		
		new DBService().releaseResources(rs, cstmt);
		return isValidUser;
	}

	public UserDto getUserDetails(Connection conn, LoginDto oLoginDto)
			throws Exception {
		UserDto oUserDto = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
		StringBuffer sbQuery = new StringBuffer(); 

		sbQuery.append(PROC_GET_USER_INFO);
		logger.error("Get User Details");
		logger.error("IN ::"+sbQuery.toString());
		logger.error("1"+oLoginDto.getSsoId());
		
		cstmt = conn.prepareCall(sbQuery.toString());
		cstmt.setString(1, oLoginDto.getSsoId());
		rs = cstmt.executeQuery();
		if(rs!=null){
			while(rs.next()){
				oUserDto = new UserDto();
				oUserDto.setSSO(Integer.toString(rs.getInt(1)));
				oUserDto.setFullName(rs.getString(2));
				oUserDto.setEmail(rs.getString(3));
			}
		}
		
		new DBService().releaseResources(rs,cstmt);
		return oUserDto;
	}

	public void setUserSession(Connection conn, UserSessionDto oUserSessionDto)
			throws Exception {
		CallableStatement cstmt = null;
		ResultSet rs = null;
		StringBuffer sbQuery = new StringBuffer(); 
		//sbQuery.append(QRY_SESSION_PROC_USER_UTILIZATION);
		
		logger.error("Setting User Info to Session");
		logger.error("IN ::"+sbQuery.toString());
		logger.error("1"+oUserSessionDto.getSso());
		logger.error("2"+oUserSessionDto.getHost());
		logger.error("3"+oUserSessionDto.getSessionid());
		logger.error("4"+oUserSessionDto.getServerHost());
		
		cstmt = conn.prepareCall(sbQuery.toString());
		cstmt.setString(1, oUserSessionDto.getSso());
		cstmt.setString(2, oUserSessionDto.getHost());
		cstmt.setString(3, oUserSessionDto.getSessionid());
		cstmt.setString(4, oUserSessionDto.getServerHost());
		cstmt.executeUpdate();
		new DBService().releaseResources(rs,cstmt);
	}

	public void updateUserSession(Connection conn,
			UserSessionDto oUserSessionDto) throws Exception {
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		StringBuffer sbQuery = new StringBuffer(); 
		
		cstmt = conn.prepareCall(sbQuery.toString());
		cstmt.setString(1, oUserSessionDto.getSessionid());
		
		cstmt.executeUpdate();
		new DBService().releaseResources(rs,cstmt);
		
	}
	
	

}
