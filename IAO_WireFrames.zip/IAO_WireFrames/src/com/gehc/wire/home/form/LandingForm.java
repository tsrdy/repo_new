package com.gehc.wire.home.form;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



public class LandingForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4018152042366357341L;
	
	private String year = null;	
	private String type = null;	
	private String colNumber = null;	
	
	
	/**
	 * @return the colNumber
	 */
	public String getColNumber() {
		return colNumber;
	}

	/**
	 * @param colNumber the colNumber to set
	 */
	public void setColNumber(String colNumber) {
		this.colNumber = colNumber;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	private String quarter = null;	
	private String region = null;;
	
	private String salesRep = null;;
	
	private String modality = null;;
	
	private String zone = null;;
	
	private String fe = null;
	private String invoke = null;
	//private String state=null;
	private String sPageNo;
	private int iRecordPerPage;
	
	private ArrayList alNotificationContractNo;
	private ArrayList alNotificationTasks;
	private ArrayList alNotificationReminderDt;
	
	/**
	 * @return the invoke
	 */
	public String getInvoke() {
		return invoke;
	}

	/**
	 * @param invoke the invoke to set
	 */
	public void setInvoke(String invoke) {
		this.invoke = invoke;
	}

	
	/**
	 * @return the sPageNo
	 */
	public String getsPageNo() {
		return sPageNo == null ? "1" : sPageNo;
	}

	/**
	 * @param sPageNo the sPageNo to set
	 */
	public void setsPageNo(String sPageNo) {
		this.sPageNo = sPageNo;
	}

	/**
	 * @return the iRecordPerPage
	 */
	public int getiRecordPerPage() {
		return iRecordPerPage == 0 ? 15 :iRecordPerPage;
	}

	/**
	 * @param iRecordPerPage the iRecordPerPage to set
	 */
	public void setiRecordPerPage(int iRecordPerPage) {
		this.iRecordPerPage = iRecordPerPage;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	private Map yearList = new HashMap (); 
	private Map quarterList = new HashMap ();  
	private Map regionList = new HashMap ();  
	private Map salesRepList = new HashMap ();  
	private Map modalityList = new HashMap ();  
	private Map zoneList = new HashMap ();  
	private Map feList = new HashMap ();  
	
	private Map salesRepsList = new HashMap ();  
	
	private String sortCol;
	private String sortBy;
	
	
	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * @return the quarter
	 */
	public String getQuarter() {
		return quarter;
	}

	/**
	 * @param quarter the quarter to set
	 */
	public void setQuarter(String quarter) {
		this.quarter = quarter;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the salesRep
	 */
	public String getSalesRep() {
		return salesRep;
	}

	/**
	 * @param salesRep the salesRep to set
	 */
	public void setSalesRep(String salesRep) {
		this.salesRep = salesRep;
	}

	/**
	 * @return the modality
	 */
	public String getModality() {
		return modality;
	}

	/**
	 * @param modality the modality to set
	 */
	public void setModality(String modality) {
		this.modality = modality;
	}

	/**
	 * @return the zone
	 */
	public String getZone() {
		return zone;
	}

	/**
	 * @param zone the zone to set
	 */
	public void setZone(String zone) {
		this.zone = zone;
	}

	/**
	 * @return the fe
	 */
	public String getFe() {
		return fe;
	}

	/**
	 * @param fe the fe to set
	 */
	public void setFe(String fe) {
		this.fe = fe;
	}

	

	/**
	 * @return the sortCol
	 */
	public String getSortCol() {
		return sortCol;
	}

	/**
	 * @param sortCol the sortCol to set
	 */
	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}

	/**
	 * @return the sortBy
	 */
	public String getSortBy() {
		return sortBy;
	}

	/**
	 * @param sortBy the sortBy to set
	 */
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	/**
	 * @return the alNotificationContractNo
	 */
	public ArrayList getAlNotificationContractNo() {
		return alNotificationContractNo;
	}

	/**
	 * @param alNotificationContractNo the alNotificationContractNo to set
	 */
	public void setAlNotificationContractNo(ArrayList alNotificationContractNo) {
		this.alNotificationContractNo = alNotificationContractNo;
	}

	/**
	 * @return the alNotificationTasks
	 */
	public ArrayList getAlNotificationTasks() {
		return alNotificationTasks;
	}

	/**
	 * @param alNotificationTasks the alNotificationTasks to set
	 */
	public void setAlNotificationTasks(ArrayList alNotificationTasks) {
		this.alNotificationTasks = alNotificationTasks;
	}

	/**
	 * @return the alNotificationReminderDt
	 */
	public ArrayList getAlNotificationReminderDt() {
		return alNotificationReminderDt;
	}

	/**
	 * @param alNotificationReminderDt the alNotificationReminderDt to set
	 */
	public void setAlNotificationReminderDt(ArrayList alNotificationReminderDt) {
		this.alNotificationReminderDt = alNotificationReminderDt;
	}

	/**
	 * @return the yearList
	 */
	public Map getYearList() {
		return yearList;
	}

	/**
	 * @param yearList the yearList to set
	 */
	public void setYearList(Map yearList) {
		this.yearList = yearList;
	}

	/**
	 * @return the quarterList
	 */
	public Map getQuarterList() {
		return quarterList;
	}

	/**
	 * @param quarterList the quarterList to set
	 */
	public void setQuarterList(Map quarterList) {
		this.quarterList = quarterList;
	}

	/**
	 * @return the regionList
	 */
	public Map getRegionList() {
		return regionList;
	}

	/**
	 * @param regionList the regionList to set
	 */
	public void setRegionList(Map regionList) {
		this.regionList = regionList;
	}

	/**
	 * @return the salesRepList
	 */
	public Map getSalesRepList() {
		return salesRepList;
	}

	/**
	 * @param salesRepList the salesRepList to set
	 */
	public void setSalesRepList(Map salesRepList) {
		this.salesRepList = salesRepList;
	}

	/**
	 * @return the modalityList
	 */
	public Map getModalityList() {
		return modalityList;
	}

	/**
	 * @param modalityList the modalityList to set
	 */
	public void setModalityList(Map modalityList) {
		this.modalityList = modalityList;
	}

	/**
	 * @return the zoneList
	 */
	public Map getZoneList() {
		return zoneList;
	}

	/**
	 * @param zoneList the zoneList to set
	 */
	public void setZoneList(Map zoneList) {
		this.zoneList = zoneList;
	}

	/**
	 * @return the feList
	 */
	public Map getFeList() {
		return feList;
	}

	/**
	 * @param feList the feList to set
	 */
	public void setFeList(Map feList) {
		this.feList = feList;
	}

	/**
	 * @return the salesRepsList
	 */
	public Map getSalesRepsList() {
		return salesRepsList;
	}

	/**
	 * @param salesRepsList the salesRepsList to set
	 */
	public void setSalesRepsList(Map salesRepsList) {
		this.salesRepsList = salesRepsList;
	}

	
	
	
	
	
}
