package com.gehc.wire.common.dto;
import java.io.Serializable;

import com.gehc.wire.common.service.CommonService;


/**
 * @author 703092428
 * @FileName UserDto.java
 * @CreateDate Nov 26, 2012
 */
public class UserDto implements Serializable{
	
	private String SSO				= null;
	private String empName 			= null;
	private String lastName			= null;
	private String firstName 		= null;
	private String fullName 		= null;
	
	private String Zone 			= null;
	private String role 			= null;
	private String statusId 		= null;

	private String lct 				= null;
	private String segment 			= null;
	private String password 		= null;
	private String type 			= null;
	private String lastLogin 		= null;
	private String email 			= null;
	private String status 			= null;
	private String comments 		= null;
	private String modality 		= null;
	private String logicalDelete 	= null;
	private String createdBy 		= null;
	private String createdDate 		= null;
	private String modifedBy 		= null;
	private String modifingDate 	= null;
	private String currPassword = null;
	private String newPassword = null;
	private String confirmNewPassword = null;
	private String segmentSSO = null;
	
	private String dataType = "Order";
	
	
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getLogicalDelete() {
		return logicalDelete;
	}
	public void setLogicalDelete(String logicalDelete) {
		this.logicalDelete = logicalDelete;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifedBy() {
		return modifedBy;
	}
	public void setModifedBy(String modifedBy) {
		this.modifedBy = modifedBy;
	}
	public String getModifingDate() {
		return modifingDate;
	}
	public void setModifingDate(String modifingDate) {
		this.modifingDate = modifingDate;
	}
	public String getSSO() {
		return SSO;
	}
	public void setSSO(String sSO) {
		SSO = sSO;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getZone() {
		return Zone;
	}
	public void setZone(String zone) {
		Zone = zone;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatusId() {
		return statusId;
	}
	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}
	public String getLct() {
		return lct;
	}
	public void setLct(String lct) {
		this.lct = lct;
	}
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public String getModality() {
		return modality;
	}
	public void setModality(String modality) {
		this.modality = modality;
	}
	public String getCurrPassword() {
		return CommonService.replaceEmptyWithNull(currPassword);
	}
	public void setCurrPassword(String currPassword) {
		this.currPassword = currPassword;
	}
	public String getNewPassword() {
		return CommonService.replaceEmptyWithNull(newPassword);
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getConfirmNewPassword() {
		return CommonService.replaceEmptyWithNull(confirmNewPassword);
	}
	public void setConfirmNewPassword(String confirmNewPassword) {
		this.confirmNewPassword = confirmNewPassword;
	}
	public String getSegmentSSO() {
		return CommonService.replaceEmptyWithNull(segmentSSO);
	}
	public void setSegmentSSO(String segmentSSO) {
		this.segmentSSO = segmentSSO;
	}
	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}
	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	

	
}
