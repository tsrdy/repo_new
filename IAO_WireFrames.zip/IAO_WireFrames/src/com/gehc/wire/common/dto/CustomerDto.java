package com.gehc.wire.common.dto;
import com.gehc.wire.common.service.CommonService;


/**
 * @author 703092428
 * @FileName CustomerDto.java
 * @CreateDate Nov 26, 2012
 */
public class CustomerDto {
	
	private String customerName		= null;
	private String address 			= null;
	private String city				= null;
	private String state 			= null;
	private String zipCode 			= null;
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return CommonService.replaceEmptyWithNull(customerName);
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return CommonService.replaceEmptyWithNull(address);
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return CommonService.replaceEmptyWithNull(city);
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return CommonService.replaceEmptyWithNull(state);
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return CommonService.replaceEmptyWithNull(zipCode);
	}
	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	

	
}
