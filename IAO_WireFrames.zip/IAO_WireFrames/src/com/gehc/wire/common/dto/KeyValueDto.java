
package com.gehc.wire.common.dto;


/**
 * @author 703092428
 * @FileName KeyValueDto.java
 * @CreateDate Nov 26, 2012
 */
public class KeyValueDto {

	private String key = null;
	private String value = null;
	private String value3 = null;
	
	/**
	 * @return the value3
	 */
	public String getValue3() {
		return value3;
	}
	/**
	 * @param value3 the value3 to set
	 */
	public void setValue3(String value3) {
		this.value3 = value3;
	}
	/**
	
	 * @return the value2
	 */
	public String getValue2() {
		return value2==null?"":value2;
	}
	/**
	 * @param value2 the value2 to set
	 */
	public void setValue2(String value2) {
		this.value2 = value2;
	}
	private String value2 = null;
	/**
	 * @return the key
	 */
	public String getKey() {
		return key==null?"":key;
	}
	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value==null?"":value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
