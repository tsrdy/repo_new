package com.gehc.wire.common.dto;


/**
 * @author 703092428
 * @FileName UserSessionDto.java
 * @CreateDate Nov 26, 2012
 */
public class UserSessionDto {
	private String id	= null;
	private String sso	= null;
	private String host	= null;
	private String serverHost	= null;
	public String getServerHost() {
		return serverHost;
	}
	public void setServerHost(String serverHost) {
		this.serverHost = serverHost;
	}
	private String sessionid	= null;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getSessionid() {
		return sessionid;
	}
	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}
	
	
	
}
