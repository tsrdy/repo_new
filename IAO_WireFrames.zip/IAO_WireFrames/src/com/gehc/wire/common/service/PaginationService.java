package com.gehc.wire.common.service;

public class PaginationService {

	public static String Pagination(int numOfRec, int recPerPage, int currPage, String url) {
		StringBuffer ressurl = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('IB');").append("\">First</a></u></b>\n");
    	   // Link to previous page
    	   if (currPage > 1) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"previousPage('IB');").append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"nextPage('IB');").append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"lastPage('IB');").append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pageNo\" name=\"pageNo\" style=\"font-size:9px\" onchange=\"pagination()\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   ressurl.append("<script type\"=text/javascript\">\n");
    	   ressurl.append("function pagination() {\n");
    	   ressurl.append("constructIBPaginationData();");
    	   //ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");
    	  }
    	  return ressurl.toString();
    	 }
	
	
	public static String JapanPagination(int numOfRec, int recPerPage, int currPage, String url) {
		StringBuffer ressurl = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('JapanIB');").append("\">First</a></u></b>\n");
    	   // Link to previous page
    	   if (currPage > 1) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"previousPage('JapanIB');").append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"nextPage('JapanIB');").append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"lastPage('JapanIB');").append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pageNo\" name=\"pageNo\" style=\"font-size:9px\" onchange=\"pagination()\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   ressurl.append("<script type\"=text/javascript\">\n");
    	   ressurl.append("function pagination() {\n");
    	   ressurl.append("constructJapanIBPaginationData();");
    	   //ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");
    	  }
    	  return ressurl.toString();
    	 }
	
	
	
	public static String OpenDispatchPagination(int numOfRec, int recPerPage, int currPage, String url) {
		StringBuffer ressurl = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('OpenDispatch');").append("\">First</a></u></b>\n");
    	   // Link to previous page
    	   if (currPage > 1) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"previousPage('OpenDispatch');").append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"nextPage('OpenDispatch');").append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"lastPage('OpenDispatch');").append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pageNo\" name=\"pageNo\" style=\"font-size:9px\" onchange=\"pagination()\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   ressurl.append("<script type\"=text/javascript\">\n");
    	   ressurl.append("function pagination() {\n");
    	   ressurl.append("constructOpenDispatchPaginationData();");
    	   //ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");
    	  }
    	  return ressurl.toString();
    	 }
	
	
	public static String CloseDispatchPagination(int numOfRec, int recPerPage, int currPage, String url) {
		StringBuffer ressurl = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('CloseDispatch');").append("\">First</a></u></b>\n");
    	   // Link to previous page
    	   if (currPage > 1) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"previousPage('CloseDispatch');").append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"nextPage('CloseDispatch');").append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"lastPage('CloseDispatch');").append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pageNo\" name=\"pageNo\" style=\"font-size:9px\" onchange=\"pagination()\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   ressurl.append("<script type\"=text/javascript\">\n");
    	   ressurl.append("function pagination() {\n");
    	   ressurl.append("constructCloseDispatchPaginationData();");
    	   //ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");
    	  }
    	  return ressurl.toString();
    	 }
	
	
	public static String MTBFPagination(int numOfRec, int recPerPage, int currPage, String url) {
		StringBuffer ressurl = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('MTBF');").append("\">First</a></u></b>\n");
    	   // Link to previous page
    	   if (currPage > 1) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"previousPage('MTBF');").append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"nextPage('MTBF');").append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"lastPage('MTBF');").append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pageNo\" name=\"pageNo\" style=\"font-size:9px\" onchange=\"pagination()\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   ressurl.append("<script type\"=text/javascript\">\n");
    	   ressurl.append("function pagination() {\n");
    	   ressurl.append("constructMTBFPaginationData();");
    	   //ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");
    	  }
    	  return ressurl.toString();
    	 }


	public static String DispatchesPagination(int numOfRec, int recPerPage, int currPage, String url) {
		StringBuffer ressurl = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('Dispatch');").append("\">First</a></u></b>\n");
    	   // Link to previous page
    	   if (currPage > 1) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"previousPage('Dispatch');").append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"nextPage('Dispatch');").append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"lastPage('Dispatch');").append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pageNo\" name=\"pageNo\" style=\"font-size:9px\" onchange=\"pagination()\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   ressurl.append("<script type\"=text/javascript\">\n");
    	   ressurl.append("function pagination() {\n");
    	   ressurl.append("constructDispatchPaginationData();");
    	   //ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");
    	  }
    	  return ressurl.toString();
    	 }


	public static String CustomerPagination(int numOfRec, int recPerPage, int currPage, String url) {
		StringBuffer ressurl = new StringBuffer();
		String spChar = "?";
		if (url.indexOf(spChar) != -1) 
			spChar = "&";
		if (numOfRec > recPerPage) {
    	   int pages = (int)java.lang.Math.ceil((double)numOfRec / (double)recPerPage);  // Get total number of pages
    	   ressurl.append("<div nowrap>\n");
    	  // ressurl.append("<font face=arial size=-1>");
    	   ressurl.append(" &nbsp;&nbsp;Page: ").append(currPage).append(" / ").append(pages);
    	   // Display link to first page
    	   ressurl.append("&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"firstPage('Customer');").append("\">First</a></u></b>\n");
    	   // Link to previous page
    	   if (currPage > 1) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"previousPage('Customer');").append("\"><<</a></u></b>\n");
    	   }
    	   // Display link to next page
    	   if (currPage < pages) {
    	       ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"nextPage('Customer');").append("\">>></a></u></b>\n");
    	   }
    	   // Link to last page
    	   ressurl.append("|&nbsp;<b><u><a class=\"gen_href\" href=\"").append("#").append("\"").append(" onclick=\"lastPage('Customer');").append("\">Last</a></u></b>\n");
    	   // Drop down navigation 
    	   ressurl.append("&nbsp;&nbsp;Go to&nbsp;<select id=\"pageNo\" name=\"pageNo\" style=\"font-size:9px\" onchange=\"pagination()\">\n");
    	   // If number of pages > 200 
    	   //    display only 20 pagination links in the drop down list
    	   // else
    	   //    display all pagination links in the drop down list
    	   int iBeginPageNo = 1, iEndPageNo = pages;
    	   if (pages >= 200) { 
    	       // Calculate the beginning index
    	       int temp = currPage - 20;    
    	       if (temp <= 0) {
    	           iBeginPageNo = 1;
    	       } else {
    	           iBeginPageNo = temp;
    	       }
    	       // Calculate the ending index
    	       temp = currPage + 20;
    	       if (temp >= pages) {
    	           iEndPageNo = pages;
    	       } else {
    	           iEndPageNo = temp;
    	       }
    	   }
    	   for (int i = iBeginPageNo; i <= iEndPageNo; i++) {
    	       if (i == currPage) {
    	           ressurl.append("<option value=\"").append(i).append("\" selected>").append(i).append("</option>\n");
    	       } else {
    	           ressurl.append("<option value=\"").append(i).append("\">").append(i).append("</option>\n");
    	       }
    	   }
    	   //ressurl.append("</select></font>\n");
    	   ressurl.append("</select>\n");
    	   ressurl.append("["+numOfRec+"]&nbsp;&nbsp;");
    	   ressurl.append("</div>\n");
    	   ressurl.append("<script type\"=text/javascript\">\n");
    	   ressurl.append("function pagination() {\n");
    	   ressurl.append("constructCustomerPaginationData();");
    	   //ressurl.append("location.href='").append(url).append(spChar).append("pageNo=' + document.getElementById('pageNo').value").append(" + '&pagenation=Y&numofrec=").append(numOfRec).append("';\n");
    	   ressurl.append("}\n");
    	   ressurl.append("</script>\n");
    	  }
    	  return ressurl.toString();
    	 }
	
}
