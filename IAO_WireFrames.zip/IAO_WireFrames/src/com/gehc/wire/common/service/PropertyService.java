
package com.gehc.wire.common.service;

import java.io.IOException;
import java.util.ResourceBundle;


/**
 * @author 703092428
 * @FileName PropertyService.java
 * @CreateDate Nov 26, 2012
 */
public class PropertyService {
	public static String getProperty(String sBundleName,String sPropsKey)
	{
		try{
			ResourceBundle bundle = ResourceBundle.getBundle(sBundleName);
			return bundle.getString(sPropsKey); 
		}catch(Exception e){
			e.printStackTrace();
		}finally{

		}

		return null;
	}
}
