package com.gehc.wire.common.exceptions;

/**
 * @author 703092428
 * @FileName BusinessDefinedException.java
 * @CreateDate Nov 26, 2012
 */
public class BusinessDefinedException extends Exception{

	private static final long serialVersionUID = 1L;
	private String Exception;

	/* public BusinessDefinedException(String printStackTrace) {
		 Exception = printStackTrace;
	}*/
	 public String toString(){     
		 
		 return Exception ; 
	} 
	 
	public BusinessDefinedException(String message) {
	        super(message);
	}

}
