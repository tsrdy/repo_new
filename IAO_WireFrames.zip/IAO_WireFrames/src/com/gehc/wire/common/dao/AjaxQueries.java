package com.gehc.wire.common.dao;

import com.gehc.wire.common.constants.MPRConstants;
import com.gehc.wire.common.service.PropertyService;

public interface AjaxQueries {

		public static final String APP_SCHEMA = PropertyService.getProperty(MPRConstants.APP_PRPPERTIES_FILE,MPRConstants.APP_DB_SCHEMA);
		
		public static final String  PROC_IAO_WIREFRAME_TURBINE_MATRICES = "{ call IAO_600_Proc_View_Wind_Power()}";
		
		
		public static final String  PROC_IAO_WIREFRAME_DT_FAILURE = "{call DT_failures_season_maint_PROC()}";
		
		public static final String  PROC_IAO_WIREFRAME_FAILURE_RATE_V1 = "{ call IAO_600_Failure_Rate_V1()}";
		
		public static final String  PROC_IAO_WIREFRAME_FAILURE_RATE_V2 = "{ call IAO_600_Failure_Rate_V2()}";
		
		public static final String  PROC_IAO_WIREFRAME_ALARMDETECTION_NORMALSHUTDOWN = "{call IAO_Chart2_Title_1()}";
		
		public static final String  PROC_IAO_WIREFRAME_ALARMDETECTION_TRIPCASE1 = "{ call IAO_Chart2_Title_2()}";
		
		public static final String  PROC_IAO_WIREFRAME_ALARMDETECTION_TRIPCASE2 = "{ call IAO_Chart2_Title_1()}";
		
		public static final String  PROC_IAO_WIREFRAME_ALARMDETECTION_FALIEDSTART = "{ call IAO_Chart2_Title_2()}";
		
}
