package com.gehc.wire.common.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.gehc.wire.common.dto.TableDto;
import com.gehc.wire.common.form.AjaxForm;
import com.gehc.wire.common.service.CommonService;
import com.gehc.wire.common.service.DBService;

public class AjaxDaoImpl implements AjaxDao,AjaxQueries {
	private static final Logger logger = Logger.getLogger(AjaxDaoImpl.class);
 
	@Override
	public String getTurbDynaValues(Connection conn)
			throws Exception {
		 
		 	CallableStatement cstmt = null;
			ResultSet rs = null;
			TableDto oTableDto = null;
			StringBuffer sbQuery = new StringBuffer();
			sbQuery.append(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
			System.out.println(PROC_IAO_WIREFRAME_TURBINE_MATRICES);
			cstmt = conn.prepareCall(sbQuery.toString());
			 
			 
			rs = cstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					oTableDto=new TableDto();
						oTableDto.setColumn1(rs.getString(1));
						oTableDto.setColumn2(rs.getString(2));
						 
					}
					
				}
			new DBService().releaseResources(rs, cstmt);
			return "";
	}


	 

	 
	
}
