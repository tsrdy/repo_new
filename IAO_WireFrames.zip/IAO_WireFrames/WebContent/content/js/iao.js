function alarmDetection() {
	
    document.forms[0].action ="getAlarmDetectionChart.jpage";
	document.forms[0].submit();
}

function DTFailure() {
	
    document.forms[0].action ="getDTFailureChart.jpage";
	document.forms[0].submit();
}
function failure() {
	
    document.forms[0].action ="failure.jpage";
	document.forms[0].submit();
}
function downTime(){
	
	 document.forms[0].action ="downTime.jpage";
		document.forms[0].submit();
	
}
function TPerformance() {
	document.forms[0].action ="getTurbinePerformanceChart.jpage";
	document.forms[0].submit();
}
function MaintenanceCostAndDT() {

    document.forms[0].action ="MaintenanceCostAndDT.jpage";
	document.forms[0].submit();
}
/*function TPerformance() {
	
    document.forms[0].action ="getTurbinePerformanceChart.jpage";
	document.forms[0].submit();
}*/

function dtFailureClassesAndWeather() {
	
    document.forms[0].action ="getDTFailureClassesAndWeather.jpage";
	document.forms[0].submit();
}

function plannedMaintanceQuadrant() {
    document.forms[0].action ="getPMQuadrantChart.jpage";
	document.forms[0].submit();

}
function FailureByPartLife() {
	document.forms[0].action ="failureByPartLife.jpage";
	document.forms[0].submit();
}
function Failurev1() {
    document.forms[0].action ="getFailurev1.jpage";
	document.forms[0].submit();
}

function Failurev2() {
    document.forms[0].action ="getFailurev2.jpage";
	document.forms[0].submit();

}
function failureRateAndDowntime() {
	
    document.forms[0].action ="getFailureRateAndDowntime.jpage";
	document.forms[0].submit();
}

function TurbineChart() {
	
    document.forms[0].action ="getTurbineChart.jpage";
	document.forms[0].submit();
}

function TurbineReliabilityDrillToPi() {
	
    document.forms[0].action ="getTurbineReliabilityDrillToPi.jpage";
	document.forms[0].submit();
}
function weiBull() {
	
    document.forms[0].action ="getWeiBull.jpage";
	document.forms[0].submit();
}
function TurbineWiseList() {
	
    document.forms[0].action ="getTurbineWiseList.jpage";
	document.forms[0].submit();

}
function failureandMaintenacecost() {
    document.forms[0].action ="failureAndMaintenanceCost.jpage";
    document.forms[0].submit();
}
function MaintenanceCostAndDT() {
    document.forms[0].action ="MaintenanceCostAndDT.jpage";
    document.forms[0].submit();

}
function filter() {
    document.forms[0].action ="getFilterPage.jpage";
    document.forms[0].submit();

}


function about() {
    document.forms[0].action ="home.jpage";
    document.forms[0].submit();

}

function siteComparision() {

    document.forms[0].action ="siteComparision.jpage";
	document.forms[0].submit();
}



function DecisionTree() {
	
	
    document.forms[0].action ="getDecisionTree.jpage";
	document.forms[0].submit();
}
 
function criticalForecast(){
	document.forms[0].action ="criticalForecast.jpage";
	document.forms[0].submit();
}
function EGTGreen() {
	
    document.forms[0].action ="getEGTChart.jpage";
	document.forms[0].submit();
}

