package com.echidna.eiq.mlo.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.echidna.eiq.mlo.dto.LoginResultJson;

public class LoginResultJsonRowMapper implements RowMapper<LoginResultJson>
	{
		public  LoginResultJson mapRow(ResultSet rs, int rowNum) throws SQLException {
			LoginResultJson customer = new LoginResultJson();
			customer.setUserName(rs.getString("user_name"));
			customer.setCount(rs.getInt("count"));
			return customer;
		}

	}