package com.echidna.eiq.mlo.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.echidna.eiq.mlo.dao.UserDAO;
import com.echidna.eiq.mlo.dto.LoginRequestJson;
import com.echidna.eiq.mlo.dto.LoginResultJson;
import com.echidna.eiq.mlo.dto.User;
import com.echidna.eiq.mlo.dto.UserRolesData;
import com.echidna.eiq.mlo.util.LoginResultJsonRowMapper;

@CrossOrigin
@RestController
public class UserService {
	/*@Autowired
	private JdbcTemplate jdbcTemplate;*/
	@Autowired
	UserDAO userDao;

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String msg() {
		return "user service Running kkkkkkkk Succesfully";
	}
	
	
	// To retrieve all users info
	@RequestMapping(value = "/getallusers", method=RequestMethod.GET)
	public List<User> getUsersInfo() {
		List<User> listOfUsers = userDao.listOfUsers();
		return listOfUsers;
	}
	
	
	// To retrieve userId and Role
	@RequestMapping(value = "/userroles", method=RequestMethod.GET)
	public List<UserRolesData> getuserroles() {
		List<UserRolesData> listofuserroles =userDao.listOfUserRoles();
		return listofuserroles;
	}
	
	
	// To validate the user login details with db
	@RequestMapping(value = "/usercheck", method = RequestMethod.POST, consumes = "application/json")
	public LoginResultJson getUserformdetails(@RequestBody LoginRequestJson rj) {
		LoginResultJson user = userDao.getUserformdetails(rj.getUserId(), rj.getPassword());
			if (user.getCount() != 0) {
				user.setUserName(user.getUserName());
				user.setResult("Success");
			}else{
				user.setResult("Failure");
			}
		return user;
	}
	
	
}
