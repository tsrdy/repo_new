package com.echidna.eiq.mlo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.echidna.eiq.mlo.dao.UserDAO;
import com.echidna.eiq.mlo.dto.User;
@Controller
public class WelcomeController {
	@Autowired
	UserDAO userDao;
	// inject via application.properties
	@Value("${welcome.message:test}")
	private String message = "Hello World";

	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {
		model.put("message", this.message);
		return "welcome";
	}
	@RequestMapping("/hello")
	public String hello(Map<String, Object> model) {
		model.put("message", this.message);
		return "hello";
	}
	@RequestMapping("/loginPage")
	public String login(Map<String, Object> model) {
		model.put("message", this.message);
		return "login";
	}
	
	@RequestMapping(value="/validateuser" , method = RequestMethod.POST)
	public ModelAndView validateUser(@RequestParam String username,@RequestParam String password) {
		System.out.println("in validateUser");
		ModelAndView model= new ModelAndView();
		boolean isValidUser=false;
		String sql="select user_id,password from userinfo where user_id=? and password=?";
		
		System.out.println("sql query::"+sql);
		List<User> userList=userDao.listOfUserByUserIdANDPassword(username, password);
		System.out.println("user::::"+userList);
		if (userList.size()!=0){
			isValidUser=true;
		}else{
			isValidUser=false;
		}
	
		if(isValidUser){
			model.addObject("title", "Spring Security Custom Login Form");
			model.addObject("message", "This is welcome page!");
			model.setViewName("hello");
		}else{
			model.addObject("title", "Spring Security Custom Login Form");
			model.addObject("message", "invalid user!");
			model.setViewName("failure");
		}
		return model;
		
	}
	
	
}