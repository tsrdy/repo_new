package com.echidna.eiq.mlo.dto;

public class UserRolesData {
	String user_id;
	String User_NAME;
	String role_name;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_NAME() {
		return User_NAME;
	}
	public void setUser_NAME(String user_NAME) {
		User_NAME = user_NAME;
	}
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public UserRolesData(String user_id, String user_NAME, String role_name) {
		super();
		this.user_id = user_id;
		User_NAME = user_NAME;
		this.role_name = role_name;
	}
	public UserRolesData() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
