package com.echidna.eiq.mlo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.echidna.eiq.mlo.dto.LoginRequestJson;
import com.echidna.eiq.mlo.dto.LoginResultJson;
import com.echidna.eiq.mlo.dto.User;
import com.echidna.eiq.mlo.dto.UserRolesData;
import com.echidna.eiq.mlo.util.LoginResultJsonRowMapper;

@Repository
public class UserDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<User> listOfUsers() {
		System.out.println("in UserDAO of listOfUsers");
		List<User> listOfUsers=new ArrayList<User>();
		String sql = "select * from userinfo";
		listOfUsers = jdbcTemplate.query(sql, new RowMapper<User>() {
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new User(rs.getString("user_id"), rs.getString("user_Name"), rs.getString("password"));
			}
		});
		System.out.println("in UserDAO of listOfUsers :: result::"+listOfUsers);
		return listOfUsers;
	}
	public List<UserRolesData> listOfUserRoles() {
		List<UserRolesData> listofuserroles = new ArrayList<UserRolesData>();
		String sql = "select ui.user_id userid,ui.user_NAME username,ur.role_name userrole from userinfo ui,user_roles ur where ui.role_id=ur.role_id";
		listofuserroles = jdbcTemplate.query(sql, new RowMapper<UserRolesData>() {
			public UserRolesData mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new UserRolesData(rs.getString("userid"), rs.getString("username"), rs.getString("userrole"));
			}
		});
		return listofuserroles;

	}
	public List<User> listOfUserByUserIdANDPassword(String user_id,String password) {
		List<User> userlist=jdbcTemplate.query("SELECT * FROM userinfo WHERE user_id = ? AND password = ?",
				new Object[] { user_id, password }, 
				new RowMapper<User>() {
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new User(rs.getString("user_id"), rs.getString("user_Name"), rs.getString("password"));
			}

		});  
		System.out.println("user list::"+userlist);

		return userlist;
	}
	public LoginResultJson getUserformdetails(String userId,String password) {
		String sql="select count(user_id) count,user_name from userinfo where user_id=? and password=?";
		LoginResultJson user = (LoginResultJson)jdbcTemplate.queryForObject(
				sql, new Object[] { userId,password}, new LoginResultJsonRowMapper());
			
		return user;
	}

}
