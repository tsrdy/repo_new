package com.echidna.eiq.mlo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication
public class MloApplication extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(MloApplication.class);
	}

	public static void main( String args[]){

		SpringApplication.run(MloApplication.class, args );
		System.out.println("MLO service  started.aa.. ");
	}
}

