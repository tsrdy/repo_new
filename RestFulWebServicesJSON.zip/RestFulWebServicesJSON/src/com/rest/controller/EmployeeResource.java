
package com.rest.controller;

import java.util.ArrayList;
import java.util.TreeMap;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value="/employee")

public class EmployeeResource {
    private TreeMap<Integer, Employee> employeeList = new TreeMap();

    public EmployeeResource() {
        this.employeeList.put(101, new Employee(101, "Rakesh", "Developer"));
        this.employeeList.put(102, new Employee(102, "Arjun", "Accountant"));
        this.employeeList.put(103, new Employee(103, "Vijayan", "Architect"));
    }
   
    @RequestMapping(value="/", method = RequestMethod.GET,produces={"application/json", "application/xml"}, headers="Accept=application/xml, application/json")
    public @ResponseBody EmployeeList getAllEmployees() {
        ArrayList<Employee> list = new ArrayList<Employee>(this.employeeList.values());
        EmployeeList elist=new EmployeeList(list);
        return elist;
    }

    @RequestMapping(value="/{id}", method = RequestMethod.GET,produces=MediaType.APPLICATION_XML_VALUE)
    
    public @ResponseBody Employee findEmployee(@PathVariable(value="id") int empId) {
        return this.employeeList.get(empId);
    }
   
}