package main.java;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



@Produces(APPLICATION_JSON)
@Consumes(APPLICATION_JSON)
@RestController
public class BookService {
	
    private static final Logger LOG = LoggerFactory.getLogger(BookService.class);
    
    Session session=null;
    private int id=0;
    public BookService() {
    	File f = new File("D:\\SpringBootV\\src\\hibernate.cfg.xml");
    	
    	Configuration configuration=new Configuration().configure(f);
    	
    	SessionFactory factory=configuration.buildSessionFactory();
		 session=factory.openSession();    	
		
       }
    
    @RequestMapping("/book")
    public String getService() {
        return "Welcome to Micro Services";
    }
    
     
    @RequestMapping(value="/getBookList", method = RequestMethod.GET,produces={"application/json", "application/xml"}, headers="Accept=application/xml, application/json")
    public @ResponseBody BookList getAllBooks() {
    				
		Query query = session.createQuery("FROM  Book");
		
		List<Book> list=query.list();
		id=list.size();
		ArrayList<Book> alist = new ArrayList<Book>();
		for(Book array:list){
			Book b=new Book();
			
			b.setId(array.getId());
			b.setName(array.getName());
			b.setAuthor(array.getAuthor());
			b.setPrice(array.getPrice());
			
			alist.add(b);
			
		}
		        
        BookList elist=new BookList(alist);
        return elist;
    }

    @RequestMapping(value="/getBook/{id}", method = RequestMethod.GET,produces={"application/json", "application/xml"}, headers="Accept=application/xml, application/json")
    
    public @ResponseBody Book findBook(@PathVariable(value="id") int empId) {
    	
    	
			
		Query query = session.createQuery("FROM  Book");
		
		List<Book> list=query.list();
		Book b=new Book();
		for(Book array:list){
			if(array.getId()==empId)
			{
			
			
			b.setId(array.getId());
			b.setName(array.getName());
			b.setAuthor(array.getAuthor());
			b.setPrice(array.getPrice());
			
			}
		}
		
        return b;
    }

    @RequestMapping(value="/addBook", method = RequestMethod.POST,consumes={"application/json", "application/xml"}, produces={"text/plain"})
    public @ResponseBody String addBook(@RequestBody Book b) {
    	
    	Book book=new Book(b.getId(), b.getName(), b.getAuthor(),b.getPrice());
		
		Transaction tx=session.beginTransaction();
		session.save(book);		
		tx.commit();		
	
        return "Book with Id " + (id+1) + " successfully  added";
    }
   
    
}
