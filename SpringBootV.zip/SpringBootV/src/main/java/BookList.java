package main.java;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)

@XmlRootElement(name = "BookList")
public class BookList {
	private List<Book> book;

	public List<Book> getBook() {
		return book;
	}

	public void setBook(List<Book> book) {
		this.book = book;
	}

	public BookList(List<Book> book) {
		super();
		this.book = book;
	}

	public BookList() {
		super();
		// TODO Auto-generated constructor stub
	}
}
